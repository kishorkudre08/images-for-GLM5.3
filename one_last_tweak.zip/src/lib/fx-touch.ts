/* t149 — JS touch-scroll driver (the guaranteed path inside the rotated stage).
   Native panning of these inner scrollers is dead on the user's phone for every
   touch-action we tried (pan-y t144, auto t148) — Chrome claims the gesture and
   dead-ends it — while the same phone scrolls the dashboard shell fine. So the
   boxes the user actually scrolls on mobile carry this driver:

   • touches are tracked on the element; the scroll follows the finger 1:1 after
     a ~5px engage (taps stay taps; a click that follows a real drag is
     suppressed once so a swipe never "taps" a dish or a button);
   • release starts a fling with native-grade physics: velocity = the average
     over the last ~120ms (a finger that slows before lifting still carries
     momentum — the t145 "stuck" feel came from sampling only the final two
     points), then decays ~0.998 per ms (iOS-like glide) and stops hard at the
     edges;
   • touch-action is synced from the element's real overflow (mount, resize and
     a 500ms poll): "none" while it can scroll so the browser never fights the
     driver, "" when it can't so touches fall through natively (short filtered
     menus, non-stage touch devices like iPads).

   The dashboard shell is NOT bound — its native scrolling demonstrably works. */

export function bindFxTouchScroll(el: HTMLElement): () => void {
  let active = false;
  let startY = 0;
  let startTop = 0;
  let moved = 0;
  let samples: { t: number; y: number }[] = [];
  let fling = 0;
  let suppressClick = false;
  let poll = 0;

  const maxTop = () => el.scrollHeight - el.clientHeight;
  const clamp = (n: number) => Math.min(Math.max(n, 0), maxTop());

  /* the browser must never start a competing pan while the box can scroll —
     but a box that can't scroll must let touches fall through to the page */
  const syncTouchAction = () => {
    el.style.touchAction = maxTop() > 0 ? "none" : "";
  };
  syncTouchAction();
  poll = window.setInterval(syncTouchAction, 500);
  window.addEventListener("resize", syncTouchAction);

  const stopFling = () => {
    if (fling) {
      cancelAnimationFrame(fling);
      fling = 0;
    }
  };

  const onClick = (e: MouseEvent) => {
    if (suppressClick) {
      e.stopPropagation();
      e.preventDefault();
    }
  };

  const onStart = (e: TouchEvent) => {
    if (e.touches.length !== 1) return;
    stopFling();
    active = true;
    suppressClick = false;
    startY = e.touches[0].clientY;
    startTop = el.scrollTop;
    moved = 0;
    samples = [{ t: e.timeStamp, y: startY }];
  };

  const onMove = (e: TouchEvent) => {
    if (!active || e.touches.length !== 1) return;
    const y = e.touches[0].clientY;
    const dy = y - startY;
    if (!moved && Math.abs(dy) < 5) return; // taps stay taps
    e.preventDefault(); // the pan belongs to us (touch-action none backs us)
    moved = Math.abs(dy);
    if (moved >= 5) suppressClick = true;
    samples.push({ t: e.timeStamp, y });
    while (samples.length > 2 && e.timeStamp - samples[0].t > 120) samples.shift();
    el.scrollTop = clamp(startTop - dy);
  };

  const onEnd = (e: TouchEvent) => {
    if (!active) return;
    active = false;
    const now = e.timeStamp;
    while (samples.length > 2 && now - samples[0].t > 120) samples.shift();
    const a = samples[0];
    const b = samples[samples.length - 1];
    const dt = b.t - a.t;
    let v = dt >= 16 ? (a.y - b.y) / dt : 0; // px/ms, + = content travelling up
    v = Math.max(-3, Math.min(3, v));
    if (Math.abs(v) < 0.1 || maxTop() <= 0) return;
    let last = now;
    const step = (ts: number) => {
      const d = Math.min(64, Math.max(1, ts - last));
      last = ts;
      v *= Math.pow(0.998, d); // iOS-grade deceleration
      if (Math.abs(v) < 0.02) {
        fling = 0;
        return;
      }
      const before = el.scrollTop;
      el.scrollTop = clamp(before + v * d);
      if (el.scrollTop === before) {
        fling = 0; // hit an edge — stop dead like native
        return;
      }
      fling = requestAnimationFrame(step);
    };
    fling = requestAnimationFrame(step);
  };

  el.addEventListener("touchstart", onStart, { passive: true });
  el.addEventListener("touchmove", onMove, { passive: false });
  el.addEventListener("touchend", onEnd, { passive: true });
  el.addEventListener("touchcancel", onEnd, { passive: true });
  el.addEventListener("click", onClick, { capture: true });

  return () => {
    stopFling();
    window.clearInterval(poll);
    window.removeEventListener("resize", syncTouchAction);
    el.removeEventListener("touchstart", onStart);
    el.removeEventListener("touchmove", onMove);
    el.removeEventListener("touchend", onEnd);
    el.removeEventListener("touchcancel", onEnd);
    el.removeEventListener("click", onClick, { capture: true });
    el.style.touchAction = "";
  };
}
