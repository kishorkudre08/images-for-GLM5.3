"use client";

/**
 * t76 · Fetch-X account theme gallery — the single source of truth for the
 * colour combos offered on /theme. Selecting one sets <html data-fx-theme>
 * and re-skins EVERY section the same way (universal — never per-section):
 *   accent A → actions + the restaurant book   (replaces the purple family)
 *   accent B → the lodge book                  (replaces the gold family)
 * The matching CSS lives in globals.css under `html[data-fx-theme=…]`, with
 * light AND dark tuning per combo. The palettes below mirror those tokens so
 * the picker can draw faithful previews of every combo without applying it.
 */

export const FX_THEME_IDS = ["classic", "dragonfruit", "lime", "emerald", "iris", "blaze", "neon", "cherry", "azure", "cyanreef"] as const;
export type FxThemeId = (typeof FX_THEME_IDS)[number];
export const DEFAULT_THEME: FxThemeId = "classic";

export type FxThemePalette = {
  page: string;
  surf: string;
  line: string;
  ink: string;
  muted: string;
  lav: string;
  a: string; // solid accent (buttons, chips)
  aInk: string; // text-safe accent
  aHi: string; // bright accent (gradient top, chart pop)
  onA: string; // readable text on solid accent
  b: string; // text-safe B (lodge)
  bHi: string; // vivid B (bars, dots)
};

export type FxTheme = {
  id: FxThemeId;
  name: string;
  tagline: string;
  light: FxThemePalette;
  dark: FxThemePalette;
};

/* t134 — COLOR CONCENTRATE palettes … superseded by t141: the canvas colours
   below (page/surf/line/ink/muted/lav) are pixel-sampled straight out of the
   settings gallery's real screenshots (public/theme-previews/*.jpg), so the
   drawn previews, the dots and the applied CSS all reproduce the images.
   Accent fields (a/aInk/aHi/onA/b/bHi) were already faithful and stay. */
const LIGHT_BASE = {
  page: "#eeeafe",
  surf: "#faf6fe",
  line: "#d4d1e4",
  ink: "#2a224a",
  muted: "#8e8aa2",
  lav: "#e2defa",
};
const DARK_BASE = {
  page: "#221a42",
  surf: "#2a225a",
  line: "#423e71",
  ink: "#eae6fe",
  muted: "#8e8ac2",
  lav: "#322a6e",
};

export const FX_THEMES: FxTheme[] = [
  {
    id: "classic",
    name: "Fetch-X Classic",
    tagline: "The house signature — violet actions with a brass lodge.",
    light: { ...LIGHT_BASE, a: "#5b4fe9", aInk: "#5b4fe9", aHi: "#8678f9", onA: "#ffffff", b: "#a16207", bHi: "#d9a441" },
    dark: { ...DARK_BASE, a: "#7a6ff0", aInk: "#8a7cf6", aHi: "#8a7cf6", onA: "#ffffff", b: "#e4c67c", bHi: "#d9a441" },
  },
  {
    id: "dragonfruit",
    name: "Dragon Fruit + Night Violet",
    tagline: "Hot magenta counter, deep violet rooms — bold and juicy.",
    light: { page: "#fae6f2", surf: "#feeaf6", line: "#dcc8d3", ink: "#46163a", muted: "#a68a9a", lav: "#f2d2ea", a: "#c81e78", aInk: "#c81e78", aHi: "#f06ab4", onA: "#ffffff", b: "#5b2d9e", bHi: "#7a4fd0" },
    dark: { page: "#32123a", surf: "#3e1646", line: "#53335c", ink: "#feeafe", muted: "#a67eaa", lav: "#462252", a: "#d64d92", aInk: "#f27ab8", aHi: "#f47fbf", onA: "#ffffff", b: "#c4a5f5", bHi: "#a78bfa" },
  },
  {
    id: "lime",
    name: "Lime Spark + Graphite",
    tagline: "Electric lime counter on cool graphite rooms — industrial fresh.",
    light: { page: "#eaf6d6", surf: "#f6faea", line: "#d0d9bc", ink: "#222e12", muted: "#8e967a", lav: "#deeec6", a: "#65a30d", aInk: "#4d7c0f", aHi: "#84cc16", onA: "#1c2507", b: "#475569", bHi: "#64748b" },
    dark: { page: "#1a2612", surf: "#263216", line: "#3f4b37", ink: "#fafeee", muted: "#869672", lav: "#2e3e22", a: "#84cc16", aInk: "#a3e635", aHi: "#a3e635", onA: "#1c2507", b: "#cbd5e1", bHi: "#94a3b8" },
  },
  {
    id: "emerald",
    name: "Emerald Ink + Champagne",
    tagline: "Emerald counter with champagne rooms — quiet luxury.",
    light: { page: "#f2f6da", surf: "#f6faea", line: "#d3d7bc", ink: "#021202", muted: "#96a28e", lav: "#e6eac6", a: "#047857", aInk: "#047857", aHi: "#10b981", onA: "#ffffff", b: "#8a6d1f", bHi: "#d9b45c" },
    dark: { page: "#0a2a22", surf: "#12362a", line: "#2c4c3d", ink: "#e2faea", muted: "#769a8a", lav: "#16422e", a: "#10b981", aInk: "#34d399", aHi: "#34d399", onA: "#06251a", b: "#e6cd8a", bHi: "#d9b45c" },
  },
  {
    id: "iris",
    name: "Butter Yellow + Royal Iris",
    tagline: "Butter-yellow counter against royal iris rooms — sunny and regal.",
    light: { page: "#fef2ce", surf: "#fefada", line: "#eee1bf", ink: "#2a2206", muted: "#a69a72", lav: "#f6e6b6", a: "#f5c51e", aInk: "#8f6c05", aHi: "#fada4a", onA: "#251c02", b: "#4f46e5", bHi: "#4f46e5" },
    dark: { page: "#221e4e", surf: "#2a2662", line: "#443f79", ink: "#fefede", muted: "#968eba", lav: "#322a6a", a: "#f5d020", aInk: "#fde047", aHi: "#fde047", onA: "#251c02", b: "#a5b4fc", bHi: "#818cf8" },
  },
  {
    id: "blaze",
    name: "Vivid Ember + Light Cream",
    tagline: "Vivid ember-orange counter on light-cream rooms — bold canteen warmth.",
    light: { page: "#f6eed6", surf: "#faf6e2", line: "#ddd5be", ink: "#3a260e", muted: "#ae9e8a", lav: "#f6e2ca", a: "#ea580c", aInk: "#c2410c", aHi: "#fb923c", onA: "#ffffff", b: "#a9834a", bHi: "#d9b978" },
    dark: { page: "#321a0a", surf: "#3a220e", line: "#533c2e", ink: "#feeeda", muted: "#a68a72", lav: "#422a16", a: "#f97316", aInk: "#fb923c", aHi: "#fb923c", onA: "#2a1203", b: "#e0cd9d", bHi: "#d9c48f" },
  },
  {
    id: "neon",
    name: "Neon Green + Charcoal",
    tagline: "Electric green counter on charcoal rooms — neon-sign night market.",
    light: { page: "#e6f6e2", surf: "#f2faf2", line: "#cbd9c8", ink: "#122a1a", muted: "#7e9686", lav: "#d2eeda", a: "#22c55e", aInk: "#15803d", aHi: "#4ade80", onA: "#052e12", b: "#3f4449", bHi: "#5d646a" },
    dark: { page: "#161a1a", surf: "#1e2626", line: "#374139", ink: "#f6fefa", muted: "#7a9286", lav: "#26322a", a: "#22c55e", aInk: "#4ade80", aHi: "#4ade80", onA: "#052e12", b: "#b6bec4", bHi: "#99a2a9" },
  },
  {
    id: "cherry",
    name: "Cherry Red + Porcelain",
    tagline: "Cherry-red counter on porcelain white — crisp diner classic.",
    light: { page: "#fae6ea", surf: "#faeeee", line: "#decbcd", ink: "#2e0a12", muted: "#aa8e92", lav: "#f6d6da", a: "#d21f3c", aInk: "#b01d3e", aHi: "#f2555a", onA: "#ffffff", b: "#9aa6b1", bHi: "#c3cbd3" },
    dark: { page: "#2e0e1a", surf: "#36121e", line: "#46202d", ink: "#feeaf2", muted: "#a67682", lav: "#421626", a: "#ef4356", aInk: "#fb7185", aHi: "#fb7185", onA: "#ffffff", b: "#dbe2e8", bHi: "#b9c2cb" },
  },
  {
    id: "azure",
    name: "Azure Sky + Deep Navy",
    tagline: "Sky-blue counter on deep navy rooms — clear-day cockpit.",
    light: { page: "#e6eefe", surf: "#eef6fa", line: "#c9d2e1", ink: "#122236", muted: "#8ea2ae", lav: "#cee6f6", a: "#0284c7", aInk: "#0369a1", aHi: "#38bdf8", onA: "#ffffff", b: "#1e40af", bHi: "#3b82f6" },
    dark: { page: "#0e1e3a", surf: "#162a4a", line: "#2d4166", ink: "#f2fefe", muted: "#7692b6", lav: "#162e56", a: "#38bdf8", aInk: "#7dd3fc", aHi: "#38bdf8", onA: "#04202e", b: "#93c5fd", bHi: "#60a5fa" },
  },
  {
    id: "cyanreef",
    name: "Reef Cyan + Storm Steel",
    tagline: "Reef-cyan counter on storm-steel rooms — aquarium calm.",
    light: { page: "#def6f6", surf: "#eefafa", line: "#c4d9da", ink: "#1a3236", muted: "#7a9296", lav: "#ceeaee", a: "#0891b2", aInk: "#0e7490", aHi: "#22d3ee", onA: "#ffffff", b: "#77828f", bHi: "#98a3b0" },
    dark: { page: "#0a222e", surf: "#122e3a", line: "#2c4951", ink: "#eefefe", muted: "#6e96a2", lav: "#123a42", a: "#22d3ee", aInk: "#67e8f9", aHi: "#67e8f9", onA: "#04262e", b: "#b9c3cd", bHi: "#9aa6b2" },
  },
];

export const themeById = (id: string): FxTheme => FX_THEMES.find((t) => t.id === id) ?? FX_THEMES[0];

/* ── storage + application (per signed-in account) ─────────────────────────── */

const LEGACY_KEY = "fx-theme";

export function fxThemeStorageKey(account?: string | null): string {
  const who = (account ?? "").trim().toLowerCase();
  return `fx-theme:${who || "guest"}`;
}

export function activeThemeId(): FxThemeId {
  if (typeof document === "undefined") return DEFAULT_THEME;
  const on = document.documentElement.dataset.fxTheme as FxThemeId | undefined;
  return on && FX_THEME_IDS.includes(on) ? on : DEFAULT_THEME;
}

export function readStoredTheme(account?: string | null): FxThemeId {
  try {
    const raw = localStorage.getItem(fxThemeStorageKey(account)) ?? localStorage.getItem(LEGACY_KEY);
    const id = raw as FxThemeId | null;
    return id && FX_THEME_IDS.includes(id) ? id : DEFAULT_THEME;
  } catch {
    return DEFAULT_THEME;
  }
}

/** Apply + persist for this account, then tell every listening chart. */
export function applyTheme(id: FxThemeId, account?: string | null, persist = true): void {
  const valid: FxThemeId = FX_THEME_IDS.includes(id) ? id : DEFAULT_THEME;
  document.documentElement.dataset.fxTheme = valid;
  if (persist) {
    try {
      localStorage.setItem(fxThemeStorageKey(account), valid);
    } catch {
      /* private mode */
    }
  }
  window.dispatchEvent(new CustomEvent("fx-theme-change", { detail: valid }));
}

/** The signed-in account identity (landing stores {name, role}). */
export function currentAccount(): string | null {
  try {
    const raw = localStorage.getItem("fx-auth");
    if (!raw) return null;
    const u = JSON.parse(raw) as { name?: string; email?: string };
    return u.email || u.name || null;
  } catch {
    return null;
  }
}
