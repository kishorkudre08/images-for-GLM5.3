import { NextResponse } from "next/server";
import {
  getHotelName,
  setHotelName,
  getPaidHolidayLimit,
  setPaidHolidayLimit,
  getDiscountLimit,
  setDiscountLimit,
} from "@/lib/settings";

export const dynamic = "force-dynamic";

// GET /api/settings — public read of tenant variables (landing needs the hotel
// name before login; nothing sensitive lives here). t126 — also returns the
// paid holidays limit that drives every salary cut. t143 — and the discount
// limit % that caps every reception discount input.
export async function GET() {
  try {
    const [hotelName, paidHolidayLimit, discountLimit] = await Promise.all([
      getHotelName(),
      getPaidHolidayLimit(),
      getDiscountLimit(),
    ]);
    return NextResponse.json({ hotelName, paidHolidayLimit, discountLimit });
  } catch {
    return NextResponse.json({ hotelName: null, paidHolidayLimit: 3, discountLimit: 10 }, { status: 200 });
  }
}

// PATCH /api/settings — update the hotel name (Management → Hotel Profile),
// the paid holidays limit (Settings → the salary rule) and/or the discount
// limit % (Settings → the bill rule). Send whichever field you want to
// change; several at once is fine.
export async function PATCH(req: Request) {
  try {
    const body = (await req.json()) as {
      hotelName?: string;
      paidHolidayLimit?: number;
      discountLimit?: number;
    };
    const wantsName = typeof body.hotelName === "string";
    const wantsLimit = body.paidHolidayLimit !== undefined && body.paidHolidayLimit !== null;
    const wantsDisc = body.discountLimit !== undefined && body.discountLimit !== null;
    if (!wantsName && !wantsLimit && !wantsDisc) {
      return NextResponse.json({ error: "hotelName, paidHolidayLimit or discountLimit is required." }, { status: 400 });
    }
    const hotelName = wantsName ? await setHotelName(body.hotelName as string) : undefined;
    const paidHolidayLimit = wantsLimit ? await setPaidHolidayLimit(Number(body.paidHolidayLimit)) : undefined;
    const discountLimit = wantsDisc ? await setDiscountLimit(Number(body.discountLimit)) : undefined;
    return NextResponse.json({
      ok: true,
      hotelName: hotelName ?? null,
      paidHolidayLimit: paidHolidayLimit ?? null,
      discountLimit: discountLimit ?? null,
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Could not save." },
      { status: 400 },
    );
  }
}
