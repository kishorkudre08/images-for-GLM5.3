import * as React from "react"

const MOBILE_BREAKPOINT = 768

/* t140 — inside the forced-landscape stage the page lays out on a fixed
   1280px desktop canvas (html[data-fx-stage="1"], see globals.css), so "is
   this a mobile layout?" must be answered from the STAGE width, not the raw
   device viewport: a portrait phone reports innerWidth ≈ 390 even though the
   user is looking at a full 1280px desktop view (this is what keeps the
   desktop sidebar instead of the mobile Sheet drawer on phones). */
function effectiveInnerWidth() {
  if (
    typeof document !== "undefined" &&
    document.documentElement.dataset.fxStage === "1"
  ) {
    const dw = parseFloat(
      getComputedStyle(document.documentElement).getPropertyValue("--fx-dw"),
    )
    return Number.isFinite(dw) && dw > 0 ? dw : 1280
  }
  return window.innerWidth
}

export function useIsMobile() {
  const [isMobile, setIsMobile] = React.useState<boolean | undefined>(undefined)

  React.useEffect(() => {
    const onChange = () => setIsMobile(effectiveInnerWidth() < MOBILE_BREAKPOINT)
    onChange()
    window.addEventListener("resize", onChange)
    window.addEventListener("orientationchange", onChange)
    return () => {
      window.removeEventListener("resize", onChange)
      window.removeEventListener("orientationchange", onChange)
    }
  }, [])

  return !!isMobile
}
