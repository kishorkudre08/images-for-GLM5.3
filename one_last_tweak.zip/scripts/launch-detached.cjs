/* Detached dev-server launcher — keeps the Fetch-X server alive after the
   tool call ends: spawn detached + unref, then exit immediately.
   Same proven pattern as the project's own start-server-detached.cjs. */
const { spawn } = require("node:child_process");

const child = spawn("bun", ["run", "dev"], {
  cwd: "/home/z/my-project",
  detached: true,
  stdio: ["ignore", "out", "err"].map((k) =>
    k === "out" ? require("node:fs").openSync("/home/z/my-project/dev.log", "a") :
    k === "err" ? require("node:fs").openSync("/home/z/my-project/dev.log", "a") : "ignore"
  ),
  env: {
    ...process.env,
    PORT: "3000",
    NODE_ENV: "development",
    DATABASE_URL: "file:/home/z/my-project/db/custom.db",
    FX_PROJECT_DIR: "/home/z/my-project",
  },
});
child.unref();
console.log("Fetch-X dev server launched detached, pid:", child.pid);
