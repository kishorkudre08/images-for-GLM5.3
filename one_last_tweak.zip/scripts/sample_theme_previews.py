#!/usr/bin/env python3
"""v2 — robust palette extraction from the settings theme-preview screenshots.

Fixes vs v1: tighter bar/dot regions, luminance-aware ink/muted sampling
(dark mode text is light-on-dark), mode-of-core-pixels instead of darkest
extreme (JPEG ringing), plus hero gradient + button cross-checks.
"""
from PIL import Image
import json, colorsys

D = "public/theme-previews"
THEMES = ["classic", "dragonfruit", "lime", "emerald", "iris", "blaze",
          "neon", "cherry", "azure", "cyanreef"]

def lum(c):
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]

def hexs(c):
    return "#%02x%02x%02x" % c[:3]

def mode_q(px, x0, y0, x1, y1, q=4):
    counts = {}
    for y in range(y0, y1):
        for x in range(x0, x1):
            key = tuple(v // q * q + q // 2 for v in px[x, y][:3])
            counts[key] = counts.get(key, 0) + 1
    return max(counts.items(), key=lambda kv: kv[1])[0]

def mode_text(px, x0, y0, x1, y1, lo, hi, q=4):
    """mode of pixels whose luminance falls in [lo, hi] (text core band)"""
    counts = {}
    for y in range(y0, y1):
        for x in range(x0, x1):
            c = px[x, y][:3]
            if lo <= lum(c) <= hi:
                key = tuple(v // q * q + q // 2 for v in c)
                counts[key] = counts.get(key, 0) + 1
    if not counts:
        return None
    return max(counts.items(), key=lambda kv: kv[1])[0]

def most_sat(px, x0, y0, x1, y1):
    best, bs = None, -1
    for y in range(y0, y1):
        for x in range(x0, x1):
            c = px[x, y][:3]
            h, s, v = colorsys.rgb_to_hsv(*(v / 255 for v in c))
            if s * v > bs:
                bs, best = s * v, c
    return best

def border_scan(px, y, x0, x1, page, surf):
    d2 = lambda a, b: sum((p - q) ** 2 for p, q in zip(a, b))
    best, bd = None, -1
    for x in range(x0, x1):
        c = px[x, y][:3]
        m = min(d2(c, page), d2(c, surf))
        if m > bd:
            bd, best = m, c
    return best

def sample_dashboard(path, dark):
    im = Image.open(path).convert("RGB")
    px = im.load()
    out = {}
    page = mode_q(px, 5, 300, 22, 330); out["page"] = hexs(page)
    surf = mode_q(px, 560, 50, 640, 68); out["surf"] = hexs(surf)
    out["surf2"] = hexs(mode_q(px, 160, 470, 300, 490))
    out["accA"] = hexs(mode_q(px, 60, 190, 95, 205))          # TODAY chip
    out["accA2"] = hexs(mode_q(px, 215, 264, 265, 280))        # ALL BUSINESS pill
    out["lav"] = hexs(mode_q(px, 700, 78, 780, 95))            # LIVE pill bg
    out["lav2"] = hexs(mode_q(px, 185, 300, 250, 315))         # COMBINED pill
    out["accB"] = hexs(mode_q(px, 740, 270, 820, 273, q=2))    # bar fill (B vivid)
    out["bdot"] = hexs(most_sat(px, 470, 265, 485, 278))       # LODGE dot
    out["adot"] = hexs(most_sat(px, 421, 265, 437, 278))       # RESTAURANT dot
    sl = tuple(int(out["page"][i:i + 2], 16) for i in (1, 3, 5))
    sf = tuple(int(out["surf2"][i:i + 2], 16) for i in (1, 3, 5))
    out["line"] = hexs(border_scan(px, 500, 18, 44, sl, sf))
    # ink: big number text core — dark mode text is BRIGHT
    bg_l = lum(sf)
    if dark:
        ink = mode_text(px, 55, 500, 185, 532, bg_l + 110, 999)
        mut = mode_text(px, 128, 41, 336, 55, bg_l + 35, bg_l + 105)
    else:
        ink = mode_text(px, 55, 500, 185, 532, 0, 150)
        mut = mode_text(px, 128, 41, 336, 55, 0, bg_l - 55)
    out["ink"] = hexs(ink) if ink else None
    out["muted"] = hexs(mut) if mut else None
    hard = mode_text(px, 150, 602, 300, 611, 0, 120)
    out["hard"] = hexs(hard) if hard else None
    return out

def sample_prelogin(path):
    im = Image.open(path).convert("RGB")
    px = im.load()
    return {
        "navsurf": hexs(mode_q(px, 520, 35, 580, 55)),
        "signin": hexs(mode_q(px, 995, 35, 1060, 55)),
        "chip": hexs(mode_q(px, 610, 36, 660, 55)),
        "started": hexs(mode_q(px, 75, 528, 140, 552)),
        "heroTop": hexs(mode_q(px, 810, 258, 860, 282)),
        "heroBot": hexs(mode_q(px, 810, 478, 860, 502)),
    }

result = {}
for t in THEMES:
    result[t] = {}
    for mode in ("light", "dark"):
        e = sample_dashboard(f"{D}/{t}-{mode}-dashboard.jpg", mode == "dark")
        e.update({k + "_pre": v for k, v in
                  sample_prelogin(f"{D}/{t}-{mode}-prelogin.jpg").items()})
        result[t][mode] = e
with open("scripts/theme-samples.json", "w") as f:
    json.dump(result, f, indent=1)
print(json.dumps(result, indent=1))
