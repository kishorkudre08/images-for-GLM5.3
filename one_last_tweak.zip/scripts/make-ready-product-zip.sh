#!/bin/bash
# "ready_product" zip — same payload contract as make-final-product-zip.sh
# (source + db + docs, no build junk). Snapshot of the approved state:
# attendance split + forced-landscape stage (t140) + theme-preview-matched
# palettes (t141); the t142 panel shift is REVERTED and absent.
set -e
cd /home/z/my-project

STAGE=$(mktemp -d)
NAME="ready_product"
mkdir -p "$STAGE/$NAME"

rsync -a \
  --exclude 'node_modules' \
  --exclude '.next' \
  --exclude 'download' \
  --exclude 'skills' \
  --exclude 'tool-results' \
  --exclude 'upload' \
  --exclude 'worklog.md' \
  --exclude 'server.log' \
  --exclude '*.log' \
  --exclude '.git' \
  --exclude 'ref-screenshot.png' \
  --exclude 'fetch-x' \
  --exclude 'tsconfig.tsbuildinfo' \
  ./ "$STAGE/$NAME/"

cd "$STAGE"
# rm first — `zip -r` into an existing archive never removes deleted entries
rm -f "/home/z/my-project/download/ready_product.zip"
zip -rq9 "/home/z/my-project/download/ready_product.zip" "$NAME"
cd /home/z/my-project
rm -rf "$STAGE"

ls -lh "download/ready_product.zip"
unzip -l "download/ready_product.zip" | tail -3
