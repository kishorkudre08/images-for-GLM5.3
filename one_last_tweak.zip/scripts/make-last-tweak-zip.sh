#!/bin/bash
# "last-tweak" zip — same payload contract as the user's own
# make-last-prototype-zip.sh (source + db + docs, no build junk).
# Snapshot of the current working state, no code changes.
set -e
cd /home/z/my-project

# the zip-append gotcha: zip -r into an EXISTING archive only adds/updates
# entries — always rm -f the target first
rm -f "/home/z/my-project/download/last-tweak.zip"

STAGE=$(mktemp -d)
NAME="last-tweak"
mkdir -p "$STAGE/$NAME"

rsync -a \
  --exclude 'node_modules' \
  --exclude '.next' \
  --exclude 'download' \
  --exclude 'skills' \
  --exclude 'tool-results' \
  --exclude 'upload' \
  --exclude 'worklog.md' \
  --exclude 'server.log' \
  --exclude '*.log' \
  --exclude '.git' \
  --exclude 'ref-screenshot.png' \
  --exclude 'fetch-x' \
  --exclude 'tsconfig.tsbuildinfo' \
  ./ "$STAGE/$NAME/"

cd "$STAGE"
zip -rq9 "/home/z/my-project/download/last-tweak.zip" "$NAME"
cd /home/z/my-project
rm -rf "$STAGE"

ls -lh "download/last-tweak.zip"
unzip -l "download/last-tweak.zip" | tail -3
