import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

/**
 * Demo sign-in — three fixed demo accounts (no account creation, everything
 * stays local). t104 — the developer account is gone entirely:
 *   • OWNER                — full platform: dashboard, POS, expenses, lodge, manage
 *   • RECEPTION_RESTAURANT — cashier station: POS billing
 *   • RECEPTION_LODGE      — front-desk station: the 100-room wall
 */
const ACCOUNTS = [
  {
    email: "spiceowner@gmail.com",
    password: "spiceowner",
    name: "Imperial",
    role: "owner",
    label: "OWNER",
  },
  {
    email: "spicerestaurant@gmail.com",
    password: "spicerestaurant",
    name: "Imperial",
    role: "reception_restaurant",
    label: "RESTAURANT RECEPTION",
  },
  {
    email: "spicelodge@gmail.com",
    password: "spicelodge",
    name: "Imperial",
    role: "reception_lodge",
    label: "LODGE RECEPTION",
  },
];

export async function POST(req: Request) {
  let body: { email?: string; password?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Bad request." }, { status: 400 });
  }

  const email = (body.email ?? "").trim().toLowerCase();
  const password = body.password ?? "";

  if (!email || !password) {
    return NextResponse.json({ ok: false, error: "Email and password are required." }, { status: 400 });
  }

  const acct = ACCOUNTS.find((a) => a.email === email && a.password === password);
  if (!acct) {
    return NextResponse.json({ ok: false, error: "Wrong email or password." }, { status: 401 });
  }

  return NextResponse.json({
    ok: true,
    user: { name: acct.name, role: acct.role, email: acct.email },
    label: acct.label,
  });
}
