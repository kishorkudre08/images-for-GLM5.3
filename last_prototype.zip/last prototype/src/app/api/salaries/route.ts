import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { invalidateDashboardCache } from "@/lib/analytics";
import { getPaidHolidayLimit } from "@/lib/settings";

export const dynamic = "force-dynamic";

// ── t119 · SALARY BASICS ────────────────────────────────────────────────────
// The owner's monthly salary run. A month may only be settled once it is
// FULLY OVER ("month not over yet" disables the run for the current and any
// future month). Marking PAID freezes the actual money handed over — base
// salary minus the attendance cut (absent days beyond paid holidays × per-day
// wage) — and the live dashboard reports these ACTUAL figures.
const round2 = (n: number) => Math.round(n * 100) / 100;

const MONTH_KEY = /^\d{4}-(0[1-9]|1[0-2])$/;
const monthKeyOf = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
export const daysInMonthOf = (key: string) => {
  const [y, m] = key.split("-").map(Number);
  return new Date(y, m, 0).getDate();
};
// A month is settled-able only when the whole month is in the past.
const isMonthOver = (key: string) => key < monthKeyOf(new Date());

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;

  // PAID HISTORY — every settled payment, newest first.
  if (sp.get("history")) {
    const rows = await db.salaryPayment.findMany({
      where: { status: "paid" },
      include: { employee: { select: { name: true, role: true, book: true } } },
      orderBy: [{ paidAt: "desc" }],
      take: 400,
    });
    return NextResponse.json({
      history: rows.map((r) => ({
        id: r.id,
        employeeId: r.employeeId,
        name: r.employee.name,
        role: r.employee.role,
        book: r.employee.book,
        month: r.month,
        base: r.base,
        absentDays: r.absentDays,
        paidHolidays: r.paidHolidays,
        deduction: r.deduction,
        netPaid: r.netPaid,
        paidAt: r.paidAt,
      })),
    });
  }

  const month = String(sp.get("month") ?? "");
  if (!MONTH_KEY.test(month))
    return NextResponse.json({ error: "month must be YYYY-MM" }, { status: 400 });

  const monthOver = isMonthOver(month);
  const days = daysInMonthOf(month);
  const from = `${month}-01`;
  const to = `${month}-${String(days).padStart(2, "0")}`;

  const [employees, attendance, payments, holidayLimit] = await Promise.all([
    db.employee.findMany({ where: { active: true }, orderBy: [{ book: "asc" }, { salary: "desc" }] }),
    db.attendance.groupBy({
      by: ["employeeId", "status"],
      where: { date: { gte: from, lte: to } },
      _count: true,
    }),
    db.salaryPayment.findMany({ where: { month } }),
    getPaidHolidayLimit(),
  ]);

  const presentOf = new Map<string, number>();
  const absentOf = new Map<string, number>();
  for (const a of attendance) {
    if (a.status === "present") presentOf.set(a.employeeId, a._count);
    else absentOf.set(a.employeeId, a._count);
  }
  const paidOf = new Map(payments.map((p) => [p.employeeId, p]));

  const rows = employees.map((e) => {
    const present = presentOf.get(e.id) ?? 0;
    const absent = absentOf.get(e.id) ?? 0;
    const p = paidOf.get(e.id);
    // t126 — attendance is DERIVED from the receptions' register: the holidays
    // applied are the global Settings limit (capped by the days actually
    // missed). Settled months keep their frozen figures.
    const paidHolidays = p ? p.paidHolidays : Math.min(holidayLimit, absent);
    const cutDays = Math.max(0, absent - paidHolidays);
    const deduction = p ? p.deduction : round2(cutDays * (e.salary / days));
    const netPaid = p ? p.netPaid : round2(e.salary - deduction);
    return {
      employeeId: e.id,
      name: e.name,
      role: e.role,
      book: e.book as "rest" | "lodge",
      base: e.salary,
      present,
      absent,
      days,
      paidHolidays,
      deduction,
      netPaid,
      status: p?.status ?? "unpaid",
      paidAt: p?.paidAt ?? null,
      paidBy: p?.paidBy ?? null,
      frozen: !!p,
    };
  });

  return NextResponse.json({ month, days, monthOver, holidayLimit, rows });
}

// POST — mark one employee's month PAID (or update the frozen figures while
// still in the same open run). Only allowed when the month is fully over.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const employeeId = String(body.employeeId ?? "");
    const month = String(body.month ?? "");
    if (!employeeId || !MONTH_KEY.test(month))
      return NextResponse.json({ error: "employeeId and month are required" }, { status: 400 });
    if (!isMonthOver(month))
      return NextResponse.json(
        { error: "Month not over yet — salaries can only be settled after the month ends." },
        { status: 409 },
      );

    const emp = await db.employee.findUnique({ where: { id: employeeId } });
    if (!emp) return NextResponse.json({ error: "Employee not found" }, { status: 404 });

    const days = daysInMonthOf(month);
    const from = `${month}-01`;
    const to = `${month}-${String(days).padStart(2, "0")}`;
    const [present, absent] = await Promise.all([
      db.attendance.count({ where: { employeeId, date: { gte: from, lte: to }, status: "present" } }),
      db.attendance.count({ where: { employeeId, date: { gte: from, lte: to }, status: "absent" } }),
    ]);

    // t126 — the paid holidays come from the GLOBAL Settings limit, never from
    // the request body: the owner cannot hand-tune attendance-derived cuts.
    // t129 — the recalculated figure IS the salary (user: "the recalculated
    // paid salary should be considered as the given business's employee
    // salary"): no actualPaid override exists anymore — what lands in the
    // ledger is exactly base − cut.
    const limit = await getPaidHolidayLimit();
    const paidHolidays = Math.max(0, Math.min(limit, absent));
    const cutDays = Math.max(0, absent - paidHolidays);
    const deduction = round2(cutDays * (emp.salary / days));
    const netPaid = round2(emp.salary - deduction);

    const payment = await db.salaryPayment.upsert({
      where: { employeeId_month: { employeeId, month } },
      create: {
        employeeId,
        month,
        base: emp.salary,
        presentDays: present,
        absentDays: absent,
        paidHolidays,
        deduction,
        netPaid,
        status: "paid",
        paidAt: new Date(),
        paidBy: String(body.paidBy ?? "OWNER").slice(0, 60) || "OWNER",
      },
      update: {
        base: emp.salary,
        presentDays: present,
        absentDays: absent,
        paidHolidays,
        deduction,
        netPaid,
        status: "paid",
        paidAt: new Date(),
        paidBy: String(body.paidBy ?? "OWNER").slice(0, 60) || "OWNER",
      },
    });
    invalidateDashboardCache();
    return NextResponse.json({ payment });
  } catch {
    return NextResponse.json({ error: "Could not settle the salary" }, { status: 500 });
  }
}

// PATCH — undo a settlement (back to unpaid). Same rule: only settled (past)
// months may change.
export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const employeeId = String(body.employeeId ?? "");
    const month = String(body.month ?? "");
    if (!employeeId || !MONTH_KEY.test(month))
      return NextResponse.json({ error: "employeeId and month are required" }, { status: 400 });
    if (!isMonthOver(month))
      return NextResponse.json({ error: "Month not over yet — nothing to undo." }, { status: 409 });

    const existing = await db.salaryPayment.findUnique({
      where: { employeeId_month: { employeeId, month } },
    });
    if (!existing) return NextResponse.json({ error: "No settlement found" }, { status: 404 });

    const payment = await db.salaryPayment.update({
      where: { employeeId_month: { employeeId, month } },
      data: { status: "unpaid", paidAt: null, paidBy: null },
    });
    invalidateDashboardCache();
    return NextResponse.json({ payment });
  } catch {
    return NextResponse.json({ error: "Could not undo the settlement" }, { status: 500 });
  }
}
