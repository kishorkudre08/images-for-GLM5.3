import { NextResponse } from "next/server";
import { getHotelName, setHotelName, getPaidHolidayLimit, setPaidHolidayLimit } from "@/lib/settings";

export const dynamic = "force-dynamic";

// GET /api/settings — public read of tenant variables (landing needs the hotel
// name before login; nothing sensitive lives here). t126 — also returns the
// paid holidays limit that drives every salary cut.
export async function GET() {
  try {
    const [hotelName, paidHolidayLimit] = await Promise.all([getHotelName(), getPaidHolidayLimit()]);
    return NextResponse.json({ hotelName, paidHolidayLimit });
  } catch {
    return NextResponse.json({ hotelName: null, paidHolidayLimit: 3 }, { status: 200 });
  }
}

// PATCH /api/settings — update the hotel name (Management → Hotel Profile)
// and/or the paid holidays limit (Settings → the salary rule). Send whichever
// field you want to change; both at once is fine.
export async function PATCH(req: Request) {
  try {
    const body = (await req.json()) as { hotelName?: string; paidHolidayLimit?: number };
    const wantsName = typeof body.hotelName === "string";
    const wantsLimit = body.paidHolidayLimit !== undefined && body.paidHolidayLimit !== null;
    if (!wantsName && !wantsLimit) {
      return NextResponse.json({ error: "hotelName or paidHolidayLimit is required." }, { status: 400 });
    }
    const hotelName = wantsName ? await setHotelName(body.hotelName as string) : undefined;
    const paidHolidayLimit = wantsLimit ? await setPaidHolidayLimit(Number(body.paidHolidayLimit)) : undefined;
    return NextResponse.json({ ok: true, hotelName: hotelName ?? null, paidHolidayLimit: paidHolidayLimit ?? null });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Could not save." },
      { status: 400 },
    );
  }
}
