import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET /api/menu — all dishes (category, then name)
export async function GET() {
  const dishes = await db.dish.findMany({
    orderBy: [{ category: "asc" }, { name: "asc" }],
  });
  return NextResponse.json(dishes);
}

// POST /api/menu — create a dish (management). Unknown categories are
// registered as new sections automatically.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const name = String(body.name ?? "").trim();
    const price = Number(body.price);
    const category = String(body.category ?? "").trim() || "Main Course";
    if (!name) return NextResponse.json({ error: "Dish name is required" }, { status: 400 });
    if (!Number.isFinite(price) || price <= 0)
      return NextResponse.json({ error: "Price must be a positive number" }, { status: 400 });

    const dish = await db.$transaction(async (tx) => {
      await tx.category.upsert({ where: { name: category }, update: {}, create: { name: category } });
      return tx.dish.create({
        data: { name, price, category, veg: Boolean(body.veg ?? true) },
      });
    });
    return NextResponse.json(dish, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }
}
