import type { Metadata, Viewport } from "next";
import { Inter, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Fetch-X — Restaurant OS",
  description:
    "Zero-entry business intelligence for restaurants — the cashier bills, the software collects. {dish, quantity, time} flows in automatically. Many hotels, one platform.",
  icons: {
    /* t137 — the tab icon is the pre-login page's CHEF CAP (lucide ChefHat
       geometry: puffy toque + band), white on the Fetch-X blue tile. The cap
       is scaled to 0.82 about the centre so nothing touches the rounded
       outline — sleek, no overflow (the old graduate-hat diamond is gone). */
    icon:
      "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Crect width='24' height='24' rx='6' fill='%235b4fe9'/%3E%3Cg fill='none' stroke='white' stroke-width='1.7' stroke-linecap='round' stroke-linejoin='round' transform='translate(12 12) scale(0.82) translate(-12 -12)'%3E%3Cpath d='M17 21a1 1 0 0 0 1-1v-5.35c0-.457.316-.844.727-1.041a4 4 0 0 0-2.134-7.589 5 5 0 0 0-9.186 0 4 4 0 0 0-2.134 7.588c.411.198.727.585.727 1.041V20a1 1 0 0 0 1 1Z'/%3E%3Cpath d='M6 17h12'/%3E%3C/g%3E%3C/svg%3E",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  /* t134 — mobile starts at 50% zoom (was 100%): the whole desktop layout fits
     on a phone at half size, and anyone who wants it bigger just pinch-zooms. */
  initialScale: 0.5,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  /* t76 — apply the signed-in account's saved theme BEFORE first paint
     (same lookup order as readStoredTheme(): account → guest → legacy). */
  const themeBoot = `try{
    var a=null;try{a=JSON.parse(localStorage.getItem("fx-auth")||"null")}catch(e){}
    var who=((a&&(a.email||a.name))||"guest").toString().trim().toLowerCase();
    var t=localStorage.getItem("fx-theme:"+who)||localStorage.getItem("fx-theme:guest")||localStorage.getItem("fx-theme")||"classic";
    if(t&&t!=="classic")document.documentElement.dataset.fxTheme=t;
  }catch(e){}`;
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeBoot }} />
      </head>
      <body className={`${inter.variable} ${geistMono.variable} antialiased bg-background text-foreground font-sans`}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false} disableTransitionOnChange>
          {children}
          <Toaster />
        </ThemeProvider>
        {/* t105 — phones run Fetch-X in LANDSCAPE only: a pure-CSS gate covers
            narrow portrait screens with a rotate prompt. Landscape phones and
            every desktop viewport never see it. Themed via the fx tokens. */}
        <div className="fx-rotate-gate" role="dialog" aria-modal="true" aria-label="Rotate your phone to landscape">
          <div className="fx-rotate-card">
            <div className="fx-rotate-phone" aria-hidden="true" />
            <h2 className="fx-rotate-title">Rotate your phone</h2>
            <p className="fx-rotate-sub">
              Fetch-X runs in landscape on mobile — turn your device sideways to continue.
            </p>
            <span className="fx-rotate-chip">LANDSCAPE MODE</span>
          </div>
        </div>
      </body>
    </html>
  );
}
