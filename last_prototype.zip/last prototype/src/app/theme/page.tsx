"use client";

/**
 * t76 · THE THEME GALLERY — a real page (/theme) the tier-band THEME button
 * opens from every section. Each combo previews as THREE mini dashboards:
 * light + dark (the two coloured ones) and one black/white — the same two
 * accents drive the whole live dashboard, so what you pick here is what every
 * section becomes, universally, for the signed-in account (guest picks stick
 * to the device until an account claims them).
 */

import * as React from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Check, Palette } from "lucide-react";
import {
  FX_THEMES,
  activeThemeId,
  applyTheme,
  currentAccount,
  type FxTheme,
  type FxThemeId,
  type FxThemePalette,
} from "@/lib/fx-themes";

/* ── one mini dashboard mock — pure inline styles off the palette ──────────── */
function MiniDash({ p, mono = false }: { p: FxThemePalette; mono?: boolean }) {
  const A = mono ? "#181635" : p.a;
  const B = mono ? "#565a72" : p.bHi;
  const onA = mono ? "#ffffff" : p.onA;
  const page = mono ? "#ffffff" : p.page;
  const surf = mono ? "#ffffff" : p.surf;
  const line = mono ? "#dcdbe8" : p.line;
  const ink = mono ? "#181635" : p.ink;
  const muted = mono ? "#8b8ea7" : p.muted;
  const lav = mono ? "#f1f0f8" : p.lav;
  const aInk = mono ? "#181635" : p.aInk;

  const stat = (label: string, val: string, bar: string, net: string, netColor: string) => (
    <div key={label} style={{ flex: 1, background: surf, border: `1px solid ${line}`, borderRadius: 10, padding: "7px 8px", minWidth: 0 }}>
      <div style={{ fontSize: 5.5, fontWeight: 800, letterSpacing: "0.13em", color: muted }}>{label}</div>
      <div style={{ fontSize: 12, fontWeight: 800, color: ink, marginTop: 2 }}>{val}</div>
      <div style={{ height: 3, borderRadius: 99, background: lav, marginTop: 4, overflow: "hidden" }}>
        <div style={{ width: "78%", height: "100%", borderRadius: 99, background: bar }} />
      </div>
      <div style={{ fontSize: 5.5, fontWeight: 800, color: netColor, marginTop: 3, letterSpacing: "0.08em" }}>{net}</div>
    </div>
  );

  return (
    <div style={{ background: page, border: `1px solid ${line}`, borderRadius: 14, padding: 9 }}>
      {/* tier band + the THEME entry point */}
      <div style={{ display: "flex", alignItems: "center", gap: 7, background: surf, border: `1px solid ${line}`, borderRadius: 10, padding: "7px 9px" }}>
        <span style={{ background: A, color: onA, borderRadius: 7, width: 20, height: 20, display: "grid", placeItems: "center", fontSize: 8, fontWeight: 800, flexShrink: 0 }}>
          01
        </span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 5.5, fontWeight: 800, letterSpacing: "0.13em", color: muted }}>TIER 01 · OWNER INTELLIGENCE</div>
          <div style={{ fontSize: 9.5, fontWeight: 800, color: ink }}>Live Dashboard</div>
        </div>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 3, border: `1px solid ${line}`, background: surf, borderRadius: 99, padding: "3px 7px", fontSize: 5.5, fontWeight: 800, letterSpacing: "0.1em", color: aInk, flexShrink: 0 }}>
          <Palette style={{ width: 7, height: 7 }} /> THEME
        </span>
      </div>
      {/* stat duo — one bar per book */}
      <div style={{ display: "flex", gap: 7, marginTop: 7 }}>
        {stat("HOTEL · FOOD & BEV", "₹1.2L", A, "NET · ₹32,540", "#0e9f6e")}
        {stat("LODGE · ROOMS & STAYS", "₹86k", B, "NET · ₹9,120", "#0e9f6e")}
      </div>
      {/* split + donut */}
      <div style={{ display: "flex", alignItems: "center", gap: 9, marginTop: 7, background: surf, border: `1px solid ${line}`, borderRadius: 10, padding: "7px 9px" }}>
        <div style={{ position: "relative", width: 38, height: 38, borderRadius: "50%", background: `conic-gradient(${A} 0 38%, ${B} 38% 74%, ${lav} 74% 100%)`, flexShrink: 0 }}>
          <div style={{ position: "absolute", inset: 10, borderRadius: "50%", background: surf }} />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 6, fontWeight: 800, color: ink }}>
            <span style={{ width: 5, height: 5, borderRadius: 99, background: A, display: "inline-block" }} /> RESTAURANT 38%
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 6, fontWeight: 800, color: ink, marginTop: 3 }}>
            <span style={{ width: 5, height: 5, borderRadius: 99, background: B, display: "inline-block" }} /> LODGE 62%
          </div>
          <div style={{ display: "flex", gap: 4, marginTop: 5 }}>
            <span style={{ background: A, color: onA, borderRadius: 99, padding: "2px 6px", fontSize: 5.5, fontWeight: 800, letterSpacing: "0.09em" }}>ALL</span>
            <span style={{ border: `1px solid ${line}`, color: muted, borderRadius: 99, padding: "2px 6px", fontSize: 5.5, fontWeight: 800, letterSpacing: "0.09em" }}>TODAY</span>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── one combo card ────────────────────────────────────────────────────────── */
function ThemeCard({ theme, current, onApply }: { theme: FxTheme; current: FxThemeId; onApply: (id: FxThemeId) => void }) {
  const isCurrent = current === theme.id;
  return (
    <div
      className={`fx-card fx-pop p-5 ${isCurrent ? "ring-2 ring-[var(--fx-purple)] ring-offset-2 ring-offset-[var(--fx-page)]" : ""}`}
      style={isCurrent ? { borderColor: "var(--fx-purple)" } : undefined}
    >
      <div className="flex flex-wrap items-center gap-3">
        <span className="flex items-center gap-1.5" aria-hidden>
          <i className="scope-dot" style={{ background: theme.light.a, width: 14, height: 14 }} />
          <i className="scope-dot" style={{ background: theme.light.bHi, width: 14, height: 14 }} />
        </span>
        <div className="min-w-0 flex-1">
          <h2 className="text-[15px] font-extrabold tracking-tight text-[var(--fx-ink)]">{theme.name}</h2>
          <p className="text-[11.5px] font-medium text-[var(--fx-muted)]">{theme.tagline}</p>
        </div>
        {isCurrent ? (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-[var(--fx-purple)] px-4 py-2 text-[10px] font-extrabold tracking-[0.12em] text-[var(--fx-on-accent)]">
            <Check className="h-3.5 w-3.5" /> CURRENT
          </span>
        ) : (
          <button
            onClick={() => onApply(theme.id)}
            className="rounded-full border border-[var(--fx-line)] bg-[var(--fx-surf)] px-4 py-2 text-[10px] font-extrabold tracking-[0.12em] text-[var(--fx-accent-ink)] shadow-[2px_2px_0_0_var(--fx-hard)] transition hover:border-[var(--fx-purple)]"
          >
            USE THIS THEME
          </button>
        )}
      </div>

      {/* the two coloured + one black/white dashboards */}
      <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-3">
        <figure>
          <MiniDash p={theme.light} />
          <figcaption className="fx-label mt-1.5 text-center">LIGHT · BOTH BOOKS</figcaption>
        </figure>
        <figure>
          <MiniDash p={theme.dark} />
          <figcaption className="fx-label mt-1.5 text-center">DARK · BOTH BOOKS</figcaption>
        </figure>
        <figure>
          <MiniDash p={theme.light} mono />
          <figcaption className="fx-label mt-1.5 text-center">BLACK &amp; WHITE</figcaption>
        </figure>
      </div>
    </div>
  );
}

/* ── the page ──────────────────────────────────────────────────────────────── */
export default function ThemePage() {
  const router = useRouter();
  const [account, setAccount] = React.useState<string | null>(null);
  const [accountName, setAccountName] = React.useState<string>("");
  const [current, setCurrent] = React.useState<FxThemeId>("classic");

  React.useEffect(() => {
    setAccount(currentAccount());
    try {
      const u = JSON.parse(localStorage.getItem("fx-auth") ?? "null") as { name?: string } | null;
      setAccountName(u?.name ?? "");
    } catch {
      /* guest */
    }
    setCurrent(activeThemeId());
  }, []);

  const apply = (id: FxThemeId) => {
    applyTheme(id, account);
    setCurrent(id);
  };

  return (
    <div className="min-h-screen bg-[var(--fx-page)]">
      <div className="mx-auto max-w-[1100px] px-4 pb-16 pt-6 md:px-7">
        {/* header */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => router.push("/")}
            aria-label="Back to the console"
            className="inline-flex h-10 items-center gap-2 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-surf)] px-4 text-[11px] font-extrabold tracking-[0.1em] text-[var(--fx-muted)] shadow-[2px_2px_0_0_var(--fx-hard)] transition hover:text-[var(--fx-ink)]"
          >
            <ArrowLeft className="h-4 w-4" /> CONSOLE
          </button>
          <span className="grid h-10 w-10 place-items-center rounded-2xl bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)]">
            <Palette className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <h1 className="text-xl font-extrabold tracking-tight text-[var(--fx-ink)] md:text-2xl">Theme Gallery</h1>
            <p className="text-[12.5px] font-medium text-[var(--fx-muted)]">
              One accent pair for the whole account — pick a combo, every section follows.
            </p>
          </div>
          <span className="rounded-full border border-[var(--fx-line)] bg-[var(--fx-lav)] px-4 py-2 text-[10px] font-extrabold tracking-[0.12em] text-[var(--fx-ink)]">
            PICKING FOR · {(accountName || "GUEST").toUpperCase()}
          </span>
        </div>

        <p className="mt-4 text-[12px] font-medium leading-relaxed text-[var(--fx-muted)]">
          Every combo below is previewed the way it will run — <b className="text-[var(--fx-ink)]">light</b> and{" "}
          <b className="text-[var(--fx-ink)]">dark</b> dashboards in that combo&apos;s two accents, plus a plain{" "}
          <b className="text-[var(--fx-ink)]">black &amp; white</b> reference. The first accent drives actions and the
          FOOD &amp; BEV book; the second drives ROOMS &amp; STAYS. Your choice applies account-wide the moment you tap
          it{account ? "" : " (signed out, it stays on this device)"} and survives sign-out.
        </p>

        <div className="mt-5 flex flex-col gap-5">
          {FX_THEMES.map((t) => (
            <ThemeCard key={t.id} theme={t} current={current} onApply={apply} />
          ))}
        </div>

        <div className="mt-6 flex justify-center">
          <button
            onClick={() => router.push("/")}
            className="inline-flex h-12 items-center gap-2 rounded-2xl bg-[var(--fx-purple)] px-8 text-[13px] font-extrabold tracking-wide text-[var(--fx-on-accent)] shadow-[3px_4px_0_0_var(--fx-hard)] transition hover:bg-[var(--fx-purple-deep)]"
          >
            <ArrowLeft className="h-4 w-4" /> BACK TO THE CONSOLE
          </button>
        </div>
      </div>
    </div>
  );
}
