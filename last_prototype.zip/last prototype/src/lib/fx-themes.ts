"use client";

/**
 * t76 · Fetch-X account theme gallery — the single source of truth for the
 * colour combos offered on /theme. Selecting one sets <html data-fx-theme>
 * and re-skins EVERY section the same way (universal — never per-section):
 *   accent A → actions + the restaurant book   (replaces the purple family)
 *   accent B → the lodge book                  (replaces the gold family)
 * The matching CSS lives in globals.css under `html[data-fx-theme=…]`, with
 * light AND dark tuning per combo. The palettes below mirror those tokens so
 * the picker can draw faithful previews of every combo without applying it.
 */

export const FX_THEME_IDS = ["classic", "dragonfruit", "lime", "emerald", "iris", "blaze", "neon", "cherry", "azure", "cyanreef"] as const;
export type FxThemeId = (typeof FX_THEME_IDS)[number];
export const DEFAULT_THEME: FxThemeId = "classic";

export type FxThemePalette = {
  page: string;
  surf: string;
  line: string;
  ink: string;
  muted: string;
  lav: string;
  a: string; // solid accent (buttons, chips)
  aInk: string; // text-safe accent
  aHi: string; // bright accent (gradient top, chart pop)
  onA: string; // readable text on solid accent
  b: string; // text-safe B (lodge)
  bHi: string; // vivid B (bars, dots)
};

export type FxTheme = {
  id: FxThemeId;
  name: string;
  tagline: string;
  light: FxThemePalette;
  dark: FxThemePalette;
};

/* t134 — COLOR CONCENTRATE: in each mode the pair's mode colour owns the page
   and the other colour tints the cards (light mode: light page / dark cards —
   dark mode: dark page / light cards). Palettes mirror globals.css exactly so
   the /theme previews stay faithful to what applying a combo looks like. */
const LIGHT_BASE = {
  page: "#f7ebd5",
  surf: "#ebeafc",
  line: "#d8d5fa",
  ink: "#241d56",
  muted: "#7c7ba0",
  lav: "#e3e1fb",
};
const DARK_BASE = {
  page: "#3e3879",
  surf: "#382b2a",
  line: "#4f3c2a",
  ink: "#eae7fc",
  muted: "#9d9ac4",
  lav: "#2a2024",
};

export const FX_THEMES: FxTheme[] = [
  {
    id: "classic",
    name: "Fetch-X Classic",
    tagline: "The house signature — violet actions with a brass lodge.",
    light: { ...LIGHT_BASE, a: "#5b4fe9", aInk: "#5b4fe9", aHi: "#8678f9", onA: "#ffffff", b: "#a16207", bHi: "#d9a441" },
    dark: { ...DARK_BASE, a: "#7a6ff0", aInk: "#8a7cf6", aHi: "#8a7cf6", onA: "#ffffff", b: "#e4c67c", bHi: "#d9a441" },
  },
  {
    id: "dragonfruit",
    name: "Dragon Fruit + Night Violet",
    tagline: "Hot magenta counter, deep violet rooms — bold and juicy.",
    light: { page: "#f7e4f1", surf: "#ebe6f3", line: "#d8cde8", ink: "#4a1040", muted: "#a4799a", lav: "#e3dbee", a: "#c81e78", aInk: "#c81e78", aHi: "#f06ab4", onA: "#ffffff", b: "#5b2d9e", bHi: "#7a4fd0" },
    dark: { page: "#4e4077", surf: "#38223c", line: "#573150", ink: "#f8e6f3", muted: "#b58cae", lav: "#2a1b30", a: "#d64d92", aInk: "#f27ab8", aHi: "#f47fbf", onA: "#ffffff", b: "#c4a5f5", bHi: "#a78bfa" },
  },
  {
    id: "lime",
    name: "Lime Spark + Graphite",
    tagline: "Electric lime counter on cool graphite rooms — industrial fresh.",
    light: { page: "#eaf4d8", surf: "#e9ebed", line: "#d3d6db", ink: "#1f3308", muted: "#7d8a67", lav: "#e0e2e5", a: "#65a30d", aInk: "#4d7c0f", aHi: "#84cc16", onA: "#1c2507", b: "#475569", bHi: "#64748b" },
    dark: { page: "#464a5b", surf: "#292e27", line: "#364325", ink: "#eef6dc", muted: "#9fac90", lav: "#1f2122", a: "#84cc16", aInk: "#a3e635", aHi: "#a3e635", onA: "#1c2507", b: "#cbd5e1", bHi: "#94a3b8" },
  },
  {
    id: "emerald",
    name: "Emerald Ink + Champagne",
    tagline: "Emerald counter with champagne rooms — quiet luxury.",
    light: { page: "#f7eedb", surf: "#e1efeb", line: "#c3dfd7", ink: "#0c2f22", muted: "#7f8a70", lav: "#d4e8e2", a: "#047857", aInk: "#047857", aHi: "#10b981", onA: "#ffffff", b: "#8a6d1f", bHi: "#d9b45c" },
    dark: { page: "#1d5a4c", surf: "#342a2d", line: "#4f4132", ink: "#e8f2e0", muted: "#90a894", lav: "#282026", a: "#10b981", aInk: "#34d399", aHi: "#34d399", onA: "#06251a", b: "#e6cd8a", bHi: "#d9b45c" },
  },
  {
    id: "iris",
    name: "Butter Yellow + Royal Iris",
    tagline: "Butter-yellow counter against royal iris rooms — sunny and regal.",
    light: { page: "#faf0cb", surf: "#eae9fd", line: "#d5d3fb", ink: "#2f2404", muted: "#96895f", lav: "#e1e0fc", a: "#f5c51e", aInk: "#8f6c05", aHi: "#fada4a", onA: "#251c02", b: "#4f46e5", bHi: "#4f46e5" },
    dark: { page: "#3e4176", surf: "#332b29", line: "#4c4229", ink: "#faf0c8", muted: "#a29dc8", lav: "#272123", a: "#f5d020", aInk: "#fde047", aHi: "#fde047", onA: "#251c02", b: "#a5b4fc", bHi: "#818cf8" },
  },
  {
    id: "blaze",
    name: "Vivid Ember + Light Cream",
    tagline: "Vivid ember-orange counter on light-cream rooms — bold canteen warmth.",
    light: { page: "#f7f0e1", surf: "#fcebe2", line: "#fad7c5", ink: "#3a1c05", muted: "#a08f70", lav: "#fbe3d6", a: "#ea580c", aInk: "#c2410c", aHi: "#fb923c", onA: "#ffffff", b: "#a9834a", bHi: "#d9b978" },
    dark: { page: "#633b25", surf: "#322b34", line: "#473f3d", ink: "#f9ecd4", muted: "#b39c7e", lav: "#26202a", a: "#f97316", aInk: "#fb923c", aHi: "#fb923c", onA: "#2a1203", b: "#e0cd9d", bHi: "#d9c48f" },
  },
  {
    id: "neon",
    name: "Neon Green + Charcoal",
    tagline: "Electric green counter on charcoal rooms — neon-sign night market.",
    light: { page: "#e4f5e4", surf: "#e8e9e9", line: "#d1d2d3", ink: "#0a2913", muted: "#6f8a76", lav: "#dedfe0", a: "#22c55e", aInk: "#15803d", aHi: "#4ade80", onA: "#052e12", b: "#3f4449", bHi: "#5d646a" },
    dark: { page: "#454752", surf: "#1e2d31", line: "#214137", ink: "#e2f3e5", muted: "#93a89a", lav: "#182128", a: "#22c55e", aInk: "#4ade80", aHi: "#4ade80", onA: "#052e12", b: "#b6bec4", bHi: "#99a2a9" },
  },
  {
    id: "cherry",
    name: "Cherry Red + Porcelain",
    tagline: "Cherry-red counter on porcelain white — crisp diner classic.",
    light: { page: "#f2f4f5", surf: "#fae4e8", line: "#f4c9d0", ink: "#3d0d16", muted: "#a07c80", lav: "#f7d9de", a: "#d21f3c", aInk: "#b01d3e", aHi: "#f2555a", onA: "#ffffff", b: "#9aa6b1", bHi: "#c3cbd3" },
    dark: { page: "#632f3f", surf: "#2f2c3e", line: "#424250", ink: "#f9e5e8", muted: "#b18e94", lav: "#252231", a: "#ef4356", aInk: "#fb7185", aHi: "#fb7185", onA: "#ffffff", b: "#dbe2e8", bHi: "#b9c2cb" },
  },
  {
    id: "azure",
    name: "Azure Sky + Deep Navy",
    tagline: "Sky-blue counter on deep navy rooms — clear-day cockpit.",
    light: { page: "#e2effa", surf: "#e4e8f5", line: "#c9d1ec", ink: "#0a2440", muted: "#6f8ba0", lav: "#d9dff1", a: "#0284c7", aInk: "#0369a1", aHi: "#38bdf8", onA: "#ffffff", b: "#1e40af", bHi: "#3b82f6" },
    dark: { page: "#304b77", surf: "#1c2c45", line: "#1f4461", ink: "#e2eefb", muted: "#8ba3c4", lav: "#182136", a: "#38bdf8", aInk: "#7dd3fc", aHi: "#38bdf8", onA: "#04202e", b: "#93c5fd", bHi: "#60a5fa" },
  },
  {
    id: "cyanreef",
    name: "Reef Cyan + Storm Steel",
    tagline: "Reef-cyan counter on storm-steel rooms — aquarium calm.",
    light: { page: "#e0f3f5", surf: "#eff0f2", line: "#dee1e4", ink: "#072a33", muted: "#6f919a", lav: "#e8eaec", a: "#0891b2", aInk: "#0e7490", aHi: "#22d3ee", onA: "#ffffff", b: "#77828f", bHi: "#98a3b0" },
    dark: { page: "#454856", surf: "#223043", line: "#2b4d5d", ink: "#e0f3f6", muted: "#8facb5", lav: "#1c2334", a: "#22d3ee", aInk: "#67e8f9", aHi: "#67e8f9", onA: "#04262e", b: "#b9c3cd", bHi: "#9aa6b2" },
  },
];

export const themeById = (id: string): FxTheme => FX_THEMES.find((t) => t.id === id) ?? FX_THEMES[0];

/* ── storage + application (per signed-in account) ─────────────────────────── */

const LEGACY_KEY = "fx-theme";

export function fxThemeStorageKey(account?: string | null): string {
  const who = (account ?? "").trim().toLowerCase();
  return `fx-theme:${who || "guest"}`;
}

export function activeThemeId(): FxThemeId {
  if (typeof document === "undefined") return DEFAULT_THEME;
  const on = document.documentElement.dataset.fxTheme as FxThemeId | undefined;
  return on && FX_THEME_IDS.includes(on) ? on : DEFAULT_THEME;
}

export function readStoredTheme(account?: string | null): FxThemeId {
  try {
    const raw = localStorage.getItem(fxThemeStorageKey(account)) ?? localStorage.getItem(LEGACY_KEY);
    const id = raw as FxThemeId | null;
    return id && FX_THEME_IDS.includes(id) ? id : DEFAULT_THEME;
  } catch {
    return DEFAULT_THEME;
  }
}

/** Apply + persist for this account, then tell every listening chart. */
export function applyTheme(id: FxThemeId, account?: string | null, persist = true): void {
  const valid: FxThemeId = FX_THEME_IDS.includes(id) ? id : DEFAULT_THEME;
  document.documentElement.dataset.fxTheme = valid;
  if (persist) {
    try {
      localStorage.setItem(fxThemeStorageKey(account), valid);
    } catch {
      /* private mode */
    }
  }
  window.dispatchEvent(new CustomEvent("fx-theme-change", { detail: valid }));
}

/** The signed-in account identity (landing stores {name, role}). */
export function currentAccount(): string | null {
  try {
    const raw = localStorage.getItem("fx-auth");
    if (!raw) return null;
    const u = JSON.parse(raw) as { name?: string; email?: string };
    return u.email || u.name || null;
  } catch {
    return null;
  }
}
