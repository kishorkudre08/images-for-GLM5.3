"use client";

/**
 * t76 — resolves the live Fetch-X theme tokens to concrete colour strings so
 * charts (recharts sets SVG attributes, where CSS var() is unreliable) can
 * follow the account theme. Re-resolves on light/dark flips AND on
 * data-fx-theme changes (the /theme gallery dispatches fx-theme-change).
 */

import * as React from "react";

export type FxColors = {
  /** vivid accent A — chart strokes, donut slices, scope dots (restaurant) */
  purple: string;
  /** vivid accent B — bars, dots, stay-mix (lodge) */
  gold: string;
  /** bright A for gradients */
  purpleHi: string;
  /** B on the always-dark occupied room blocks */
  goldOnDark: string;
  /** the extra purple-family donut slice */
  accent3: string;
  /** readable text on solid accent backgrounds */
  onAccent: string;
  /** t91 — the wall's occupied slice (theme-following ink) */
  ink: string;
};

const TOKENS: Array<[keyof FxColors, string]> = [
  ["purple", "--fx-chart-a"],
  ["gold", "--fx-gold-hi"],
  ["purpleHi", "--fx-purple-hi"],
  ["goldOnDark", "--fx-gold-ondark"],
  ["accent3", "--fx-accent-3"],
  ["onAccent", "--fx-on-accent"],
  ["ink", "--fx-ink"],
];

function read(): FxColors {
  if (typeof window === "undefined") {
    // SSR-safe defaults (classic theme)
    return { purple: "#5b4fe9", gold: "#d9a441", purpleHi: "#8678f9", goldOnDark: "#e4c67c", accent3: "#8a7cf6", onAccent: "#ffffff", ink: "#1c1840" };
  }
  const cs = getComputedStyle(document.documentElement);
  const out = {} as FxColors;
  for (const [k, v] of TOKENS) {
    const val = cs.getPropertyValue(v).trim();
    out[k] = val || "#5b4fe9";
  }
  return out;
}

export function useFxColors(): FxColors {
  const [colors, setColors] = React.useState<FxColors>(read);

  React.useEffect(() => {
    const refresh = () => setColors(read());
    const ro = new MutationObserver(refresh);
    ro.observe(document.documentElement, { attributes: true, attributeFilter: ["class", "data-fx-theme"] });
    window.addEventListener("fx-theme-change", refresh);
    return () => {
      ro.disconnect();
      window.removeEventListener("fx-theme-change", refresh);
    };
  }, []);

  return colors;
}
