/**
 * t76 — the numbered tier bands, in ONE place. "Re-number the tier according
 * to the account" = every section the signed-in account opens shows its band
 * number from this registry, so the sequence 01→05 can never drift (the old
 * hard-coded strings had a duplicate TIER 03). Adding/removing a section for
 * an account tier is a one-line edit here.
 */

export const FX_TIERS = {
  dashboard: { num: "01", label: "OWNER INTELLIGENCE" },
  tasks: { num: "02", label: "OWNER'S TASKS" },
  pos: { num: "03", label: "CASHIER BILLING" },
  menu: { num: "03", label: "MENU MANAGER" }, // t115 — the owner's menu control (billing stays at the reception)
  expenses: { num: "04", label: "COST LEDGER" },
  lodge: { num: "05", label: "LODGE" },
  management: { num: "06", label: "TEAM & SALARIES" }, // t113 — renamed Employee
  attendance: { num: "07", label: "STAFF ATTENDANCE" }, // t113 — the receptions' 4th section
  settings: { num: "08", label: "ACCOUNT SETTINGS" },
} as const;

export type FxTierKey = keyof typeof FX_TIERS;

export const tierEyebrow = (t: { num: string; label: string }): string => `TIER ${t.num} · ${t.label}`;
