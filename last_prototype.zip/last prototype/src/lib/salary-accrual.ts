import { db } from "@/lib/db";
import { getPaidHolidayLimit } from "@/lib/settings";

// ── t129 · ATTENDANCE-DERIVED SALARY ACCRUAL ────────────────────────────────
// "keep updating this month, this week, today employee salary according to the
// employee attendance" + "the recalculated paid salary should be considered as
// the given business's employee salary".
//
// Every calendar day (IST) accrues an employee's day-wage — monthly salary ÷
// days in THAT month — when the register marks them PRESENT, or when they are
// ABSENT inside that month's paid-holiday allowance (the first `limit`
// absences of the month, the exact rule /api/salaries settles by). Absent
// beyond the allowance, and unmarked days, accrue nothing. A settled month's
// total therefore equals its frozen netPaid, while the running month updates
// live as the receptions mark attendance — no settlement needed.

export type Accrual = { total: number; rest: number; lodge: number };

const IST_FMT = new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Kolkata" });

/** IST calendar day (YYYY-MM-DD) of an instant. */
export function istKeyOf(d: Date): string {
  return IST_FMT.format(d);
}

function addDaysKey(key: string, n: number): string {
  const [y, m, d] = key.split("-").map(Number);
  return IST_FMT.format(new Date(y, m - 1, d + n));
}

function daysInMonthOf(key: string): number {
  const [y, m] = key.split("-").map(Number);
  return new Date(y, m, 0).getDate();
}

/**
 * Salary accrued across the IST window [fromKey … toKey] (inclusive), split by
 * book. Attendance from the window's first month-start is loaded so each
 * month's paid-holiday allowance counts absences from the 1st, not from the
 * window edge — windows that cross a month boundary stay exact.
 */
export async function accrueSalaries(fromKey: string, toKey: string): Promise<Accrual> {
  const [emps, limit] = await Promise.all([
    db.employee.findMany({
      where: { active: true },
      select: { id: true, salary: true, book: true },
    }),
    getPaidHolidayLimit(),
  ]);
  const out: Accrual = { total: 0, rest: 0, lodge: 0 };
  if (emps.length === 0) return out;

  // month-start ≤ fromKey so the allowance ordinals are complete
  const fetchFrom = `${fromKey.slice(0, 7)}-01`;
  const rows = await db.attendance.findMany({
    where: { employeeId: { in: emps.map((e) => e.id) }, date: { gte: fetchFrom, lte: toKey } },
    select: { employeeId: true, date: true, status: true },
  });

  // employeeId → (dateKey → status)
  const statusOf = new Map<string, Map<string, string>>();
  for (const r of rows) {
    let m = statusOf.get(r.employeeId);
    if (!m) {
      m = new Map();
      statusOf.set(r.employeeId, m);
    }
    m.set(r.date, r.status);
  }

  for (const e of emps) {
    const marks = statusOf.get(e.id);
    if (!marks || marks.size === 0) continue;
    const book = e.book === "lodge" ? "lodge" : "rest";

    // walk the window day by day, tracking each month's absence ordinal
    let cursor = fromKey;
    let monthAbsences = 0;
    let monthCursor = cursor.slice(0, 7);
    // count absences of the first month that fall BEFORE the window (from the
    // month's 1st up to fromKey−1) so the ordinal inside the window is exact
    for (const [date, st] of marks) {
      if (st === "absent" && date.slice(0, 7) === monthCursor && date < fromKey) monthAbsences++;
    }
    // wages change at the month boundary (per-day = salary ÷ that month's length)
    let perDay = e.salary / daysInMonthOf(cursor);

    while (cursor <= toKey) {
      const mk = cursor.slice(0, 7);
      if (mk !== monthCursor) {
        monthCursor = mk;
        monthAbsences = 0; // allowance resets on the 1st
        perDay = e.salary / daysInMonthOf(cursor);
      }
      const st = marks.get(cursor);
      if (st === "present") {
        out[book] += perDay;
      } else if (st === "absent") {
        monthAbsences += 1;
        if (monthAbsences <= limit) out[book] += perDay; // inside the paid-holiday allowance
      }
      cursor = addDaysKey(cursor, 1);
    }
  }

  out.rest = Math.round(out.rest * 100) / 100;
  out.lodge = Math.round(out.lodge * 100) / 100;
  out.total = Math.round((out.rest + out.lodge) * 100) / 100;
  return out;
}
