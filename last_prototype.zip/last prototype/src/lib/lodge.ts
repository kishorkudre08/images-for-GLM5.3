// Lodge domain logic — shared by the API route and the front-desk UI.
// Ported 1:1 from the approved demo engine so the math never drifts:
// stays bill to the hour — rate × hours ÷ 24, never below the ₹1,000 floor,
// then 5% GST (CGST 2.5% + SGST 2.5%).

export const LG_MIN = 1000;

export type LgTier = { from: number; to: number; rate: number; label: string; name: string };

export const LG_TIERS: LgTier[] = [
  { from: 1, to: 40, rate: 2499, label: "ROOMS 1 – 40", name: "BASIC" },
  { from: 41, to: 80, rate: 2999, label: "ROOMS 41 – 80", name: "STANDARD" },
  { from: 81, to: 100, rate: 3999, label: "ROOMS 81 – 100", name: "LUXURY" },
];

export function lgTier(n: number): LgTier {
  return n <= 40 ? LG_TIERS[0] : n <= 80 ? LG_TIERS[1] : LG_TIERS[2];
}

export type StayMath = { raw: number; stay: number; min: boolean };

export function lgStay(rate: number, hours: number): StayMath {
  const raw = Math.round((rate * hours) / 24);
  const min = raw < LG_MIN;
  return { raw, stay: min ? LG_MIN : raw, min };
}

/** "13 h" · "0.5 h" · "26.75 h" — the formula line shown on the bill preview. */
export function fmtHrs(hours: number): string {
  const v = Math.round(hours * 100) / 100;
  const s = v % 1 === 0 ? String(Math.round(v)) : v.toFixed(2).replace(/0+$/, "").replace(/\.$/, "");
  return `${s} h`;
}

/** "1 d 2 h 30 m" — human stay duration. */
export function fmtDur(hours: number): string {
  const mins = Math.max(0, Math.round(hours * 60));
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  let txt = h >= 24 ? `${Math.floor(h / 24)} d ${h % 24} h` : `${h} h`;
  if (m) txt += ` ${m} m`;
  return txt;
}

// ── Editable lodge levels (Management · ROOMS & RATES) ─────────────────────
// The wall's tiers are no longer hard-coded: the owner can move boundaries
// (grow/shrink), reprice each level and add levels. The config lives in
// Setting.lodgeLevels as JSON and is validated on every read.

export type Level = { from: number; to: number; rate: number; name: string };

export const DEFAULT_LEVELS: Level[] = [
  { from: 1, to: 40, rate: 2499, name: "BASIC" },
  { from: 41, to: 80, rate: 2999, name: "STANDARD" },
  { from: 81, to: 100, rate: 3999, name: "LUXURY" },
];

export const LG_ROOMS = 100; // the DEFAULT wall size (the live max lives in Setting.lodgeMaxRooms)

// t116 — the wall's maximum room is flexible: the owner may grow it anytime,
// but a reduce only lands once every room being cut is FREE (the owner waits).
export const LG_ROOMS_MIN = 10;
export const LG_ROOMS_MAX = 500;
export const MAX_ROOMS_KEY = "lodgeMaxRooms";

/** Setting value → the live wall size, clamped to sane bounds (default 100). */
export function parseMaxRooms(raw: string | null | undefined): number {
  const n = Math.round(Number(raw));
  if (!Number.isFinite(n)) return LG_ROOMS;
  return Math.min(LG_ROOMS_MAX, Math.max(LG_ROOMS_MIN, n));
}

/** Validate + normalize a levels config against the given wall size. Returns null when unusable. */
export function parseLevels(raw: string | null | undefined, max: number = LG_ROOMS): Level[] | null {
  if (!raw) return null;
  let arr: unknown;
  try { arr = JSON.parse(raw); } catch { return null; }
  if (!Array.isArray(arr) || arr.length === 0) return null;
  const levels: Level[] = [];
  for (const it of arr) {
    const from = Math.round(Number((it as Level).from));
    const to = Math.round(Number((it as Level).to));
    const rate = Math.round(Number((it as Level).rate));
    const name = String((it as Level).name ?? "").trim().toUpperCase();
    if (!Number.isFinite(from) || !Number.isFinite(to) || !Number.isFinite(rate)) return null;
    if (from < 1 || to > max || from > to || rate < 100) return null;
    if (!name || name.length > 16) return null;
    levels.push({ from, to, rate, name });
  }
  levels.sort((a, b) => a.from - b.from);
  // must cover 1..max exactly once, no gaps/overlaps
  let expect = 1;
  for (const l of levels) {
    if (l.from !== expect) return null;
    expect = l.to + 1;
  }
  if (expect !== max + 1) return null;
  return levels;
}

/** Fit a levels config to the wall's size — the last level's `to` always
 *  lands exactly on `max`: stretched when the wall grows, clamped when it
 *  shrinks (levels fully above the new max are dropped). The first level
 *  always starts at 1, so the result always covers 1..max exactly. */
export function fitLevelsToMax(levels: Level[], max: number): Level[] {
  const kept = levels.filter((l) => l.from <= max).map((l) => ({ ...l }));
  if (!kept.length) return [{ ...levels[0], from: 1, to: max }];
  kept[kept.length - 1].to = max;
  return kept;
}

export function tierOfRoom(n: number, levels: Level[]): Level {
  for (const l of levels) if (n >= l.from && n <= l.to) return l;
  return levels[levels.length - 1];
}

/** "ROOMS 1 – 40" chip label for a level. */
export function levelLabel(l: Level): string {
  return `ROOMS ${l.from} – ${l.to}`;
}
