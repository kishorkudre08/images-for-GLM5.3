import { db } from "@/lib/db";
import { HOTEL_DEFAULT } from "@/lib/brand";

export const HOTEL_NAME_KEY = "hotelName";

/** Server-side read of the variable hotel identity (falls back to the default). */
export async function getHotelName(): Promise<string> {
  const row = await db.setting.findUnique({ where: { key: HOTEL_NAME_KEY } });
  const name = row?.value.trim();
  return name ? name : HOTEL_DEFAULT.name;
}

/** Upsert the hotel name (validated 2–40 chars). Returns the stored value. */
export async function setHotelName(raw: string): Promise<string> {
  const name = raw.trim().replace(/\s+/g, " ").slice(0, 40);
  if (name.length < 2) throw new Error("Hotel name needs at least 2 characters.");
  await db.setting.upsert({
    where: { key: HOTEL_NAME_KEY },
    update: { value: name },
    create: { key: HOTEL_NAME_KEY, value: name },
  });
  return name;
}

// ── t126 · PAID HOLIDAYS LIMIT — the salary rule lives in Settings ──────────
// Attendance is DERIVED from the receptions' register — the owner never
// hand-edits it. The only lever is ONE global allowance: how many paid
// holidays each employee gets per month before absences start cutting pay.
export const PAID_HOLIDAY_LIMIT_KEY = "paidHolidayLimit";
export const PAID_HOLIDAY_LIMIT_DEFAULT = 3;

/** Server-side read of the paid holidays limit (falls back to 3). */
export async function getPaidHolidayLimit(): Promise<number> {
  const row = await db.setting.findUnique({ where: { key: PAID_HOLIDAY_LIMIT_KEY } });
  const n = Math.floor(Number(row?.value));
  return Number.isFinite(n) && n >= 0 ? Math.min(n, 31) : PAID_HOLIDAY_LIMIT_DEFAULT;
}

/** Upsert the paid holidays limit (validated 0–31). Returns the stored value. */
export async function setPaidHolidayLimit(raw: number): Promise<number> {
  const n = Math.floor(Number(raw));
  if (!Number.isFinite(n) || n < 0 || n > 31)
    throw new Error("Paid holidays limit must be a whole number between 0 and 31.");
  await db.setting.upsert({
    where: { key: PAID_HOLIDAY_LIMIT_KEY },
    update: { value: String(n) },
    create: { key: PAID_HOLIDAY_LIMIT_KEY, value: String(n) },
  });
  return n;
}
