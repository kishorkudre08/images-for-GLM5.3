/**
 * Self-healing startup — runs once when the Next.js server boots, before any
 * route can import the database client.
 *
 * If the generated Prisma client is missing or half-built (fresh extraction,
 * interrupted npm install, postinstall skipped), the server simply generates
 * it right here. That makes "@prisma/client did not initialize yet" a thing
 * of the past: however the app is launched (npm run dev:w, npx next dev, …),
 * the first boot repairs itself.
 *
 * Node APIs are reached through a runtime-evaluated import (new Function) so
 * the Edge build of this file — which never executes them — stays clean.
 */
type FsLike = { existsSync: (p: string) => boolean };
type PathLike = { resolve: (...s: string[]) => string; join: (...s: string[]) => string };
type CpLike = { execSync: (cmd: string, opts?: Record<string, unknown>) => unknown };

export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;
  const g = globalThis as unknown as { fxCliHealed?: boolean };
  if (g.fxCliHealed) return;
  g.fxCliHealed = true;

  try {
    const dynImport = new Function("m", "return import(m);") as (m: string) => Promise<Record<string, unknown>>;
    const { existsSync } = (await dynImport("fs")) as unknown as FsLike;
    const path = (await dynImport("path")) as unknown as PathLike;

    // path.resolve("") === cwd, without calling process.cwd here. Pinned into
    // the env BEFORE any route (and therefore db.ts) loads, so the database
    // locator has a trustworthy base even if some later worker changes cwd.
    // (The launcher sets the same variable from its own cwd; whoever runs
    // first wins — both point at the real project folder.)
    if (!process.env.FX_PROJECT_DIR) process.env.FX_PROJECT_DIR = path.resolve("");

    // db.ts reads FX_PROJECT_DIR lazily; routes can only load after this hook
    // (instrumentation registers before any route) — so the pin above covers
    // non-launcher launches too (npx next dev, bun dev).
    const base = process.env.FX_PROJECT_DIR as string;
    const clientDir = path.resolve(base, "node_modules", ".prisma", "client");
    const ready =
      existsSync(path.join(clientDir, "default.js")) &&
      existsSync(path.join(clientDir, "index.js")) &&
      existsSync(path.join(clientDir, "schema.prisma"));
    if (ready) return;

    const cli = path.resolve(base, "node_modules", "prisma", "build", "index.js");
    if (!existsSync(cli)) {
      console.error("[fetchx] Prisma client not generated and CLI not found — run: npm install");
      return;
    }

    console.log("[fetchx] Prisma client not generated yet — generating now (one time, ~10s)…");
    const { execSync } = (await dynImport("child_process")) as unknown as CpLike;
    // Plain "node" (NOT process.execPath — referencing Node APIs here trips the
    // Edge-runtime linter). "node" is always on PATH in any environment that
    // could run this server at all.
    execSync(`node "${cli}" generate`, { stdio: "inherit", timeout: 180_000 });
    console.log("[fetchx] Prisma client ready.");
  } catch (e) {
    console.error("[fetchx] Auto-generate failed — run manually: npx prisma generate");
    console.error(String((e as Error)?.message ?? e).split("\n").slice(0, 6).join("\n"));
  }
}
