"use client";

/**
 * Fetch-X motion layer (restored at t94, reworked at t99).
 *
 * Mouse-follow — ONE rAF-throttled document mousemove listener finds the
 * [data-fx-motion] card under the cursor and writes the normalized offsets
 * (--mx / --my, −1…1) onto THAT element alone; the previous card is zeroed on
 * switch. Only the card the mouse is on ever drifts — never more than one at
 * a time. The drift rides the standalone `translate` property (compose-safe
 * with hover transforms), capped at MAX_SHIFT px.
 *
 * The same component arms the entrance observer: every .fx-rise element pops
 * in (fxPopIn) the first time it scrolls into view, then the classes are
 * stripped on animationend so the parallax translate takes over cleanly.
 *
 * Reduced-motion users get static content; touch devices get entrances but
 * no cursor follow.
 */

import * as React from "react";

export const MAX_SHIFT = 9; // px — the drift ceiling for [data-fx-motion="3"]

export function FxMotion() {
  React.useEffect(() => {
    const calm = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (calm) return;

    /* ── entrance observer — always on (touch included) ── */
    const io = new IntersectionObserver(
      (es) =>
        es.forEach((en) => {
          if (!en.isIntersecting) return;
          const el = en.target as HTMLElement;
          el.style.setProperty("--fx-delay", `${Number(el.dataset.fxDelay ?? 0) * 70}ms`);
          el.classList.add("fx-in");
          io.unobserve(el);
        }),
      { threshold: 0.12 },
    );

    /* every card is a candidate: auto-arm .fx-card blocks (skipping anything
       inside dialogs/popovers where drift feels wrong) */
    const tagCards = () => {
      document.querySelectorAll<HTMLElement>(".fx-card:not([data-fx-motion])").forEach((el) => {
        if (el.closest("[role='dialog'], [data-radix-popper-content-wrapper]")) return;
        el.dataset.fxMotion = "1";
      });
    };

    const arm = () => {
      tagCards();
      document.querySelectorAll(".fx-rise:not(.fx-in)").forEach((el) => io.observe(el));
    };
    arm();
    /* t129 — also watch CLASS changes: when React rewrites an element's
       className after the pop-in stripped fx-rise/fx-in (e.g. a task card
       toggling its open state), "fx-rise" comes back and the element sits at
       opacity 0 forever — the observer never re-armed because classList edits
       are attribute mutations, not childList. Watching classes re-arms the
       entrance instantly. */
    const mo = new MutationObserver(arm);
    mo.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["class"] });

    /* strip entrance classes after the pop so the follow owns the translate */
    const onAnimEnd = (e: AnimationEvent) => {
      const t = e.target as HTMLElement | null;
      if (!t || e.animationName !== "fxPopIn") return;
      if (t.classList.contains("fx-in")) {
        t.classList.remove("fx-in", "fx-rise");
        t.style.removeProperty("--fx-delay");
      }
    };
    document.addEventListener("animationend", onAnimEnd);

    /* ── t99 mouse-follow: the card under the cursor, and only that card ── */
    const zero = (el: HTMLElement | null) => {
      if (!el) return;
      el.style.setProperty("--mx", "0");
      el.style.setProperty("--my", "0");
    };

    let raf = 0;
    let lastX = 0;
    let lastY = 0;
    let lastTarget: EventTarget | null = null;
    let hovered: HTMLElement | null = null;

    const apply = () => {
      raf = 0;
      /* real events carry the element under the cursor — the cheapest path.
         Synthetic events (window target) fall back to elementFromPoint. */
      let el: HTMLElement | null = null;
      if (lastTarget && typeof (lastTarget as Element).closest === "function") {
        el = ((lastTarget as Element).closest("[data-fx-motion]") as HTMLElement | null) ?? null;
      }
      if (!el) {
        const hit = document.elementFromPoint(lastX, lastY);
        el = (hit?.closest("[data-fx-motion]") as HTMLElement | null) ?? null;
      }
      if (el !== hovered) {
        zero(hovered); // the previous card settles back — only one ever moves
        hovered = el;
      }
      if (!el) return;
      const r = el.getBoundingClientRect();
      const nx = Math.max(-1, Math.min(1, ((lastX - r.left) / Math.max(1, r.width)) * 2 - 1));
      const ny = Math.max(-1, Math.min(1, ((lastY - r.top) / Math.max(1, r.height)) * 2 - 1));
      el.style.setProperty("--mx", nx.toFixed(4));
      el.style.setProperty("--my", ny.toFixed(4));
    };

    const onMove = (e: MouseEvent) => {
      lastX = e.clientX;
      lastY = e.clientY;
      lastTarget = e.target;
      if (!raf) raf = requestAnimationFrame(apply);
    };
    const onLeave = () => {
      if (raf) {
        cancelAnimationFrame(raf);
        raf = 0;
      }
      zero(hovered);
      hovered = null;
    };

    const fine = window.matchMedia("(pointer: fine)").matches;
    if (fine) {
      window.addEventListener("mousemove", onMove, { passive: true });
      document.documentElement.addEventListener("mouseleave", onLeave);
    }

    return () => {
      io.disconnect();
      mo.disconnect();
      document.removeEventListener("animationend", onAnimEnd);
      if (fine) {
        window.removeEventListener("mousemove", onMove);
        document.documentElement.removeEventListener("mouseleave", onLeave);
      }
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  return null;
}
