"use client";

// ── t98 · ROOMS & RATES — the level categorizer, relocated ──────────────────
// Picked out of Management and pasted at the bottom of the Lodge Front Desk
// so the wall's own station edits its own levels. Same logic as before: name
// each level, set its room range and the 24-hour charge; ranges must cover
// every room exactly once (start at 1, end at the wall's max, no gaps or
// overlaps).
// t116 — the wall's MAX ROOMS is flexible: grow it anytime (new rooms arrive
// green), but a reduce only lands once every room being cut is FREE — until
// then the apply stays locked and the wait panel names the busy rooms.

import * as React from "react";
import { BedDouble, Loader2, Plus, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { DEFAULT_LEVELS, LG_ROOMS, LG_ROOMS_MAX, LG_ROOMS_MIN, type Level } from "@/lib/lodge";
import type { Room } from "@/lib/types";

export function RoomLevelsEditor() {
  const { toast } = useToast();

  const [levels, setLevels] = React.useState<Level[] | null>(null);
  const [levelsDraft, setLevelsDraft] = React.useState<Array<{ name: string; from: string; to: string; rate: string }>>([]);
  const [levelsBusy, setLevelsBusy] = React.useState(false);
  const [armedRemove, setArmedRemove] = React.useState<number | null>(null);
  // t116 — the flexible wall size
  const [maxRooms, setMaxRooms] = React.useState<number>(LG_ROOMS);
  const [maxDraft, setMaxDraft] = React.useState<string>(String(LG_ROOMS));
  const [maxBusy, setMaxBusy] = React.useState(false);
  const [rooms, setRooms] = React.useState<Room[]>([]);

  const loadLevels = React.useCallback(async () => {
    try {
      const w = await fetch("/api/lodge", { cache: "no-store" }).then((x) => x.json());
      const lv: Level[] = Array.isArray(w.levels) && w.levels.length ? w.levels : DEFAULT_LEVELS;
      const mx = Math.round(Number(w.maxRooms));
      const live = Number.isFinite(mx) && mx > 0 ? mx : LG_ROOMS;
      setLevels(lv);
      setMaxRooms(live);
      setMaxDraft(String(live));
      setRooms(Array.isArray(w.rooms) ? w.rooms : []);
      setLevelsDraft(
        lv.map((l) => ({ name: l.name, from: String(l.from), to: String(l.to), rate: String(l.rate) })),
      );
    } catch {
      setLevels(null);
    }
  }, []);
  React.useEffect(() => {
    void loadLevels();
  }, [loadLevels]);

  // the wall breathes — re-check every minute so a reduce unlocks itself the
  // moment the rooms it wants to cut check out / finish maintenance
  React.useEffect(() => {
    const t = setInterval(() => void loadLevels(), 60000);
    return () => clearInterval(t);
  }, [loadLevels]);

  /* ── t116 · max-rooms guard — which rooms block a reduce right now ── */
  const newMax = Math.round(Number(maxDraft));
  const maxValid = Number.isFinite(newMax) && newMax >= LG_ROOMS_MIN && newMax <= LG_ROOMS_MAX;
  const cutBusy = React.useMemo(
    () =>
      maxValid && newMax < maxRooms
        ? rooms.filter((r) => r.number > newMax && r.status !== "avl").map((r) => ({ n: r.number, st: r.status }))
        : [],
    [rooms, newMax, maxRooms, maxValid],
  );
  const maxApplyable = maxValid && !maxBusy && cutBusy.length === 0;

  const applyMaxRooms = async () => {
    if (!maxApplyable) return;
    setMaxBusy(true);
    try {
      const res = await fetch("/api/lodge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "max-rooms", maxRooms: newMax }),
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Could not change the wall size");
      toast({
        title: `Wall now runs room 1 – ${newMax}`,
        description:
          newMax > maxRooms
            ? "The new rooms joined the last level as free — the picker, tooltips and dashboard rebuilt."
            : "The cut rooms and their level boundary are gone — past bills keep their snapshots.",
      });
      window.dispatchEvent(new Event("fx-lodge-changed")); // t116 — the wall above rebuilds now
      await loadLevels();
    } catch (e) {
      toast({
        title: "Could not change the wall size",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
      await loadLevels();
    } finally {
      setMaxBusy(false);
    }
  };

  const setLvlAt = (i: number, patch: Partial<{ name: string; from: string; to: string; rate: string }>) =>
    setLevelsDraft((m) => m.map((r, j) => (j === i ? { ...r, ...patch } : r)));

  const levelsCheck = (): { ok: boolean; msg: string | null; bad: Set<number> } => {
    const bad = new Set<number>();
    const rows = levelsDraft.map((r) => ({
      name: r.name.trim().toUpperCase(),
      from: Math.round(Number(r.from)),
      to: Math.round(Number(r.to)),
      rate: Math.round(Number(r.rate)),
      i: 0,
    }));
    if (!rows.length) return { ok: false, msg: "Add at least one level.", bad };
    rows.forEach((r, i) => {
      r.i = i;
      if (!r.name) bad.add(i);
      if (!Number.isFinite(r.rate) || r.rate < 100) bad.add(i);
      if (!Number.isFinite(r.from) || !Number.isFinite(r.to) || r.from < 1 || r.to > maxRooms || r.from > r.to)
        bad.add(i);
    });
    const sorted = [...rows].sort((a, b) => a.from - b.from);
    let msg: string | null = null;
    if (sorted.some((r) => bad.has(r.i))) {
      msg = `Fix the highlighted rows — every level needs a name, a rate of at least ₹100, and a low → high range inside 1 – ${maxRooms}.`;
    } else {
      for (let j = 1; j < sorted.length; j++) {
        const prev = sorted[j - 1];
        const cur = sorted[j];
        if (cur.from <= prev.to) {
          bad.add(prev.i);
          bad.add(cur.i);
          msg = `OVERLAP — "${prev.name}" and "${cur.name}" both claim rooms ${cur.from}–${Math.min(prev.to, cur.to)}. No two levels may share a room.`;
          break;
        }
        if (cur.from > prev.to + 1) {
          bad.add(prev.i);
          bad.add(cur.i);
          msg = `GAP — rooms ${prev.to + 1}–${cur.from - 1} belong to no level. Extend "${prev.name}" or "${cur.name}" to cover them.`;
          break;
        }
      }
      if (!msg) {
        if (sorted[0].from !== 1) {
          bad.add(sorted[0].i);
          msg = `The first level must start at room 1 — it starts at ${sorted[0].from}.`;
        } else if (sorted[sorted.length - 1].to !== maxRooms) {
          bad.add(sorted[sorted.length - 1].i);
          msg = `The last level must end at room ${maxRooms} — it ends at ${sorted[sorted.length - 1].to}.`;
        } else {
          const names = rows.map((r) => r.name);
          if (new Set(names).size !== names.length) {
            rows.forEach((r, i) => {
              if (names.indexOf(r.name) !== i) bad.add(i);
            });
            msg = "Two levels share a name — rename one.";
          }
        }
      }
    }
    return { ok: !msg, msg, bad };
  };
  const lvCheck = levelsCheck();

  const applyLevels = async () => {
    if (!lvCheck.ok || levelsBusy) return;
    const payload = levelsDraft.map((r) => ({
      name: r.name.trim().toUpperCase(),
      from: Math.round(Number(r.from)),
      to: Math.round(Number(r.to)),
      rate: Math.round(Number(r.rate)),
    }));
    setLevelsBusy(true);
    try {
      const res = await fetch("/api/lodge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "levels-apply", levels: payload }),
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Apply failed");
      setLevels(out.levels ?? payload);
      window.dispatchEvent(new Event("fx-lodge-changed")); // t116 — the wall above rebuilds now
      toast({
        title: `Levels applied — ${payload.length} across ${maxRooms} rooms`,
        description: "The wall, check-in picker, tooltips and the dashboard's revenue-by-level all rebuild.",
      });
    } catch (e) {
      toast({
        title: "Could not apply levels",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setLevelsBusy(false);
    }
  };

  const addLevel = () => {
    if (levelsDraft.length >= 8) {
      toast({ title: "Eight levels is plenty", description: "Split further only if the wall really needs it." });
      return;
    }
    let wi = 0;
    let w = 0;
    levelsDraft.forEach((t, i) => {
      const sz = (Number(t.to) || 0) - (Number(t.from) || 0) + 1;
      if (sz > w) {
        w = sz;
        wi = i;
      }
    });
    if (w < 2) {
      toast({ title: "Nothing left to split", description: "Every level is a single room — remove one instead." });
      return;
    }
    const t = levelsDraft[wi];
    const mid = Math.round(Number(t.from)) + Math.ceil(w / 2) - 1;
    setLevelsDraft((m) => {
      const copy = [...m];
      copy.splice(
        wi,
        1,
        { name: `${t.name} A`, from: t.from, to: String(mid), rate: t.rate },
        { name: `${t.name} B`, from: String(mid + 1), to: t.to, rate: t.rate },
      );
      return copy;
    });
    toast({ title: "Level split — apply to save", description: "Rename both halves and set their charges, then APPLY LEVELS." });
  };

  const removeLevel = (i: number) => {
    setLevelsDraft((m) => {
      const copy = [...m];
      const gone = copy.splice(i, 1)[0];
      if (copy.length) {
        if (copy[i - 1]) copy[i - 1].to = gone.to; // merge into the previous neighbour
        else copy[0].from = gone.from; // first level merges forward into the next
      }
      return copy;
    });
  };

  return (
    <div className="fx-card fx-rise p-5" data-testid="room-levels-editor" data-fx-motion="1">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="fx-label inline-flex items-center gap-2">
          <BedDouble className="h-3.5 w-3.5" /> ROOMS &amp; RATES · THE LEVEL CATEGORIZER
        </span>
        <span className="mut-chip">
          {maxRooms} ROOMS · {levels?.length ?? "–"} LEVELS
        </span>
      </div>
      <p className="mt-2 text-[10.5px] font-semibold text-[var(--fx-muted)]">
        Name each level, set its room range and the 24-hour charge. Ranges must cover every room
        exactly once: start at room 1, end at room {maxRooms}, no gaps or overlaps. ADD LEVEL splits
        the widest level; REMOVE merges a level into its neighbour.
      </p>
      <div className="mt-3 flex flex-col gap-2">
        {levelsDraft.map((t, i) => {
          const bad = lvCheck.bad.has(i);
          return (
            <div key={i} className="flex flex-wrap items-center gap-2">
              <span
                className={`h-2.5 w-2.5 shrink-0 rounded-full ${
                  bad ? "bg-[var(--fx-rose)]" : i % 3 === 0 ? "bg-[var(--fx-green)]" : i % 3 === 1 ? "bg-[#f97316]" : "bg-[var(--fx-purple)]"
                }`}
                aria-hidden
              />
              <Input
                value={t.name}
                onChange={(e) => setLvlAt(i, { name: e.target.value })}
                placeholder="Level name"
                aria-label={`Level ${i + 1} name`}
                className={`h-9 min-w-[120px] flex-[1.4] rounded-xl bg-[var(--fx-page)] font-bold ${bad ? "border-[var(--fx-rose)]" : "border-[var(--fx-line)]"}`}
              />
              <Input
                value={t.from}
                onChange={(e) => setLvlAt(i, { from: e.target.value })}
                type="number"
                min={1}
                aria-label={`Level ${i + 1} first room`}
                className={`fx-num h-9 w-[76px] rounded-xl bg-[var(--fx-page)] font-bold ${bad ? "border-[var(--fx-rose)]" : "border-[var(--fx-line)]"}`}
              />
              <Input
                value={t.to}
                onChange={(e) => setLvlAt(i, { to: e.target.value })}
                type="number"
                min={1}
                aria-label={`Level ${i + 1} last room`}
                className={`fx-num h-9 w-[76px] rounded-xl bg-[var(--fx-page)] font-bold ${bad ? "border-[var(--fx-rose)]" : "border-[var(--fx-line)]"}`}
              />
              <Input
                value={t.rate}
                onChange={(e) => setLvlAt(i, { rate: e.target.value })}
                type="number"
                min={0}
                aria-label={`Level ${i + 1} charge per 24 hours`}
                className={`fx-num h-9 w-[92px] rounded-xl bg-[var(--fx-page)] font-bold ${bad ? "border-[var(--fx-rose)]" : "border-[var(--fx-line)]"}`}
              />
              <span className="text-[9.5px] font-extrabold tracking-[0.08em] text-[var(--fx-muted)]">₹ / 24 H</span>
              {levelsDraft.length > 1 &&
                (armedRemove === i ? (
                  <Button
                    size="sm"
                    onClick={() => {
                      removeLevel(i);
                      setArmedRemove(null);
                    }}
                    className="h-9 rounded-xl bg-[var(--fx-rose)] px-3 text-[10px] font-extrabold tracking-wider text-white"
                  >
                    SURE?
                  </Button>
                ) : (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setArmedRemove(i)}
                    title="Merge this level into its neighbour"
                    className="h-9 rounded-xl border-[var(--fx-line)] bg-[var(--fx-surf)] px-3 text-[10px] font-extrabold tracking-wider text-[var(--fx-muted)]"
                  >
                    REMOVE
                  </Button>
                ))}
            </div>
          );
        })}
      </div>
      {lvCheck.msg && (
        <p
          role="alert"
          className="mt-3 rounded-xl border border-[var(--fx-rose)]/40 bg-[color-mix(in_srgb,var(--fx-rose)_8%,transparent)] px-3 py-2 text-[11px] font-bold text-[var(--fx-rose)]"
        >
          {lvCheck.msg}
        </p>
      )}

      {/* t116 — the flexible wall size: grow anytime, reduce only when free */}
      <div
        className="mt-4 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] p-3.5"
        data-testid="max-rooms-box"
      >
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="fx-label">MAX ROOMS · THE WALL'S SIZE</span>
          <span className="mut-chip">GROW ANYTIME · REDUCE ONLY WHEN THE CUT ROOMS ARE FREE</span>
        </div>
        <div className="mt-2.5 flex flex-wrap items-center gap-2">
          <Input
            value={maxDraft}
            onChange={(e) => setMaxDraft(e.target.value)}
            type="number"
            min={LG_ROOMS_MIN}
            max={LG_ROOMS_MAX}
            aria-label="Maximum room number"
            data-testid="max-rooms-input"
            className={`fx-num h-9 w-[112px] rounded-xl bg-[var(--fx-surf)] font-bold ${maxValid ? "border-[var(--fx-line)]" : "border-[var(--fx-rose)]"}`}
          />
          <Button
            onClick={() => void applyMaxRooms()}
            disabled={!maxApplyable}
            data-testid="max-rooms-apply"
            className="h-9 rounded-xl bg-[var(--fx-purple)] px-4 text-[11px] font-extrabold tracking-wider text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)] disabled:opacity-50"
          >
            {maxBusy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
            APPLY MAX ROOMS
          </Button>
          {maxValid && newMax === maxRooms && (
            <span className="text-[10px] font-extrabold tracking-[0.08em] text-[var(--fx-muted)]">
              CURRENT SIZE — CHANGE THE NUMBER TO GROW OR SHRINK
            </span>
          )}
          {maxValid && newMax > maxRooms && (
            <span className="text-[10px] font-extrabold tracking-[0.08em] text-[var(--fx-green)]">
              +{newMax - maxRooms} NEW ROOMS ARRIVE FREE THE MOMENT YOU APPLY
            </span>
          )}
        </div>
        {maxValid && newMax < maxRooms && cutBusy.length > 0 && (
          <div
            role="alert"
            data-testid="max-rooms-wait"
            className="mt-2.5 rounded-xl border border-[var(--fx-rose)]/40 bg-[color-mix(in_srgb,var(--fx-rose)_8%,transparent)] px-3 py-2 text-[11px] font-bold leading-snug text-[var(--fx-rose)]"
          >
            WAIT — the wall can't shrink yet. {cutBusy.slice(0, 8).map((b) => `Room ${b.n} (${b.st === "occ" ? "occupied" : "maintenance"})`).join(", ")}
            {cutBusy.length > 8 ? ` +${cutBusy.length - 8} more` : ""} must be free first. The Apply unlocks by
            itself the moment they check out / finish maintenance — no need to touch anything.
          </div>
        )}
        {maxValid && newMax < maxRooms && cutBusy.length === 0 && (
          <div className="mt-2.5 text-[10px] font-extrabold tracking-[0.08em] text-[var(--fx-rose)]">
            SHRINKING BY {maxRooms - newMax} ROOMS — ROOMS {newMax + 1} – {maxRooms} LEAVE THE WALL (PAST BILLS KEEP
            THEIR SNAPSHOTS)
          </div>
        )}
        {!maxValid && (
          <div className="mt-2.5 text-[10px] font-extrabold tracking-[0.08em] text-[var(--fx-rose)]">
            THE WALL RUNS BETWEEN {LG_ROOMS_MIN} AND {LG_ROOMS_MAX} ROOMS
          </div>
        )}
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <Button
          onClick={addLevel}
          className="h-9 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-surf)] px-4 text-[11px] font-extrabold tracking-wider text-[var(--fx-ink)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-lav)]"
        >
          <Plus className="h-3.5 w-3.5" /> ADD LEVEL
        </Button>
        <Button
          onClick={() => void applyLevels()}
          disabled={!lvCheck.ok || levelsBusy}
          className="h-9 rounded-xl bg-[var(--fx-purple)] px-4 text-[11px] font-extrabold tracking-wider text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)] disabled:opacity-50"
        >
          {levelsBusy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
          APPLY LEVELS
        </Button>
        {!lvCheck.ok && (
          <span className="text-[10px] font-extrabold tracking-[0.08em] text-[var(--fx-rose)]">
            FIX THE RANGES TO ENABLE APPLY
          </span>
        )}
      </div>
      <p className="mt-3 text-[10.5px] font-semibold text-[var(--fx-muted)]">
        APPLY LEVELS pushes them live — the wall above, the check-in picker, tooltips and the
        dashboard's revenue-by-level all rebuild. Bills already printed keep the rate that was
        charged.
      </p>
    </div>
  );
}
