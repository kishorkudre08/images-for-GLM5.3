"use client";

/**
 * t91/t92 — the lodge wall as one donut.
 *
 * The room-hours math stays server-side (analytics-lodge.ts); this donut only
 * ever DISPLAYS rooms: 24 room-hours fold back into one room, and the three
 * slices are the time-weighted share of the window, normalised so they always
 * sum to the 100-room wall. 40 rooms filled for 12 hours reads as 20 rooms —
 * never "%", never raw "room-days".
 *
 * Without `hours` (Lodge Front Desk live snapshot) it falls back to the
 * current room counts with each row's share of the wall.
 */

import * as React from "react";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import { useFxColors } from "@/lib/fx-colors";
import type { RoomHoursData } from "@/lib/types";

export type RoomStatusCounts = { avl: number; occ: number; mnt: number };

type StatusId = "free" | "guests" | "mnt";

const ORDER: StatusId[] = ["free", "guests", "mnt"];
const NAMES: Record<StatusId, string> = { free: "FREE", guests: "GUESTS", mnt: "MAINTENANCE" };

/** Largest-remainder rounding — integer rooms that always sum to `total`. */
function largestRemainder(values: number[], total: number): number[] {
  const sum = values.reduce((s, v) => s + v, 0);
  if (sum <= 0 || total <= 0) return values.map(() => 0);
  const exact = values.map((v) => (v / sum) * total);
  const floors = exact.map((v) => Math.floor(v));
  let rem = total - floors.reduce((s, v) => s + v, 0);
  const byFrac = exact
    .map((v, i) => ({ i, frac: v - Math.floor(v) }))
    .sort((a, b) => b.frac - a.frac || a.i - b.i);
  const out = [...floors];
  for (let k = 0; rem > 0; k++, rem--) out[byFrac[k % byFrac.length].i] += 1;
  return out;
}

function FxTip({
  active,
  payload,
  windowLabel,
}: {
  active?: boolean;
  payload?: Array<{ payload?: { name: string; amt: number } }>;
  windowLabel: string;
}) {
  if (!active || !payload || !payload.length) return null;
  const p = payload[0].payload;
  if (!p) return null;
  return (
    <div className="chart-tip">
      <span className="ct-l">{p.name} · {windowLabel}</span>
      <span className="ct-v fx-num">{p.amt} ROOMS</span>
    </div>
  );
}

export function RoomStatusDonut({
  counts,
  hours,
  testId = "room-status-donut",
  legendPrefix = "lroom",
  emptyText = "THE WALL IS RESTING",
}: {
  counts: RoomStatusCounts;
  hours?: RoomHoursData | null;
  testId?: string;
  legendPrefix?: string;
  emptyText?: string;
}) {
  const C = useFxColors();
  const sliceColor: Record<StatusId, string> = { free: C.gold, guests: C.ink, mnt: C.purple };

  /* ── values: rooms (time-weighted) when room-hours exist, else live counts ── */
  const rhOf = (id: StatusId): number =>
    id === "free" ? hours?.free ?? 0 : id === "guests" ? hours?.guests ?? 0 : hours?.mnt ?? 0;

  const hasHours = !!hours && hours.total > 0;
  const rooms = largestRemainder(
    ORDER.map((id) => (hasHours ? rhOf(id) : id === "free" ? counts.avl : id === "guests" ? counts.occ : counts.mnt)),
    hasHours ? hours.totalRooms : counts.avl + counts.occ + counts.mnt,
  );
  const wallTotal = hasHours ? hours.totalRooms : counts.avl + counts.occ + counts.mnt;
  const amtOf = (i: number): number => rooms[i];
  const legendVal = (i: number): string => {
    if (hasHours) return `${rooms[i]} ROOMS`;
    return wallTotal > 0 ? `${rooms[i]} · ${Math.round((rooms[i] / wallTotal) * 100)}%` : `${rooms[i]}`;
  };

  const windowLabel = hasHours ? hours.windowLabel : "LIVE";
  /* t99 — the ring hole is 124px; compact the window so the label never
     leaks out of the donut (the card header carries the full label anyway) */
  const COMPACT: Record<string, string> = {
    TODAY: "TODAY",
    "LAST 7 DAYS": "7 DAYS",
    "LAST 30 DAYS": "30 DAYS",
    "LAST 3 MONTHS": "3 MONTHS",
    "LAST 12 MONTHS": "12 MONTHS",
  };
  const centreTop = `${wallTotal}`;
  const centreLabel = hasHours
    ? `ROOMS · ${COMPACT[hours.windowLabel] ?? hours.windowLabel}`
    : "ROOMS ON THE WALL";
  const fit = centreTop.length <= 8 ? 20 : centreTop.length <= 10 ? 17 : 15;

  if (wallTotal <= 0) {
    return (
      <div className="grid h-[170px] place-items-center" data-testid={testId}>
        <span className="fx-label">{emptyText}</span>
      </div>
    );
  }

  return (
    <div className="donut-flex" data-testid={testId}>
      <div className="donut-w">
        <div className="h-[170px] w-[240px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={ORDER.map((id, i) => ({ name: NAMES[id], value: Math.max(rooms[i], 0.4), amt: amtOf(i) }))}
                dataKey="value"
                innerRadius={62}
                outerRadius={84}
                paddingAngle={2}
                stroke="none"
              >
                {ORDER.map((id, i) => (
                  <Cell key={id} fill={sliceColor[id]} />
                ))}
              </Pie>
              <Tooltip content={<FxTip windowLabel={windowLabel} />} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="donut-c">
          <div>
            <div
              className="dc-v fx-num whitespace-nowrap"
              style={{ fontSize: `${fit}px`, letterSpacing: "-0.02em" }}
            >
              {centreTop}
            </div>
            <div className="fx-label">{centreLabel}</div>
          </div>
        </div>
      </div>
      <div className="donut-legend">
        {ORDER.map((id, i) => (
          <div
            className="dl-row"
            key={id}
            data-testid={`${legendPrefix}-${id}`}
            data-amt={amtOf(i)}
          >
            <i className="scope-dot" style={{ background: sliceColor[id] }} />
            {NAMES[id]}
            <span className="dl-v fx-num">{legendVal(i)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
