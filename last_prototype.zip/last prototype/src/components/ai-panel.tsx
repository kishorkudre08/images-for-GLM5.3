"use client";

import * as React from "react";
import {
  Bot,
  Send,
  Sparkles,
  X,
  Loader2,
  RotateCcw,
  Maximize2,
  Minimize2,
} from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Button } from "@/components/ui/button";
import type { RangeKey } from "@/lib/types";

type Msg = { role: "user" | "assistant"; content: string };

const QUICK: Array<{ q: string; range: RangeKey }> = [
  { q: "Summarize my sales for this period", range: "today" },
  { q: "Which dishes should I promote or reprice?", range: "7d" },
  { q: "What are my peak hours and how do I staff them?", range: "today" },
  { q: "Tips to grow revenue this month", range: "1m" },
];

const WIDTH_KEY = "fx-ai-width";

/** Past this many px from the viewport's left edge a drag snaps into fullscreen. */
const MAX_SNAP = 48;

// Rich answer rendering — the copilot answers in Markdown (bold figures,
// bullet lists, GFM tables) and the panel draws them with Fetch-X styling.
const MD_COMPONENTS = {
  table: (p: React.ComponentPropsWithoutRef<"table">) => (
    <div className="ai-md-tblw">
      <table {...p} />
    </div>
  ),
  a: (p: React.ComponentPropsWithoutRef<"a">) => <a {...p} target="_blank" rel="noreferrer" />,
};

function AiMarkdown({ text }: { text: string }) {
  return (
    <div className="ai-md">
      <ReactMarkdown remarkPlugins={[remarkGfm]} components={MD_COMPONENTS}>
        {text}
      </ReactMarkdown>
    </div>
  );
}

export function AiPanel({ range, hideFab = false }: { range: RangeKey; hideFab?: boolean }) {
  const [open, setOpen] = React.useState(false);
  const [width, setWidth] = React.useState(340);
  const [max, setMax] = React.useState(false);
  const [msgs, setMsgs] = React.useState<Msg[]>([]);
  const [input, setInput] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [err, setErr] = React.useState<string | null>(null);
  const scrollRef = React.useRef<HTMLDivElement>(null);
  const dragging = React.useRef(false);

  // restore saved width (can now be up to the full viewport)
  React.useEffect(() => {
    const w = Number(localStorage.getItem(WIDTH_KEY));
    if (Number.isFinite(w) && w >= 280) setWidth(Math.min(w, window.innerWidth));
  }, []);
  // Escape leaves fullscreen
  React.useEffect(() => {
    if (!open || !max) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMax(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, max]);
  React.useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [msgs, busy]);

  // drag-to-resize (left edge handle)
  React.useEffect(() => {
    const move = (e: MouseEvent | TouchEvent) => {
      if (!dragging.current) return;
      const x = "touches" in e ? e.touches[0].clientX : e.clientX;
      // stretch from 280px all the way to the full viewport —
      // pull the handle to the LEFT edge and the panel snaps fullscreen
      if (x <= MAX_SNAP) {
        setMax(true);
        return;
      }
      setWidth(Math.max(280, Math.min(window.innerWidth, window.innerWidth - x)));
    };
    const up = () => {
      if (!dragging.current) return;
      dragging.current = false;
      document.body.style.userSelect = "";
      localStorage.setItem(WIDTH_KEY, String(width));
    };
    window.addEventListener("mousemove", move);
    window.addEventListener("touchmove", move, { passive: true });
    window.addEventListener("mouseup", up);
    window.addEventListener("touchend", up);
    return () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("touchmove", move);
      window.removeEventListener("mouseup", up);
      window.removeEventListener("touchend", up);
    };
  }, [width]);

  const send = async (text: string) => {
    const message = text.trim();
    if (!message || busy) return;
    setInput("");
    setErr(null);
    setMsgs((m) => [...m, { role: "user", content: message }]);
    setBusy(true);
    try {
      const res = await fetch("/api/ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, history: msgs.slice(-8), range }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "AI failed");
      setMsgs((m) => [...m, { role: "assistant", content: data.reply }]);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      {/* ── FAB (collapsed state) — t117: on EVERY screen, all three accounts ── */}
      {!open && !hideFab && (
        <button
          onClick={() => setOpen(true)}
          aria-label="Open Fetch-X AI assistant"
          data-testid="ai-fab"
          className="fixed bottom-[calc(84px+env(safe-area-inset-bottom))] right-4 z-40 grid h-14 w-14 place-items-center rounded-2xl bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[3px_4px_0_0_var(--fx-hard)] transition hover:bg-[var(--fx-purple-deep)] md:bottom-6 md:right-6"
        >
          <Sparkles className="h-6 w-6" />
          <span className="fx-live-dot absolute -right-0.5 -top-0.5" aria-hidden />
        </button>
      )}

      {/* ── Panel ──
          Mobile: fixed overlay drawer.  Desktop (md+): inline flex sibling —
          the main content contracts to make room, and drag-resize reflows it.
          Fullscreen: fixed over everything (Esc or the header button exits). */}
      {open && (
        <aside
          className={
            max
              ? "fixed inset-0 z-[70] flex flex-col bg-[var(--fx-surf)]"
              : "fixed inset-y-0 right-0 z-50 flex flex-col rounded-l-[20px] border border-[var(--fx-line)] bg-[var(--fx-surf)] shadow-[-3px_4px_0_0_var(--fx-hard)] md:relative md:inset-auto md:z-auto md:shrink-0 md:rounded-none md:border-l md:border-r-0 md:border-t-0 md:border-b-0 md:shadow-none"
          }
          style={max ? undefined : { width: `min(${width}px, 100vw)` }}
          aria-label="Fetch-X AI assistant"
        >
          {/* resize handle (meaningless in fullscreen) */}
          {!max && (
            <div
              role="separator"
              aria-orientation="vertical"
              aria-label="Resize panel"
              onMouseDown={() => {
                dragging.current = true;
                document.body.style.userSelect = "none";
              }}
              onTouchStart={() => {
                dragging.current = true;
                document.body.style.userSelect = "none";
              }}
              className="absolute -left-1.5 top-0 z-10 h-full w-3 cursor-ew-resize touch-none"
            />
          )}

          {/* header */}
          <div className="flex items-center gap-3 border-b border-dashed border-[var(--fx-line)] px-5 py-4">
            <span className="relative grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)]">
              <Bot className="h-5 w-5" />
              <span className="fx-live-dot absolute -right-1 -top-1" aria-hidden />
            </span>
            <div className="min-w-0 flex-1">
              <div className="text-[14px] font-extrabold tracking-tight text-[var(--fx-ink)]">
                FETCH-X AI
              </div>
              <div className="fx-label">BUSINESS COPILOT · LIVE DATA</div>
            </div>
            <button
              title={max ? "Restore panel size" : "Full screen"}
              aria-label={max ? "Restore AI panel size" : "Open AI panel full screen"}
              onClick={() => setMax((v) => !v)}
              className="grid h-8 w-8 place-items-center rounded-lg text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
            >
              {max ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            </button>
            <button
              title="Clear conversation"
              aria-label="Clear conversation"
              onClick={() => {
                setMsgs([]);
                setErr(null);
              }}
              className="grid h-8 w-8 place-items-center rounded-lg text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
            >
              <RotateCcw className="h-4 w-4" />
            </button>
            <button
              title="Collapse panel"
              aria-label="Collapse AI panel"
              onClick={() => setOpen(false)}
              className="grid h-8 w-8 place-items-center rounded-lg text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* messages — fullscreen centres the conversation so lines stay readable */}
          <div
            ref={scrollRef}
            className={`fx-scroll min-h-0 flex-1 space-y-3 overflow-y-auto px-4 py-4 ${max ? "mx-auto w-full max-w-3xl" : ""}`}
          >
            {msgs.length === 0 && !busy && (
              <div className="px-2 py-6 text-center">
                <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]">
                  <Sparkles className="h-5 w-5" />
                </div>
                <p className="mt-3 text-[13px] font-bold text-[var(--fx-ink)]">
                  Your restaurant, explained.
                </p>
                <p className="mt-1 text-[12px] font-medium text-[var(--fx-muted)]">
                  I read your live bills — sales, dishes, peak hours — and answer like a business
                  analyst. Ask anything, or start with:
                </p>
                <div className="mt-4 space-y-2">
                  {QUICK.map((q) => (
                    <button
                      key={q.q}
                      onClick={() => void send(q.q)}
                      className="w-full rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-3 py-2.5 text-left text-[12px] font-bold text-[var(--fx-ink)] transition hover:border-[var(--fx-purple)] hover:text-[var(--fx-accent-ink)]"
                    >
                      {q.q}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {msgs.map((m, i) => (
              <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
                <div
                  className={`max-w-[88%] rounded-2xl px-3.5 py-2.5 text-[12.5px] font-medium leading-relaxed ${
                    m.role === "user"
                      ? "whitespace-pre-wrap rounded-br-md bg-[var(--fx-purple)] text-[var(--fx-on-accent)]"
                      : "rounded-bl-md bg-[var(--fx-lav)] text-[var(--fx-ink)]"
                  }`}
                >
                  {m.role === "assistant" ? <AiMarkdown text={m.content} /> : m.content}
                </div>
              </div>
            ))}
            {busy && (
              <div className="flex justify-start">
                <div className="flex items-center gap-2 rounded-2xl rounded-bl-md bg-[var(--fx-lav)] px-3.5 py-3">
                  <Loader2 className="h-3.5 w-3.5 animate-spin text-[var(--fx-accent-ink)]" />
                  <span className="text-[11px] font-bold tracking-wider text-[var(--fx-muted)]">
                    READING LIVE BILLS…
                  </span>
                </div>
              </div>
            )}
            {err && (
              <p className="rounded-xl bg-[color-mix(in_srgb,var(--fx-rose)_10%,transparent)] px-3 py-2 text-[12px] font-semibold text-[var(--fx-rose)]">
                {err}
              </p>
            )}
          </div>

          {/* input */}
          <div className="border-t border-dashed border-[var(--fx-line)] p-3">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                void send(input);
              }}
              className="flex items-center gap-2"
            >
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask about your business…"
                aria-label="Ask the AI copilot"
                className="h-11 min-w-0 flex-1 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-3.5 text-[13px] font-semibold text-[var(--fx-ink)] outline-none placeholder:text-[var(--fx-muted)] focus:border-[var(--fx-purple)]"
              />
              <Button
                type="submit"
                disabled={busy || !input.trim()}
                aria-label="Send message"
                className="h-11 w-11 shrink-0 rounded-xl bg-[var(--fx-purple)] p-0 text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
              >
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </aside>
      )}
    </>
  );
}
