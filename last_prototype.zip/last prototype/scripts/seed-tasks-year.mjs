// ── t98 — seed a full YEAR of owner-forwarded task history ──────────────────
// ~1 task every couple of days across 365 days: budgeted + free tasks, both
// books, progress updates from the desks, closed tasks with actual costs that
// auto-register crown expenses (via="task") — plus a light sprinkle of the
// receptions' own station expenses (raw materials / upgrades / maintenance).
// Existing task data is wiped first so the board is deterministic.
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const DAY = 86_400_000;
const rnd = (a, b) => a + Math.random() * (b - a);
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
const r2 = (n) => Math.round(n * 100) / 100;

const REST_TASKS = [
  ["Deep-clean the kitchen exhaust", "maintenance", 2500],
  ["Restock the spice-grinding station", "raw_material", 3000],
  ["Fix the wobbling counter chair set", "maintenance", 800],
  ["Service the AC over the dining hall", "maintenance", 1500],
  ["Repaint the entrance signboard", "maintenance", 2000],
  ["Recalibrate the billing printer", "maintenance", 500],
  ["Refill the takeaway packaging stock", "raw_material", 1200],
  ["Steam-clean the tandoor corner", "maintenance", 900],
  ["Upgrade the counter LED menu board", "upgrade", 5000],
  ["Replace the water filter cartridge", "raw_material", 1000],
  ["New chairs for the family booths", "upgrade", 6000],
  ["Sound system for the mezzanine", "upgrade", 4200],
];
const LODGE_TASKS = [
  ["Repaint room 12 doors", "maintenance", 1800],
  ["Fix the geysers on floor 2", "maintenance", 2200],
  ["Deep-clean the lobby carpet", "maintenance", 1200],
  ["Service the corridor air-coolers", "maintenance", 1600],
  ["Upgrade room 30's bedding set", "upgrade", 3500],
  ["Unclog the floor-3 washrooms", "maintenance", 700],
  ["Pest control for the west wing", "maintenance", 1400],
  ["Replace worn room-number plates", "raw_material", 600],
  ["Polish the front-desk brass fittings", "maintenance", 400],
  ["Rewire the parking lot lights", "maintenance", 2800],
  ["Smart TVs for the luxury wing", "upgrade", 7500],
  ["Keycard locks for floors 3-4", "upgrade", 5200],
];

const REST_DESK = ["PRIYA", "ASHA"];
const LODGE_DESK = ["RAVI", "MEENA"];

const PROGRESS = [
  "Supervisor visited — quote received, waiting on confirmation.",
  "Half the work is done — the left side is finished, right side tomorrow.",
  "Materials picked up from the market, starting first thing in the morning.",
  "Housekeeping finished their half; the contractor comes in the evening.",
  "Main work is done — cleaning up the area before closing it out.",
  "Needed a small extra part from the hardware shop, back in an hour.",
  "Work started after the lunch rush so guests are not disturbed.",
];

const FORWARD_BUDGETED = (b, k) =>
  `Task forwarded with a max budget of ₹${b.toLocaleString("en-IN")} · ${k === "raw_material" ? "raw-material" : k === "upgrade" ? "upgrade" : "maintenance"} spend.`;
const FORWARD_FREE = "Task forwarded as a FREE task — no budget attached.";

console.log("wiping previous task history…");
await db.taskUpdate.deleteMany();
await db.task.deleteMany();
await db.expense.deleteMany({ where: { via: "task" } });

let made = 0;
let doneCount = 0;
let notesCount = 0;
let crownSum = 0;

for (let back = 364; back >= 0; back--) {
  // roughly one task every ~1.6 days, a small afternoon spike
  if (Math.random() > 0.62) continue;
  const [title, kind, baseBudget] = pick(Math.random() < 0.5 ? REST_TASKS : LODGE_TASKS);
  const book = REST_TASKS.some(([t]) => t === title) ? "rest" : "lodge";
  const desk = pick(book === "rest" ? REST_DESK : LODGE_DESK);

  const createdAt = new Date(Date.now() - back * DAY - rnd(2, 14) * 3_600_000);
  const budgeted = Math.random() < 0.62;
  const maxBudget = budgeted ? pick([baseBudget, baseBudget, Math.round(baseBudget * 1.5)]) : null;
  const description = budgeted
    ? kind === "raw_material"
      ? `Covers the materials and the carry bags — keep every receipt and pin it here. (≈ ₹${maxBudget.toLocaleString("en-IN")} assumed)`
      : `Covers the labour and the small parts — finish within the day if possible. (≈ ₹${maxBudget.toLocaleString("en-IN")} assumed)`
    : "";

  // closure — recent tasks stay open more often; a few are overdue on purpose
  const openChance = back > 45 ? 0.08 : back > 7 ? 0.22 : 0.38;
  const isOpen = Math.random() < openChance;

  const deadline = new Date(createdAt.getTime() + Math.floor(rnd(2, 8)) * DAY);
  let doneAt = null;
  let actualCost = null;
  let doneBy = null;

  if (!isOpen) {
    doneAt = new Date(Math.min(Date.now() - rnd(1, 20) * 3_600_000, createdAt.getTime() + rnd(0.4, 2.6) * DAY));
    if (doneAt <= createdAt) doneAt = new Date(createdAt.getTime() + 3 * 3_600_000);
    doneBy = desk;
    const zeroSpend = Math.random() < 0.12 && !budgeted;
    if (!zeroSpend) {
      const frac = pick([0.55, 0.62, 0.7, 0.78, 0.85, 0.9, 0.96, 1]);
      actualCost = budgeted ? r2(maxBudget * frac) : r2(pick([200, 350, 500, 750, 900, 1200]));
    } else {
      actualCost = 0;
    }
  }

  const updatesData = [{ author: "OWNER", role: "owner", message: budgeted ? FORWARD_BUDGETED(maxBudget, kind) : FORWARD_FREE, createdAt: new Date(createdAt.getTime() + 60_000) }];
  const nNotes = Math.floor(rnd(1, 3.4));
  for (let i = 1; i <= nNotes; i++) {
    updatesData.push({
      author: desk,
      role: "reception",
      message: pick(PROGRESS),
      createdAt: new Date(createdAt.getTime() + (i + 1) * rnd(2, 9) * 3_600_000),
    });
  }
  if (!isOpen) {
    updatesData.push({
      author: desk,
      role: "reception",
      message:
        actualCost > 0
          ? `Marked DONE — ₹${actualCost.toLocaleString("en-IN")} spent${budgeted ? ` of the ₹${maxBudget.toLocaleString("en-IN")} budget` : ""}. The spend is booked in the ${book === "lodge" ? "LODGE" : "RESTAURANT"} ledger with the owner's crown.`
          : "Marked DONE — nothing was spent.",
      createdAt: doneAt,
    });
  }
  updatesData.forEach((u) => {
    const t = u.createdAt.getTime();
    u.createdAt = new Date(Math.min(t, Date.now() - 60_000));
  });

  const task = await db.task.create({
    data: {
      title,
      book,
      kind,
      maxBudget,
      description,
      deadline,
      status: isOpen ? "open" : "done",
      createdBy: "OWNER",
      createdAt,
      doneAt,
      doneBy,
      actualCost,
      updates: { create: updatesData },
    },
  });
  notesCount += updatesData.length;
  made++;
  if (!isOpen) {
    doneCount++;
    if (actualCost > 0) {
      crownSum += actualCost;
      await db.expense.create({
        data: {
          kind,
          book,
          label: `TASK · ${title}`.slice(0, 120),
          amount: actualCost,
          spentOn: doneAt,
          via: "task",
          taskId: task.id,
        },
      });
    }
  }

  // the receptions' own station expenses — a light sprinkle across the year
  if (Math.random() < 0.34) {
    const kindE = pick(["raw_material", "upgrade", "maintenance"]);
    const labels = {
      raw_material: book === "rest" ? "Vegetables & dairy top-up" : "Housekeeping supplies restock",
      upgrade: book === "rest" ? "Counter chair cushions replaced" : "Room 40-series curtains upgraded",
      maintenance: book === "rest" ? "Gas cylinder + burner servicing" : "Water pump repair, floor 1",
    };
    await db.expense.create({
      data: {
        kind: kindE,
        book,
        label: labels[kindE],
        amount: r2(rnd(300, 4200)),
        spentOn: new Date(Math.max(createdAt.getTime() + rnd(0, 2) * DAY, Date.now() - 360 * DAY)),
      },
    });
  }
}

// guarantee TODAY has visible activity for the smallest toggle window
const todayDeskRest = pick(REST_DESK);
const todayDeskLodge = pick(LODGE_DESK);
const todayBase = new Date();
todayBase.setHours(0, 0, 0, 0);

const todayPlan = [
  {
    title: "Refill the takeaway packaging stock",
    book: "rest",
    kind: "raw_material",
    maxBudget: 1200,
    actualCost: 900,
    desk: todayDeskRest,
    status: "done",
  },
  {
    title: "Fix the geysers on floor 2",
    book: "lodge",
    kind: "maintenance",
    maxBudget: 2200,
    actualCost: null,
    desk: todayDeskLodge,
    status: "open",
  },
  {
    title: "Steam-clean the tandoor corner",
    book: "rest",
    kind: "maintenance",
    maxBudget: null,
    actualCost: null,
    desk: todayDeskRest,
    status: "open",
  },
];

for (const p of todayPlan) {
  const createdAt = new Date(todayBase.getTime() + rnd(8, 12) * 3_600_000);
  const doneAt = p.status === "done" ? new Date(Math.min(Date.now() - 30 * 60_000, createdAt.getTime() + 2 * 3_600_000)) : null;
  const updates = [
    { author: "OWNER", role: "owner", message: p.maxBudget ? FORWARD_BUDGETED(p.maxBudget, p.kind) : FORWARD_FREE, createdAt: new Date(createdAt.getTime() + 60_000) },
    { author: p.desk, role: "reception", message: pick(PROGRESS), createdAt: new Date(createdAt.getTime() + 3_600_000) },
  ];
  if (p.status === "done") {
    updates.push({
      author: p.desk,
      role: "reception",
      message: `Marked DONE — ₹${p.actualCost.toLocaleString("en-IN")} spent of the ₹${p.maxBudget.toLocaleString("en-IN")} budget. The spend is booked in the RESTAURANT ledger with the owner's crown.`,
      createdAt: doneAt,
    });
  }
  const task = await db.task.create({
    data: {
      title: p.title,
      book: p.book,
      kind: p.kind,
      maxBudget: p.maxBudget,
      description: p.maxBudget ? "Covers the materials for today — receipts pinned here." : "",
      deadline: new Date(todayBase.getTime() + 3 * DAY),
      status: p.status,
      createdBy: "OWNER",
      createdAt,
      doneAt,
      doneBy: p.status === "done" ? p.desk : null,
      actualCost: p.actualCost,
      updates: { create: updates },
    },
  });
  if (p.status === "done" && p.actualCost > 0) {
    await db.expense.create({
      data: {
        kind: p.kind,
        book: p.book,
        label: `TASK · ${p.title}`.slice(0, 120),
        amount: p.actualCost,
        spentOn: doneAt,
        via: "task",
        taskId: task.id,
      },
    });
  }
  made++;
  if (p.status === "done") doneCount++;
}

const agg = await db.expense.aggregate({ where: { via: "task" }, _sum: { amount: true } });
console.log(
  `seeded ${made} tasks (${doneCount} done, ${notesCount} updates) · crown expenses ₹${Math.round(agg._sum.amount ?? 0)} (tracked ${Math.round(crownSum)})`,
);
await db.$disconnect();
