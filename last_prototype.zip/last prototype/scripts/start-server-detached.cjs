/* Detached server launcher — the only reliable way to keep a server alive
   after the tool call ends: spawn detached + unref, then exit immediately.
   (stdio pipes keep the parent alive → harness reaps the whole tree.) */
const { spawn } = require("node:child_process");

const child = spawn("bun", ["/home/z/my-project/.next/standalone/server.js"], {
  cwd: "/home/z/my-project/.next/standalone",
  detached: true,
  stdio: "ignore",
  env: {
    ...process.env,
    PORT: "3000",
    HOSTNAME: "0.0.0.0",
    NODE_ENV: "production",
    DATABASE_URL: "file:/home/z/my-project/db/custom.db",
  },
});
child.unref();
process.exit(0);
