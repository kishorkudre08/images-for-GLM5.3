// Utility: wipe all bills (keeps menu). Run: bun scripts/clean-bills.ts
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  const n = await db.bill.deleteMany({});
  console.log(`Deleted ${n.count} bills.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
