#!/bin/bash
# t134 — rebuild the "final product" zip in download/
# Full runnable Fetch-X project (source + db + setup docs), no build junk.
set -e
cd /home/z/my-project

STAGE=$(mktemp -d)
NAME="FetchX-Final-Product"
mkdir -p "$STAGE/$NAME"

# project payload — everything needed to run on the owner's PC
rsync -a \
  --exclude 'node_modules' \
  --exclude '.next' \
  --exclude 'download' \
  --exclude 'skills' \
  --exclude 'tool-results' \
  --exclude 'upload' \
  --exclude 'worklog.md' \
  --exclude 'server.log' \
  --exclude '*.log' \
  --exclude '.git' \
  ./ "$STAGE/$NAME/"

cd "$STAGE"
zip -rq9 "/home/z/my-project/download/$NAME.zip" "$NAME"
cd /home/z/my-project
rm -rf "$STAGE"

ls -lh "download/$NAME.zip"
unzip -l "download/$NAME.zip" | tail -3
