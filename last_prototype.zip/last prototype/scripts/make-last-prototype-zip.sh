#!/bin/bash
# t137 — "last prototype" zip: same payload as the final product (source + db +
# setup docs, no build junk), rebuilt after the t137 fixes.
set -e
cd /home/z/my-project

STAGE=$(mktemp -d)
NAME="last prototype"
mkdir -p "$STAGE/$NAME"

rsync -a \
  --exclude 'node_modules' \
  --exclude '.next' \
  --exclude 'download' \
  --exclude 'skills' \
  --exclude 'tool-results' \
  --exclude 'upload' \
  --exclude 'worklog.md' \
  --exclude 'server.log' \
  --exclude '*.log' \
  --exclude '.git' \
  --exclude 'ref-screenshot.png' \
  ./ "$STAGE/$NAME/"

cd "$STAGE"
zip -rq9 "/home/z/my-project/download/last prototype.zip" "$NAME"
cd /home/z/my-project
rm -rf "$STAGE"

ls -lh "download/last prototype.zip"
unzip -l "download/last prototype.zip" | tail -3
