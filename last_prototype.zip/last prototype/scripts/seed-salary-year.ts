// ── t119/t121 — seed a FULL YEAR of attendance + settled salaries ──────────
// Every active employee gets 365 days of attendance (≈92% present, realistic
// clusters), and every FULLY-PAST month gets a settled SalaryPayment whose
// deduction is derived from that month's real absence rows — so the live
// dashboard reports ACTUAL paid money after the holiday cuts.
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

// deterministic RNG so re-runs are stable
let seed = 20260929;
const rnd = () => {
  seed = (seed * 1103515245 + 12345) & 0x7fffffff;
  return seed / 0x7fffffff;
};

const pad = (n) => String(n).padStart(2, "0");
const dateKey = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const monthKey = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
const daysInMonth = (key) => {
  const [y, m] = key.split("-").map(Number);
  return new Date(y, m, 0).getDate();
};

async function main() {
  const employees = await db.employee.findMany({ where: { active: true } });
  const now = new Date();
  const todayKey = dateKey(now);

  // ── 1 · attendance: 365 days back from today (inclusive) ─────────────────
  const attRows = [];
  const absentByMonth = new Map(); // `${empId}|${month}` -> absent count
  for (const e of employees) {
    // per-employee base absence rate + sick clusters
    const baseRate = 0.03 + rnd() * 0.05; // 3–8%
    const clusters = Array.from({ length: 2 + Math.floor(rnd() * 3) }, () => ({
      start: Math.floor(rnd() * 360),
      len: 2 + Math.floor(rnd() * 4),
    }));
    for (let i = 364; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i);
      const key = dateKey(d);
      const idx = 364 - i;
      const inCluster = clusters.some((c) => idx >= c.start && idx < c.start + c.len);
      const absent = inCluster || rnd() < baseRate;
      attRows.push({ employeeId: e.id, date: key, status: absent ? "absent" : "present" });
      if (absent) {
        const mk = `${e.id}|${monthKey(d)}`;
        absentByMonth.set(mk, (absentByMonth.get(mk) ?? 0) + 1);
      }
    }
  }
  // upsert in one transaction per 500 rows (SQLite-friendly)
  for (let i = 0; i < attRows.length; i += 500) {
    const chunk = attRows.slice(i, i + 500);
    await db.$transaction(
      chunk.map((r) =>
        db.attendance.upsert({
          where: { employeeId_date: { employeeId: r.employeeId, date: r.date } },
          create: r,
          update: { status: r.status },
        }),
      ),
    );
  }
  console.log(`attendance rows written: ${attRows.length} (employees × 365 days)`);

  // ── 2 · settled salaries for every FULLY-PAST month in the window ────────
  const curKey = monthKey(now); // e.g. 2026-09 — NOT settle-able
  // window: months from (today − 365d) → last month
  const startD = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 364);
  let y = startD.getFullYear();
  let m = startD.getMonth() + 1;
  const months = [];
  while (true) {
    const key = `${y}-${pad(m)}`;
    if (key >= curKey) break;
    months.push(key);
    m += 1;
    if (m > 12) { m = 1; y += 1; }
  }

  let payments = 0;
  for (const mk of months) {
    const dim = daysInMonth(mk);
    const nextMonthFirst = new Date(Number(mk.slice(0, 4)), Number(mk.slice(5, 7)), 1 + Math.floor(rnd() * 3), 10, 30);
    for (const e of employees) {
      const absent = absentByMonth.get(`${e.id}|${mk}`) ?? 0;
      const paidHolidays = Math.min(absent, rnd() < 0.55 ? 0 : 1 + Math.floor(rnd() * 2));
      const cut = Math.max(0, absent - paidHolidays);
      const deduction = Math.round(cut * (e.salary / dim) * 100) / 100;
      const netPaid = Math.round((e.salary - deduction) * 100) / 100;
      const present = Math.max(0, dim - absent);
      await db.salaryPayment.upsert({
        where: { employeeId_month: { employeeId: e.id, month: mk } },
        create: {
          employeeId: e.id,
          month: mk,
          base: e.salary,
          presentDays: present,
          absentDays: absent,
          paidHolidays,
          deduction,
          netPaid,
          status: "paid",
          paidAt: nextMonthFirst,
          paidBy: "OWNER",
        },
        update: {
          base: e.salary,
          presentDays: present,
          absentDays: absent,
          paidHolidays,
          deduction,
          netPaid,
          status: "paid",
          paidAt: nextMonthFirst,
        },
      });
      payments += 1;
    }
  }
  console.log(`salary settlements written: ${payments} (${months.length} months × ${employees.length} staff; ${curKey} left unpaid — month not over)`);

  // ── 3 · summary ──────────────────────────────────────────────────────────
  const [attCount, payCount, paidTotal] = await Promise.all([
    db.attendance.count(),
    db.salaryPayment.count({ where: { status: "paid" } }),
    db.salaryPayment.aggregate({ where: { status: "paid" }, _sum: { netPaid: true } }),
  ]);
  console.log({ attendance: attCount, paidSettlements: payCount, totalActuallyPaid: Math.round(paidTotal._sum.netPaid ?? 0) });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
