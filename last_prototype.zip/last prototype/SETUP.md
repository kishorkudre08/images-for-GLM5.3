# Fetch-X — run it on your Windows PC

Everything the app needs is inside this folder. Your data lives in one file:
`db/custom.db` — copy that file somewhere safe and you have a full backup.

## First run (about 5 minutes)

1. Install Node.js LTS (20.9 or newer) from https://nodejs.org — skip if you
   already have it (check: open a terminal and type `node -v`).
2. Extract this zip to a folder you like. Spaces in the folder name are fine
   (e.g. `Documents\Fetch-X Lodge`).
3. Open that folder in VS Code → menu **Terminal → New Terminal**.
4. Start the app:
   ```
   npm run dev:w
   ```

That single command does EVERYTHING by itself:
- dependencies not installed yet? → it runs `npm install` for you (first run
  only, a few minutes — every later start is instant)
- database client missing? → it runs `prisma generate` for you
- then it starts the server and prints a health report (Node version,
  database file found, AI key set or not)

5. Open **http://localhost:3000** in your browser. Done.

The terminal must show `[fetchx] database OK → ...path...` — that line means
the app found and opened its own database, even if the folder was renamed,
moved, or a stale setting pointed somewhere else.

The black terminal window IS the app server — keep it open while you use
Fetch-X. Closing it never loses data (everything is written to the database
instantly). To work again later: open the folder in VS Code, terminal,
`npm run dev:w`.

## Your AI copilot key (optional)

Open the `.env` file, find the `GROQ_API_KEY` line, remove the `#` and paste
your key from https://console.groq.com/keys :

```
GROQ_API_KEY=gsk_...your key...
```

Save and restart the server (`Ctrl+C`, then `npm run dev:w` again). The
launcher confirms the key was detected
(`AI copilot → Groq key gsk_…abcd`). The copilot then runs on Groq's
`openai/gpt-oss-120b` (change `GROQ_MODEL` for a different engine).

Without a key the app works fine — the AI panel simply shows setup steps.

## If something goes wrong

- Watch the terminal: on every start it must print
  `[fetchx] database OK → ...path...`. That line means the database opened.
- If you see `DATABASE OPEN FAILED` instead, run:
  ```
  npm run doctor
  ```
  It finds the database file, opens it for real, and prints the exact `.env`
  line to use. Follow what it says.
- `'next' is not recognized` or other "missing" errors? Just run
  `npm run dev:w` again — it detects broken or missing dependencies and
  repairs them automatically (this is now the same one command).
- Extracted over an OLD copy of the project? Delete the `.next` folder once,
  then start again.
- Seeing `@prisma/client did not initialize yet`? It repairs itself at boot
  (`[fetchx] Prisma client not generated yet — generating now…`); if you ever
  need it by hand: `npx prisma generate`.
- If data models seem missing after an update: `npx prisma generate`, restart.

## Good to know

- Restaurant bills count up from 1001, lodge bills print as L-5001+.
- The database is SQLite — no server, no setup, it is just a file.
- Want a second business file? Copy the whole folder; each copy keeps its own
  `db/custom.db`.
- `package-lock.json` pins the exact dependency versions this build was
  tested with — do not delete it, and do not run `npm update`.
