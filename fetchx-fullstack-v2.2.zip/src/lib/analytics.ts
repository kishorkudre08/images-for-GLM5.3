import { db } from "@/lib/db";
import { getBookCosts, getLodgeBlock, type BookCosts, type LodgeBlock } from "@/lib/analytics-lodge";

// ── Ranges ──────────────────────────────────────────────────────────────────
export const RANGE_KEYS = ["today", "7d", "1m", "3m", "1y"] as const;
export type RangeKey = (typeof RANGE_KEYS)[number];

export const RANGE_META: Record<
  RangeKey,
  { label: string; days: number; bucket: "hour" | "day" | "week" | "month"; chartTitle: string }
> = {
  today: { label: "Today", days: 1, bucket: "hour", chartTitle: "SALES CURVE · TODAY (IST)" },
  "7d": { label: "Last 7 days", days: 7, bucket: "day", chartTitle: "REVENUE · LAST 7 DAYS" },
  "1m": { label: "Last 1 month", days: 30, bucket: "day", chartTitle: "REVENUE · LAST 30 DAYS" },
  "3m": { label: "Last 3 months", days: 91, bucket: "week", chartTitle: "REVENUE · LAST 3 MONTHS" },
  "1y": { label: "Last 1 year", days: 365, bucket: "month", chartTitle: "REVENUE · LAST 12 MONTHS" },
};

export function parseRange(v: string | null): RangeKey {
  return (RANGE_KEYS as readonly string[]).includes(v ?? "") ? (v as RangeKey) : "today";
}

// Salary proration: monthly salaries ÷ 30 × these day-counts per range.
// 1m = exactly 1 month, 3m = 3 months, 1y = 12 months.
export const SALARY_DAYS: Record<RangeKey, number> = {
  today: 1,
  "7d": 7,
  "1m": 30,
  "3m": 90,
  "1y": 360,
};

// ── IST (UTC+5:30) helpers ──────────────────────────────────────────────────
const IST_OFFSET_MIN = 330;
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function istShift(d: Date): Date {
  return new Date(d.getTime() + IST_OFFSET_MIN * 60000);
}
function istDayStart(d: Date): Date {
  const s = istShift(d);
  s.setUTCHours(0, 0, 0, 0);
  return new Date(s.getTime() - IST_OFFSET_MIN * 60000);
}
function istHour(d: Date): number {
  return istShift(d).getUTCHours();
}
function istDateKey(d: Date): string {
  return istShift(d).toISOString().slice(0, 10);
}
function hourLabel(h: number): string {
  const suffix = h >= 12 ? "PM" : "AM";
  const base = h % 12 === 0 ? 12 : h % 12;
  return `${base} ${suffix}`;
}
function dateKeyLabel(key: string): string {
  const [, m, d] = key.split("-").map(Number);
  return `${d} ${MONTHS[m - 1]}`;
}
function monthKeyLabel(key: string): string {
  const [y, m] = key.split("-").map(Number);
  return `${MONTHS[m - 1]} '${String(y).slice(2)}`;
}
function weekStartOf(d: Date): Date {
  const s = istDayStart(d);
  s.setUTCDate(s.getUTCDate() - s.getUTCDay()); // weeks start Sunday (IST calendar)
  return s;
}

const round2 = (n: number) => Math.round(n * 100) / 100;

export type Bucket = { label: string; revenue: number; bills: number };

export type DashboardResult = {
  generatedAt: string;
  range: RangeKey;
  stats: {
    revenue: number;
    bills: number;
    items: number;
    avgTicket: number;
    discounts: number;
    revenueDeltaPct: number | null;
    billDeltaPct: number | null;
  };
  peakLabel: string | null;
  buckets: Bucket[];
  hourly: {
    series: Array<{ label: string; avg: number; bills: number }>;
    peak: string | null;
    quiet: string | null;
    days: number;
  };
  itemsSold: Array<{ name: string; qty: number; revenue: number }>;
  categoryMix: Array<{ category: string; revenue: number; share: number }>;
  recentBills: Array<{
    id: string;
    number: number;
    createdAt: Date;
    itemCount: number;
    total: number;
    subtotal: number;
    discount: number;
    tax: number;
    items: Array<{ id: string; dishId: string | null; name: string; qty: number; price: number }>;
  }>;
  allTime: { bills: number; revenue: number };
  team: {
    employees: Array<{ id: string; name: string; role: string; salary: number }>;
    monthlyTotal: number;
    periodCost: number;
  };
  costs: {
    salaries: number;
    rawMaterials: number;
    upgrades: number;
    maintenance: number;
    profit: number;
    marginPct: number | null;
  };
  books: { rest: BookCosts; lodge: BookCosts };
  lodge: LodgeBlock;
};

// ── Main aggregation ────────────────────────────────────────────────────────
// Small TTL cache: the dashboard polls every 15s and each poll used to scan
// up to 2× the range. With a year of history (~10k bills) we cache results
// briefly and invalidate the moment a new bill is written.
const dashboardCache = new Map<RangeKey, { at: number; data: DashboardResult }>();
const CACHE_TTL_MS = 5000;

export function invalidateDashboardCache() {
  dashboardCache.clear();
}

export async function getDashboardData(range: RangeKey): Promise<DashboardResult> {
  const hit = dashboardCache.get(range);
  if (hit && Date.now() - hit.at < CACHE_TTL_MS) return hit.data;
  const data = await buildDashboard(range);
  dashboardCache.set(range, { at: Date.now(), data });
  return data;
}

async function buildDashboard(range: RangeKey): Promise<DashboardResult> {
  const meta = RANGE_META[range];
  const now = new Date();
  const start = istDayStart(new Date(now.getTime() - (meta.days - 1) * 86400000));
  const prevStart = istDayStart(new Date(start.getTime() - meta.days * 86400000));

  // Current range: full rows (buckets + item/category mix need line items).
  const bills = await db.bill.findMany({
    where: { createdAt: { gte: start } },
    select: {
      total: true,
      discount: true,
      itemCount: true,
      createdAt: true,
      items: { select: { name: true, category: true, qty: true, price: true } },
    },
    orderBy: { createdAt: "asc" },
  });

  // Previous period: cheap SQL aggregate — no rows pulled into Node.
  const prevAgg = await db.bill.aggregate({
    where: { createdAt: { gte: prevStart, lt: start } },
    _count: true,
    _sum: { total: true, discount: true, itemCount: true },
  });

  // Team + manually-entered costs (salaries prorate; expenses are actuals).
  const [emps, expAgg] = await Promise.all([
    db.employee.findMany({ where: { active: true }, orderBy: { salary: "desc" } }),
    db.expense.groupBy({
      by: ["kind"],
      where: { spentOn: { gte: start } },
      _sum: { amount: true },
    }),
  ]);
  const monthlyTotal = round2(emps.reduce((s, e) => s + e.salary, 0));
  const salaries = round2((monthlyTotal / 30) * SALARY_DAYS[range]);
  const rawMaterials = round2(expAgg.find((e) => e.kind === "raw_material")?._sum.amount ?? 0);
  const upgrades = round2(expAgg.find((e) => e.kind === "upgrade")?._sum.amount ?? 0);
  const maintenance = round2(expAgg.find((e) => e.kind === "maintenance")?._sum.amount ?? 0);
  const prev = {
    revenue: prevAgg._sum.total ?? 0,
    bills: prevAgg._count,
    items: prevAgg._sum.itemCount ?? 0,
    discounts: prevAgg._sum.discount ?? 0,
  };

  const cur = { revenue: 0, bills: 0, items: 0, discounts: 0 };

  // buckets keyed by hour / date / week-start / month
  const bucketMap = new Map<string, { at: number; label: string; revenue: number; bills: number }>();
  const itemAgg = new Map<string, { name: string; qty: number; revenue: number }>();
  const catAgg = new Map<string, number>();
  // Hour-of-day accumulation across the WHOLE range — powers the permanent
  // "average day" hourly rhythm chart (avg = total per hour ÷ days in range).
  const hourly = Array.from({ length: 24 }, (_, h) => ({ h, revenue: 0, bills: 0 }));

  const bucketKeyOf = (d: Date): string => {
    if (meta.bucket === "hour") return String(istHour(d));
    if (meta.bucket === "day") return istDateKey(d);
    if (meta.bucket === "week") return istDateKey(weekStartOf(d));
    return istDateKey(d).slice(0, 7); // month
  };
  const bucketLabelOf = (key: string): string => {
    if (meta.bucket === "hour") return hourLabel(Number(key));
    if (meta.bucket === "month") return monthKeyLabel(key);
    return dateKeyLabel(key);
  };

  for (const b of bills) {
    cur.revenue += b.total;
    cur.bills += 1;
    cur.items += b.itemCount;
    cur.discounts += b.discount;

    const key = bucketKeyOf(b.createdAt);
    const bk = bucketMap.get(key) ?? { at: 0, label: bucketLabelOf(key), revenue: 0, bills: 0 };
    bk.revenue += b.total;
    bk.bills += 1;
    bucketMap.set(key, bk);

    hourly[istHour(b.createdAt)].revenue += b.total;
    hourly[istHour(b.createdAt)].bills += 1;
    for (const it of b.items) {
      const it2 = itemAgg.get(it.name) ?? { name: it.name, qty: 0, revenue: 0 };
      it2.qty += it.qty;
      it2.revenue += it.qty * it.price;
      itemAgg.set(it.name, it2);
      catAgg.set(it.category, (catAgg.get(it.category) ?? 0) + it.qty * it.price);
    }
  }

  // ── Build full bucket series (fill gaps) ──
  const buckets: Bucket[] = [];
  if (meta.bucket === "hour") {
    // show 7 AM → 11 PM (restaurant hours)
    for (let h = 7; h <= 23; h++) {
      const bk = bucketMap.get(String(h));
      buckets.push({ label: hourLabel(h), revenue: round2(bk?.revenue ?? 0), bills: bk?.bills ?? 0 });
    }
  } else if (meta.bucket === "day") {
    for (let i = meta.days - 1; i >= 0; i--) {
      const key = istDateKey(new Date(now.getTime() - i * 86400000));
      const bk = bucketMap.get(key);
      buckets.push({ label: dateKeyLabel(key), revenue: round2(bk?.revenue ?? 0), bills: bk?.bills ?? 0 });
    }
  } else if (meta.bucket === "week") {
    const first = weekStartOf(start).getTime();
    const last = weekStartOf(now).getTime();
    for (let t = first; t <= last; t += 7 * 86400000) {
      const key = istDateKey(new Date(t));
      const bk = bucketMap.get(key);
      buckets.push({ label: dateKeyLabel(key), revenue: round2(bk?.revenue ?? 0), bills: bk?.bills ?? 0 });
    }
  } else {
    // month
    for (let m = 11; m >= 0; m--) {
      const d = new Date(Date.UTC(istShift(now).getUTCFullYear(), istShift(now).getUTCMonth() - m, 1));
      const key = d.toISOString().slice(0, 7);
      const bk = bucketMap.get(key);
      buckets.push({ label: monthKeyLabel(key), revenue: round2(bk?.revenue ?? 0), bills: bk?.bills ?? 0 });
    }
  }

  // ── Peak ──
  let peakLabel: string | null = null;
  if (range === "today") {
    const peak = hourly.reduce((best, h) => (h.revenue > best.revenue ? h : best), hourly[0]);
    peakLabel = cur.revenue > 0 ? hourLabel(peak.h) : null;
  } else {
    const peak = buckets.reduce(
      (best, b) => (b.revenue > best.revenue ? b : best),
      buckets[0] ?? { label: "", revenue: 0, bills: 0 },
    );
    peakLabel = peak.revenue > 0 ? peak.label : null;
  }

  // ── Hourly rhythm: the AVERAGE day across this range (peak & bottom hours) ──
  const days = meta.days;
  const hourlySeries: Array<{ label: string; avg: number; bills: number }> = [];
  for (let h = 7; h <= 23; h++) {
    hourlySeries.push({
      label: hourLabel(h),
      avg: round2(hourly[h].revenue / days),
      bills: hourly[h].bills,
    });
  }
  const withSales = hourlySeries.filter((x) => x.avg > 0);
  const hourlyPeak =
    withSales.length > 0
      ? withSales.reduce((best, x) => (x.avg > best.avg ? x : best), withSales[0]).label
      : null;
  const hourlyQuiet =
    withSales.length > 1
      ? withSales.reduce((worst, x) => (x.avg < worst.avg ? x : worst), withSales[0]).label
      : null;

  const catTotal = [...catAgg.values()].reduce((s, v) => s + v, 0);
  const pct = (a: number, b: number) => (b > 0 ? round2(((a - b) / b) * 100) : null);
  const profit = round2(cur.revenue - salaries - rawMaterials - upgrades - maintenance);
  const marginPct = cur.revenue > 0 ? round2((profit / cur.revenue) * 100) : null;

  const recent = await db.bill.findMany({
    orderBy: { createdAt: "desc" },
    take: 10,
    include: { items: true },
  });
  const allTime = await db.bill.aggregate({ _count: true, _sum: { total: true } });

  const [books, lodge] = await Promise.all([getBookCosts(range, meta.days), getLodgeBlock(range)]);
  books.rest.profit = round2(cur.revenue - books.rest.salaries - books.rest.rawMaterials - books.rest.upgrades - books.rest.maintenance);
  books.lodge.profit = round2(lodge.revenue - books.lodge.salaries - books.lodge.rawMaterials - books.lodge.upgrades - books.lodge.maintenance);

  return {
    generatedAt: now.toISOString(),
    range,
    books,
    lodge,
    stats: {
      revenue: round2(cur.revenue),
      bills: cur.bills,
      items: cur.items,
      avgTicket: cur.bills ? round2(cur.revenue / cur.bills) : 0,
      discounts: round2(cur.discounts),
      revenueDeltaPct: pct(cur.revenue, prev.revenue),
      billDeltaPct: pct(cur.bills, prev.bills),
    },
    peakLabel,
    buckets,
    hourly: { series: hourlySeries, peak: hourlyPeak, quiet: hourlyQuiet, days },
    itemsSold: [...itemAgg.values()]
      .sort((a, b) => b.qty - a.qty)
      .map((d) => ({ ...d, revenue: round2(d.revenue) })),
    categoryMix: [...catAgg.entries()]
      .map(([category, revenue]) => ({
        category,
        revenue: round2(revenue),
        share: catTotal ? round2((revenue / catTotal) * 100) : 0,
      }))
      .sort((a, b) => b.revenue - a.revenue),
    // full receipt shape — dashboard reprint renders these straight into the
    // thermal sheet, so subtotal/discount/tax + per-item price MUST ride along
    recentBills: recent.map((b) => ({
      id: b.id,
      number: b.number,
      createdAt: b.createdAt,
      itemCount: b.itemCount,
      total: b.total,
      subtotal: round2(b.subtotal),
      discount: round2(b.discount),
      tax: round2(b.tax),
      items: b.items.map((it) => ({
        id: it.id,
        dishId: it.dishId,
        name: it.name,
        qty: it.qty,
        price: it.price,
      })),
    })),
    allTime: { bills: allTime._count, revenue: round2(allTime._sum.total ?? 0) },
    team: {
      employees: emps.map((e) => ({
        id: e.id,
        name: e.name,
        role: e.role,
        salary: round2(e.salary),
        book: e.book === "lodge" ? "lodge" : "rest",
      })),
      monthlyTotal,
      periodCost: salaries,
    },
    costs: { salaries, rawMaterials, upgrades, maintenance, profit, marginPct },
  };
}
