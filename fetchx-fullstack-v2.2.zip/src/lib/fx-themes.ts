"use client";

/**
 * t76 · Fetch-X account theme gallery — the single source of truth for the
 * colour combos offered on /theme. Selecting one sets <html data-fx-theme>
 * and re-skins EVERY section the same way (universal — never per-section):
 *   accent A → actions + the restaurant book   (replaces the purple family)
 *   accent B → the lodge book                  (replaces the gold family)
 * The matching CSS lives in globals.css under `html[data-fx-theme=…]`, with
 * light AND dark tuning per combo. The palettes below mirror those tokens so
 * the picker can draw faithful previews of every combo without applying it.
 */

export const FX_THEME_IDS = ["classic", "dragonfruit", "lime", "emerald", "iris", "blaze", "neon", "cherry", "azure", "cyanreef"] as const;
export type FxThemeId = (typeof FX_THEME_IDS)[number];
export const DEFAULT_THEME: FxThemeId = "classic";

export type FxThemePalette = {
  page: string;
  surf: string;
  line: string;
  ink: string;
  muted: string;
  lav: string;
  a: string; // solid accent (buttons, chips)
  aInk: string; // text-safe accent
  aHi: string; // bright accent (gradient top, chart pop)
  onA: string; // readable text on solid accent
  b: string; // text-safe B (lodge)
  bHi: string; // vivid B (bars, dots)
};

export type FxTheme = {
  id: FxThemeId;
  name: string;
  tagline: string;
  light: FxThemePalette;
  dark: FxThemePalette;
};

const LIGHT_BASE = {
  page: "#ebe8fc",
  surf: "#f7f5fe",
  line: "#d9d4f2",
  ink: "#241d56",
  muted: "#7c7ba0",
  lav: "#e2ddfa",
};
const DARK_BASE = {
  page: "#1f1a44",
  surf: "#282257",
  line: "#3b3480",
  ink: "#eae7fc",
  muted: "#9d9ac4",
  lav: "#322b6b",
};

export const FX_THEMES: FxTheme[] = [
  {
    id: "classic",
    name: "Fetch-X Classic",
    tagline: "The house signature — violet actions with a brass lodge.",
    light: { ...LIGHT_BASE, a: "#5b4fe9", aInk: "#5b4fe9", aHi: "#8678f9", onA: "#ffffff", b: "#a16207", bHi: "#d9a441" },
    dark: { ...DARK_BASE, a: "#7a6ff0", aInk: "#8a7cf6", aHi: "#8a7cf6", onA: "#ffffff", b: "#e4c67c", bHi: "#d9a441" },
  },
  {
    id: "dragonfruit",
    name: "Dragon Fruit + Night Violet",
    tagline: "Hot magenta counter, deep violet rooms — bold and juicy.",
    light: { page: "#f7e4f1", surf: "#fcebf5", line: "#e9c9de", ink: "#4a1040", muted: "#a4799a", lav: "#efd3e6", a: "#c81e78", aInk: "#c81e78", aHi: "#f06ab4", onA: "#ffffff", b: "#5b2d9e", bHi: "#7a4fd0" },
    dark: { page: "#31123a", surf: "#3c1846", line: "#562664", ink: "#f8e6f3", muted: "#b58cae", lav: "#482052", a: "#d64d92", aInk: "#f27ab8", aHi: "#f47fbf", onA: "#ffffff", b: "#c4a5f5", bHi: "#a78bfa" },
  },
  {
    id: "lime",
    name: "Lime Spark + Graphite",
    tagline: "Electric lime counter on cool graphite rooms — industrial fresh.",
    light: { page: "#eaf4d8", surf: "#f3f9e6", line: "#d3e5b4", ink: "#1f3308", muted: "#7d8a67", lav: "#dfecc4", a: "#65a30d", aInk: "#4d7c0f", aHi: "#84cc16", onA: "#1c2507", b: "#475569", bHi: "#64748b" },
    dark: { page: "#1c2712", surf: "#243119", line: "#35482a", ink: "#eef6dc", muted: "#9fac90", lav: "#2c3c20", a: "#84cc16", aInk: "#a3e635", aHi: "#a3e635", onA: "#1c2507", b: "#cbd5e1", bHi: "#94a3b8" },
  },
  {
    id: "emerald",
    name: "Emerald Ink + Champagne",
    tagline: "Emerald counter with champagne rooms — quiet luxury.",
    light: { page: "#eff3d9", surf: "#f7f8e6", line: "#d9e0b8", ink: "#0c2f22", muted: "#7f8a70", lav: "#e4e9c6", a: "#047857", aInk: "#047857", aHi: "#10b981", onA: "#ffffff", b: "#8a6d1f", bHi: "#d9b45c" },
    dark: { page: "#0c2a1d", surf: "#123427", line: "#1f4a38", ink: "#e8f2e0", muted: "#90a894", lav: "#17402f", a: "#10b981", aInk: "#34d399", aHi: "#34d399", onA: "#06251a", b: "#e6cd8a", bHi: "#d9b45c" },
  },
  {
    id: "iris",
    name: "Butter Yellow + Royal Iris",
    tagline: "Butter-yellow counter against royal iris rooms — sunny and regal.",
    light: { page: "#faf0cb", surf: "#fdf7de", line: "#ecdfa8", ink: "#2f2404", muted: "#96895f", lav: "#f2e6b4", a: "#f5c51e", aInk: "#8f6c05", aHi: "#fada4a", onA: "#251c02", b: "#4f46e5", bHi: "#4f46e5" },
    dark: { page: "#221e4d", surf: "#2b2660", line: "#3e3780", ink: "#faf0c8", muted: "#a29dc8", lav: "#322c68", a: "#f5d020", aInk: "#fde047", aHi: "#fde047", onA: "#251c02", b: "#a5b4fc", bHi: "#818cf8" },
  },
  {
    id: "blaze",
    name: "Vivid Ember + Light Cream",
    tagline: "Vivid ember-orange counter on light-cream rooms — bold canteen warmth.",
    light: { page: "#f7ecd6", surf: "#fcf4e2", line: "#ead9b4", ink: "#3a1c05", muted: "#a08f70", lav: "#f0e2c2", a: "#ea580c", aInk: "#c2410c", aHi: "#fb923c", onA: "#ffffff", b: "#a9834a", bHi: "#d9b978" },
    dark: { page: "#2f1a0c", surf: "#3a2212", line: "#54321c", ink: "#f9ecd4", muted: "#b39c7e", lav: "#452917", a: "#f97316", aInk: "#fb923c", aHi: "#fb923c", onA: "#2a1203", b: "#e0cd9d", bHi: "#d9c48f" },
  },
  {
    id: "neon",
    name: "Neon Green + Charcoal",
    tagline: "Electric green counter on charcoal rooms — neon-sign night market.",
    light: { page: "#e4f5e4", surf: "#eefaf0", line: "#c4e4c9", ink: "#0a2913", muted: "#6f8a76", lav: "#d5ecd9", a: "#22c55e", aInk: "#15803d", aHi: "#4ade80", onA: "#052e12", b: "#3f4449", bHi: "#5d646a" },
    dark: { page: "#161d18", surf: "#1e2822", line: "#2e3b32", ink: "#e2f3e5", muted: "#93a89a", lav: "#253028", a: "#22c55e", aInk: "#4ade80", aHi: "#4ade80", onA: "#052e12", b: "#b6bec4", bHi: "#99a2a9" },
  },
  {
    id: "cherry",
    name: "Cherry Red + Porcelain",
    tagline: "Cherry-red counter on porcelain white — crisp diner classic.",
    light: { page: "#f9e7e7", surf: "#fceeee", line: "#eccdcd", ink: "#3d0d16", muted: "#a07c80", lav: "#f2d8d8", a: "#d21f3c", aInk: "#b01d3e", aHi: "#f2555a", onA: "#ffffff", b: "#9aa6b1", bHi: "#c3cbd3" },
    dark: { page: "#2c0e17", surf: "#38131f", line: "#501e2d", ink: "#f9e5e8", muted: "#b18e94", lav: "#421723", a: "#ef4356", aInk: "#fb7185", aHi: "#fb7185", onA: "#ffffff", b: "#dbe2e8", bHi: "#b9c2cb" },
  },
  {
    id: "azure",
    name: "Azure Sky + Deep Navy",
    tagline: "Sky-blue counter on deep navy rooms — clear-day cockpit.",
    light: { page: "#e2effa", surf: "#ecf5fc", line: "#c4dcec", ink: "#0a2440", muted: "#6f8ba0", lav: "#d0e5f4", a: "#0284c7", aInk: "#0369a1", aHi: "#38bdf8", onA: "#ffffff", b: "#1e40af", bHi: "#3b82f6" },
    dark: { page: "#0d1e3c", surf: "#13284c", line: "#1f3a68", ink: "#e2eefb", muted: "#8ba3c4", lav: "#182f57", a: "#38bdf8", aInk: "#7dd3fc", aHi: "#38bdf8", onA: "#04202e", b: "#93c5fd", bHi: "#60a5fa" },
  },
  {
    id: "cyanreef",
    name: "Reef Cyan + Storm Steel",
    tagline: "Reef-cyan counter on storm-steel rooms — aquarium calm.",
    light: { page: "#e0f3f5", surf: "#ebf8f9", line: "#c2e2e6", ink: "#072a33", muted: "#6f919a", lav: "#cfeaed", a: "#0891b2", aInk: "#0e7490", aHi: "#22d3ee", onA: "#ffffff", b: "#77828f", bHi: "#98a3b0" },
    dark: { page: "#0b232b", surf: "#112e38", line: "#1c4452", ink: "#e0f3f6", muted: "#8facb5", lav: "#163844", a: "#22d3ee", aInk: "#67e8f9", aHi: "#67e8f9", onA: "#04262e", b: "#b9c3cd", bHi: "#9aa6b2" },
  },
];

export const themeById = (id: string): FxTheme => FX_THEMES.find((t) => t.id === id) ?? FX_THEMES[0];

/* ── storage + application (per signed-in account) ─────────────────────────── */

const LEGACY_KEY = "fx-theme";

export function fxThemeStorageKey(account?: string | null): string {
  const who = (account ?? "").trim().toLowerCase();
  return `fx-theme:${who || "guest"}`;
}

export function activeThemeId(): FxThemeId {
  if (typeof document === "undefined") return DEFAULT_THEME;
  const on = document.documentElement.dataset.fxTheme as FxThemeId | undefined;
  return on && FX_THEME_IDS.includes(on) ? on : DEFAULT_THEME;
}

export function readStoredTheme(account?: string | null): FxThemeId {
  try {
    const raw = localStorage.getItem(fxThemeStorageKey(account)) ?? localStorage.getItem(LEGACY_KEY);
    const id = raw as FxThemeId | null;
    return id && FX_THEME_IDS.includes(id) ? id : DEFAULT_THEME;
  } catch {
    return DEFAULT_THEME;
  }
}

/** Apply + persist for this account, then tell every listening chart. */
export function applyTheme(id: FxThemeId, account?: string | null, persist = true): void {
  const valid: FxThemeId = FX_THEME_IDS.includes(id) ? id : DEFAULT_THEME;
  document.documentElement.dataset.fxTheme = valid;
  if (persist) {
    try {
      localStorage.setItem(fxThemeStorageKey(account), valid);
    } catch {
      /* private mode */
    }
  }
  window.dispatchEvent(new CustomEvent("fx-theme-change", { detail: valid }));
}

/** The signed-in account identity (landing stores {name, role}). */
export function currentAccount(): string | null {
  try {
    const raw = localStorage.getItem("fx-auth");
    if (!raw) return null;
    const u = JSON.parse(raw) as { name?: string; email?: string };
    return u.email || u.name || null;
  } catch {
    return null;
  }
}
