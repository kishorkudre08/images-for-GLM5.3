export type Dish = {
  id: string;
  name: string;
  price: number;
  category: string;
  veg: boolean;
  active: boolean;
  createdAt: string;
};

export type BillItem = {
  id: string;
  billId?: string;
  dishId: string | null;
  name: string;
  category: string;
  qty: number;
  price: number;
};

export type Bill = {
  id: string;
  number: number;
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  itemCount: number;
  createdAt: string;
  items: BillItem[];
  // Lodge receipts only — printed number ("L-5001") and guest/service lines.
  numberLabel?: string;
  meta2?: string;
  meta3?: string;
};

export type RangeKey = "today" | "7d" | "1m" | "3m" | "1y";

export type Employee = {
  id: string;
  name: string;
  role: string;
  salary: number; // monthly, INR
  book: "rest" | "lodge"; // which cost book carries this salary
  active: boolean;
  createdAt: string;
};

export type Expense = {
  id: string;
  kind: "raw_material" | "upgrade" | "maintenance";
  book: "rest" | "lodge"; // which business's cost book this entry belongs to
  label: string;
  amount: number;
  spentOn: string;
  via?: string | null; // "task" — auto-registered from a completed owner task (crown row)
  taskId?: string | null;
  createdAt: string;
};

export type Category = {
  id: string;
  name: string;
  createdAt: string;
};

export type RoomStatus = "avl" | "occ" | "mnt";

export type Room = {
  number: number;
  status: RoomStatus;
  guestName: string | null;
  guestPhone: string | null;
  checkInAt: string | null;
  updatedAt: string;
};

export type LodgeBill = {
  id: string;
  number: number; // 5001… printed as L-5001
  room: number;
  guestName: string;
  guestPhone: string;
  tier: string;
  rate: number;
  checkInAt: string;
  checkOutAt: string;
  hours: number;
  stay: number;
  minApplied: boolean;
  discount: number;
  tax: number;
  total: number;
  createdAt: string;
};

export type BookCosts = {
  salaries: number;
  rawMaterials: number;
  upgrades: number; // t98 — the receptions' third expense type
  maintenance: number;
  profit: number;
};

/** t97 — one progress note posted on an owner task. */
export type TaskNote = {
  id: string;
  taskId: string;
  author: string;
  role: string;
  message: string;
  createdAt: string;
};

/** t97 — a task the owner forwards to the lodge or restaurant reception.
 * maxBudget = null → free task; when budgeted, kind + description are set. */
export type FxTask = {
  id: string;
  title: string;
  book: "rest" | "lodge"; // which reception the task is forwarded to
  kind: "raw_material" | "upgrade" | "maintenance" | null; // expense type (required when budgeted)
  maxBudget: number | null;
  description: string;
  deadline: string;
  status: "open" | "done";
  createdBy: string;
  createdAt: string;
  doneAt: string | null;
  doneBy: string | null;
  actualCost: number | null;
  updates: TaskNote[];
};

/** t91 — room-hours wall split (mirrors src/lib/analytics-lodge.ts). */
export type RoomHoursData = {
  guests: number; // room-hours hosted by guests inside the window
  mnt: number; // room-hours spent under maintenance
  free: number; // the wall's leftover room-hours
  total: number; // totalRooms × windowHours
  totalRooms: number; // the wall size (100) — donut slices sum to this
  windowHours: number; // window length in hours
  windowLabel: string; // "TODAY" / "LAST 7 DAYS" …
};

export type LodgeBlock = {
  revenue: number;
  stays: number;
  avgStay: number;
  deltaPct: number | null;
  buckets: Array<{ label: string; revenue: number; stays: number }>;
  peakLabel: string | null;
  dayCurve: Array<{ label: string; pct: number }>;
  dayPeak: string | null;
  inHouse: number;
  pctFull: number;
  mnt: number;
  tonight: number;
  stayMix: Array<{ label: string; share: number }>;
  tierMix: Array<{ tier: string; revenue: number; share: number }>;
  /** t91 — room-hours split of the wall for the selected window */
  roomHours: RoomHoursData;
  recent: Array<{
    number: number;
    room: number;
    guestName: string;
    total: number;
    createdAt: string;
    hours: number;
  }>;
};

export type DashboardData = {
  generatedAt: string;
  range: RangeKey;
  stats: {
    revenue: number;
    bills: number;
    items: number;
    avgTicket: number;
    discounts: number;
    revenueDeltaPct: number | null;
    billDeltaPct: number | null;
  };
  peakLabel: string | null;
  buckets: Array<{ label: string; revenue: number; bills: number }>;
  hourly: {
    series: Array<{ label: string; avg: number; bills: number }>;
    peak: string | null;
    quiet: string | null;
    days: number;
  };
  itemsSold: Array<{ name: string; qty: number; revenue: number }>;
  categoryMix: Array<{ category: string; revenue: number; share: number }>;
  recentBills: Bill[];
  allTime: { bills: number; revenue: number };
  team: {
    employees: Array<{ id: string; name: string; role: string; salary: number; book: "rest" | "lodge" }>;
    monthlyTotal: number;
    periodCost: number;
  };
  costs: {
    salaries: number;
    rawMaterials: number;
    upgrades: number;
    maintenance: number;
    profit: number;
    marginPct: number | null;
  };
  books: { rest: BookCosts; lodge: BookCosts };
  lodge: LodgeBlock;
};

export const CATEGORIES = [
  "Starters",
  "Main Course",
  "Breads",
  "Rice & Biryani",
  "Desserts",
  "Beverages",
] as const;
