"use client";

// ── t99 · SETTINGS — a whole page, not a pop-up ─────────────────────────────
// t104 — the theme gallery shows the REAL page screenshots again, arranged
// exactly the way the user asked (and matching the reference screenshot):
//   · ONE theme per column — each theme is its own individual block
//   · inside, the four REAL screenshots stack into a 1×4 rectangle (never
//     the 2×2 square) in the fixed order
//       PRE-LOGIN · LIGHT → DASHBOARD · LIGHT
//       → PRE-LOGIN · DARK → DASHBOARD · DARK
//   · each shot is its own framed cell with its own caption BELOW it, its
//     own motion, and the block carries the theme's tinted page colours
//     (combo's lighter colour = the light page, darker = the dark page).
// t108 — COMPACT GALLERY (user: "decrease the size of theme preview · 1×4
// meant 1 column and 4 rows"): the 4 shots stay a single 1-column stack but
// render as uniform 80px-tall thumbnails (object-cover, top-anchored), the
// per-theme blocks shrink (padding, type, chips) and the gallery re-flows to
// a denser responsive grid — 2 columns on phones, 3 on tablets, 4 on desktop.
// t109 — DIRECTION FIX (user: "theme should be left to right, not up to
// down"): the 4 REAL screenshots now flow LEFT → RIGHT as one 4-across strip
// (grid-cols-4) of the same uniform 80px thumbs; theme blocks need width for
// the strip, so the gallery re-flows to 1 column on phones and 2 on lg+.
// t110 — ONE THEME PER COLUMN (user: "only one per column … overcrowded …
// last change on themes"): the gallery drops the lg:2 split — every theme
// block takes the full column width on every viewport; blocks and titles
// unchanged. Below the gallery: the tenant profile rename.
// t111 — FINAL SHAPE (user sketch: wide rounded blocks stacked top→bottom):
// the ten theme blocks stack VERTICALLY — ONE theme per row at full column
// width on every viewport (the sketch's stack of wide rectangles) — while
// INSIDE each block its four REAL screenshots keep flowing in ONE left→right
// line (grid-cols-4, uniform 80px thumbs, fixed order). Blocks and titles
// unchanged from t109. This is the settled theme-gallery layout. Below the
// gallery: the tenant profile rename.
// t112 — NO-CROP THUMBS (user: "they get cut in half due to less height"):
// the fixed 80px height cropped each page shot, so every thumbnail now sits
// in an 8:5 frame with object-contain — the WHOLE screenshot always visible
// (prelogin 1100×560 and dashboard 880×620 both fit), slim surf bands where
// the aspect differs. Gallery stays one theme per row.

import * as React from "react";
import { Check, Loader2, ListChecks, Palette, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FX_TIERS, tierEyebrow } from "@/lib/tiers";
import { TierBand } from "@/components/fx";
import { useHotel } from "@/components/hotel-context";
import { useToast } from "@/hooks/use-toast";
import {
  FX_THEMES,
  activeThemeId,
  applyTheme,
  currentAccount,
  type FxTheme,
  type FxThemeId,
} from "@/lib/fx-themes";
import { TASK_FAB_EVENT, TASK_FAB_KEY } from "@/components/task-tracker";

/* one REAL screenshot cell — framed card, caption BELOW (like the reference),
   own motion, own dot; light shots framed in the theme's light surf, dark
   shots in the dark surf, captions always on the block's tinted page */
function ShotBlock({
  caption,
  dot,
  delay,
  testid,
  src,
  alt,
  surf,
  line,
  ink,
}: {
  caption: string;
  dot: string;
  delay: number;
  testid: string;
  src: string;
  alt: string;
  surf: string;
  line: string;
  ink: string;
}) {
  return (
    <figure
      className="fx-pop-in rounded-lg p-1"
      style={{ background: surf, border: `1px solid ${line}`, animationDelay: `${delay}ms` }}
      data-testid={testid}
    >
      {/* t112 — no-crop thumb (user: "cut in half due to less height"): one
          8:5 frame + object-contain shows the WHOLE page shot every time */}
      <img
        src={src}
        alt={alt}
        loading="lazy"
        className="block w-full rounded-md object-contain"
        style={{ aspectRatio: "8 / 5", border: `1px solid ${line}` }}
      />
      <figcaption className="fx-label !text-[6.5px] !tracking-normal mt-0.5 flex items-center justify-center gap-1" style={{ color: ink }}>
        <i className="h-1 w-1 shrink-0 rounded-full" style={{ background: dot }} aria-hidden />
        {caption}
      </figcaption>
    </figure>
  );
}

/* ── one theme = ONE full-width ROW in the vertical stack of themes ── */

function ThemeCard({ t, active, index }: { t: FxTheme; active: boolean; index: number }) {
  return (
    <div
      className="fx-card fx-pop-in rounded-xl border p-2 shadow-[2px_3px_0_0_var(--fx-hard)]"
      style={{
        animationDelay: `${Math.min(index, 6) * 60}ms`,
        background: t.light.page,
        borderColor: active ? "var(--fx-purple)" : t.light.line,
      }}
      data-testid={`settings-theme-${t.id}`}
      aria-pressed={active}
      role="button"
      tabIndex={0}
      onClick={() => applyTheme(t.id, currentAccount())}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          applyTheme(t.id, currentAccount());
        }
      }}
    >
      {/* theme header — one inline row for the full-width block: dots + title left, chip right */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="flex items-center gap-2">
          <span className="flex items-center -space-x-1">
            <i className="h-3 w-3 rounded-full border" style={{ background: t.light.a, borderColor: t.light.surf }} />
            <i className="h-3 w-3 rounded-full border" style={{ background: t.light.bHi, borderColor: t.light.surf }} />
          </span>
          <span className="flex items-center gap-1 text-[10px] font-extrabold leading-tight" style={{ color: t.light.ink }}>
            {t.name}
            {active && <Check className="h-3 w-3 shrink-0" style={{ color: t.light.aInk }} aria-label="Active theme" />}
          </span>
        </span>
        <span
          className="rounded-full px-1.5 py-0.5 text-[6.5px] font-extrabold tracking-widest"
          style={active ? { background: t.light.a, color: t.light.onA } : { background: t.light.lav, color: t.light.aInk }}
        >
          {active ? "ACTIVE" : "TAP TO APPLY"}
        </span>
      </div>

      {/* the 4-across strip — four REAL screenshots in ONE row, flowing LEFT → RIGHT */}
      <div className="mt-1.5 grid grid-cols-4 gap-1.5">
        <ShotBlock
          caption="PRE-LOGIN · LIGHT"
          dot={t.light.a}
          delay={0}
          testid={`settings-theme-${t.id}-light-prelogin`}
          src={`/theme-previews/${t.id}-light-prelogin.jpg`}
          alt={`${t.name} — pre-login page, light mode`}
          surf={t.light.surf}
          line={t.light.line}
          ink={t.light.muted}
        />
        <ShotBlock
          caption="DASHBOARD · LIGHT"
          dot={t.light.bHi}
          delay={70}
          testid={`settings-theme-${t.id}-light-dashboard`}
          src={`/theme-previews/${t.id}-light-dashboard.jpg`}
          alt={`${t.name} — live dashboard, light mode`}
          surf={t.light.surf}
          line={t.light.line}
          ink={t.light.muted}
        />
        <ShotBlock
          caption="PRE-LOGIN · DARK"
          dot={t.dark.a}
          delay={140}
          testid={`settings-theme-${t.id}-dark-prelogin`}
          src={`/theme-previews/${t.id}-dark-prelogin.jpg`}
          alt={`${t.name} — pre-login page, dark mode`}
          surf={t.dark.surf}
          line={t.dark.line}
          ink={t.light.muted}
        />
        <ShotBlock
          caption="DASHBOARD · DARK"
          dot={t.dark.bHi}
          delay={210}
          testid={`settings-theme-${t.id}-dark-dashboard`}
          src={`/theme-previews/${t.id}-dark-dashboard.jpg`}
          alt={`${t.name} — live dashboard, dark mode`}
          surf={t.dark.surf}
          line={t.dark.line}
          ink={t.light.muted}
        />
      </div>
    </div>
  );
}

export function SettingsView({ roleName }: { roleName: string }) {
  const { toast } = useToast();
  const { hotelName, saveHotelName } = useHotel();
  const [nameDraft, setNameDraft] = React.useState<string | null>(null);
  const [saving, setSaving] = React.useState(false);
  const [theme, setTheme] = React.useState<FxThemeId>("classic");
  /* t118 — the floating task tracker's on/off switch (all three accounts) */
  const [taskFab, setTaskFab] = React.useState(true);

  React.useEffect(() => {
    setTheme(activeThemeId());
    const on = () => setTheme(activeThemeId());
    window.addEventListener("fx-theme-change", on);
    setTaskFab(localStorage.getItem(TASK_FAB_KEY) !== "0");
    return () => window.removeEventListener("fx-theme-change", on);
  }, []);

  const flipTaskFab = (on: boolean) => {
    setTaskFab(on);
    try {
      localStorage.setItem(TASK_FAB_KEY, on ? "1" : "0");
    } catch {
      /* private mode */
    }
    window.dispatchEvent(new Event(TASK_FAB_EVENT));
  };

  const nameValue = nameDraft ?? hotelName;
  const nameDirty = nameValue.trim() !== hotelName && nameValue.trim().length >= 2;

  const saveName = async () => {
    setSaving(true);
    const ok = await saveHotelName(nameValue);
    setSaving(false);
    if (ok) {
      setNameDraft(null);
      toast({ title: `Name updated — every screen now says “${nameValue.trim()}”` });
    } else {
      toast({
        title: "Could not rename",
        description: "Name needs at least 2 characters.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-5" data-testid="settings-view">
      <TierBand
        num={FX_TIERS.settings.num}
        eyebrow={tierEyebrow(FX_TIERS.settings)}
        title="Settings"
        sub="Make the console yours — the ten themes stack ONE per row like the sketch's wide cards, and inside each row its four REAL page screenshots flow left to right (pre-login and live dashboard, light and dark) in the combo's real colours. The tenant rename flows onto every screen; the Fetch-X platform brand stays fixed."
        tag={`${FX_THEMES.length} THEMES · ONE PER ROW · 4 SHOTS EACH`}
      />

      {/* ── THEMES — one theme per ROW (the sketch), 4 shots LEFT→RIGHT inside ── */}
      <div className="fx-card p-5" data-testid="settings-themes">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="fx-label inline-flex items-center gap-2">
            <Palette className="h-3.5 w-3.5 text-[var(--fx-accent-ink)]" />
            THEMES · ONE PER ROW · 4 SHOTS LEFT → RIGHT
          </span>
          <span className="mut-chip inline-flex items-center gap-1.5">
            4 FULL SHOTS PER THEME · PRELOGIN / DASHBOARD × LIGHT / DARK
          </span>
        </div>
        <div className="mt-3 grid grid-cols-1 gap-4">
          {FX_THEMES.map((t, i) => (
            <ThemeCard key={t.id} t={t} active={t.id === theme} index={i} />
          ))}
        </div>
        <p className="mt-3 text-[10.5px] font-semibold text-[var(--fx-muted)]">
          Tap a block to apply that theme to this account — every shot is a real page screenshot in
          that theme's colours; the combo's lighter colour becomes the light-mode page, its darker
          colour the dark-mode page. Remembered per account.
        </p>
      </div>

      {/* ── t118 — FLOATING TASK TRACKER — the on/off switch (every account) ── */}
      <div className="fx-card p-5" data-testid="settings-task-fab">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="fx-label inline-flex items-center gap-2">
            <ListChecks className="h-3.5 w-3.5 text-[var(--fx-accent-ink)]" />
            FLOATING TASK TRACKER
          </span>
          <button
            onClick={() => flipTaskFab(!taskFab)}
            aria-pressed={taskFab}
            data-testid="task-fab-toggle"
            className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-[10.5px] font-extrabold tracking-[0.09em] transition ${
              taskFab
                ? "bg-[var(--fx-green)] text-[var(--fx-surf)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                : "border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
            }`}
          >
            <span className={`h-2 w-2 rounded-full ${taskFab ? "bg-[var(--fx-surf)]" : "bg-[var(--fx-muted)]"}`} aria-hidden />
            {taskFab ? "SHOWING · TAP TO HIDE" : "HIDDEN · TAP TO SHOW"}
          </button>
        </div>
        <p className="mt-3 text-[10.5px] font-semibold leading-relaxed text-[var(--fx-muted)]">
          The pocket version of the Tasks section — a small button floats over every screen with this
          account's open work, deadlines and budgets, and taps into the full board. Turn it off and the
          button disappears everywhere; turn it back on here. Remembered per browser, for all three
          accounts.
        </p>
      </div>

      {/* ── PROFILE — the tenant name change ── */}
      <div className="fx-card p-5" data-testid="settings-profile">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="fx-label inline-flex items-center gap-2">
            <UserRound className="h-3.5 w-3.5 text-[var(--fx-accent-ink)]" />
            PROFILE · {roleName}
          </span>
          <span className="mut-chip">FLOWS ONTO THE SIDEBAR, BILLS &amp; DASHBOARDS</span>
        </div>
        <div className="mt-3 flex max-w-[520px] items-center gap-2">
          <Input
            value={nameValue}
            onChange={(e) => setNameDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && nameDirty) void saveName();
            }}
            placeholder="Display name…"
            aria-label="Display name"
            data-testid="settings-name-input"
            className="h-10 min-w-0 flex-1 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-semibold"
          />
          <Button
            onClick={() => void saveName()}
            disabled={saving || !nameDirty}
            data-testid="settings-name-save"
            className="h-10 shrink-0 rounded-xl bg-[var(--fx-purple)] px-4 text-[11px] font-extrabold text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)] disabled:opacity-50"
          >
            {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
            SAVE NAME
          </Button>
        </div>
        <p className="mt-3 text-[10.5px] font-semibold text-[var(--fx-muted)]">
          The name flows onto the sidebar, bills and dashboards — the Fetch-X platform brand stays
          fixed.
        </p>
      </div>
    </div>
  );
}
