"use client";

import * as React from "react";
import { Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";

// ── Block-scoped scroller with a bottom fade when content overflows ────────
// The block scrolls, the page doesn't (TEAM roster, LATEST ACTIVITY, ledger).
export function ScrollFadeBox({
  children,
  maxH = 352,
  className = "",
}: {
  children: React.ReactNode;
  maxH?: number;
  className?: string;
}) {
  const ref = React.useRef<HTMLDivElement>(null);
  const [scrollable, setScrollable] = React.useState(false);
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const measure = () => setScrollable(el.scrollHeight > el.clientHeight + 4);
    measure();
    if (typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return (
    <div className={`scrollfade ${scrollable ? "is-scrollable" : ""} ${className}`}>
      <div ref={ref} className="fx-scroll overflow-y-auto pr-1" style={{ maxHeight: maxH }}>
        {children}
      </div>
    </div>
  );
}

// ── Theme toggle (sun/moon, like the attachment header) ────────────────────
export function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const dark = theme === "dark";
  return (
    <Button
      variant="outline"
      size="icon"
      aria-label="Toggle dark mode"
      title="Dark / light mode"
      onClick={() => setTheme(dark ? "light" : "dark")}
      className="rounded-xl border-[var(--fx-line)] bg-[var(--fx-surf)] shadow-[2px_3px_0_0_var(--fx-hard)]"
    >
      {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
    </Button>
  );
}

// ── t76 · universal theme selector — REMOVED (t101): the theme already
//    lives in Settings, so the per-band THEME button is gone by request.

// ── Numbered tier band — the section opener from the attachment ───────────
export function TierBand({
  num,
  eyebrow,
  title,
  sub,
  tag,
  live,
  children,
}: {
  num: string;
  eyebrow: string;
  title: string;
  sub: string;
  tag?: React.ReactNode;
  live?: boolean;
  children?: React.ReactNode;
}) {
  return (
    <div className="fx-band fx-rise flex flex-wrap items-center gap-4 rounded-[18px] border-[var(--fx-line)] px-6 py-5" data-fx-motion="1">
      <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-[var(--fx-purple)] font-mono text-sm font-bold text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)]">
        {num}
      </span>
      <div className="min-w-[200px] flex-1">
        <div className="fx-label flex items-center gap-2">
          {live && <span className="fx-live-dot" aria-hidden />}
          {eyebrow}
        </div>
        <h1 className="mt-0.5 text-xl font-extrabold tracking-tight text-[var(--fx-ink)] md:text-2xl">
          {title}
        </h1>
        <p className="mt-0.5 text-[13px] font-medium text-[var(--fx-muted)]">{sub}</p>
      </div>
      {tag && (
        <span className="rounded-full border border-[var(--fx-line)] bg-[var(--fx-lav)] px-4 py-2 text-[10px] font-extrabold tracking-[0.12em] text-[var(--fx-ink)]">
          {tag}
        </span>
      )}
      {children}
    </div>
  );
}

// ── Veg / Non-veg marker (Indian FSSAI convention) ─────────────────────────
export function VegDot({ veg, className = "" }: { veg: boolean; className?: string }) {
  return (
    <span
      title={veg ? "Vegetarian" : "Non-vegetarian"}
      className={`inline-grid h-4 w-4 shrink-0 place-items-center rounded-[4px] border ${
        veg ? "border-[var(--fx-green)]" : "border-[var(--fx-rose)]"
      } ${className}`}
      aria-hidden
    >
      <span
        className={`h-1.5 w-1.5 rounded-full ${veg ? "bg-[var(--fx-green)]" : "bg-[var(--fx-rose)]"}`}
      />
    </span>
  );
}

// ── Stat card for the live strip ───────────────────────────────────────────
export function StatCard({
  label,
  value,
  icon,
  delta,
  footnote,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  delta?: { text: string; up: boolean } | null;
  footnote?: string;
}) {
  return (
    <div className="fx-card px-5 py-4">
      <div className="flex items-center justify-between gap-3">
        <span className="fx-label">{label}</span>
        <span className="grid h-8 w-8 place-items-center rounded-xl bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]">
          {icon}
        </span>
      </div>
      <div className="fx-num mt-2 text-2xl font-extrabold tracking-tight text-[var(--fx-ink)] md:text-[26px]">
        {value}
      </div>
      <div className="mt-1 h-4 text-[11px] font-semibold">
        {delta ? (
          <span className={delta.up ? "text-[var(--fx-green)]" : "text-[var(--fx-rose)]"}>
            {delta.text}
          </span>
        ) : (
          <span className="text-[var(--fx-muted)]">{footnote ?? ""}</span>
        )}
      </div>
    </div>
  );
}

// ── Fetch-X date picker — replaces the raw native <input type="date"> ──────
// Premium month grid with purple accents, dark-mode aware, TODAY + CLEAR
// footer, future dates blocked (the books only record costs already paid).
export function FxDatePicker({
  value,
  onChange,
  ariaLabel,
  disableFuture = true,
}: {
  value: string; // yyyy-mm-dd
  onChange: (v: string) => void;
  ariaLabel?: string;
  disableFuture?: boolean;
}) {
  const [open, setOpen] = React.useState(false);
  const wrapRef = React.useRef<HTMLDivElement>(null);

  // close on outside click / Escape
  React.useEffect(() => {
    if (!open) return;
    const away = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setOpen(false);
    };
    const esc = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", away);
    document.addEventListener("keydown", esc);
    return () => {
      document.removeEventListener("mousedown", away);
      document.removeEventListener("keydown", esc);
    };
  }, [open]);

  const parse = (s: string) => new Date(`${s}T12:00:00`); // noon dodges DST edges
  const fmt = (s: string) =>
    `${parse(s).toLocaleDateString("en-IN", { day: "2-digit", month: "short" })} ${parse(s).getFullYear()}`;
  const todayISO = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  };
  const [view, setView] = React.useState(() => {
    const base = value || todayISO();
    const d = parse(base);
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });

  const select = (d: Date) => {
    const iso = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    onChange(iso);
    setOpen(false);
  };
  const shift = (n: number) => setView((v) => new Date(v.getFullYear(), v.getMonth() + n, 1));

  const y = view.getFullYear();
  const m = view.getMonth();
  const firstDow = new Date(y, m, 1).getDay();
  const daysInMonth = new Date(y, m + 1, 0).getDate();
  const daysPrev = new Date(y, m, 0).getDate();
  const cells: Array<{ d: Date; inMonth: boolean }> = [];
  for (let i = firstDow - 1; i >= 0; i--) cells.push({ d: new Date(y, m - 1, daysPrev - i), inMonth: false });
  for (let d = 1; d <= daysInMonth; d++) cells.push({ d: new Date(y, m, d), inMonth: true });
  while (cells.length % 7 !== 0) {
    const next = new Date(y, m + 1, (cells.length - firstDow - daysInMonth) + 1);
    cells.push({ d: next, inMonth: false });
  }
  const iso = (d: Date) =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const futureISO = todayISO();
  const today = todayISO();

  return (
    <div className="relative" ref={wrapRef}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-label={ariaLabel ?? "Pick a date"}
        aria-expanded={open}
        className="fx-num inline-flex h-10 items-center gap-2 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-3 text-[12.5px] font-bold text-[var(--fx-ink)] transition hover:border-[color-mix(in_srgb,var(--fx-purple)_45%,var(--fx-line))]"
      >
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" className="h-3.5 w-3.5 text-[var(--fx-muted)]">
          <rect x="3" y="4" width="18" height="18" rx="3" />
          <path d="M16 2v4M8 2v4M3 10h18" />
        </svg>
        {fmt(value || today)}
      </button>
      {open && (
        <div
          role="dialog"
          aria-label="Calendar"
          className="absolute left-0 top-[calc(100%+6px)] z-50 w-[268px] rounded-2xl border border-[var(--fx-line)] bg-[var(--fx-surf)] p-3 shadow-[6px_10px_30px_-12px_rgba(35,32,72,.5)]"
        >
          <div className="flex items-center justify-between gap-2 pb-2">
            <button
              type="button"
              aria-label="Previous month"
              onClick={() => shift(-1)}
              className="grid h-7 w-7 place-items-center rounded-lg text-[var(--fx-muted)] transition hover:bg-[var(--fx-lav)] hover:text-[var(--fx-accent-ink)]"
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" className="h-3.5 w-3.5"><path d="M15 18l-6-6 6-6" /></svg>
            </button>
            <b className="text-[12px] font-extrabold tracking-wide text-[var(--fx-ink)]">
              {view.toLocaleDateString("en-IN", { month: "long", year: "numeric" })}
            </b>
            <button
              type="button"
              aria-label="Next month"
              onClick={() => shift(1)}
              className="grid h-7 w-7 place-items-center rounded-lg text-[var(--fx-muted)] transition hover:bg-[var(--fx-lav)] hover:text-[var(--fx-accent-ink)]"
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" className="h-3.5 w-3.5"><path d="M9 6l6 6-6 6" /></svg>
            </button>
          </div>
          <div className="grid grid-cols-7 gap-0.5 pb-1 text-center">
            {["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].map((w) => (
              <span key={w} className="py-1 text-[8.5px] font-extrabold tracking-wider text-[var(--fx-muted)]">
                {w}
              </span>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-0.5">
            {cells.map(({ d, inMonth }, i) => {
              const isoD = iso(d);
              const isSel = isoD === value;
              const isToday = isoD === today;
              const isFuture = disableFuture && isoD > futureISO;
              return (
                <button
                  key={i}
                  type="button"
                  disabled={isFuture}
                  onClick={() => select(d)}
                  aria-label={d.toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}
                  className={`fx-num grid h-8 place-items-center rounded-lg text-[11.5px] font-bold transition ${
                    isSel
                      ? "bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[1px_2px_0_0_var(--fx-hard)]"
                      : isFuture
                        ? "cursor-not-allowed text-[var(--fx-muted)] opacity-35"
                        : inMonth
                          ? `text-[var(--fx-ink)] hover:bg-[var(--fx-lav)] ${isToday ? "ring-1 ring-inset ring-[var(--fx-purple)]/50" : ""}`
                          : "text-[var(--fx-muted)] opacity-50 hover:bg-[var(--fx-lav)]"
                  }`}
                >
                  {d.getDate()}
                </button>
              );
            })}
          </div>
          <div className="mt-2 flex items-center justify-between border-t border-dashed border-[var(--fx-line)] pt-2">
            <button
              type="button"
              onClick={() => {
                const d = new Date();
                d.setDate(d.getDate() - 1);
                onChange(iso(d));
                setView(new Date(d.getFullYear(), d.getMonth(), 1));
              }}
              className="rounded-lg px-2 py-1 text-[9.5px] font-extrabold tracking-wider text-[var(--fx-muted)] transition hover:text-[var(--fx-rose)]"
            >
              YESTERDAY
            </button>
            <button
              type="button"
              onClick={() => select(parse(today))}
              className="rounded-lg bg-[var(--fx-lav)] px-3 py-1.5 text-[9.5px] font-extrabold tracking-wider text-[var(--fx-accent-ink)] transition hover:bg-[var(--fx-purple)] hover:text-[var(--fx-on-accent)]"
            >
              TODAY
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
