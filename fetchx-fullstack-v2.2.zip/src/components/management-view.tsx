"use client";

// ── t98 · MANAGEMENT — slimmed down ─────────────────────────────────────────
// The menu editor lived here until the owner's menu editing moved into the
// POS view (add-category on top, a blank add-dish block in every category,
// edit/delete beside every dish). The rooms & rates editor moved to the bottom
// of the Lodge Front Desk.
// t113 — the section is renamed EMPLOYEE (nav + title) and the HOTEL PROFILE
// subsection is gone entirely — that rename already lives in Settings, so
// keeping it here was a duplicate. What remains: the team roster.

import * as React from "react";
import { Loader2, Plus, RotateCcw, Users, Save, Pencil, X, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FX_TIERS, tierEyebrow } from "@/lib/tiers";
import { TierBand } from "@/components/fx";
import { useToast } from "@/hooks/use-toast";
import type { Employee } from "@/lib/types";
import { inr } from "@/lib/format";

export function ManagementView() {
  const { toast } = useToast();

  // ── data ──────────────────────────────────────────────────────────────────
  const [employees, setEmployees] = React.useState<Employee[]>([]);
  const [opLoading, setOpLoading] = React.useState(false);
  const [confirming, setConfirming] = React.useState<string | null>(null); // two-step delete

  const loadOps = React.useCallback(async () => {
    try {
      const e = await fetch("/api/employees").then((x) => x.json());
      setEmployees(Array.isArray(e) ? e : []);
    } catch {
      // keep old data on failure
    }
  }, []);

  React.useEffect(() => {
    void loadOps();
  }, [loadOps]);

  const activeEmployees = employees.filter((e) => e.active);
  const monthlySalary = activeEmployees.reduce((s, e) => s + e.salary, 0);

  // ── collapsible subsections ────────────────────────────────────────────────
  const [open, setOpen] = React.useState<Record<string, boolean>>({
    emp: true,
  });
  const toggle = (k: string) => setOpen((m) => ({ ...m, [k]: !m[k] }));

  // ── inline row editing (one row in edit mode at a time) ───────────────────
  const [editing, setEditing] = React.useState<string | null>(null);
  const [draft, setDraft] = React.useState<Record<string, Record<string, string>>>({});
  const setD = (k: string, patch: Record<string, string>) =>
    setDraft((m) => ({ ...m, [k]: { ...m[k], ...patch } }));

  const startEdit = (k: string, vals: Record<string, string>) => {
    setConfirming(null);
    setEditing(k);
    setDraft((m) => ({ ...m, [k]: vals }));
  };
  const cancelEdit = () => setEditing(null);

  // ── mutation helper ───────────────────────────────────────────────────────
  const mutate = async (
    url: string,
    method: string,
    body?: unknown,
    okMsg?: string,
    after?: () => Promise<void>,
  ): Promise<boolean> => {
    setOpLoading(true);
    try {
      const res = await fetch(url, {
        method,
        headers: body ? { "Content-Type": "application/json" } : undefined,
        body: body ? JSON.stringify(body) : undefined,
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error ?? "Request failed");
      }
      if (after) await after();
      if (okMsg) toast({ title: okMsg });
      return true;
    } catch (e) {
      toast({
        title: "Action failed",
        description: e instanceof Error ? e.message : "Unknown error",
        variant: "destructive",
      });
      return false;
    } finally {
      setOpLoading(false);
    }
  };

  // two-step delete: first click arms the button, second click executes
  const confirmBtn = (key: string, onConfirm: () => void, label = "Remove") => {
    const armed = confirming === key;
    return (
      <Button
        size="sm"
        variant="ghost"
        disabled={opLoading}
        onClick={() => {
          if (armed) {
            setConfirming(null);
            onConfirm();
          } else {
            setConfirming(key);
            setTimeout(() => setConfirming((c) => (c === key ? null : c)), 3000); // auto-disarm
          }
        }}
        className={`h-8 shrink-0 rounded-lg px-2.5 text-[10.5px] font-extrabold tracking-wider ${
          armed
            ? "bg-[var(--fx-rose)] text-white hover:bg-[var(--fx-rose)]"
            : "text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-rose)]"
        }`}
      >
        {armed ? "SURE?" : label.toUpperCase()}
      </Button>
    );
  };

  // shared row buttons: EDIT · SAVE · CANCEL · RESTORE
  const editBtn = (key: string, vals: Record<string, string>) => (
    <Button
      size="sm"
      variant="ghost"
      disabled={opLoading}
      onClick={() => startEdit(key, vals)}
      className="h-8 shrink-0 rounded-lg px-2.5 text-[10.5px] font-extrabold tracking-wider text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-accent-ink)]"
    >
      <Pencil className="mr-1 h-3 w-3" /> EDIT
    </Button>
  );
  const saveBtn = (onSave: () => void) => (
    <Button
      size="sm"
      disabled={opLoading}
      onClick={onSave}
      className="h-8 shrink-0 rounded-lg bg-[var(--fx-purple)] px-3 text-[10.5px] font-extrabold tracking-wider text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
    >
      {opLoading ? <Loader2 className="h-3 w-3 animate-spin" /> : <><Save className="mr-1 h-3 w-3" /> SAVE</>}
    </Button>
  );
  const cancelBtn = () => (
    <Button
      size="sm"
      variant="ghost"
      onClick={cancelEdit}
      aria-label="Cancel editing"
      className="h-8 w-8 shrink-0 rounded-lg p-0 text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
    >
      <X className="h-3.5 w-3.5" />
    </Button>
  );
  const restoreBtn = (onClick: () => void) => (
    <Button
      size="sm"
      variant="ghost"
      disabled={opLoading}
      onClick={onClick}
      className="h-8 shrink-0 rounded-lg px-2.5 text-[10.5px] font-extrabold tracking-wider text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-green)]"
    >
      <RotateCcw className="mr-1 h-3 w-3" /> RESTORE
    </Button>
  );

  // collapsible numbered section shell
  const sectionHead = (
    num: string,
    icon: React.ReactNode,
    title: string,
    badge: string,
    isOpen: boolean,
  ) => (
    <span className="flex min-w-0 flex-1 flex-wrap items-center gap-2.5">
      <span className="fx-num grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-[var(--fx-purple)] text-[12px] font-black text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)]">
        {num}
      </span>
      <span className="fx-label flex items-center gap-2">
        {icon} {title}
      </span>
      <span className="fx-num ml-auto max-w-[240px] truncate rounded-full bg-[var(--fx-lav)] px-3 py-1 text-[10px] font-extrabold text-[var(--fx-muted)]">
        {badge}
      </span>
      <ChevronDown
        aria-hidden
        className={`h-4 w-4 shrink-0 text-[var(--fx-muted)] transition-transform ${isOpen ? "" : "-rotate-90"}`}
      />
    </span>
  );

  // ══ 01 · EMPLOYEE LIST ═══════════════════════════════════════════════════
  const [empName, setEmpName] = React.useState("");
  const [empRole, setEmpRole] = React.useState("");
  const [empSalary, setEmpSalary] = React.useState("");
  const [empBook, setEmpBook] = React.useState<"all" | "rest" | "lodge">("all");
  const [empNewBook, setEmpNewBook] = React.useState<"rest" | "lodge">("rest");

  const addEmployee = async () => {
    const salary = Number(empSalary);
    if (!empName.trim() || !Number.isFinite(salary) || salary <= 0) {
      toast({
        title: "Missing details",
        description: "Employee needs a name and a monthly salary above zero.",
        variant: "destructive",
      });
      return;
    }
    const ok = await mutate(
      "/api/employees",
      "POST",
      { name: empName.trim(), role: empRole.trim() || "Staff", salary, book: empNewBook },
      `${empName.trim()} joined the team`,
      loadOps,
    );
    if (ok) {
      setEmpName("");
      setEmpRole("");
      setEmpSalary("");
    }
  };

  const saveEmployee = async (emp: Employee) => {
    const d = draft[`emp:${emp.id}`] ?? {};
    const name = (d.name ?? "").trim();
    const salary = Number(d.salary);
    if (!name || !Number.isFinite(salary) || salary <= 0) {
      toast({
        title: "Missing details",
        description: "Name and a monthly salary above zero are required.",
        variant: "destructive",
      });
      return;
    }
    const ok = await mutate(
      "/api/employees",
      "PATCH",
      { id: emp.id, name, role: (d.role ?? "").trim() || emp.role, salary },
      `${name} updated`,
      loadOps,
    );
    if (ok) setEditing(null);
  };

  const empRow = (emp: Employee) => {
    const ek = `emp:${emp.id}`;
    if (editing === ek) {
      const d = draft[ek] ?? {};
      return (
        <div
          key={emp.id}
          className="flex flex-wrap items-center gap-2 rounded-xl border border-[var(--fx-purple)]/40 bg-[var(--fx-lav)] px-3 py-2"
        >
          <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-[var(--fx-purple)] text-[12px] font-black text-[var(--fx-on-accent)]">
            {emp.name.slice(0, 1).toUpperCase()}
          </span>
          <Input
            value={d.name ?? ""}
            onChange={(e) => setD(ek, { name: e.target.value })}
            placeholder="Name"
            aria-label={`Edit name of ${emp.name}`}
            className="h-9 min-w-[120px] flex-[1.2] rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] font-semibold"
          />
          <Input
            value={d.role ?? ""}
            onChange={(e) => setD(ek, { role: e.target.value })}
            placeholder="Role"
            aria-label={`Edit role of ${emp.name}`}
            className="h-9 min-w-[100px] flex-1 rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] font-semibold"
          />
          <Input
            value={d.salary ?? ""}
            onChange={(e) => setD(ek, { salary: e.target.value })}
            type="number"
            min={0}
            placeholder="₹/month"
            aria-label={`Edit monthly salary of ${emp.name}`}
            className="fx-num h-9 w-[104px] rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] font-bold"
          />
          {saveBtn(() => void saveEmployee(emp))}
          {cancelBtn()}
        </div>
      );
    }
    return (
      <div
        key={emp.id}
        className={`flex items-center gap-2.5 rounded-xl border border-[var(--fx-line)] px-3 py-2 ${
          emp.active ? "bg-[var(--fx-page)]" : "bg-[var(--fx-lav)] opacity-60"
        }`}
      >
        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-[var(--fx-lav)] text-[12px] font-black text-[var(--fx-accent-ink)]">
          {emp.name.slice(0, 1).toUpperCase()}
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[13px] font-bold text-[var(--fx-ink)]">
            {emp.name}
          </span>
          <span className="block truncate text-[10.5px] font-semibold text-[var(--fx-muted)]">
            {emp.role}
          </span>
        </span>
        <span className="fx-num shrink-0 text-right text-[13px] font-extrabold text-[var(--fx-ink)]">
          {inr(emp.salary)}
          <span className="text-[9.5px] font-bold text-[var(--fx-muted)]">/MO</span>
        </span>
        {emp.active ? (
          <>
            {editBtn(ek, { name: emp.name, role: emp.role, salary: String(emp.salary) })}
            {confirmBtn(ek, () =>
              void mutate("/api/employees", "DELETE", undefined, `${emp.name} removed`, loadOps),
            )}
          </>
        ) : (
          restoreBtn(() =>
            void mutate("/api/employees", "PATCH", { id: emp.id, active: true }, `${emp.name} restored`, loadOps),
          )
        )}
      </div>
    );
  };

  return (
    <div className="space-y-5">
      <TierBand
        num={FX_TIERS.management.num}
        eyebrow={tierEyebrow(FX_TIERS.management)}
        title="Employee"
        sub="Your team roster — add, edit or remove staff and their salaries; salaries flow into the dashboards automatically. The menu lives on the POS screen, room rates at the bottom of the Lodge Front Desk, and the hotel profile now lives in Settings."
        tag={`${activeEmployees.length} EMPLOYEES · ${inr(monthlySalary)}/MO`}
      />

      {/* ── 01 · EMPLOYEE LIST ── */}
      <div className="fx-card overflow-hidden">
        <button
          onClick={() => toggle("emp")}
          aria-expanded={open.emp}
          className="flex w-full flex-wrap items-center gap-2.5 px-5 py-4 text-left transition hover:bg-[var(--fx-lav)]/40"
        >
          {sectionHead("01", <Users className="h-3.5 w-3.5" />, "EMPLOYEE LIST", `${activeEmployees.length} STAFF · ${inr(monthlySalary)}/MO`, open.emp)}
        </button>
        {open.emp && (
          <div className="border-t border-[var(--fx-line)] p-5">
            <div className="mb-3 flex flex-wrap items-center gap-1.5">
              {([["all", "ALL BOOKS"], ["rest", "RESTAURANT BOOK"], ["lodge", "LODGE BOOK"]] as const).map(([v, l]) => (
                <button
                  key={v}
                  onClick={() => setEmpBook(v)}
                  aria-pressed={empBook === v}
                  className={`rounded-full px-3.5 py-1.5 text-[9.5px] font-extrabold tracking-[0.09em] transition ${
                    empBook === v
                      ? "bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                      : "border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
                  }`}
                >
                  {l}
                </button>
              ))}
              <span className="fx-label ml-auto hidden md:inline-flex">NEW STAFF JOINS</span>
              <select
                value={empNewBook}
                onChange={(e) => setEmpNewBook(e.target.value === "lodge" ? "lodge" : "rest")}
                aria-label="Book for the new employee"
                className="h-9 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-2.5 text-[11px] font-extrabold text-[var(--fx-ink)]"
              >
                <option value="rest">RESTAURANT BOOK</option>
                <option value="lodge">LODGE BOOK</option>
              </select>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Input
                value={empName}
                onChange={(e) => setEmpName(e.target.value)}
                placeholder="Name…"
                aria-label="Employee name"
                className="h-10 min-w-[150px] flex-[1.2] rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-semibold"
              />
              <Input
                value={empRole}
                onChange={(e) => setEmpRole(e.target.value)}
                placeholder="Role e.g. Cook"
                aria-label="Employee role"
                className="h-10 min-w-[130px] flex-1 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-semibold"
              />
              <Input
                value={empSalary}
                onChange={(e) => setEmpSalary(e.target.value)}
                placeholder="₹/month"
                type="number"
                min={0}
                aria-label="Monthly salary in rupees"
                className="fx-num h-10 w-[110px] rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-bold"
              />
              <Button
                onClick={() => void addEmployee()}
                disabled={opLoading}
                className="ml-auto h-10 rounded-xl bg-[var(--fx-purple)] px-4 text-[12px] font-extrabold text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
              >
                {opLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
                ADD
              </Button>
            </div>
            <div className="fx-scroll mt-3 max-h-[300px] space-y-1.5 overflow-y-auto pr-1">
              {(empBook === "all" ? employees : employees.filter((e) => e.book === empBook)).map(empRow)}
              {(empBook === "all" ? employees : employees.filter((e) => e.book === empBook)).length === 0 && (
                <p className="py-8 text-center text-[13px] font-semibold text-[var(--fx-muted)]">
                  No employees yet — add your team above.
                </p>
              )}
            </div>
            <p className="mt-2 text-[10.5px] font-semibold text-[var(--fx-muted)]">
              EDIT changes name, role or salary. Salaries flow into the dashboard automatically —
              day = ÷30, week = ÷30×7, year = ×12. Both receptions mark this team's daily
              attendance in their own Attendance section.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
