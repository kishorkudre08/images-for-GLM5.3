"use client";

// ── t118 · FLOATING TASK TRACKER — back by user request ─────────────────────
// "previously we had a task tracker that was floating and could be
//  enabled/disabled using settings I want that in all three accounts"
// A floating launcher (bottom-left, clear of the AI FAB which stays on the
// owner's bottom-right) opens a glanceable tracker card: the tasks for THIS
// account — the owner sees both books, each reception sees its own book —
// open tasks first (soonest deadline), then the freshly closed ones.
// The full board stays where it always was (the Tasks section); the tracker
// is the pocket version that floats over every screen, and SETTINGS carries
// the on/off switch (localStorage "fx-task-fab", default ON) which is the
// enable/disable the user remembered.

import * as React from "react";
import { CalendarClock, ListChecks, X } from "lucide-react";
import type { FxTask } from "@/lib/types";

export const TASK_FAB_KEY = "fx-task-fab"; // "0" = hidden, absent/"1" = shown
export const TASK_FAB_EVENT = "fx-task-fab-change";

/** Shared by the tracker (instant hide/show) and the settings switch. */
export function useTaskFabEnabled(): boolean {
  const [enabled, setEnabled] = React.useState(true);
  React.useEffect(() => {
    const read = () => setEnabled(localStorage.getItem(TASK_FAB_KEY) !== "0");
    read();
    window.addEventListener(TASK_FAB_EVENT, read);
    return () => window.removeEventListener(TASK_FAB_EVENT, read);
  }, []);
  return enabled;
}

const istDue = (iso: string) =>
  new Date(iso).toLocaleString("en-IN", {
    timeZone: "Asia/Kolkata",
    day: "numeric",
    month: "short",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });

const KIND_CHIP: Record<NonNullable<FxTask["kind"]>, { label: string; cls: string }> = {
  raw_material: { label: "RAW MATERIAL", cls: "bg-[#0d9488]/12 text-[#0d9488]" },
  upgrade: { label: "UPGRADE", cls: "bg-[#7c3aed]/12 text-[#7c3aed]" },
  maintenance: { label: "MAINTENANCE", cls: "bg-[color-mix(in_srgb,var(--fx-amber)_14%,transparent)] text-[var(--fx-amber)]" },
};

function TrackerRow({ t }: { t: FxTask }) {
  const overdue = t.status === "open" && new Date(t.deadline).getTime() < Date.now();
  return (
    <div
      data-testid="task-tracker-row"
      data-status={t.status}
      className="rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-3 py-2.5"
    >
      <div className="flex items-start gap-2">
        <span
          aria-hidden
          className={`mt-1 h-2.5 w-2.5 shrink-0 rounded-full ${
            t.status === "done"
              ? "bg-[var(--fx-muted)]/40"
              : overdue
                ? "bg-[var(--fx-rose)]"
                : "bg-[var(--fx-green)] fx-live-dot"
          }`}
        />
        <div className="min-w-0 flex-1">
          <div className={`truncate text-[12.5px] font-bold text-[var(--fx-ink)] ${t.status === "done" ? "line-through opacity-60" : ""}`}>
            {t.title}
          </div>
          <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[9.5px] font-extrabold tracking-[0.07em] text-[var(--fx-muted)]">
            <span
              className={`rounded-full px-2 py-0.5 ${
                t.book === "lodge"
                  ? "bg-[color-mix(in_srgb,var(--fx-gold)_14%,transparent)] text-[var(--fx-gold)]"
                  : "bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]"
              }`}
            >
              {t.book === "lodge" ? "LODGE" : "RESTAURANT"}
            </span>
            {t.kind && (
              <span className={`rounded-full px-2 py-0.5 ${KIND_CHIP[t.kind].cls}`}>{KIND_CHIP[t.kind].label}</span>
            )}
            <span className="inline-flex items-center gap-1">
              <CalendarClock className="h-3 w-3" />
              {t.status === "done" ? `DONE · ${t.doneAt ? istDue(t.doneAt) : "—"}` : `${overdue ? "OVERDUE ·" : "DUE"} ${istDue(t.deadline)}`}
            </span>
            {t.maxBudget !== null && <span className="text-[var(--fx-ink)]">MAX {`₹${t.maxBudget.toLocaleString("en-IN")}`}</span>}
          </div>
        </div>
      </div>
    </div>
  );
}

export function TaskTracker({
  role,
  onOpenBoard,
}: {
  role: string;
  onOpenBoard: () => void;
}) {
  const enabled = useTaskFabEnabled();
  const [open, setOpen] = React.useState(false);
  const [tasks, setTasks] = React.useState<FxTask[]>([]);

  /* role → book: the owner watches both books, each reception its own */
  const book = role === "reception_restaurant" ? "rest" : role === "reception_lodge" ? "lodge" : null;

  React.useEffect(() => {
    if (!enabled) return;
    let alive = true;
    const load = () =>
      fetch(`/api/tasks${book ? `?book=${book}` : ""}`, { cache: "no-store" })
        .then((r) => (r.ok ? r.json() : { tasks: [] }))
        .then((d) => {
          if (alive) setTasks(Array.isArray(d?.tasks) ? d.tasks : []);
        })
        .catch(() => undefined);
    void load();
    const t = setInterval(load, 60000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [enabled, book]);

  if (!enabled) return null;

  const openTasks = tasks.filter((t) => t.status === "open");
  const doneTasks = tasks.filter((t) => t.status !== "open");
  const shown = [...openTasks, ...doneTasks].slice(0, 30);

  return (
    <>
      {/* ── launcher — bottom-LEFT (the AI FAB owns the owner's bottom-right) ── */}
      {!open && (
        <button
          onClick={() => setOpen(true)}
          aria-label="Open the floating task tracker"
          data-testid="task-fab"
          className="fixed bottom-[calc(84px+env(safe-area-inset-bottom))] left-4 z-40 flex h-14 items-center gap-2 rounded-2xl bg-[var(--fx-ink)] px-4 text-[var(--fx-page)] shadow-[3px_4px_0_0_var(--fx-hard)] transition hover:opacity-90 md:bottom-6 md:left-6"
        >
          <ListChecks className="h-5 w-5" />
          <span className="hidden text-[10px] font-extrabold tracking-[0.14em] sm:inline">TASKS</span>
          {openTasks.length > 0 && (
            <span
              data-testid="task-fab-count"
              className="grid h-5 min-w-5 place-items-center rounded-full bg-[var(--fx-green)] px-1 text-[10px] font-black text-[var(--fx-surf)]"
            >
              {openTasks.length}
            </span>
          )}
        </button>
      )}

      {/* ── the floating tracker card ── */}
      {open && (
        <aside
          data-testid="task-tracker-panel"
          aria-label="Floating task tracker"
          className="fixed bottom-[calc(84px+env(safe-area-inset-bottom))] left-4 z-50 flex max-h-[68vh] w-[min(400px,calc(100vw-2rem))] flex-col rounded-2xl border border-[var(--fx-line)] bg-[var(--fx-surf)] shadow-[3px_4px_0_0_var(--fx-hard)] md:bottom-[92px] md:left-6"
        >
          {/* header */}
          <div className="flex items-center gap-3 border-b border-dashed border-[var(--fx-line)] px-4 py-3">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[var(--fx-ink)] text-[var(--fx-page)] shadow-[2px_3px_0_0_var(--fx-hard)]">
              <ListChecks className="h-4.5 w-4.5" />
            </span>
            <div className="min-w-0 flex-1">
              <div className="text-[13px] font-extrabold tracking-tight text-[var(--fx-ink)]">TASK TRACKER</div>
              <div className="fx-label">
                {openTasks.length} OPEN · {doneTasks.length} DONE
                {book ? ` · ${book === "lodge" ? "LODGE" : "RESTAURANT"}` : " · BOTH BOOKS"}
              </div>
            </div>
            <button
              title="Collapse tracker"
              aria-label="Collapse the floating task tracker"
              onClick={() => setOpen(false)}
              className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* rows */}
          <div className="fx-scroll min-h-0 flex-1 space-y-2 overflow-y-auto p-3">
            {shown.length === 0 ? (
              <p className="px-2 py-8 text-center text-[12px] font-semibold text-[var(--fx-muted)]">
                {book
                  ? `No ${book === "lodge" ? "lodge" : "restaurant"} tasks yet — the owner's forwards land here.`
                  : "No tasks yet — forward work from the Tasks section and it lands here."}
              </p>
            ) : (
              shown.map((t) => <TrackerRow key={t.id} t={t} />)
            )}
          </div>

          {/* footer — into the full board */}
          <div className="border-t border-dashed border-[var(--fx-line)] p-3">
            <button
              onClick={() => {
                setOpen(false);
                onOpenBoard();
              }}
              data-testid="task-tracker-open-board"
              className="w-full rounded-xl bg-[var(--fx-purple)] py-2.5 text-[11px] font-extrabold tracking-[0.1em] text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] transition hover:bg-[var(--fx-purple-deep)]"
            >
              OPEN THE FULL TASKS BOARD
            </button>
            <p className="mt-2 text-center text-[9.5px] font-bold tracking-[0.06em] text-[var(--fx-muted)]">
              TURN IT OFF ANYTIME · SETTINGS → FLOATING TASK TRACKER
            </p>
          </div>
        </aside>
      )}
    </>
  );
}
