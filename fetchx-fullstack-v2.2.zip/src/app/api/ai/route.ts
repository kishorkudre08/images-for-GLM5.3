import { NextRequest, NextResponse } from "next/server";
import { aiChat } from "@/lib/ai-client";
import { db } from "@/lib/db";
import { getDashboardData, parseRange, RANGE_META } from "@/lib/analytics";
import { getHotelName } from "@/lib/settings";
import { parseLevels, parseMaxRooms, tierOfRoom, DEFAULT_LEVELS, MAX_ROOMS_KEY } from "@/lib/lodge";
import { istDateTime } from "@/lib/format";
import type { RangeKey } from "@/lib/analytics";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

type ChatMsg = { role: "user" | "assistant"; content: string };

const round2 = (n: number) => Math.round(n * 100) / 100;
const IST_OFFSET_MS = 5.5 * 3600000;

// IST calendar helpers — every timestamp the AI sees is IST, time-wise.
const istDayKey = (ts: Date) => new Date(ts.getTime() + IST_OFFSET_MS).toISOString().slice(0, 10);
const istDayLabel = (key: string) => {
  const [y, m, d] = key.split("-").map(Number);
  const mon = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][m - 1];
  return `${String(d).padStart(2, "0")} ${mon}${y !== new Date().getFullYear() ? " '" + String(y).slice(2) : ""}`;
};
const istHourLabel = (h: number) => (h % 12 === 0 ? 12 : h % 12) + (h < 12 ? " AM" : " PM");

// POST /api/ai — business copilot for the configured hotel (variable tenant).
// The AI receives the ENTIRE property record, time-wise: both books' full
// daily timelines, today hour-by-hour, every recent bill with its items and
// time, lodge stays with check-in/check-out, expenses tagged with the book
// they belong to, employees, menu, levels/rates and per-book net profit.
// Every entry the owner records exists to feed this copilot — it never
// invents numbers.
// Body: { message, history?: ChatMsg[], range?: RangeKey }
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const message = String(body.message ?? "").trim().slice(0, 600);
    if (!message) return NextResponse.json({ error: "Message is required" }, { status: 400 });

    const range: RangeKey = parseRange(typeof body.range === "string" ? body.range : null);
    const rawHistory: ChatMsg[] = Array.isArray(body.history) ? body.history : [];
    const history = rawHistory
      .filter((m) => (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
      .slice(-8)
      .map((m) => ({ role: m.role, content: m.content.slice(0, 1200) }));

    // Live, real data from the database — the AI never invents numbers.
    const [data, hotelName] = await Promise.all([getDashboardData(range), getHotelName()]);

    // ── The pieces the dashboard aggregates but the AI needs in full detail ──
    const since30 = new Date(Date.now() - 30 * 86400000);
    const nowIst = new Date(Date.now() + IST_OFFSET_MS);
    const monthStart = new Date(Date.UTC(nowIst.getUTCFullYear(), nowIst.getUTCMonth(), 1) - IST_OFFSET_MS);
    const todayStart = new Date(Date.UTC(nowIst.getUTCFullYear(), nowIst.getUTCMonth(), nowIst.getUTCDate()) - IST_OFFSET_MS);

    const [
      dishes,
      expRows,
      occRooms,
      mntRooms,
      levelsSetting,
      maxSetting,
      lodgeAll,
      rest30,
      lodge30,
      restRecentFull,
      lodgeRecentFull,
      expMonthAgg,
      lodgeToday,
    ] = await Promise.all([
      db.dish.findMany({
        where: { active: true },
        orderBy: [{ category: "asc" }, { name: "asc" }],
        select: { name: true, price: true, category: true },
      }),
      db.expense.findMany({
        orderBy: { spentOn: "desc" },
        take: 80,
        select: { kind: true, label: true, amount: true, book: true, spentOn: true },
      }),
      db.room.findMany({ where: { status: "occ" }, orderBy: { number: "asc" } }),
      db.room.findMany({ where: { status: "mnt" }, orderBy: { number: "asc" }, select: { number: true } }),
      db.setting.findUnique({ where: { key: "lodgeLevels" } }),
      db.setting.findUnique({ where: { key: MAX_ROOMS_KEY } }),
      db.lodgeBill.aggregate({ _count: true, _sum: { total: true } }),
      db.bill.findMany({ where: { createdAt: { gte: since30 } }, select: { createdAt: true, total: true, itemCount: true } }),
      db.lodgeBill.findMany({ where: { createdAt: { gte: since30 } }, select: { createdAt: true, total: true } }),
      db.bill.findMany({ orderBy: { createdAt: "desc" }, take: 25, include: { items: true } }),
      db.lodgeBill.findMany({ orderBy: { createdAt: "desc" }, take: 20 }),
      db.expense.groupBy({ by: ["book", "kind"], where: { spentOn: { gte: monthStart } }, _sum: { amount: true }, _count: true }),
      // t76 — every stay bill today IS one housekeeping turnaround task
      db.lodgeBill.findMany({ where: { createdAt: { gte: todayStart } }, select: { room: true } }),
    ]);
    const maxRooms = parseMaxRooms(maxSetting?.value);
    const levels = parseLevels(levelsSetting?.value, maxRooms) ?? DEFAULT_LEVELS;
    const now = Date.now();
    const hrsIn = (iso: Date | null) =>
      iso ? round2(Math.max(0, (now - new Date(iso).getTime()) / 3600000)) : 0;

    const menu = dishes.map((d) => ({ name: d.name, price: d.price, category: d.category }));

    // 30-day daily timeline — both books side by side, IST calendar days.
    const dayMap = new Map<string, { rest: number; lodge: number }>();
    for (let i = 29; i >= 0; i--) {
      const key = new Date(Date.now() - i * 86400000 + IST_OFFSET_MS).toISOString().slice(0, 10);
      dayMap.set(key, { rest: 0, lodge: 0 });
    }
    for (const b of rest30) {
      const k = istDayKey(b.createdAt);
      const e = dayMap.get(k);
      if (e) e.rest = round2(e.rest + b.total);
    }
    for (const b of lodge30) {
      const k = istDayKey(b.createdAt);
      const e = dayMap.get(k);
      if (e) e.lodge = round2(e.lodge + b.total);
    }
    const timeline = [...dayMap.entries()].map(([key, v]) => ({ day: istDayLabel(key), restaurant: v.rest, lodge: v.lodge }));

    // Today hour by hour — restaurant bills + lodge checkouts (IST clock).
    const restHour = new Map<number, { revenue: number; bills: number }>();
    for (const b of restRecentFull) {
      const ts = new Date(b.createdAt).getTime();
      if (ts < todayStart.getTime()) continue;
      const h = new Date(ts + IST_OFFSET_MS).getUTCHours();
      const e = restHour.get(h) ?? { revenue: 0, bills: 0 };
      e.revenue = round2(e.revenue + b.total);
      e.bills += 1;
      restHour.set(h, e);
    }
    const lodgeHour = new Map<number, { revenue: number; checkouts: number }>();
    for (const b of lodgeRecentFull) {
      const ts = new Date(b.createdAt).getTime();
      if (ts < todayStart.getTime()) continue;
      const h = new Date(ts + IST_OFFSET_MS).getUTCHours();
      const e = lodgeHour.get(h) ?? { revenue: 0, checkouts: 0 };
      e.revenue = round2(e.revenue + b.total);
      e.checkouts += 1;
      lodgeHour.set(h, e);
    }
    const todayHourly = {
      restaurant: [...restHour.entries()].sort((a, b) => a[0] - b[0]).map(([h, v]) => ({ hour: istHourLabel(h), ...v })),
      lodgeCheckouts: [...lodgeHour.entries()].sort((a, b) => a[0] - b[0]).map(([h, v]) => ({ hour: istHourLabel(h), ...v })),
    };

    const inHouseGuests = occRooms.map((r) => {
      const t = tierOfRoom(r.number, levels);
      return {
        room: r.number,
        guest: r.guestName,
        phone: r.guestPhone,
        tier: t.name,
        rate24h: t.rate,
        checkedInAt: r.checkInAt ? istDateTime(r.checkInAt) : null,
        hoursInHouse: hrsIn(r.checkInAt),
      };
    });

    const netProfit = {
      restaurant: { revenue: data.stats.revenue, ...data.books.rest },
      lodge: { revenue: data.lodge.revenue, ...data.books.lodge },
      combined: round2(data.books.rest.profit + data.books.lodge.profit),
    };

    /* ── t76 · operations feed: task completion + budget utilization ──
       Task flow = room turnaround: every checkout opens one housekeeping task,
       "maintenance done" closes it. Budget = month-to-date spend vs revenue
       per book (lower % = leaner book). Both computed from the same books. */
    const mntSet = new Set(mntRooms.map((r) => r.number));
    const turnaroundsToday = lodgeToday.length;
    const stillPendingToday = lodgeToday.filter((b) => mntSet.has(b.room)).length;
    const completedToday = turnaroundsToday - stillPendingToday;
    const completionPct =
      turnaroundsToday > 0 ? Math.round((completedToday / turnaroundsToday) * 100) : mntRooms.length > 0 ? 0 : 100;
    const monthRevenueOf = (rows: Array<{ createdAt: Date; total: number }>) =>
      round2(rows.filter((r) => new Date(r.createdAt).getTime() >= monthStart.getTime()).reduce((s, r) => s + r.total, 0));
    const spendOfBook = (book: "restaurant" | "lodge") =>
      round2(
        expMonthAgg
          .filter((g) => (g.book === "lodge" ? "lodge" : "restaurant") === book)
          .reduce((s, g) => s + (g._sum.amount ?? 0), 0),
      );
    const restSpendM = spendOfBook("restaurant");
    const lodgeSpendM = spendOfBook("lodge");
    const restRevM = monthRevenueOf(rest30);
    const lodgeRevM = monthRevenueOf(lodge30);
    const utilPct = (spend: number, rev: number) => (rev > 0 ? Math.round((spend / rev) * 100) : null);

    const operations = {
      housekeeping: {
        definition: "one task = one checkout's room turnaround; 'maintenance done' completes it",
        tasksCreatedToday: turnaroundsToday,
        tasksCompletedToday: completedToday,
        completionRatePct: completionPct,
        pendingRightNow: mntRooms.length,
        pendingRooms: mntRooms.map((r) => r.number),
        roomsReadyNow: maxRooms - mntRooms.length,
        readinessPct: Math.round(((maxRooms - mntRooms.length) / maxRooms) * 100),
      },
      budgetUtilization: {
        definition: "month-to-date spend vs month-to-date revenue, per book — lower % is leaner",
        monthStartIST: istDateTime(monthStart),
        restaurant: { spend: restSpendM, revenue: restRevM, utilizationPct: utilPct(restSpendM, restRevM) },
        lodge: { spend: lodgeSpendM, revenue: lodgeRevM, utilizationPct: utilPct(lodgeSpendM, lodgeRevM) },
        combined: {
          spend: round2(restSpendM + lodgeSpendM),
          revenue: round2(restRevM + lodgeRevM),
          utilizationPct: utilPct(restSpendM + lodgeSpendM, restRevM + lodgeRevM),
        },
        payroll: { monthlyCommitment: data.team.monthlyTotal, periodCostSoFar: data.team.periodCost },
      },
    };

    const toExp = (kind: string) =>
      expRows
        .filter((e) => e.kind === kind)
        .map((e) => ({
          label: e.label || "(unlabelled)",
          amount: round2(e.amount),
          book: e.book === "lodge" ? "lodge" : "restaurant",
          date: istDateTime(e.spentOn),
        }));

    const digest = {
      hotel: {
        name: hotelName,
        setup: "pure-vegetarian restaurant (Counter 01) + 100-room lodge on the same property",
        books: { restaurant: "FOOD & BEV", lodge: "ROOMS & STAYS" },
        currency: "INR (₹)", timezone: "IST",
        dataNote: "Every entry below was recorded by the owner specifically to feed you — it is the complete ground truth, newest first, all times IST.",
      },
      period: RANGE_META[range].label,
      timeline: {
        daily30: timeline,
        todayHourly,
        hourlyAverages: data.hourly.series,
      },
      restaurant: {
        stats: data.stats,
        peak: data.peakLabel,
        itemsSold: data.itemsSold.slice(0, 15),
        categoryMix: data.categoryMix,
        trend: data.buckets.filter((b) => b.revenue > 0).slice(-14),
        recentBills: restRecentFull.map((b) => ({
          number: b.number,
          time: istDateTime(b.createdAt),
          total: b.total,
          discount: b.discount || undefined,
          items: b.items.map((i) => `${i.name}×${i.qty}`).join(", "),
        })),
        allTime: data.allTime,
        menu,
      },
      lodge: {
        revenue: data.lodge.revenue,
        stays: data.lodge.stays,
        avgStayValue: data.lodge.avgStay,
        deltaPct: data.lodge.deltaPct,
        peak: data.lodge.peakLabel,
        occupancy: {
          inHouse: data.lodge.inHouse,
          pctFull: data.lodge.pctFull,
          maintenanceRooms: mntRooms.map((r) => r.number),
          tonightIfAllStay: data.lodge.tonight,
          curveToday: data.lodge.dayCurve,
        },
        levels: levels.map((l) => ({ tier: l.name, rooms: `${l.from}-${l.to}`, rate24h: l.rate })),
        inHouseGuests,
        recentStayBills: lodgeRecentFull.map((b) => ({
          number: `L-${b.number}`,
          room: b.room,
          guest: b.guestName,
          phone: b.guestPhone || undefined,
          tier: b.tier,
          rate24h: b.rate,
          checkIn: istDateTime(b.checkInAt),
          checkOut: istDateTime(b.checkOutAt),
          hours: b.hours,
          total: b.total,
        })),
        allTime: { bills: lodgeAll._count, revenue: round2(lodgeAll._sum.total ?? 0) },
        stayMix: data.lodge.stayMix,
        revenueByLevel: data.lodge.tierMix,
      },
      team: {
        employees: data.team.employees,
        monthlyPayroll: data.team.monthlyTotal,
        periodSalaryCost: data.team.periodCost,
      },
      expenses: {
        thisMonthByBookKind: expMonthAgg.map((g) => ({
          book: g.book === "lodge" ? "lodge" : "restaurant",
          kind: g.kind,
          total: round2(g._sum.amount ?? 0),
          entries: g._count,
        })),
        rawMaterials: toExp("raw_material"),
        maintenance: toExp("maintenance"),
      },
      netProfit,
      operations,
    };

    const system = [
      `You are the Fetch-X AI copilot inside the dashboard of ${hotelName.toUpperCase()} — a pure-vegetarian restaurant (Counter 01, India, ₹, IST) WITH a 100-room lodge on the same property. Two books: FOOD & BEV (restaurant) and ROOMS & STAYS (lodge). Fetch-X is the platform brand; ${hotelName} is the hotel running on it.`,
      "You advise the owner using ONLY the live JSON data provided after the user's message — never invent numbers, names, bills or entries.",
      "The data covers EVERYTHING, time-wise: a 30-day daily revenue timeline for both books; today hour by hour; hourly averages; the latest restaurant bills with their items and exact times; lodge stays with check-in/check-out times; occupancy live including every in-house guest with name and check-in time; every recent expense tagged with the book it belongs to (restaurant or lodge); employees with names, roles, salaries and books; the full menu with prices; room levels and rates; stay mix and revenue by level; net profit per book and combined; PLUS operations data — housekeeping task completion (each checkout opens a room-turnaround task, completing maintenance closes it) and month-to-date budget utilization (spend vs revenue per book). When asked about tasks or budget, quote these fields.",
      "The owner records every bill, stay and expense precisely so you can interpret the business — treat each entry as ground truth and quote real names, items and ₹ figures with their dates when you advise.",
      "If a question needs data genuinely absent from the JSON, say so plainly instead of guessing.",
      "Your answers render as rich Markdown in the panel, so format them well: **bold** the key figures, use short bullet lists, and use Markdown tables when comparing dishes, days, books or options. Be concise and practical, and end with a concrete recommendation (pricing, staffing, promotions, occupancy, cost control). Generic cooking questions are out of scope.",
    ].join(" ");

    const reply = await aiChat(
      [
        { role: "system", content: system },
        ...history,
        {
          role: "user",
          content: `${message}\n\n[LIVE DATA · period = ${RANGE_META[range].label}]\n${JSON.stringify(digest)}`,
        },
      ],
      { temperature: 0.3, maxTokens: 2048 }
    );
    if (!reply) return NextResponse.json({ error: "AI returned an empty response" }, { status: 502 });
    return NextResponse.json({ reply });
  } catch (e) {
    console.error("AI route failed:", e);
    return NextResponse.json({ error: "The AI copilot is unavailable right now." }, { status: 500 });
  }
}
