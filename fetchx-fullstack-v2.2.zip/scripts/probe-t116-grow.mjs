// t116 probe — what does the wall show right after a MAX ROOMS grow?
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
await page.goto("http://localhost:3000", { waitUntil: "domcontentloaded" });
await page.evaluate(() =>
  localStorage.setItem("fx-auth", JSON.stringify({ name: "Imperial", role: "owner", email: "spiceowner@gmail.com" })),
);
await page.goto("http://localhost:3000", { waitUntil: "domcontentloaded" });
await page.waitForTimeout(2500);
await page.getByRole("button", { name: "Lodge Front Desk" }).first().click();
await page.waitForTimeout(2200);
await page.locator('[data-testid="max-rooms-input"]').fill("104");
await page.locator('[data-testid="max-rooms-apply"]').click();
await page.waitForTimeout(3000);
const labels = await page.evaluate(() => {
  const cells = [...document.querySelectorAll('button[aria-label^="Room "]')];
  return { total: cells.length, last3: cells.slice(-3).map((c) => c.getAttribute("aria-label")) };
});
console.log("wall cells:", JSON.stringify(labels));
const api = await page.evaluate(async () => await (await fetch("/api/lodge")).json());
console.log("api maxRooms:", api.maxRooms, "| api rooms:", api.rooms.length, "| last level:", JSON.stringify(api.levels.at(-1)));
await browser.close();
