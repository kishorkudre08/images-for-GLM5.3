/* Double-fork supervisor: parent exits immediately, detached child owns the server. */
const { spawn } = require("node:child_process");
const fs = require("node:fs");

const srv = spawn(
  process.execPath,
  [".next/standalone/server.js"],
  {
    cwd: "/home/z/my-project",
    detached: true,
    stdio: ["ignore", "pipe", "pipe"],
    env: { ...process.env, PORT: "3000", NODE_ENV: "production" },
  }
);
const out = fs.openSync("/home/z/my-project/scripts/v2-server.log", "a");
srv.stdout.on("data", (d) => fs.writeSync(out, d));
srv.stderr.on("data", (d) => fs.writeSync(out, d));
srv.unref();
console.log("forked pid:", srv.pid);
