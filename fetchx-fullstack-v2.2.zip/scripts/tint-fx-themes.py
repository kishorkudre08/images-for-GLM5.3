#!/usr/bin/env python3
"""t103 — fx-themes.ts: per-theme tinted bases (mirroring the CSS tokens) so
the gallery previews paint the SAME tinted pages the app will actually run."""
import re

PATH = "/home/z/my-project/src/app/fx-themes-placeholder.ts"
PATH = "/home/z/my-project/src/lib/fx-themes.ts"
src = open(PATH).read()

# classic stays as the DEFAULT :root/.dark (also tinted now) — handled inline
# below; the other 9 themes get their own bases matching globals.css.
BASES = {
  "dragonfruit": {
    "light": dict(page="#f7e4f1", surf="#fcebf5", line="#e9c9de", lav="#efd3e6", ink="#4a1040", muted="#a4799a"),
    "dark":  dict(page="#31123a", surf="#3c1846", line="#562664", lav="#482052", ink="#f8e6f3", muted="#b58cae"),
  },
  "lime": {
    "light": dict(page="#eaf4d8", surf="#f3f9e6", line="#d3e5b4", lav="#dfecc4", ink="#1f3308", muted="#7d8a67"),
    "dark":  dict(page="#1c2712", surf="#243119", line="#35482a", lav="#2c3c20", ink="#eef6dc", muted="#9fac90"),
  },
  "emerald": {
    "light": dict(page="#eff3d9", surf="#f7f8e6", line="#d9e0b8", lav="#e4e9c6", ink="#0c2f22", muted="#7f8a70"),
    "dark":  dict(page="#0c2a1d", surf="#123427", line="#1f4a38", lav="#17402f", ink="#e8f2e0", muted="#90a894"),
  },
  "iris": {
    "light": dict(page="#faf0cb", surf="#fdf7de", line="#ecdfa8", lav="#f2e6b4", ink="#2f2404", muted="#96895f"),
    "dark":  dict(page="#221e4d", surf="#2b2660", line="#3e3780", lav="#322c68", ink="#faf0c8", muted="#a29dc8"),
  },
  "blaze": {
    "light": dict(page="#f7ecd6", surf="#fcf4e2", line="#ead9b4", lav="#f0e2c2", ink="#3a1c05", muted="#a08f70"),
    "dark":  dict(page="#2f1a0c", surf="#3a2212", line="#54321c", lav="#452917", ink="#f9ecd4", muted="#b39c7e"),
  },
  "neon": {
    "light": dict(page="#e4f5e4", surf="#eefaf0", line="#c4e4c9", lav="#d5ecd9", ink="#0a2913", muted="#6f8a76"),
    "dark":  dict(page="#161d18", surf="#1e2822", line="#2e3b32", lav="#253028", ink="#e2f3e5", muted="#93a89a"),
  },
  "cherry": {
    "light": dict(page="#f9e7e7", surf="#fceeee", line="#eccdcd", lav="#f2d8d8", ink="#3d0d16", muted="#a07c80"),
    "dark":  dict(page="#2c0e17", surf="#38131f", line="#501e2d", lav="#421723", ink="#f9e5e8", muted="#b18e94"),
  },
  "azure": {
    "light": dict(page="#e2effa", surf="#ecf5fc", line="#c4dcec", lav="#d0e5f4", ink="#0a2440", muted="#6f8ba0"),
    "dark":  dict(page="#0d1e3c", surf="#13284c", line="#1f3a68", lav="#182f57", ink="#e2eefb", muted="#8ba3c4"),
  },
  "cyanreef": {
    "light": dict(page="#e0f3f5", surf="#ebf8f9", line="#c2e2e6", lav="#cfeaed", ink="#072a33", muted="#6f919a"),
    "dark":  dict(page="#0b232b", surf="#112e38", line="#1c4452", lav="#163844", ink="#e0f3f6", muted="#8facb5"),
  },
}

TINTED_LIGHT = 'page: "#ebe8fc", surf: "#f7f5fe", line: "#d9d4f2", ink: "#241d56", muted: "#7c7ba0", lav: "#e2ddfa"'
TINTED_DARK = 'page: "#1f1a44", surf: "#282257", line: "#3b3480", ink: "#eae7fc", muted: "#9d9ac4", lav: "#322b6b"'

for theme, modes in BASES.items():
    lit = 'page: "%(page)s", surf: "%(surf)s", line: "%(line)s", ink: "%(ink)s", muted: "%(muted)s", lav: "%(lav)s"' % modes["light"]
    drk = 'page: "%(page)s", surf: "%(surf)s", line: "%(line)s", ink: "%(ink)s", muted: "%(muted)s", lav: "%(lav)s"' % modes["dark"]
    # light: find the theme object's light line: `light: { ...LIGHT_BASE, a: ...` and
    # replace the spread with explicit tinted values
    pat = re.compile(r'(id: "%s",[\s\S]*?light: \{ )\.\.\.LIGHT_BASE,' % theme)
    src, n = pat.subn(lambda m: m.group(1) + lit + ",", src)
    assert n == 1, f"light base not patched for {theme} ({n})"
    pat = re.compile(r'(id: "%s",[\s\S]*?dark: \{ )\.\.\.DARK_BASE,' % theme)
    src, n = pat.subn(lambda m: m.group(1) + drk + ",", src)
    assert n == 1, f"dark base not patched for {theme} ({n})"

# classic: the shared bases themselves become the tinted classic values
src = src.replace(
    'const LIGHT_BASE = {\n  page: "#fbfbfe",\n  surf: "#ffffff",\n  line: "#e9e8f3",\n  ink: "#1c1840",\n  muted: "#8b8ea7",\n  lav: "#f2f0fb",\n};',
    'const LIGHT_BASE = {\n  page: "#ebe8fc",\n  surf: "#f7f5fe",\n  line: "#d9d4f2",\n  ink: "#241d56",\n  muted: "#7c7ba0",\n  lav: "#e2ddfa",\n};',
)
src = src.replace(
    'const DARK_BASE = {\n  page: "#131120",\n  surf: "#1b1930",\n  line: "#2c2946",\n  ink: "#eceaf8",\n  muted: "#8f92ab",\n  lav: "#262244",\n};',
    'const DARK_BASE = {\n  page: "#1f1a44",\n  surf: "#282257",\n  line: "#3b3480",\n  ink: "#eae7fc",\n  muted: "#9d9ac4",\n  lav: "#322b6b",\n};',
)
assert "fbfbfe" not in src and "131120" not in src, "old bases still present"

# the user's combo was "vivid orange red + light cream" — name it as before
src = src.replace('name: "Blaze Orange + Cream",\n    tagline: "Vivid orange-red counter on soft cream rooms — bold canteen warmth.",',
                  'name: "Vivid Ember + Light Cream",\n    tagline: "Vivid ember-orange counter on light-cream rooms — bold canteen warmth.",')

open(PATH, "w").write(src)
print("fx-themes.ts: 10 tinted bases + Vivid Ember rename done")
