// t116 verify — the owner's Lodge Front Desk is a MONITOR and the wall is flexible:
//   (1) owner lodge: NO expenses block, NO check-in/check-out management
//       (no ENTER NEW GUEST / RESET WALL / bill UNDO),
//   (2) owner taps a room → status chip + resident details ONLY when occupied,
//   (3) the donut sits ABOVE the rooms for the owner (counter keeps it below),
//   (4) MAX ROOMS: grow anytime; reduce blocked with a WAIT panel while a cut
//       room is busy, unlocks when it frees; wall shrinks & grows for real,
//   (5) receptions untouched: lodge desk keeps ENTER NEW GUEST + station
//       expenses + donut-below + UNDO; restaurant POS keeps its expense entry.
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;

const BASE = "http://localhost:3000";
const OWNER = { name: "Imperial", role: "owner", email: "spiceowner@gmail.com" };
const REST = { name: "Imperial", role: "reception_restaurant", email: "spicerestaurant@gmail.com" };
const LODGE = { name: "Imperial", role: "reception_lodge", email: "spicelodge@gmail.com" };

let pass = 0, fail = 0;
const ok = (cond, name) => {
  if (cond) { pass++; console.log("  ✓", name); }
  else { fail++; console.log("  ✗ FAIL:", name); }
};

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(String(e).slice(0, 150)));

const login = async (u) => {
  await page.goto(BASE, { waitUntil: "domcontentloaded" });
  await page.evaluate((x) => localStorage.setItem("fx-auth", JSON.stringify(x)), u);
  await page.goto(BASE, { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(2500);
};

// ── API helpers (fixture setup / teardown, mirrors the front-desk engine) ──
const api = async (body) => {
  const res = await page.request.post(`${BASE}/api/lodge`, { data: body });
  return { status: res.status(), data: await res.json().catch(() => ({})) };
};
const checkin = async (room, name = "Verify T116", phone = "9876543210") =>
  api({ action: "checkin", room, name, phone });
// checkout → housekeeping → tear the bill: the room ends free, the ledger clean
const freeRoom = async (room) => {
  let co = await api({ action: "checkout", room });
  if (co.status !== 200) {
    // same-millisecond exit races the entry clock — give it a beat and retry
    await new Promise((r) => setTimeout(r, 1200));
    co = await api({ action: "checkout", room });
  }
  const num = co.data?.bill?.number;
  if (num) await api({ action: "maintenance-done", room });
  if (num) await api({ action: "bill-undo", number: num });
  if (co.status !== 200) console.log(`  ⚠ freeRoom(${room}): checkout said`, JSON.stringify(co.data).slice(0, 120));
  return co;
};

const openLodge = async () => {
  await page.getByRole("button", { name: "Lodge Front Desk" }).first().click();
  await page.waitForTimeout(2200);
};
const roomCell = (n) => page.locator(`button[aria-label^="Room ${n} —"]`).first();
const wallCard = page.locator(".fx-card", { hasText: "ALL ROOMS" }).first();

// the editor's live size has settled (chip shows it) — guards against racing the fetch
const editorSettled = async (size) => {
  await page.getByText(`${size} ROOMS`, { exact: false }).first().waitFor({ timeout: 10000 });
};
const applyEnabled = () =>
  page.evaluate(() => {
    const b = document.querySelector('[data-testid="max-rooms-apply"]');
    const i = document.querySelector('[data-testid="max-rooms-input"]');
    const w = document.querySelector('[data-testid="max-rooms-wait"]');
    return { disabled: !b || b.hasAttribute("disabled"), val: i?.value, wait: w ? w.innerText.slice(0, 140) : null };
  });

/* ── 1 · OWNER — the monitor wall ──────────────────────────────────────────── */
console.log("1 · owner lodge: monitor only");
await login(OWNER);
await openLodge();
ok((await page.getByRole("button", { name: /ENTER NEW GUEST/ }).count()) === 0, "no ENTER NEW GUEST for the owner");
ok((await page.getByRole("button", { name: /RESET WALL/ }).count()) === 0, "no RESET WALL for the owner");
ok((await page.locator('[data-testid="station-expenses-lodge"]').count()) === 0, "no expenses block for the owner");
ok((await page.locator(".f-undo").count()) === 0, "no bill UNDO for the owner (checkout management is the counter's)");
ok((await page.getByText("WALL SNAPSHOT · LIVE").count()) === 1, "wall snapshot donut present");

const snapY = (await page.locator('[data-testid="lodge-wall-snapshot"]').boundingBox())?.y ?? -1;
const wallY = (await wallCard.boundingBox())?.y ?? -1;
ok(snapY >= 0 && wallY >= 0 && snapY < wallY, `donut sits ABOVE the rooms (donut ${Math.round(snapY)} < wall ${Math.round(wallY)})`);

/* ── 2 · owner room tap — status + resident only when occupied ─────────────── */
console.log("2 · owner room tap: status + resident details");
const ci = await checkin(3);
ok(ci.status === 200, "fixture: guest checked into room 3");
await page.reload({ waitUntil: "domcontentloaded" }); // sync the wall with the API fixture
await page.waitForTimeout(2600);
await openLodge();
await roomCell(3).click();
await page.waitForTimeout(600);
ok((await page.locator('[data-testid="owner-room-status"]').innerText().catch(() => "")) === "OCCUPIED", "occupied room shows OCCUPIED");
ok((await page.locator('[data-testid="owner-room-resident"]').count()) === 1, "resident details visible while occupied");
const resTxt = (await page.locator('[data-testid="owner-room-resident"]').innerText().catch(() => "")).toUpperCase();
ok(resTxt.includes("VERIFY T116") && resTxt.includes("9876543210"), "resident card carries name + phone");
ok((await page.getByRole("button", { name: /CHECK OUT|SETTLE/i }).count()) === 0, "no checkout action in the owner's dialog");
await page.keyboard.press("Escape");
await page.waitForTimeout(500);

await roomCell(2).click();
await page.waitForTimeout(600);
ok((await page.locator('[data-testid="owner-room-status"]').innerText().catch(() => "")) === "FREE", "free room shows FREE");
ok((await page.locator('[data-testid="owner-room-resident"]').count()) === 0, "NO resident details when free");
ok((await page.locator('[data-testid="owner-room-no-resident"]').count()) === 1, "free room explains there is no resident");
await page.keyboard.press("Escape");
await page.waitForTimeout(400);
const fr = await freeRoom(3);
ok(fr.status === 200, "fixture: room 3 freed, ledger clean");

/* ── 3 · MAX ROOMS — grow anytime, reduce waits for free rooms ────────────── */
console.log("3 · max rooms: flexible wall with the wait-for-free guard");
await page.waitForTimeout(800);
const input = page.locator('[data-testid="max-rooms-input"]');
const apply = page.locator('[data-testid="max-rooms-apply"]');
ok((await input.count()) === 1 && (await apply.count()) === 1, "MAX ROOMS control renders in the editor");

// grow: 100 → 104 lands immediately
await editorSettled(100);
await input.fill("104");
ok((await page.getByText("+4 NEW ROOMS ARRIVE FREE", { exact: false }).count()) === 1, "grow shows the +rooms promise");
await apply.click();
await page.waitForTimeout(2600);
ok((await page.locator('button[aria-label^="Room 104 —"]').count()) === 1, "room 104 exists on the wall after grow");
ok((await page.getByText("104 ROOMS", { exact: false }).count()) >= 1, "editor chip shows the new size");

// reduce blocked while a cut room is busy: room 102 occupied → 96 blocked
const ci2 = await checkin(102);
ok(ci2.status === 200, "fixture: guest in room 102 (inside the cut band 97–104)");
await page.reload({ waitUntil: "domcontentloaded" }); // sync the editor's room list
await page.waitForTimeout(2600);
await openLodge();
await editorSettled(104);
await input.fill("96");
await page.waitForTimeout(500);
ok((await page.locator('[data-testid="max-rooms-wait"]').count()) === 1, "WAIT panel names the busy cut room");
ok((await page.locator('[data-testid="max-rooms-wait"]').innerText().catch(() => "")).includes("Room 102"), "wait panel names Room 102");
ok(await apply.isDisabled(), "APPLY MAX ROOMS locked while the cut room is busy");
// the API backs the same guard with a 409 + busy list
const blocked = await api({ action: "max-rooms", maxRooms: 96 });
ok(blocked.status === 409 && Array.isArray(blocked.data.busy) && blocked.data.busy.includes(102), "API refuses the reduce (409 + busy list)");

// the guest checks out → housekeeping → the same reduce now lands
const freed = await freeRoom(102);
ok(freed.status === 200, `fixture: room 102 freed (status ${freed.status})`);
await page.reload({ waitUntil: "domcontentloaded" });
await page.waitForTimeout(2600);
await openLodge();
await editorSettled(104);
await input.fill("96");
await page.waitForTimeout(700);
const st1 = await applyEnabled();
ok(!st1.wait && !st1.disabled, `WAIT panel gone once the cut rooms are free (val=${st1.val} disabled=${st1.disabled} wait=${st1.wait ?? "none"})`);
await apply.click({ timeout: 12000 });
await page.waitForTimeout(1800);
ok((await page.locator('button[aria-label^="Room 104 —"]').count()) === 0, "rooms above 96 left the wall");
ok((await page.locator('button[aria-label^="Room 96 —"]').count()) === 1, "room 96 is the wall's new edge");
// bills of cut rooms keep their snapshots — nothing else moved
const back = await api({ action: "max-rooms", maxRooms: 100 });
ok(back.status === 200 && back.data.maxRooms === 100, "grow back to 100 via API (increase anytime)");
await page.reload({ waitUntil: "domcontentloaded" });
await page.waitForTimeout(2600);
await openLodge();
await page.waitForTimeout(1200);
ok((await page.locator('button[aria-label^="Room 100 —"]').count()) === 1, "wall is whole again (100 rooms)");
// out-of-bounds guard
const bad = await api({ action: "max-rooms", maxRooms: 501 });
ok(bad.status === 400, "API caps the wall at 500");

/* ── 4 · RECEPTIONS — the operating desk, untouched ───────────────────────── */
console.log("4 · receptions: the operating desk is untouched");
await login(LODGE);
await openLodge();
ok((await page.getByRole("button", { name: /ENTER NEW GUEST/ }).count()) === 1, "lodge desk keeps ENTER NEW GUEST");
ok((await page.locator('[data-testid="station-expenses-lodge"]').count()) === 1, "lodge desk keeps its expense entry (STATION EXPENSES)");
ok((await page.locator('[data-testid="stn-add-lodge"]').count()) === 1, "lodge desk ADD EXPENSE present");
const snapY2 = (await page.locator('[data-testid="lodge-wall-snapshot"]').boundingBox())?.y ?? -1;
const wallY2 = (await wallCard.boundingBox())?.y ?? -1;
ok(snapY2 >= 0 && wallY2 >= 0 && snapY2 > wallY2, `counter's donut stays BELOW the rooms (donut ${Math.round(snapY2)} > wall ${Math.round(wallY2)})`);
ok((await page.locator(".f-undo").count()) >= 0, "feed renders for the counter (undo on rows with bills)");

await login(REST);
await page.getByRole("button", { name: "POS Billing" }).first().click();
await page.waitForTimeout(2200);
ok((await page.locator('[data-testid="station-expenses-rest"]').count()) === 1, "restaurant desk keeps its expense entry (STATION EXPENSES)");
ok((await page.locator('[data-testid="stn-add-rest"]').count()) === 1, "restaurant desk ADD EXPENSE present");

ok(errors.length === 0, `zero page errors across the run${errors.length ? " — " + errors[0] : ""}`);

console.log(`\nverify-t116: ${pass}/${pass + fail}`);
await browser.close();
process.exit(fail ? 1 : 0);
