#!/usr/bin/env python3
"""t104 — shrink the theme-preview jpegs for the single-file demo.
The full-stack app serves public/theme-previews (full size); the demo inlines
data URIs, so it gets public/theme-previews-demo (640px wide, q42) to keep the
download small. Run: python3 scripts/shrink-previews-for-demo.py"""
import os
from PIL import Image

SRC = "/home/z/my-project/public/theme-previews"
DST = "/home/z/my-project/public/theme-previews-demo"
os.makedirs(DST, exist_ok=True)
total = 0
n = 0
for f in sorted(os.listdir(SRC)):
    if not f.endswith(".jpg"):
        continue
    im = Image.open(f"{SRC}/{f}").convert("RGB")
    w = 640
    h = round(im.height * w / im.width)
    im = im.resize((w, h), Image.LANCZOS)
    im.save(f"{DST}/{f}", "JPEG", quality=42, optimize=True, progressive=True)
    total += os.path.getsize(f"{DST}/{f}")
    n += 1
print(f"{n} images -> {DST}, {total // 1024}KB total")
