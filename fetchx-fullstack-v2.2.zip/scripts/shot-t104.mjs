/* t104 — visual check of the new theme gallery (desktop + phone). */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;

const BASE = "http://localhost:3000";
const OUT = "/home/z/my-project/download";
const browser = await chromium.launch();

/* desktop owner settings */
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();
await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
await page.waitForSelector("text=finally intelligent", { timeout: 60000 });
await page.evaluate(() => {
  localStorage.setItem("fx-auth", JSON.stringify({ name: "Imperial", role: "owner", email: "spiceowner@gmail.com" }));
});
await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
await page.waitForSelector("text=Live Dashboard", { timeout: 60000 });
await page.waitForTimeout(2200);
await page.locator('[data-testid="settings-btn"]').first().click();
await page.waitForSelector('[data-testid="settings-themes"]', { timeout: 30000 });
await page.waitForTimeout(2600);
await page.screenshot({ path: `${OUT}/t104-gallery-desktop.png` });
/* count imgs */
const imgs = await page.evaluate(() =>
  [...document.querySelectorAll('[data-testid="settings-themes"] img')].map((i) => ({ ok: i.complete && i.naturalWidth > 0 }))
);
console.log("desktop imgs:", imgs.length, "loaded:", imgs.filter((x) => x.ok).length);
await ctx.close();

/* phone settings via bottom bar */
const ctx2 = await browser.newContext({ viewport: { width: 390, height: 844 } });
const p2 = await ctx2.newPage();
await p2.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
await p2.evaluate(() => {
  localStorage.setItem("fx-auth", JSON.stringify({ name: "Imperial", role: "owner", email: "spiceowner@gmail.com" }));
});
await p2.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
await p2.locator('[data-testid="settings-btn-mobile"]').waitFor({ timeout: 60000 });
await p2.waitForTimeout(2200);
await p2.locator('[data-testid="settings-btn-mobile"]').click();
await p2.waitForSelector('[data-testid="settings-themes"]', { timeout: 30000 });
await p2.waitForTimeout(2600);
await p2.screenshot({ path: `${OUT}/t104-gallery-phone.png` });
await ctx2.close();

/* landing demo-accounts rows (developer must be gone) */
const ctx3 = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const p3 = await ctx3.newPage();
await p3.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
await p3.waitForSelector("text=finally intelligent", { timeout: 60000 });
await p3.waitForTimeout(1200);
const rows = await p3.evaluate(() => document.body.textContent.match(/DEVELOPER|OWNER|RESTAURANT RECEPTION|LODGE RECEPTION/g));
console.log("landing account rows seen:", JSON.stringify([...new Set(rows || [])]));
const el = await p3.locator("text=Demo access — all three accounts").first().isVisible().catch(() => false);
console.log("three-accounts heading visible:", el);
await p3.evaluate(() => document.querySelector("#home + section, section#privacy")?.scrollIntoView());
await p3.getByRole("button", { name: "Sign In" }).first().click();
await p3.waitForTimeout(900);
const modalRows = await p3.evaluate(() =>
  [...document.querySelectorAll("h3, b, span")].map((e) => e.textContent?.trim()).filter((t) => t && t.length < 30).filter((t) => /DEVELOPER|OWNER|RECEPTION/.test(t))
);
console.log("modal tap-to-fill rows:", JSON.stringify([...new Set(modalRows)]));
await p3.screenshot({ path: `${OUT}/t104-landing-modal.png` });
await ctx3.close();

await browser.close();
console.log("VISUAL CHECK DONE");
