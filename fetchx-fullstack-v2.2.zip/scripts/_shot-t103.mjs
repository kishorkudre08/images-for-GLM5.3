import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
const b = await chromium.launch();
const ctx = await b.newContext({ viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();
await page.addInitScript(() => {
  localStorage.setItem("fx-auth", JSON.stringify({ name: "Imperial", role: "owner", email: "spiceowner@gmail.com" }));
});
await page.goto("http://localhost:3000/", { waitUntil: "domcontentloaded", timeout: 90000 });
await page.waitForSelector("text=Live Dashboard", { timeout: 90000 });
await page.evaluate(() => localStorage.setItem("fx-theme:spiceowner@gmail.com", "classic"));
await page.goto("http://localhost:3000/", { waitUntil: "domcontentloaded", timeout: 90000 });
await page.waitForSelector("text=Live Dashboard", { timeout: 90000 });
await page.waitForTimeout(1200);
const bg = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
console.log("classic light page bg:", bg);
await page.goto("http://localhost:3000/", { waitUntil: "domcontentloaded" });
await page.evaluate(() => { const b = [...document.querySelectorAll("aside nav button")].length; });
await page.waitForTimeout(600);
// open settings
await page.click('[data-testid="settings-btn"]');
await page.waitForTimeout(1500);
await page.evaluate(() => document.querySelector('[data-testid="settings-themes"]').scrollIntoView());
await page.waitForTimeout(500);
await page.screenshot({ path: "/home/z/my-project/download/t103-settings-classic.png" });
// apply blaze → whole page should tint cream
await page.locator('[data-testid="settings-theme-blaze"]').click();
await page.waitForTimeout(900);
const bg2 = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
console.log("blaze light page bg:", bg2);
await page.evaluate(() => document.querySelector('[data-testid="settings-themes"]').scrollIntoView());
await page.waitForTimeout(400);
await page.screenshot({ path: "/home/z/my-project/download/t103-settings-blaze.png" });
// dashboard under blaze light
await page.evaluate(() => { [...document.querySelectorAll("aside nav button")].find(x => x.textContent.toLowerCase().includes("dashboard"))?.click(); });
await page.waitForTimeout(1600);
await page.screenshot({ path: "/home/z/my-project/download/t103-dash-blaze-light.png" });
await b.close();
console.log("done");
