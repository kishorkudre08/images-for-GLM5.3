/* Fetch-X standalone demo runtime — inlined by build-demo.mjs.
 * Drives the captured real-app DOM: sessions, view switching, dashboard
 * tabs/scopes, the AI copilot (hardcoded answers) and the subscribe prompt. */
(function () {
  "use strict";

  var ACCOUNTS = {
    "spiceowner@gmail.com": { pass: "spiceowner", role: "owner", name: "Imperial", home: "dash-all-today", label: "OWNER" },
    "spicerestaurant@gmail.com": { pass: "spicerestaurant", role: "reception_restaurant", name: "Imperial", home: "reception-pos", label: "RESTAURANT RECEPTION" },
    "spicelodge@gmail.com": { pass: "spicelodge", role: "reception_lodge", name: "Imperial", home: "reception-lodge", label: "LODGE RECEPTION" },
  };
  var OWNER_NAV = { dashboard: "dash-all-today", tasks: "tasks", menu: "menu", expenses: "expenses", lodge: "lodge", management: "manage" };
  var NAV_LABELS = { "Live Dashboard": "dashboard", "Tasks": "tasks", "POS Billing": "pos", "Menu Manager": "menu", "Expenses": "expenses", "Lodge Front Desk": "lodge", "Employee": "management", "Attendance": "attendance" };
  /* last dashboard scope/range — the mobile bottom nav returns here */
  var lastDash = { scope: "all", range: "today" };
  var RANGES = { "TODAY": "today", "7 DAYS": "7d", "1 MONTH": "1m", "3 MONTHS": "3m", "1 YEAR": "1y" };
  var SCOPES = { "ALL BUSINESS": "all", "RESTAURANT": "rest", "LODGE": "lodge" };
  var RANGE_ORDER = ["today", "7d", "1m", "3m", "1y"];

  var stage = document.getElementById("fx-stage");
  var session = null;
  var current = null;

  function $(sel, root) { return (root || stage).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || stage).querySelectorAll(sel)); }
  function esc(s) { return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }

  /* ── tiny markdown → html (matches .ai-md expectations) ── */
  function inline(s) {
    return esc(s)
      .replace(/`([^`]+)`/g, "<code>$1</code>")
      .replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>")
      .replace(/(^|[\s(])\*([^*\n]+)\*/g, "$1<em>$2</em>");
  }
  function mdToHtml(md) {
    var lines = md.split("\n");
    var out = [], i = 0, list = null, table = null;
    var closeList = function () { if (list) { out.push("</" + list + ">"); list = null; } };
    var closeTable = function () {
      if (table && table.length) {
        var h = "<div class=\"ai-md-tblw\"><table><thead><tr>";
        table[0].forEach(function (c) { h += "<th>" + inline(c.trim()) + "</th>"; });
        h += "</tr></thead><tbody>";
        for (var r = 1; r < table.length; r++) {
          if (/^[\s|:-]+$/.test(table[r].join(""))) continue;
          h += "<tr>";
          table[r].forEach(function (c) { h += "<td>" + inline(c.trim()) + "</td>"; });
          h += "</tr>";
        }
        out.push(h + "</tbody></table></div>");
      }
      table = null;
    };
    var cells = function (l) { return l.replace(/^\||\|$/g, "").split("|"); };
    for (; i < lines.length; i++) {
      var l = lines[i];
      if (/^\s*\|.*\|\s*$/.test(l)) { closeList(); table = table || []; table.push(cells(l.trim())); continue; }
      closeTable();
      if (/^###\s/.test(l)) { closeList(); out.push("<h4>" + inline(l.replace(/^###\s/, "")) + "</h4>"); }
      else if (/^##\s/.test(l)) { closeList(); out.push("<h3>" + inline(l.replace(/^##\s/, "")) + "</h3>"); }
      else if (/^#\s/.test(l)) { closeList(); out.push("<h2>" + inline(l.replace(/^#\s/, "")) + "</h2>"); }
      else if (/^---+\s*$/.test(l)) { closeList(); out.push("<hr>"); }
      else if (/^[-*]\s+/.test(l)) { if (list !== "ul") { closeList(); out.push("<ul>"); list = "ul"; } out.push("<li>" + inline(l.replace(/^[-*]\s+/, "")) + "</li>"); }
      else if (/^\d+[.)]\s+/.test(l)) { if (list !== "ol") { closeList(); out.push("<ol>"); list = "ol"; } out.push("<li>" + inline(l.replace(/^\d+[.)]\s+/, "")) + "</li>"); }
      else if (/^\s*$/.test(l)) { closeList(); }
      else { closeList(); out.push("<p>" + inline(l) + "</p>"); }
    }
    closeList(); closeTable();
    return out.join("\n");
  }

  /* ── view switching ── */
  function show(id) {
    var tpl = document.querySelector('template[data-state="' + id + '"]');
    if (!tpl) return;
    current = id;
    stage.replaceChildren(tpl.content.cloneNode(true));
    window.scrollTo(0, 0);
    document.title = "Fetch-X — Live Product Demo";
    bind(id);
  }

  /* ── phone support: the captured bottom nav (md:hidden) becomes live on
   *    small screens. t101 — the bar is Instagram-style PURE ICONS, so the
   *    buttons are matched by aria-label (they carry no text any more) and
   *    the settings gear is already captured in the bar itself. ── */
  function bindMobileNav() {
    var mnav = $('nav[aria-label="Main mobile"]');
    if (!mnav) return;
    $$("button", mnav).forEach(function (b) {
      var t = (b.getAttribute("aria-label") || b.getAttribute("title") || "").toLowerCase();
      var target = null;
      if (t.indexOf("live dashboard") >= 0) target = "dash-" + lastDash.scope + "-" + lastDash.range;
      else if (t.indexOf("tasks") >= 0) target = "tasks";
      else if (t.indexOf("menu manager") >= 0) target = "menu"; // t115 — the owner's menu control
      else if (t.indexOf("pos") >= 0) target = session && session.role === "reception_restaurant" ? "reception-pos" : "pos";
      else if (t.indexOf("expenses") >= 0) target = "expenses";
      else if (t.indexOf("lodge") >= 0) target = session && session.role === "reception_lodge" ? "reception-lodge" : "lodge";
      else if (t.indexOf("management") >= 0) target = "manage";
      else if (t.indexOf("attendance") >= 0) target = session && session.role === "reception_lodge" ? "reception-attendance-lodge" : "reception-attendance";
      else if (t.indexOf("settings") >= 0) target = "settings";
      if (!target) return;
      b.addEventListener("click", function () {
        if (!session) session = ACCOUNTS["spiceowner@gmail.com"];
        show(target);
      });
    });
  }

  var toastEl = null, toastT = null;
  function toast(msg) {
    if (!toastEl) {
      toastEl = document.createElement("div");
      toastEl.id = "fx-toast";
      document.body.appendChild(toastEl);
    }
    toastEl.innerHTML = msg;
    toastEl.className = "on";
    clearTimeout(toastT);
    toastT = setTimeout(function () { toastEl.className = ""; }, 2600);
  }

  /* ── landing ── */
  function bindLanding(id) {
    var openModal = function () { show("landing-modal"); };
    $$("button").forEach(function (b) {
      /* the modal's submit "Sign In" button must stay form-live — never re-open the modal */
      if (id === "landing-modal" && b.closest("form")) return;
      var t = (b.textContent || "").trim();
      if (t === "Sign In" || t === "Get Started") b.addEventListener("click", openModal);
      else if (t === "Live Demo") b.addEventListener("click", function () {
        session = ACCOUNTS["spiceowner@gmail.com"];
        show("dash-all-today");
        toast("SIGNED IN AS OWNER — IMPERIAL");
      });
    });
    if (id !== "landing-modal") { armReveal(); return; }
    /* modal state: everything behind the blur is already revealed — no re-fade */
    $$(".rv").forEach(function (el) { el.classList.add("in"); });

    /* modal: tap-to-fill chips */
    $$(".mt-4.rounded-xl button, div.rounded-xl button").forEach(function (b) {
      var codes = $$("code", b);
      if (codes.length === 2) {
        b.addEventListener("click", function () {
          var em = $("input[type=email]"), pw = $("input[type=password]");
          if (em) em.value = codes[0].textContent.trim();
          if (pw) pw.value = codes[1].textContent.trim();
        });
      }
    });
    /* demo table rows behind the modal keep their own sign-in buttons —
       only the modal's submit + close are live here */
    var form = $("form");
    if (form) {
      form.addEventListener("submit", function (e) {
        e.preventDefault();
        var em = ($("input[type=email]") || {}).value || "";
        var pw = ($("input[type=password]") || {}).value || "";
        var a = ACCOUNTS[(em || "").trim().toLowerCase()];
        var oldErr = $(".jk-shake", form.parentElement);
        if (oldErr) oldErr.remove();
        if (a && a.pass === pw) {
          session = a;
          show(a.home);
          toast("SIGNED IN AS " + a.label);
        } else {
          var div = document.createElement("div");
          div.className = "jk-shake rounded-[9px] border border-[rgba(220,38,38,.3)] bg-[rgba(220,38,38,.08)] px-3 py-2.5 text-center text-[12px] font-bold text-[#dc2626]";
          div.setAttribute("role", "alert");
          div.textContent = "Wrong email or password.";
          form.insertBefore(div, form.querySelector("button[type=submit], button"));
        }
      });
    }
    var closeBtn = $('button[aria-label="Close"]');
    if (closeBtn) closeBtn.addEventListener("click", function () { show("landing"); });
  }

  /* ── app shell states ── */
  function bindApp(id) {
    var dash = /^dash-(all|rest|lodge)-(\w+)$/.exec(id);
    var scope = dash ? dash[1] : "all";
    var range = dash ? dash[2] : "today";
    if (dash) lastDash = { scope: scope, range: range };

    /* phone bottom nav + injected settings gear */
    bindMobileNav();

    /* settings gear (desktop sidebar, captured in owner states) */
    var gear = $('[data-testid="settings-btn"]');
    if (gear) gear.addEventListener("click", function () {
      show("settings");
      toast("SETTINGS — THEMES & PROFILE · PERSISTS PER ACCOUNT IN THE FULL BUILD");
    });
    /* settings page: theme gallery + profile save give a hint toast */
    $$("[data-testid^='settings-theme-']").forEach(function (b) {
      b.addEventListener("click", function () { toast("THEME PERSISTS PER ACCOUNT IN THE FULL BUILD"); });
    });
    $$("[data-testid='settings-name-save']").forEach(function (b) {
      b.addEventListener("click", function () { toast("PROFILE NAME PERSISTS PER ACCOUNT IN THE FULL BUILD"); });
    });
    /* t113 — attendance register · t114 — marks STAGE, then SUBMIT registers
       the day with the exact toast the user asked for */
    $$("[data-testid^='attendance-status-']").forEach(function (b) {
      b.addEventListener("click", function () { toast("MARK STAGED — PRESS SUBMIT ATTENDANCE TO REGISTER THE DAY"); });
    });
    $$("[data-testid='attendance-all-present'], [data-testid='attendance-all-absent']").forEach(function (b) {
      b.addEventListener("click", function () { toast("WHOLE DAY STAGED — PRESS SUBMIT ATTENDANCE TO REGISTER"); });
    });
    $$("[data-testid='attendance-submit']").forEach(function (b) {
      b.addEventListener("click", function () { toast("Attendance registered successfully ✅"); });
    });
    /* t115 — the menu manager's delete warnings (dish + section, 10s lock) */
    $$("[data-testid^='pos-dish-delete-'], [data-testid^='pos-cat-delete-']").forEach(function (b) {
      b.addEventListener("click", function () { toast("WARNING FIRST — THE DELETE STAYS LOCKED 10s, THEN IT CAN FIRE"); });
    });
    /* t114 — the restored ENTER EXPENSES section (business toggle + 3 forms) */
    var entryBook = "rest";
    $$("[data-testid='exp-entry-book-rest'], [data-testid='exp-entry-book-lodge']").forEach(function (b) {
      b.addEventListener("click", function () {
        entryBook = (b.getAttribute("data-testid") || "").slice(-5) === "lodge" ? "lodge" : "rest";
        toast("ENTRY SET TO THE " + (entryBook === "lodge" ? "LODGE" : "RESTAURANT") + " BOOK — FORMS SAVE IN THE FULL BUILD");
      });
    });
    $$("[data-testid^='exp-add-']").forEach(function (b) {
      b.addEventListener("click", function () {
        toast("EXPENSE LOGGED INTO THE " + (entryBook === "lodge" ? "LODGE" : "RESTAURANT") + " BOOK — SAVED IN THE FULL BUILD");
      });
    });
    /* tasks view: range toggle + add task are live only in the full build */
    $$("[data-testid^='tk-range-']").forEach(function (b) {
      b.addEventListener("click", function () { toast("TASKS WINDOW TOGGLE RUNS LIVE IN THE FULL BUILD"); });
    });
    var addTask = $("[data-testid='task-add-btn']");
    if (addTask) addTask.addEventListener("click", function () { toast("ADD TASK · BUDGETS & DEADLINES SHIP IN THE FULL BUILD"); });

    /* sidebar nav */
    $$("aside nav button").forEach(function (b) {
      var view = NAV_LABELS[(b.textContent || "").trim().replace(/\s+/g, " ")];
      if (!view) return;
      b.addEventListener("click", function () {
        if (!session) session = ACCOUNTS["spiceowner@gmail.com"];
        if (view === "attendance") show(session.role === "reception_lodge" ? "reception-attendance-lodge" : "reception-attendance");
        else if (session.role === "reception_restaurant") show("reception-pos");
        else if (session.role === "reception_lodge") show("reception-lodge");
        else show(OWNER_NAV[view]);
      });
    });
    /* sign out */
    $$("button").forEach(function (b) {
      if (/sign out/i.test(b.getAttribute("aria-label") || "") || /^SIGN OUT/i.test((b.textContent || "").trim())) {
        b.addEventListener("click", function () { session = null; show("landing"); });
      }
    });
    /* theme controls */
    var themeBtn = $('button[aria-label="Open theme gallery"]');
    if (themeBtn) themeBtn.addEventListener("click", function () {
      toast("THEME GALLERY SHIPS WITH YOUR FETCH-X BUILD — LIGHT/DARK + 5 ACCENTS");
    });
    var darkBtn = $('button[aria-label="Toggle dark mode"]');
    if (darkBtn) darkBtn.addEventListener("click", function () {
      toast("DARK MODE + 5 ACCOUNT THEMES IN THE FULL BUILD");
    });

    /* t96 — TASK PULSE cards: expand/collapse + the maintenance-done lever */
    $$(".task-card .task-top").forEach(function (top) {
      top.addEventListener("click", function () {
        top.closest(".task-card").classList.toggle("open");
      });
    });
    $$("[data-testid$='complete-'], [data-testid*='task-complete']").forEach(function (btn) {
      var card = btn.closest(".task-card");
      var room = card ? (card.querySelector(".task-room") || {}).textContent : "";
      btn.addEventListener("click", function () {
        card.classList.remove("open");
        var chip = card.querySelector(".task-chip");
        if (chip) { chip.className = "task-chip done"; chip.textContent = "DONE"; }
        var bar = card.querySelector(".task-cbar i");
        if (bar) bar.className = "fin";
        var sq = card.querySelector(".task-room");
        if (sq) sq.classList.remove("hot");
        toast("ROOM " + (room || "").trim() + " IS GREEN AGAIN — TURNAROUND CLOSED");
      });
    });
    /* AI fab */
    var fab = $('button[aria-label="Open Fetch-X AI assistant"]');
    if (fab) fab.addEventListener("click", function () { show("ai-open"); });

    if (!dash) return;
    /* range tabs */
    $$('[role=tablist][aria-label="Dashboard time range"] [role=tab]').forEach(function (t) {
      t.addEventListener("click", function () {
        var k = RANGES[(t.textContent || "").trim().replace(/\s+/g, " ")];
        if (k) show("dash-" + scope + "-" + k);
      });
    });
    /* scope chips */
    $$('[role=tablist][aria-label="Business view"] [role=tab]').forEach(function (t) {
      t.addEventListener("click", function () {
        var s = SCOPES[(t.textContent || "").trim().replace(/\s+/g, " ")];
        if (s) show("dash-" + s + "-" + range);
      });
    });
  }

  /* ── AI copilot ── */
  function panelRoot() { return $('aside[aria-label="Fetch-X AI assistant"]') || $('[aria-label="Fetch-X AI assistant"]'); }
  function msgList() {
    var p = panelRoot();
    return p ? p.querySelector(".fx-scroll") : null;
  }
  function bubble(role, html) {
    var wrap = document.createElement("div");
    wrap.className = role === "user" ? "flex justify-end" : "flex justify-start";
    var b = document.createElement("div");
    b.className = "max-w-[88%] rounded-2xl px-3.5 py-2.5 text-[12.5px] font-medium leading-relaxed " +
      (role === "user"
        ? "whitespace-pre-wrap rounded-br-md bg-[var(--fx-purple)] text-[var(--fx-on-accent)]"
        : "rounded-bl-md bg-[var(--fx-lav)] text-[var(--fx-ink)]");
    if (role === "assistant") b.innerHTML = '<div class="ai-md">' + html + "</div>";
    else b.textContent = html;
    wrap.appendChild(b);
    return wrap;
  }
  function scrollBottom() {
    var m = msgList();
    if (m) m.scrollTop = m.scrollHeight;
  }
  function ask(q, md) {
    var m = msgList();
    if (!m) return;
    var empty = m.querySelector(".px-2.py-6");
    if (empty) empty.remove();
    m.appendChild(bubble("user", q));
    var think = bubble("assistant", '<p><span class="fx-thinking">FETCH-X AI is reading your books…</span></p>');
    m.appendChild(think);
    scrollBottom();
    setTimeout(function () {
      think.remove();
      m.appendChild(bubble("assistant", mdToHtml(md)));
      var hint = m.querySelector(".fx-sub-hint");
      if (!hint) {
        hint = document.createElement("p");
        hint.className = "fx-sub-hint";
        m.appendChild(hint);
      }
      scrollBottom();
    }, 1100);
  }
  function subscribeReply(q) {
    return "## Demo question set\nThis offline demo ships with the four suggested questions only — **live AI answers run on your own data after activation.**\n\n**Contact Fetch-X to purchase the subscription** and the copilot unlocks for your whole team:\n\n- Unlimited questions across both ledgers\n- Reads your live bills, stays, expenses and team\n- Owner and reception consoles included\n\n`sales@fetchx.app` — mention \u201c" + esc(q) + "\u201d and we will set you up.";
  }
  function bindAi() {
    bindApp("dash-all-today");
    var backDash = "dash-" + lastDash.scope + "-" + lastDash.range;
    var close = $('button[aria-label="Collapse AI panel"]');
    if (close) close.addEventListener("click", function () { show(backDash); });
    var clear = $('button[aria-label="Clear conversation"]');
    if (clear) clear.addEventListener("click", function () { show("ai-open"); });
    var full = $('button[aria-label="Open AI panel full screen"]');
    if (full) full.addEventListener("click", function () { toast("FULLSCREEN COPILOT IN THE FULL BUILD"); });

    /* suggested question chips — hardcoded answers */
    var root = panelRoot();
    var chips = root ? root.querySelectorAll("button") : [];
    Array.prototype.forEach.call(chips, function (b) {
      var t = (b.textContent || "").trim();
      var hit = AI_SEED.filter(function (s) { return s.q === t; })[0];
      if (hit) b.addEventListener("click", function () { ask(hit.q, hit.a); });
    });
    /* free text → subscribe prompt */
    var form = ($('input[aria-label="Ask the AI copilot"]') || {}).closest && $('input[aria-label="Ask the AI copilot"]').closest("form");
    if (form) {
      form.addEventListener("submit", function (e) {
        e.preventDefault();
        var inp = form.querySelector("input");
        var q = (inp.value || "").trim();
        if (!q) return;
        inp.value = "";
        var seeded = AI_SEED.filter(function (s) { return s.q.toLowerCase() === q.toLowerCase(); })[0];
        ask(q, seeded ? seeded.a : subscribeReply(q));
      });
    }
  }

  /* ── landing reveal-on-scroll (real .rv behaviour) ── */
  var revealIo = null;
  function armReveal() {
    if (revealIo) revealIo.disconnect();
    if (!("IntersectionObserver" in window)) {
      $$(".rv").forEach(function (el) { el.classList.add("in"); });
      return;
    }
    revealIo = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (!e.isIntersecting) return;
        e.target.classList.add("in");
        revealIo.unobserve(e.target);
      });
    }, { threshold: 0.12 });
    $$(".rv").forEach(function (el) { revealIo.observe(el); });
  }

  function bind(id) {
    if (id === "landing" || id === "landing-modal") bindLanding(id);
    else if (id === "ai-open") bindAi();
    else bindApp(id);
  }

  /* public hook for verification */
  window.FX_DEMO = { show: show, state: function () { return current; } };

  /* boot is triggered by the hydrator once the gzip states are decoded */
  window.FX_START = function () {
    var start = (location.hash || "").replace("#", "");
    show(document.querySelector('template[data-state="' + start + '"]') ? start : "landing");
  };
})();
