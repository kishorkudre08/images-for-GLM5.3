/* phone-compat probe — LANDSCAPE is the supported phone mode (t105):
 * sweep every view at 667×375, spot-check the desktop layout at 844×390,
 * then confirm portrait 390×844 is gated by the rotate prompt.
 * Run: node scripts/mobile-probe.mjs
 */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
import fs from "node:fs";

const BASE = "http://localhost:3000";
const OUT = "/home/z/my-project/download";
const W = 667, H = 375;

const OWNER = { name: "Imperial", role: "owner", email: "spiceowner@gmail.com" };
const REST = { name: "Imperial", role: "reception_restaurant", email: "spicerestaurant@gmail.com" };
const LODGE = { name: "Imperial", role: "reception_lodge", email: "spicelodge@gmail.com" };

const browser = await chromium.launch();
const ctx = await browser.newContext({
  viewport: { width: W, height: H },
  deviceScaleFactor: 2,
  isMobile: true,
  hasTouch: true,
  userAgent: "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
});
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(String(e)));

const settle = async (ms = 2400) => {
  await page.waitForLoadState("networkidle", { timeout: 20000 }).catch(() => {});
  await page.waitForTimeout(ms);
};

const probe = async (label) => {
  const m = await page.evaluate(() => {
    const doc = document.documentElement;
    const overW = Math.max(doc.scrollWidth, document.body.scrollWidth) - window.innerWidth;
    // find the widest offenders
    const offenders = [];
    document.querySelectorAll("body *").forEach((el) => {
      const r = el.getBoundingClientRect();
      if (r.width > 0 && (r.right > window.innerWidth + 6 || r.left < -6) && !el.closest("[data-probe-ok]")) {
        const cls = (el.className && typeof el.className === "string") ? el.className.slice(0, 70) : "";
        if (offenders.length < 6 && r.width > window.innerWidth * 0.55)
          offenders.push(`${el.tagName.toLowerCase()}.${cls} w=${Math.round(r.width)} right=${Math.round(r.right)}`);
      }
    });
    return { overW, offenders };
  });
  const file = `${OUT}/mob-${label}.png`;
  await page.screenshot({ path: file, fullPage: false });
  console.log(`${m.overW > 2 ? "✗ OVERFLOW" : "✓ ok     "} ${label}  over=${m.overW}px ${m.offenders.length ? "\n    · " + m.offenders.join("\n    · ") : ""}`);
  return m.overW;
};

/* 1 · landing */
await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
await settle(2800);
await probe("01-landing");
await page.getByRole("button", { name: "Sign In" }).first().click().catch(() => {});
await settle(700);
await probe("02-landing-modal");

/* 2 · owner: all six views */
await page.evaluate((u) => localStorage.setItem("fx-auth", JSON.stringify(u)), OWNER);
await page.goto(BASE, { waitUntil: "domcontentloaded" });
await settle(3200);
await probe("03-owner-dash");
for (const [label, name] of [["04-owner-tasks", "TASKS"], ["05-owner-menu", "Menu Manager"], ["06-owner-expenses", "EXPENSES"], ["07-owner-lodge", "LODGE"], ["08-owner-employee", "Employee"]]) {
  await page.getByRole("button", { name }).first().click().catch(async (e) => {
    console.log(`  (nav "${name}" failed: ${String(e).slice(0, 60)})`);
  });
  await settle(2200);
  await probe(label);
}

/* 3 · restaurant reception */
await page.evaluate((u) => localStorage.setItem("fx-auth", JSON.stringify(u)), REST);
await page.goto(BASE, { waitUntil: "domcontentloaded" });
await settle(2600);
await probe("10-rest-pos");
await page.getByRole("button", { name: "Attendance" }).first().click().catch(async (e) => {
  console.log(`  (nav "Attendance" failed: ${String(e).slice(0, 60)})`);
});
await settle(2000);
await probe("10b-rest-attendance");

/* 4 · lodge reception */
await page.evaluate((u) => localStorage.setItem("fx-auth", JSON.stringify(u)), LODGE);
await page.goto(BASE, { waitUntil: "domcontentloaded" });
await settle(2600);
await probe("11-lodge-desk");
await page.getByRole("button", { name: "Attendance" }).first().click().catch(async (e) => {
  console.log(`  (nav "Attendance" failed: ${String(e).slice(0, 60)})`);
});
await settle(2000);
await probe("11b-lodge-attendance");

/* 5 · bigger phone in landscape (844×390) → desktop layout spot check */
await page.setViewportSize({ width: 844, height: 390 });
await page.evaluate((u) => localStorage.setItem("fx-auth", JSON.stringify(u)), OWNER);
await page.goto(BASE, { waitUntil: "domcontentloaded" });
await settle(3000);
await probe("12-owner-dash-844-landscape");

/* 6 · portrait phone 390×844 MUST be gated by the rotate prompt (t105) */
await page.setViewportSize({ width: 390, height: 844 });
await page.goto(BASE, { waitUntil: "domcontentloaded" });
await settle(1800);
const gateOn = await page.evaluate(() => {
  const g = document.querySelector(".fx-rotate-gate");
  return !!g && getComputedStyle(g).display !== "none";
});
console.log(`${gateOn ? "✓ ok     " : "✗ GATE MISSING"} 13-portrait-gate (rotate prompt covers portrait phones)`);
await page.screenshot({ path: `${OUT}/mob-13-portrait-gate.png` });
if (!gateOn) errors.push("portrait 390×844 did not show the landscape gate");

console.log("page errors:", errors.length ? errors : "none");
await browser.close();
console.log("MOBILE PROBE DONE");
