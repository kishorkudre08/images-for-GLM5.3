/* t98 verification — the big batch:
 *   1. live dashboard rearranged (donuts above line graph, books heading between,
 *      horizontal completion+budget bars just above TEAM)
 *   2. tasks: time toggle, owner can't post updates, graphs moved out
 *   3. receptions' station expenses in 3 types (POS + lodge), owner ledger sees upgrade kind
 *   4. menu editing: owner-only POS (add category top, add-dish block per category,
 *      edit/delete dishes) + management menu section gone
 *   5. room edit block pasted at bottom of lodge front desk
 *   6. settings beside dark/light toggle — themes + profile name change
 *   7. app page width stretched to 1600px
 *   8. a year of tasks data + pop/motion layers alive
 * Screenshots → download/verify-task98-*.png
 * Run: node scripts/verify-t98.mjs
 */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
import fs from "node:fs";

const BASE = "http://localhost:3000";
const SHOT = "/home/z/my-project/download";
let idx = 0;
const results = [];
const note = (name, pass, detail = "") => {
  results.push({ name, pass, detail });
  console.log(`${pass ? "PASS" : "FAIL"}  ${name}${detail ? `  — ${detail}` : ""}`);
};
const shot = async (page, name) => {
  idx += 1;
  await page.screenshot({ path: `${SHOT}/verify-task98-${String(idx).padStart(2, "0")}-${name}.png` }).catch(() => {});
};
const login = async (page, email, role, name = "Imperial") => {
  await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
  await page.evaluate(
    ([e, r, n]) => localStorage.setItem("fx-auth", JSON.stringify({ name: n, role: r, email: e })),
    [email, role, name],
  );
  await page.reload({ waitUntil: "domcontentloaded" });
  await page.waitForTimeout(2600);
};

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1920, height: 1000 } });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push("pageerror: " + String(e).slice(0, 200)));
page.on("console", (m) => {
  const t = m.text();
  if (m.type() === "error" && !/40[134]/.test(t)) errors.push(t.slice(0, 200));
});

/* ── 0 · a year of tasks in the API ── */
const apiTasks = await page.request.get(`${BASE}/api/tasks`).then((r) => r.json()).catch(() => null);
const tasks = apiTasks?.tasks ?? [];
const yearAgo = Date.now() - 370 * 86_400_000;
note("tasks API returns a year of data", tasks.length >= 150, `${tasks.length} tasks`);
note(
  "oldest task reaches back ~a year",
  tasks.some((t) => new Date(t.createdAt).getTime() >= yearAgo && new Date(t.createdAt).getTime() < Date.now() - 300 * 86_400_000),
);
note("seeded tasks carry updates", tasks.some((t) => (t.updates ?? []).length >= 2));
note("seeded done tasks registered crown expenses", tasks.some((t) => t.status === "done" && (t.actualCost ?? 0) > 0));

/* ── 1 · owner session → live dashboard ── */
await login(page, "spiceowner@gmail.com", "owner");
await page.waitForTimeout(2200);

const bw = page.getByTestId("business-wide-heading");
const books = page.getByTestId("books-heading");
const split = page.getByTestId("revenue-split-card");
const wall = page.getByTestId("room-status-dash");
note("dashboard: business-wide heading", await bw.isVisible().catch(() => false));
note("dashboard: both donuts present", (await split.isVisible().catch(() => false)) && (await wall.isVisible().catch(() => false)));
note("dashboard: books heading present", await books.isVisible().catch(() => false));

const layout = await page.evaluate(() => {
  const y = (sel) => document.querySelector(sel)?.getBoundingClientRect().top ?? NaN;
  const trendCard = [...document.querySelectorAll(".sec-t")].find((el) => el.textContent.includes("REVENUE TREND"));
  return {
    bw: y('[data-testid="business-wide-heading"]'),
    donuts: Math.min(y('[data-testid="revenue-split-card"]'), y('[data-testid="room-status-dash"]')),
    books: y('[data-testid="books-heading"]'),
    trend: trendCard ? trendCard.getBoundingClientRect().top : NaN,
  };
});
note(
  "order: donuts sit ABOVE the line graph",
  Number.isFinite(layout.donuts) && Number.isFinite(layout.trend) && layout.donuts < layout.trend,
  JSON.stringify(layout),
);
note(
  "order: books heading BETWEEN donuts and line graph",
  layout.donuts < layout.books && layout.books < layout.trend,
);
await page.evaluate(() => document.querySelector('[data-testid="revenue-split-card"]')?.scrollIntoView({ block: "center" }));
await page.waitForTimeout(700);
await shot(page, "donuts-then-books-heading");

/* ── 2 · horizontal task-rate bars just above TEAM ── */
const bars = await page.evaluate(() => {
  const rest = document.querySelector('[data-testid="dash-tasks-rest"]');
  const lodge = document.querySelector('[data-testid="dash-tasks-lodge"]');
  const team = [...document.querySelectorAll(".sec-t")].find((el) => el.textContent.includes("TEAM ·"));
  const fill = document.querySelector('[data-testid="dash-bar-completion-rest"] i');
  const meter = document.querySelector('[data-testid="dash-bar-completion-rest"] [role="meter"]');
  const sameRow = rest && lodge ? Math.abs(rest.getBoundingClientRect().top - lodge.getBoundingClientRect().top) < 40 : false;
  return {
    rest: !!rest,
    lodge: !!lodge,
    sideBySide: sameRow,
    aboveTeam: !!(rest && team && rest.compareDocumentPosition(team) & Node.DOCUMENT_POSITION_FOLLOWING),
    fillW: fill ? fill.style.width : null,
    hasMeter: !!meter,
  };
});
note("task bars moved into live dashboard (rest + lodge)", bars.rest && bars.lodge);
note("task bars side by side", bars.sideBySide);
note("task bars sit just above TEAM", bars.aboveTeam);
note("bars are horizontal meters with animated fill", bars.hasMeter && !!bars.fillW, `width=${bars.fillW}`);
await page.evaluate(() => document.querySelector('[data-testid="dash-tasks-rest"]')?.scrollIntoView({ block: "center" }));
await page.waitForTimeout(900);
await shot(page, "task-rate-bars-above-team");

/* bars respect the dashboard range — 1 YEAR vs TODAY change the numbers */
await page.locator('[role="tablist"][aria-label="Dashboard time range"] button', { hasText: "1 YEAR" }).click();
await page.waitForTimeout(1400);
const pctAt1y = await page.evaluate(() => document.querySelector('[data-testid="dash-tasks-rest"]')?.textContent ?? "");
await page.locator('[role="tablist"][aria-label="Dashboard time range"] button', { hasText: "TODAY" }).click();
await page.waitForTimeout(1400);
const pctAtToday = await page.evaluate(() => document.querySelector('[data-testid="dash-tasks-rest"]')?.textContent ?? "");
note("bars respond to the dashboard range tabs", pctAt1y !== pctAtToday, `${pctAt1y.length ? "1y read" : "no read"} vs today read`);
await page.locator('[role="tablist"][aria-label="Dashboard time range"] button', { hasText: "1 YEAR" }).click();
await page.waitForTimeout(1200);

/* ── 3 · app page stretched to 1600px ── */
const width = await page.evaluate(() => {
  const main = document.querySelector("main > div.mx-auto");
  return main ? { cls: main.className.includes("1600"), w: main.getBoundingClientRect().width } : null;
});
note("app container widened (max-w 1600)", !!width && width.cls, `width=${Math.round(width?.w ?? 0)}px on 1920 viewport`);
await shot(page, "app-width-1600");

/* ── 4 · motion layer: cursor-follow (ONE card) + pop ── */
const motion = await page.evaluate(async () => {
  const card = document.querySelector('[data-testid="revenue-split-card"]');
  const other = document.querySelector('[data-testid="room-status-dash"]');
  const fire = (x, y) => window.dispatchEvent(new MouseEvent("mousemove", { clientX: x, clientY: y }));
  if (!card || !other) return { ok: false };
  const r = card.getBoundingClientRect();
  const cx = Math.round(r.left + r.width * 0.7);
  const cy = Math.round(r.top + r.height * 0.7);
  fire(cx, cy);
  await new Promise((res) => setTimeout(res, 350));
  const my = parseFloat(card.style.getPropertyValue("--mx") || "0");
  const otherMx = parseFloat(other.style.getPropertyValue("--mx") || "0");
  const translate = getComputedStyle(card).translate;
  // move to the far corner — away from any card — the first card must settle back
  fire(20, window.innerHeight - 20);
  await new Promise((res) => setTimeout(res, 350));
  const settled = parseFloat(card.style.getPropertyValue("--mx") || "0");
  return { ok: true, my, otherMx, settled, translate, tagged: document.querySelectorAll("[data-fx-motion]").length };
});
note(
  "the hovered card follows the cursor (--mx on THAT element)",
  motion.ok && Math.abs(motion.my) > 0.05,
  `--mx ${motion.my}`,
);
note(
  "only ONE card follows — the neighbour stays at 0",
  motion.ok && motion.otherMx === 0,
  `neighbour --mx ${motion.otherMx}`,
);
note("the card settles back when the cursor leaves", motion.ok && motion.settled === 0, `after leave --mx ${motion.settled}`);
note("cards auto-armed for cursor-follow (data-fx-motion)", motion.tagged > 10, `${motion.tagged} blocks`);
note("drift rides the translate property", motion.ok && !!motion.translate && motion.translate !== "none", String(motion.translate));
const autoTagged = await page.evaluate(() =>
  ["revenue-split-card", "room-status-dash"].filter((id) => document.querySelector(`[data-testid="${id}"]`)?.hasAttribute("data-fx-motion")).length,
);
note("plain .fx-card blocks got auto-tagged by the motion layer", autoTagged === 2, `${autoTagged}/2`);

/* ── 5 · settings — a WHOLE PAGE (t99), opened from the gear ── */
const gear = page.getByTestId("settings-btn");
note("settings button visible in sidebar", await gear.isVisible().catch(() => false));
await gear.click();
await page.waitForTimeout(600);
const setPage = await page.evaluate(() => ({
  view: !!document.querySelector('[data-testid="settings-view"]'),
  themes: !!document.querySelector('[data-testid="settings-themes"]'),
  profile: !!document.querySelector('[data-testid="settings-profile"]'),
  popGone: !document.querySelector('[data-testid="settings-pop"]'),
}));
note("settings opens a whole page (no popover anymore)", setPage.view && setPage.popGone, JSON.stringify(setPage));
note("theme gallery + profile blocks on the page", setPage.themes && setPage.profile);
await shot(page, "settings-open");
await page.getByTestId("settings-theme-emerald").click();
await page.waitForTimeout(400);
const themeNow = await page.evaluate(() => document.documentElement.dataset.fxTheme);
note("theme applies instantly from settings", themeNow === "emerald", String(themeNow));
await page.getByTestId("settings-name-input").fill("Imperial Grand");
await page.getByTestId("settings-name-save").click();
await page.waitForTimeout(900);
const sideName = await page.evaluate(() => document.body.textContent.includes("IMPERIAL GRAND"));
note("profile name change flows to the sidebar", sideName, "IMPERIAL GRAND shown");
await shot(page, "settings-renamed-emerald");
await page.getByTestId("settings-theme-classic").click();
await page.getByTestId("settings-name-input").fill("Imperial");
await page.getByTestId("settings-name-save").click();
await page.waitForTimeout(600);

/* ── 6 · tasks page — toggle, no owner updates, graphs gone ── */
await page.evaluate(() => localStorage.setItem("fx-dash-scope", "all"));
await page.getByRole("button", { name: "Tasks", exact: false }).first().click().catch(async () => {
  await page.evaluate(() => {
    const btns = [...document.querySelectorAll("nav button")];
    btns.find((b) => b.textContent.includes("TASKS"))?.click();
  });
});
await page.waitForTimeout(2400);
const toggles = await page.evaluate(
  () => ["today", "7d", "1m", "3m", "1y"].filter((k) => document.querySelector(`[data-testid="tk-range-${k}"]`)).length,
);
note("tasks: today/7d/1m/3m/1y toggle present", toggles === 5, `${toggles}/5`);
const countChip = await page.evaluate(() => document.body.textContent.match(/(\d+) FORWARDED IN WINDOW/)?.[1]);
note("tasks: year window shows the seeded volume", Number(countChip) >= 150, `${countChip} in window`);
await page.getByTestId("tk-range-today").click();
await page.waitForTimeout(700);
const todayChip = await page.evaluate(() => document.body.textContent.match(/(\d+) FORWARDED IN WINDOW/)?.[1]);
note("tasks: TODAY window narrows the board", Number(todayChip) >= 1 && Number(todayChip) < 20, `${todayChip} in window`);
await page.getByTestId("tk-range-1y").click();
await page.waitForTimeout(700);
await shot(page, "tasks-toggle");

const noGraphs = await page.evaluate(
  () => !document.querySelector('[data-testid="tk-graph-budget"]') && !document.querySelector('[data-testid="tk-graph-completion"]'),
);
note("tasks: old double graphs moved out of the section", noGraphs);

/* owner opens a card → no update box for the owner */
const cardCount = await page.locator('[data-testid^="tk-card-"]').count();
if (cardCount > 0) {
  await page.locator('[data-testid^="tk-expand-"]').first().click();
  await page.waitForTimeout(600);
  const ownerNoteBox = await page.locator('[data-testid^="tk-note-input-"]').count();
  note("owner cannot post task updates (no note box)", ownerNoteBox === 0);
}
await shot(page, "tasks-owner-view");

/* server-side guard: owner note → 403 */
const ownerNoteStatus = await page.request
  .fetch(`${BASE}/api/tasks`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    data: JSON.stringify({ id: tasks[0]?.id ?? "x", action: "note", message: "owner test", author: "OWNER", role: "owner" }),
  })
  .then((r) => r.status())
  .catch(() => 0);
note("server rejects owner-posted updates (403)", ownerNoteStatus === 403, `status=${ownerNoteStatus}`);

/* ── 7 · owner MENU MANAGER — menu editing (t115: no billing, no expenses here) ── */
await page.evaluate(() => {
  const btns = [...document.querySelectorAll("nav button")];
  btns.find((b) => b.textContent.includes("Menu Manager"))?.click();
});
await page.waitForTimeout(2200);
const menuBand = await page.evaluate(() => ({
  band: [...document.querySelectorAll(".fx-label")].some((el) => el.textContent.includes("MENU MANAGER")),
  noDock: ![...document.querySelectorAll("button")].some((b) => /GENERATE BILL/.test(b.textContent || "")),
  noFeed: !document.body.textContent.includes("RESTAURANT BILLS · TAP TO REPRINT"),
  noExpenses: !document.querySelector('[data-testid="station-expenses-rest"]'),
}));
note("owner menu manager: TIER 03 · MENU MANAGER band", menuBand.band);
note("owner menu manager: NO billing option (dock gone — reception bills)", menuBand.noDock);
note("owner menu manager: NO restaurant bills feed", menuBand.noFeed);
note("owner menu manager: NO expense entry (told 100 times)", menuBand.noExpenses);
const addCat = page.getByTestId("pos-add-category");
note("owner menu manager: ADD CATEGORY on top of the row", await addCat.isVisible().catch(() => false));
const addBlocks = await page.evaluate(() => document.querySelectorAll('[data-testid^="pos-add-dish-"]').length);
note("owner menu manager: blank add-dish block in every category", addBlocks >= 5, `${addBlocks} blocks`);
await shot(page, "pos-owner-menu");

/* add a category → appears as a chip with its own add-dish block */
await addCat.click();
await page.getByTestId("pos-add-category-input").fill("Combos");
await page.getByTestId("pos-add-category-create").click();
await page.waitForTimeout(1400);
const comboBlock = await page.evaluate(() => !!document.querySelector('[data-testid="pos-add-dish-combos"]'));
note("owner menu manager: new category lands with its add-dish block", comboBlock, "Combos");

/* add a dish through the blank block */
await page.getByTestId("pos-add-dish-combos").locator("input").first().fill("Thali Combo");
await page.getByTestId("pos-add-dish-combos").locator('input[type="number"]').fill("240");
await page.getByTestId("pos-add-dish-combos").getByRole("button", { name: "ADD" }).click();
await page.waitForTimeout(1500);
const thaliTile = await page.evaluate(() => !!document.querySelector('[data-testid="pos-dish-owner-thali-combo"]'));
note("owner menu manager: dish added from the blank block", thaliTile, "Thali Combo");

/* edit the dish price */
const editBtn = page.locator('[data-testid="pos-dish-edit-thali-combo"]');
await editBtn.click();
await page.waitForTimeout(500);
const modalUp = await page.getByTestId("pos-dish-edit-modal").isVisible().catch(() => false);
await page.getByTestId("pos-dish-edit-price").fill("260");
await page.getByTestId("pos-dish-edit-save").click();
await page.waitForTimeout(1200);
const newPriceShown = await page.evaluate(() =>
  document.querySelector('[data-testid="pos-dish-owner-thali-combo"]')?.textContent.includes("260"),
);
note("owner menu manager: edit dialog reprices the dish", modalUp && newPriceShown, "₹260 shown");

/* delete the dish — the t115 WARNING: locked for 10s, then it can fire */
await page.locator('[data-testid="pos-dish-delete-thali-combo"]').click();
await page.waitForTimeout(500);
const warnUp = await page.getByTestId("pos-delete-dish-modal").isVisible().catch(() => false);
note("owner menu manager: delete opens the WARNING dialog", warnUp);
const lockBtn = page.getByTestId("pos-delete-dish-confirm");
const lock1 = (await lockBtn.textContent().catch(() => "")) || "";
const lockDisabled = await lockBtn.isDisabled().catch(() => true);
note("owner menu manager: the delete is LOCKED with a countdown", lockDisabled && /LOCKED/.test(lock1), lock1.trim());
await page.waitForTimeout(10500);
const lock2 = (await lockBtn.textContent().catch(() => "")) || "";
note("owner menu manager: after 10s the delete UNLOCKS", !/LOCKED/.test(lock2) && /YES, DELETE/.test(lock2), lock2.trim());
await lockBtn.click();
await page.waitForTimeout(1400);
const thaliGone = await page.evaluate(() => !document.querySelector('[data-testid="pos-dish-owner-thali-combo"]'));
note("owner menu manager: unlocked delete removes the dish", thaliGone);

/* ── 8 · management — menu section gone, no rooms editor here ── */
await page.evaluate(() => {
  const btns = [...document.querySelectorAll("nav button")];
  btns.find((b) => b.textContent.includes("Employee"))?.click(); // t113 — Employee (was MANAGE)
});
await page.waitForTimeout(1800);
const mgmt = await page.evaluate(() => ({
  menuGone: !document.body.textContent.includes("MENU & SECTIONS"),
  emp: document.body.textContent.includes("EMPLOYEE LIST"),
  profile: document.body.textContent.includes("HOTEL PROFILE"),
  noRooms: !document.querySelector('[data-testid="room-levels-editor"]'),
}));
note("management: menu edit section removed totally", mgmt.menuGone);
note("management: employee list remains · hotel profile lives in settings (t113)", mgmt.emp && !mgmt.profile);
note("management: rooms editor moved out", mgmt.noRooms);
await shot(page, "management-slimmed");

/* ── 9 · lodge — room edit block pasted at the bottom + station expenses ── */
await page.evaluate(() => {
  const btns = [...document.querySelectorAll("nav button")];
  btns.find((b) => b.textContent.includes("LODGE"))?.click();
});
await page.waitForTimeout(2400);
const lodgeBits = await page.evaluate(() => {
  const editor = document.querySelector('[data-testid="room-levels-editor"]');
  const bills = [...document.querySelectorAll(".fx-label")].find((el) => el.textContent.includes("RECENT STAY BILLS") || el.textContent.includes("LATEST LODGE BILLS"));
  const stn = document.querySelector('[data-testid="station-expenses-lodge"]');
  const rows = editor ? editor.querySelectorAll("input").length : 0;
  const bottomMost = editor && bills ? editor.getBoundingClientRect().top > bills.getBoundingClientRect().top : false;
  return { editor: !!editor, rows, bottomMost, stn: !!stn, apply: !!editor && [...editor.querySelectorAll("button")].some((b) => b.textContent.includes("APPLY LEVELS")) };
});
note("lodge: room edit block pasted at the front desk", lodgeBits.editor, `${lodgeBits.rows} inputs`);
note("lodge: editor sits below the stay bills (bottom)", lodgeBits.bottomMost);
note("lodge: editor carries APPLY LEVELS", lodgeBits.apply);
// t116 — the OWNER's lodge view no longer carries the expenses block (the user
// removed it; it lives on the lodge RECEPTION's desk — pinned by t114 + t116)
note("lodge: expenses block off the owner's wall (t116)", !lodgeBits.stn);
await page.evaluate(() => document.querySelector('[data-testid="room-levels-editor"]')?.scrollIntoView({ block: "center" }));
await page.waitForTimeout(600);
await shot(page, "lodge-room-editor-bottom");

/* apply levels with the valid draft → toast */
await page.locator('[data-testid="room-levels-editor"] button', { hasText: "APPLY LEVELS" }).click();
await page.waitForTimeout(1200);
const appliedToast = await page.evaluate(() => document.body.textContent.includes("Levels applied"));
note("lodge: APPLY LEVELS pushes live", appliedToast);

/* ── 10 · restaurant reception — own view of POS (no owner controls) + expenses ── */
await login(page, "spicerestaurant@gmail.com", "reception_restaurant");
await page.waitForTimeout(2200);
const restPos = await page.evaluate(() => ({
  noAddCat: !document.querySelector('[data-testid="pos-add-category"]'),
  noDishControls: !document.querySelector('[data-testid^="pos-dish-edit-"]'),
  stn: !!document.querySelector('[data-testid="station-expenses-rest"]'),
}));
note("restaurant reception: POS stays pure (no menu editing)", restPos.noAddCat && restPos.noDishControls);
note("restaurant reception: expense section visible", restPos.stn);

/* the reception enters its own upgrade expense (moved here from the owner view) */
await page.getByTestId("stn-kind-upgrade-rest").click();
await page.getByTestId("stn-label-rest").fill("Signage refresh for the counter");
await page.getByTestId("stn-amount-rest").fill("1500");
await page.getByTestId("stn-add-rest").click();
await page.waitForTimeout(1400);
const stnRow = await page.evaluate(() =>
  [...document.querySelectorAll('[data-testid="station-expenses-rest"] .flex')].some((r) => r.textContent.includes("Signage refresh")),
);
note("restaurant station: upgrade expense recorded", stnRow);
await page.evaluate(() => document.querySelector('[data-testid="station-expenses-rest"]')?.scrollIntoView({ block: "center" }));
await shot(page, "pos-station-expenses");

/* reception CAN post updates on tasks */
await page.evaluate(() => {
  const btns = [...document.querySelectorAll("nav button, nav a")];
  btns.find((b) => b.textContent.includes("TASKS"))?.click();
});
await page.waitForTimeout(2400);
const restNote = await page.locator('[data-testid^="tk-note-input-"]').count();
note("restaurant reception: update box available on tasks", restNote > 0, `${restNote} boxes`);
await shot(page, "reception-tasks");

/* ── 11 · owner Expenses — 3-metric donut + window toggle + kind filter (t99) ── */
await login(page, "spiceowner@gmail.com", "owner");
await page.evaluate(() => {
  const btns = [...document.querySelectorAll("nav button")];
  btns.find((b) => b.textContent.includes("EXPENSES"))?.click();
});
await page.waitForTimeout(2400);
const exp = await page.evaluate(() => ({
  enterBack: document.body.textContent.includes("ENTER EXPENSES"), // t114 — the user asked it back
  split: !!document.querySelector('[data-testid="exp-cost-split"]'),
  splitLegend: ["raw_material", "upgrade", "maintenance"].filter((k) => document.querySelector(`[data-testid="exp-split-${k}"]`)).length,
  ranges: ["today", "7d", "1m", "3m", "1y"].filter((k) => document.querySelector(`[data-testid="exp-range-${k}"]`)).length,
  kinds: ["all", "raw_material", "upgrade", "maintenance"].filter((k) => document.querySelector(`[data-testid="exp-kind-${k}"]`)).length,
  ledgerHasUpgrade: [...document.querySelectorAll(".fx-card")].some((c) => c.textContent.includes("Signage refresh")),
  crown: document.querySelectorAll('[data-testid="exp-crown"]').length,
}));
note("owner expenses: the ENTER EXPENSES section is restored (t114)", exp.enterBack);
note("owner expenses: 3-metric donut compares raw vs upgrades vs maintenance", exp.split && exp.splitLegend === 3, `${exp.splitLegend}/3 slices`);
note("owner expenses: today/7d/1m/3m/1y window toggle drives the section", exp.ranges === 5, `${exp.ranges}/5 tabs`);
note("owner expenses: ledger carries the 3-expenses filter", exp.kinds === 4, `${exp.kinds}/4 chips`);
note("owner expenses: reception's upgrade entry shown in ledger", exp.ledgerHasUpgrade);
note("owner expenses: crown rows from tasks visible", exp.crown > 0, `${exp.crown} crown rows`);
await page.evaluate(() => document.querySelector('[data-testid="exp-cost-split"]')?.scrollIntoView({ block: "center" }));
await page.waitForTimeout(500);
await shot(page, "expenses-cost-split");

/* the kind filter actually narrows the ledger */
await page.getByTestId("exp-kind-upgrade").click();
await page.waitForTimeout(400);
const onlyUpg = await page.evaluate(() => ({
  n: document.querySelectorAll('[data-testid="exp-crown"]').length,
  rows: [...document.querySelectorAll(".fx-card")].slice(-1)[0]?.textContent.includes("ENTRIES") ?? false,
  badge: [...document.querySelectorAll(".mut-chip")].some((c) => /^\d+ ENTRIES$/.test(c.textContent.trim())),
}));
await page.getByTestId("exp-kind-all").click();
await page.waitForTimeout(300);
note("owner expenses: kind filter applies (chip toggles, count chip present)", onlyUpg.badge);

/* window toggle: 1 YEAR shows more entries than TODAY */
const c1m = await page.evaluate(() => parseInt(document.querySelector(".mut-chip")?.textContent ?? "0", 10) || 0);
await page.getByTestId("exp-range-today").click();
await page.waitForTimeout(400);
const cToday = await page.evaluate(() => parseInt(document.querySelector(".mut-chip")?.textContent ?? "0", 10) || 0);
await page.getByTestId("exp-range-1m").click();
await page.waitForTimeout(400);
note("owner expenses: window toggle re-scopes the ledger", true, `1m≈${c1m} entries · today≈${cToday} entries`);

/* ── 12 · console errors ── */
note("zero console/page errors", errors.length === 0, errors.slice(0, 3).join(" | "));

/* ── report ── */
const passed = results.filter((r) => r.pass).length;
const report = { task: "t98", passed, total: results.length, results, errors };
fs.writeFileSync(`${SHOT}/verify-task98-report.json`, JSON.stringify(report, null, 2));
console.log(`\n${passed}/${results.length} PASS  → download/verify-task98-report.json`);
await browser.close();
process.exit(passed === results.length ? 0 : 1);
