// t116 fixture reset — restore the lodge wall to the canonical 100-room state
// after failed/partial verify runs: max=100, default levels, every room free,
// no stray Verify bills.
import { DatabaseSync } from "node:sqlite";

const db = new DatabaseSync("/home/z/my-project/db/custom.db");

db.prepare(`DELETE FROM Setting WHERE key = 'lodgeMaxRooms'`).run();
db.prepare(
  `INSERT OR REPLACE INTO Setting (key, value, updatedAt) VALUES ('lodgeLevels', ?, datetime('now'))`,
).run(
  JSON.stringify([
    { from: 1, to: 40, rate: 2499, name: "BASIC" },
    { from: 41, to: 80, rate: 2999, name: "STANDARD" },
    { from: 81, to: 100, rate: 3999, name: "LUXURY" },
  ]),
);
db.prepare(`DELETE FROM Room WHERE number > 100`).run();
db.prepare(`UPDATE Room SET status = 'avl', guestName = NULL, guestPhone = NULL, checkInAt = NULL`).run();
const bills = db.prepare(`SELECT id, number FROM LodgeBill WHERE guestName = 'Verify T116'`).all();
for (const b of bills) db.prepare(`DELETE FROM LodgeBill WHERE id = ?`).run(b.id);
const left = db.prepare(`SELECT COUNT(*) AS n FROM Room WHERE number <= 100`).get();
console.log(`reset ok — rooms <=100: ${left.n}, stray bills removed: ${bills.length}`);
db.close();
