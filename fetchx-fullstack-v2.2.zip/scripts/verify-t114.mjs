// t114 verify — (1) ENTER EXPENSES restored on the owner's Expenses page
// (business toggle + 3 add forms; a UI entry round-trips to the DB),
// (2) STATION EXPENSES still present on BOTH reception desks (never-remove
// guard), (3) attendance: stage → SUBMIT ATTENDANCE → exact toast
// "Attendance registered successfully ✅", persisted for the test date.
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
import fs from "node:fs";
const { chromium } = pw;

const BASE = "http://localhost:3000";
const OWNER = { name: "Imperial", role: "owner", email: "spiceowner@gmail.com" };
const REST = { name: "Imperial", role: "reception_restaurant", email: "spicerestaurant@gmail.com" };
const LODGE = { name: "Imperial", role: "reception_lodge", email: "spicelodge@gmail.com" };

let pass = 0, fail = 0;
const ok = (cond, name) => {
  if (cond) { pass++; console.log("  ✓", name); }
  else { fail++; console.log("  ✗ FAIL:", name); }
};

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
page.on("pageerror", (e) => console.log("PAGEERROR:", String(e).slice(0, 150)));

const login = async (u) => {
  await page.goto(BASE, { waitUntil: "domcontentloaded" });
  await page.evaluate((x) => localStorage.setItem("fx-auth", JSON.stringify(x)), u);
  await page.goto(BASE, { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(2500);
};

/* ── 1 · OWNER — ENTER EXPENSES restored ─────────────────────────────────── */
console.log("1 · owner expenses: ENTER EXPENSES restored");
await login(OWNER);
await page.getByRole("button", { name: "Expenses" }).first().click();
await page.waitForTimeout(2200);
ok((await page.locator('[data-testid="exp-entry"]').count()) === 1, "ENTER EXPENSES card renders");
ok((await page.getByText("ENTER EXPENSES FOR").count()) >= 1, "ENTER EXPENSES FOR label present");
ok((await page.locator('[data-testid="exp-entry-book-rest"]').count()) === 1, "RESTAURANT toggle present");
ok((await page.locator('[data-testid="exp-entry-book-lodge"]').count()) === 1, "LODGE toggle present");
for (const k of ["raw_material", "upgrade", "maintenance"]) {
  ok((await page.locator(`[data-testid="exp-add-${k}"]`).count()) === 1, `ADD form for ${k}`);
}
ok((await page.locator('[data-testid="exp-cost-split"]').count()) === 1, "t99 donut still here (nothing removed)");

// round-trip: enter a raw-material spend for the LODGE book, expect the toast
await page.locator('[data-testid="exp-entry-book-lodge"]').click();
await page.waitForTimeout(300);
await page.locator('[data-testid="exp-entry-label-raw_material"]').fill("verify-t114 test ghee");
await page.locator('[data-testid="exp-entry-amount-raw_material"]').fill("1234");
await page.locator('[data-testid="exp-add-raw_material"]').click();
await page.waitForTimeout(1600);
const toastText = await page.evaluate(() => document.body.innerText);
ok(/Raw material cost of ₹1,234 recorded/.test(toastText), "entry toast fired");
ok(/LODGE book/.test(toastText), "toast names the LODGE book");
// the new row must appear in the ledger
const ledgerHasRow = await page.evaluate(() => document.body.innerText.includes("verify-t114 test ghee"));
ok(ledgerHasRow, "new entry visible in the ledger");
// cleanup: DELETE the test row via API
const del = await page.evaluate(async () => {
  const rows = await fetch("/api/expenses?kind=raw_material&limit=400").then((x) => x.json());
  const mine = (Array.isArray(rows) ? rows : []).find((r) => r.label === "verify-t114 test ghee");
  if (!mine) return false;
  const res = await fetch(`/api/expenses?id=${encodeURIComponent(mine.id)}`, { method: "DELETE" });
  return res.ok;
});
ok(del, "test expense row cleaned up");

/* ── 2 · BOTH RECEPTIONS — STATION EXPENSES still in place (guard) ───────── */
console.log("2 · receptions: station expense entry still in place");
await login(REST);
ok((await page.locator('[data-testid="station-expenses-rest"]').count()) === 1, "restaurant desk: STATION EXPENSES card");
ok((await page.locator('[data-testid="stn-add-rest"]').count()) === 1, "restaurant desk: ADD EXPENSE button");
await login(LODGE);
ok((await page.locator('[data-testid="station-expenses-lodge"]').count()) === 1, "lodge desk: STATION EXPENSES card");
ok((await page.locator('[data-testid="stn-add-lodge"]').count()) === 1, "lodge desk: ADD EXPENSE button");

/* ── 3 · ATTENDANCE — stage → SUBMIT → exact toast ───────────────────────── */
console.log("3 · attendance: submit button + exact toast");
const TEST_DATE = "2001-01-01"; // far-past date — invisible in daily use, cleaned at the end
await page.getByRole("button", { name: "Attendance" }).first().click();
await page.waitForTimeout(2000);
ok((await page.locator('[data-testid="attendance-submit"]').count()) === 1, "SUBMIT ATTENDANCE button renders");
const disabledBefore = await page.locator('[data-testid="attendance-submit"]').isDisabled();
ok(disabledBefore, "submit disabled with nothing staged");
// ALL PRESENT stages the whole register
await page.locator('[data-testid="attendance-all-present"]').click();
await page.waitForTimeout(300);
const presentChips = await page.locator('[data-testid^="attendance-status-"]:has-text("PRESENT")').count();
ok(presentChips >= 1, `ALL PRESENT staged (${presentChips} chips)`);
// set the far-past date, roster reloads from server (empty), stage again
await page.locator('[data-testid="attendance-date"]').fill(TEST_DATE);
await page.waitForTimeout(1500);
await page.locator('[data-testid="attendance-all-present"]').click();
await page.waitForTimeout(300);
const submitEnabled = await page.locator('[data-testid="attendance-submit"]').isEnabled();
ok(submitEnabled, "submit enabled once marks are staged");
await page.locator('[data-testid="attendance-submit"]').click();
await page.waitForTimeout(1800);
const bodyText = await page.evaluate(() => document.body.innerText);
ok(bodyText.includes("Attendance registered successfully ✅"), "exact toast: 'Attendance registered successfully ✅'");
// persisted?
const saved = await page.evaluate(async (d) => {
  const rows = await fetch(`/api/attendance?date=${d}`).then((x) => x.json());
  return Array.isArray(rows) ? rows.length : 0;
}, TEST_DATE);
ok(saved >= 1, `marks persisted for ${TEST_DATE} (${saved} rows)`);
await page.screenshot({ path: "download/verify-t114-attendance-submit.png", fullPage: false });
await page.screenshot({ path: "download/verify-t114-expenses-entry.png", fullPage: false });

await browser.close();

/* cleanup: drop the 2001-01-01 attendance rows via direct SQLite */
try {
  const { DatabaseSync } = await import("node:sqlite");
  const db = new DatabaseSync("/home/z/my-project/db/custom.db");
  const r = db.prepare("DELETE FROM Attendance WHERE date = ?").run(TEST_DATE);
  db.close();
  console.log(`cleanup: removed ${r.changes} attendance rows for ${TEST_DATE}`);
} catch (e) {
  console.log("cleanup skipped:", String(e).slice(0, 120));
}

fs.writeFileSync("/home/z/my-project/tool-results/t114-result.json", JSON.stringify({ pass, fail }));
console.log(`\nRESULT: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
