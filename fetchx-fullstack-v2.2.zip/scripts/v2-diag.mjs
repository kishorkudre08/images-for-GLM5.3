/* V2 lock diagnostic — what does http://localhost:3000 actually render at 390px? */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;

const browser = await chromium.launch();
const ctx = await browser.newContext({
  viewport: { width: 390, height: 844 },
  deviceScaleFactor: 2,
  isMobile: true,
  hasTouch: true,
});
const page = await ctx.newPage();
const errors = [];
const failed = [];
page.on("pageerror", (e) => errors.push("pageerror: " + String(e).slice(0, 300)));
page.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text().slice(0, 300)); });
page.on("requestfailed", (r) => failed.push(r.url() + " → " + (r.failure()?.errorText || "?")));
page.on("response", (r) => { if (r.status() >= 400) failed.push(r.url() + " → HTTP " + r.status()); });

const OWNER = { name: "Imperial", role: "owner", email: "spiceowner@gmail.com" };
await page.addInitScript((u) => localStorage.setItem("fx-auth", JSON.stringify(u)), OWNER);

let gotoErr = "none";
await page
  .goto("http://127.0.0.1:3000", { waitUntil: "networkidle", timeout: 30000 })
  .catch((e) => { gotoErr = String(e).slice(0, 300); });
await page.waitForTimeout(3000);

console.log("GOTO ERROR:", gotoErr);
console.log("PAGE URL:", page.url());

const title = await page.title().catch(() => "<no title>");
const bodyText = (await page.locator("body").innerText().catch(() => "<no body>")).slice(0, 400);
const hasNav = await page.locator('nav[aria-label="Main mobile"]').count();
const authRaw = await page
  .evaluate(() => localStorage.getItem("fx-auth"))
  .catch((e) => "<denied: " + String(e).slice(0, 120) + ">");

await page.screenshot({ path: "/home/z/my-project/download/v2-diag-phone.png" });

console.log("TITLE:", title);
console.log("NAV COUNT:", hasNav);
console.log("LS fx-auth:", authRaw);
console.log("HTTP/REQ FAILURES:", failed.length ? failed.join("\n  ") : "none");
console.log("PAGE/CONSOLE ERRORS:", errors.length ? errors.join("\n  ") : "none");
console.log("BODY TEXT (first 400):", bodyText.replace(/\n+/g, " | "));

await browser.close();
