/* Task 96 verification — TASK PULSE · HOUSEKEEPING:
 * dashboard section, front-desk strip, live turnaround loop
 * (checkin → checkout opens a task → maintenance-done closes it),
 * role gating, regressions. Screenshots → download/verify-task96-*.png
 * Run: node scripts/verify-t96.mjs
 */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
import fs from "node:fs";

const BASE = "http://localhost:3000";
const SHOT = "/home/z/my-project/download";
let idx = 0;
const results = [];
const note = (name, pass, detail = "") => {
  results.push({ name, pass, detail });
  console.log(`${pass ? "PASS" : "FAIL"}  ${name}${detail ? `  — ${detail}` : ""}`);
};
const shot = async (page, name) => {
  idx += 1;
  await page.screenshot({ path: `${SHOT}/verify-task96-${String(idx).padStart(2, "0")}-${name}.png` }).catch(() => {});
};

const api = async (path, opts) => (await fetch(`${BASE}${path}`, opts)).json();
const post = (body) => api("/api/lodge", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push("pageerror: " + String(e).slice(0, 200)));
page.on("console", (m) => {
  const t = m.text();
  if (m.type() === "error" && !/40[134]/.test(t)) errors.push(t.slice(0, 200));
});

const login = async (auth) => {
  await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
  await page.evaluate((u) => localStorage.setItem("fx-auth", JSON.stringify(u)), auth);
  await page.reload({ waitUntil: "domcontentloaded" });
  await page.waitForTimeout(3000);
};

/* ══ 1 · OWNER — dashboard ALL scope: the section is there ══ */
await login({ name: "Imperial", role: "owner", email: "spiceowner@gmail.com" });

const apiTasks = await api("/api/dashboard?range=today").then((d) => d.tasks);
note("API exposes tasks block", !!apiTasks && typeof apiTasks.createdToday === "number");

const section = page.getByTestId("task-pulse");
note("TASK PULSE section visible (ALL scope)", await section.isVisible().catch(() => false));
const secTxt = (await section.textContent().catch(() => "")) || "";
note("heading reads TASK PULSE · HOUSEKEEPING", secTxt.includes("TASK PULSE · HOUSEKEEPING"));
note("sub-line explains the model", secTxt.includes("ONE CHECKOUT = ONE TURNAROUND"));

const complTxt = (await page.getByTestId("task-completion-pct").textContent().catch(() => "")) || "";
note("completion % matches API", complTxt.trim() === `${apiTasks.completionRatePct}%`, `ui=${complTxt} api=${apiTasks.completionRatePct}%`);
const readyTxt = (await page.getByTestId("task-readiness-pct").textContent().catch(() => "")) || "";
note("readiness % matches API", readyTxt.trim() === `${apiTasks.readinessPct}%`, `ui=${readyTxt} api=${apiTasks.readinessPct}%`);

const cardCount = await page.locator('[data-testid^="task-card-"]').count();
const expectCards = apiTasks.tasks.length + apiTasks.carryoverRooms.length;
note("task cards = today's + carry-over", cardCount === expectCards, `ui=${cardCount} api=${expectCards}`);

const openChips = await page.locator('[data-testid^="task-state-"]:has-text("OPEN")').count();
const doneChips = await page.locator('[data-testid^="task-state-"]:has-text("DONE")').count();
const expectOpen = apiTasks.tasks.filter((t) => t.status === "in-progress").length + apiTasks.carryover;
note("OPEN chips match API", openChips === expectOpen, `ui=${openChips} api=${expectOpen}`);
note("DONE chips match API", doneChips === apiTasks.completedToday, `ui=${doneChips} api=${apiTasks.completedToday}`);

await page.getByTestId("task-pulse").scrollIntoViewIfNeeded().catch(() => {});
await page.waitForTimeout(600);
await shot(page, "task-pulse-section");

/* ══ 2 · expand a card — the body and its action ══ */
const firstCard = page.locator('[data-testid^="task-card-"]').first();
const firstId = (await firstCard.getAttribute("data-testid")) || "";
const firstRoom = firstId.replace("task-card-", "");
await firstCard.locator(".task-top").click();
await page.waitForTimeout(500);
const bodyVisible = await page.getByTestId(`task-body-${firstRoom}`).isVisible().catch(() => false);
note("card expands (body visible)", bodyVisible, `room=${firstRoom}`);
const expandedTxt = (await page.getByTestId(`task-body-${firstRoom}`).textContent().catch(() => "")) || "";
note("body carries the completion affordance or closed note", /MAINTENANCE DONE|ready for check-in/.test(expandedTxt));
await shot(page, "task-card-expanded");

/* ══ 3 · the full live loop — checkout opens a task, maintenance-done closes it ══ */
const lodge = await api("/api/lodge");
const todayRooms = new Set(apiTasks.tasks.map((t) => t.room));
const avlRoom = lodge.rooms.find((r) => r.status === "avl" && !todayRooms.has(r.number) && r.number > 80)?.number;
note("picked a clean avl room for the loop", Number.isInteger(avlRoom), `room=${avlRoom}`);

const ci = await post({ action: "checkin", room: avlRoom, name: "Verify Turnaround", phone: "9900000001" });
note("check-in ok", ci.ok === true);
const co = await post({ action: "checkout", room: avlRoom });
note("checkout ok (stay bill printed)", co.ok === true && !!co.bill);

// the dashboard caches briefly — poll the API until the task shows up
let openTask = null;
let tOpen = null;
for (let i = 0; i < 20 && !openTask; i++) {
  await page.waitForTimeout(500);
  tOpen = await api("/api/dashboard?range=today").then((d) => d.tasks);
  openTask = tOpen.tasks.find((t) => t.room === avlRoom) ?? null;
}
note("checkout opened a task (API)", !!openTask && openTask.status === "in-progress", `bill L-${openTask?.billNumber}`);
note("task stats moved (created+1, pending+1)", !!openTask && tOpen.createdToday === apiTasks.createdToday + 1 && tOpen.pendingNow === apiTasks.pendingNow + 1);

await page.reload({ waitUntil: "domcontentloaded" });
await page.waitForTimeout(3000);
const newCard = page.getByTestId(`task-card-${avlRoom}`);
note("new OPEN card renders on the dashboard", await newCard.isVisible().catch(() => false));
const newState = ((await page.getByTestId(`task-state-${avlRoom}`).textContent().catch(() => "")) || "").trim();
note("new card state reads OPEN", newState.includes("OPEN"), newState);
await newCard.scrollIntoViewIfNeeded().catch(() => {});
await shot(page, "task-open-after-checkout");

await page.getByTestId(`task-card-${avlRoom}`).locator(".task-top").click();
await page.waitForTimeout(450);
await page.getByTestId(`task-complete-${avlRoom}`).click();
// the click triggers maintenance-done + immediate reload — wait for the flip
let flipped = false;
for (let i = 0; i < 40 && !flipped; i++) {
  await page.waitForTimeout(500);
  const s = ((await page.getByTestId(`task-state-${avlRoom}`).textContent().catch(() => "")) || "").trim();
  flipped = s.includes("DONE");
}
note("UI complete flips the card to DONE", flipped);
const after = await api("/api/lodge").then((d) => d.rooms.find((r) => r.number === avlRoom));
note("room is back on the green wall (avl)", after?.status === "avl", after?.status);
const tDone = await api("/api/dashboard?range=today").then((d) => d.tasks);
note("completion % reflects the closure", tDone.completedToday === apiTasks.completedToday + 1 && tDone.completionRatePct === Math.round(((apiTasks.completedToday + 1) / (apiTasks.createdToday + 1)) * 100), `${tDone.completionRatePct}%`);
await page.getByTestId(`task-card-${avlRoom}`).scrollIntoViewIfNeeded().catch(() => {});
await shot(page, "task-done-after-complete");

/* cleanup — tear the verify bill so the books return to the pre-test state */
const undoNum = openTask?.billNumber ?? null;
if (undoNum) {
  const undo = await post({ action: "bill-undo", number: undoNum });
  const billsAfter = await api("/api/lodge").then((d) => d.bills.find((b) => b.number === undoNum));
  note("verify bill undone (books restored)", undo.ok === true && !billsAfter, `L-${undoNum}`);
} else {
  note("verify bill undone (books restored)", false, "no bill number captured");
}

/* ══ 4 · regressions on the same screen ══ */
const bw = page.getByTestId("business-wide-heading");
note("business-wide heading still present", await bw.isVisible().catch(() => false));
const orderOk = await page.evaluate(() => {
  const a = document.querySelector('[data-testid="room-status-dash"]');
  const t = document.querySelector('[data-testid="task-pulse"]');
  const b = document.querySelector('[data-testid="books-heading"]');
  return !!(a && t && b && a.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_FOLLOWING && t.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING);
});
note("flow order: wall → TASK PULSE → two-books", !!orderOk);

/* ══ 5 · RECEPTION_LODGE — the front-desk strip ══ */
await login({ name: "Imperial", role: "reception_lodge", email: "spicelodge@gmail.com" });
const desk = page.getByTestId("desk-task-pulse");
note("front-desk TASK PULSE strip visible", await desk.isVisible().catch(() => false));
const deskTxt = (await desk.textContent().catch(() => "")) || "";
note("desk chips: OPEN / CLOSED TODAY / READY", /OPEN/.test(deskTxt) && /CLOSED TODAY/.test(deskTxt) && /READY/.test(deskTxt));
const deskOpen = ((await page.getByTestId("desk-task-open").textContent().catch(() => "")) || "").trim();
note("desk OPEN count matches API", deskOpen === `${tDone.pendingNow} OPEN`, deskOpen);
const deskCards = await page.locator('[data-testid^="desk-task-card-"]').count();
note("desk lists only open work", deskCards === tDone.pendingNow, `ui=${deskCards} api=${tDone.pendingNow}`);
const hasComplete = await page.locator('[data-testid^="desk-task-complete-"]').first().isVisible().catch(() => false);
note("desk card exposes the complete action", hasComplete);
await desk.scrollIntoViewIfNeeded().catch(() => {});
await page.waitForTimeout(500);
await shot(page, "desk-task-pulse");

/* ══ 6 · RECEPTION_RESTAURANT — no housekeeping station ══ */
await login({ name: "Imperial", role: "reception_restaurant", email: "spicerestaurant@gmail.com" });
note("restaurant reception has no task section", !(await page.getByTestId("desk-task-pulse").isVisible().catch(() => false)));
await shot(page, "restaurant-reception-no-task");

/* ══ 7 · console cleanliness ══ */
note("zero console/page errors (401/400/403 filtered)", errors.length === 0, errors.slice(0, 2).join(" | "));

await browser.close();

const report = { task: "96", when: new Date().toISOString(), pass: results.filter((r) => r.pass).length, total: results.length, results };
fs.writeFileSync(`${SHOT}/verify-task96-report.json`, JSON.stringify(report, null, 2));
console.log(`\n══════ TASK 96 VERIFY: ${report.pass}/${report.total} PASS ══════`);
process.exit(report.pass === report.total ? 0 : 1);
