import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 667, height: 375 }, isMobile: true, hasTouch: true });
const errs = [];
page.on("pageerror", (e) => errs.push(e.message));
page.on("console", (m) => { if (m.type() === "error") errs.push("console: " + m.text().slice(0, 120)); });
await page.addInitScript(() => localStorage.setItem("fx-auth", JSON.stringify({ name: "Imperial", role: "owner", email: "spiceowner@gmail.com" })));
await page.goto("http://localhost:3000", { waitUntil: "networkidle", timeout: 30000 }).catch((e) => errs.push("goto: " + e.message));
await page.waitForTimeout(2500);
const state = await page.evaluate(() => ({
  nav: !!document.querySelector('nav[aria-label="Main mobile"]'),
  gate: !!document.querySelector(".fx-rotate-gate") && getComputedStyle(document.querySelector(".fx-rotate-gate")).display !== "none",
  bodyText: document.body.innerText.slice(0, 150).replace(/\n/g, " | "),
}));
console.log("STATE:", JSON.stringify(state));
console.log("ERRORS:", errs.length ? errs.slice(0, 5) : "none");
await page.screenshot({ path: "/home/z/my-project/download/verify-t108-debug-phone.png" });
await browser.close();
