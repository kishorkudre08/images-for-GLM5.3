/* Tasks 91+92 verification — business-wide heading, books heading,
 * room-hours lodge wall donut displaying ROOMS with slices summing to 100.
 * Screenshots → download/verify-task9x-*.png
 * Run: node scripts/verify-t91-92.mjs
 */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
import fs from "node:fs";

const BASE = "http://localhost:3000";
const SHOT = "/home/z/my-project/download";
let idx = 0;
const results = [];
const note = (name, pass, detail = "") => {
  results.push({ name, pass, detail });
  console.log(`${pass ? "PASS" : "FAIL"}  ${name}${detail ? `  — ${detail}` : ""}`);
};
const shot = async (page, name) => {
  idx += 1;
  await page.screenshot({ path: `${SHOT}/verify-task9x-${String(idx).padStart(2, "0")}-${name}.png` }).catch(() => {});
};

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push("pageerror: " + String(e).slice(0, 200)));
page.on("console", (m) => {
  const t = m.text();
  if (m.type() === "error" && !/40[134]/.test(t)) errors.push(t.slice(0, 200));
});

/* owner session */
await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
await page.evaluate(() =>
  localStorage.setItem("fx-auth", JSON.stringify({ name: "Imperial", role: "OWNER", email: "spiceowner@gmail.com" })),
);
await page.reload({ waitUntil: "domcontentloaded" });
await page.waitForTimeout(2600);

/* ── 1 · headings on ALL scope ── */
const bwHead = page.getByTestId("business-wide-heading");
const booksHead = page.getByTestId("books-heading");
note("business-wide heading visible", await bwHead.isVisible().catch(() => false));
note("business-wide text", (await bwHead.textContent().catch(() => "") || "").includes("BUSINESS-WIDE ANALYTICS"));
note("books heading visible", await booksHead.isVisible().catch(() => false));
note("books heading text", (await booksHead.textContent().catch(() => "") || "").includes("RESTAURANT AND LODGE"));
const orderOk = await page.evaluate(() => {
  const a = document.querySelector('[data-testid="business-wide-heading"]');
  const b = document.querySelector('[data-testid="books-heading"]');
  return !!(a && b && a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING);
});
note("business-wide sits ABOVE books heading (analytics first)", !!orderOk);
await page.locator('[data-testid="business-wide-heading"]').scrollIntoViewIfNeeded().catch(() => {});
await shot(page, "business-wide-heading");

/* ── 2 · wall donut in rooms, sum = 100 (TODAY) ── */
const donut = page.getByTestId("room-status-donut-dash");
note("wall donut card visible", await donut.isVisible().catch(() => false));
const sumOf = (prefix) =>
  page.evaluate((p) => {
    const rows = document.querySelectorAll(`[data-testid^="${p}-"]`);
    let sum = 0;
    rows.forEach((r) => (sum += parseFloat(r.getAttribute("data-amt") || "0")));
    return { sum: Math.round(sum * 10) / 10, n: rows.length };
  }, prefix);
const s0 = await sumOf("lroomdash");
note("three slices present", s0.n === 3, `n=${s0.n}`);
note("slices sum to 100 rooms (TODAY)", Math.abs(s0.sum - 100) < 0.001, `sum=${s0.sum}`);
const legendTxt = (await donut.textContent().catch(() => "")) || "";
note("legend displays ROOMS unit", /ROOMS/.test(legendTxt));
note("centre label has window", /ROOMS · TODAY/.test(legendTxt));
const dashSub = (await page.getByTestId("room-status-dash").textContent().catch(() => "")) || "";
note("dashboard sub-label mentions 24 room-hours", /24 room-hours/i.test(dashSub));
await page.getByTestId("room-status-dash").scrollIntoViewIfNeeded().catch(() => {});
await shot(page, "wall-donut-today");

/* ── 3 · every time window keeps the sum at 100 ── */
for (const [tab, tag] of [["7 DAYS", "7d"], ["1 MONTH", "1m"], ["3 MONTHS", "3m"], ["1 YEAR", "1y"]]) {
  await page.getByRole("tab", { name: tab, exact: true }).click();
  await page.waitForTimeout(2200);
  const s = await sumOf("lroomdash");
  const txt = (await donut.textContent().catch(() => "")) || "";
  note(`sum = 100 rooms (${tag})`, Math.abs(s.sum - 100) < 0.001, `sum=${s.sum}`);
  /* t99 — the ring-hole centre label is compacted ("ROOMS · 7 DAYS"); the
     card header above the donut still carries the full "LAST 7 DAYS" form */
  note(`legend shows window label (${tag})`, txt.includes(tag === "7d" ? "7 DAYS" : tag === "1m" ? "30 DAYS" : tag === "3m" ? "3 MONTHS" : "12 MONTHS"));
  if (tag === "1m") {
    await page.getByTestId("room-status-dash").scrollIntoViewIfNeeded().catch(() => {});
    await shot(page, "wall-donut-1m");
  }
}

/* ── 4 · scope behaviour ── */
await page.getByRole("tab", { name: "TODAY", exact: true }).click();
await page.waitForTimeout(1800);
await page.getByRole("tab", { name: "LODGE", exact: true }).click(); // scope chip inside BUSINESS VIEW
await page.waitForTimeout(1500);
note("LODGE scope keeps the wall donut", await page.getByTestId("room-status-donut-dash").isVisible().catch(() => false));
const sL = await sumOf("lroomdash");
note("slices sum to 100 rooms (LODGE scope)", Math.abs(sL.sum - 100) < 0.001, `sum=${sL.sum}`);
await page.getByTestId("room-status-dash").scrollIntoViewIfNeeded().catch(() => {});
await shot(page, "wall-donut-lodge-scope");
note("business-wide heading hidden outside ALL scope", !(await bwHead.isVisible().catch(() => false)));
await page.getByRole("tab", { name: "ALL BUSINESS", exact: true }).click();
await page.waitForTimeout(1200);

/* ── 5 · lodge front desk live snapshot (counts mode) ── */
await page.getByRole("button", { name: /Lodge Front Desk/ }).first().click();
await page.waitForTimeout(2400);
const fd = page.getByTestId("room-status-donut");
note("front desk snapshot donut visible", await fd.isVisible().catch(() => false));
const sF = await sumOf("lroom");
note("front desk slices sum to the 100-room wall", Math.abs(sF.sum - 100) < 0.001, `sum=${sF.sum}`);
await page.getByTestId("lodge-wall-snapshot").scrollIntoViewIfNeeded().catch(() => {});
await shot(page, "front-desk-snapshot-donut");

/* ── 6 · regressions ── */
note("no page/console errors", errors.length === 0, errors.slice(0, 3).join(" | "));

const failed = results.filter((r) => !r.pass);
console.log(`\n${results.length - failed.length}/${results.length} PASS`);
fs.writeFileSync(`${SHOT}/verify-task9x-report.json`, JSON.stringify(results, null, 2));
await browser.close();
process.exit(failed.length ? 1 : 0);
