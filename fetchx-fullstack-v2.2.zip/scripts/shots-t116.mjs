// t116 evidence shots — owner monitor wall + occupied room card + wait-for-free state
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
await page.goto("http://localhost:3000", { waitUntil: "domcontentloaded" });
await page.evaluate(() =>
  localStorage.setItem("fx-auth", JSON.stringify({ name: "Imperial", role: "owner", email: "spiceowner@gmail.com" })),
);
await page.goto("http://localhost:3000", { waitUntil: "domcontentloaded" });
await page.waitForTimeout(2500);

// fixture: a guest in room 3 for the resident card
await page.request.post("http://localhost:3000/api/lodge", {
  data: { action: "checkin", room: 3, name: "Ramesh Kulkarni", phone: "9822011234" },
});
await page.reload({ waitUntil: "domcontentloaded" });
await page.waitForTimeout(2600);
await page.getByRole("button", { name: "Lodge Front Desk" }).first().click();
await page.waitForTimeout(2400);
await page.screenshot({ path: "/home/z/my-project/download/verify-t116-owner-monitor-wall.png" });

// occupied room card
await page.locator('button[aria-label^="Room 3 —"]').first().click();
await page.waitForTimeout(700);
await page.screenshot({ path: "/home/z/my-project/download/verify-t116-owner-room-resident.png" });
await page.keyboard.press("Escape");
await page.waitForTimeout(400);

// max-rooms wait state: ask to shrink below the occupied band edge
await page.locator('[data-testid="max-rooms-input"]').fill("96");
await page.waitForTimeout(600);
await page.locator('[data-testid="max-rooms-box"]').scrollIntoViewIfNeeded();
await page.waitForTimeout(400);
await page.screenshot({ path: "/home/z/my-project/download/verify-t116-max-rooms-wait.png" });

// cleanup — tear the fixture stay
await page.request.post("http://localhost:3000/api/lodge", { data: { action: "checkout", room: 3 } });
await page.request.post("http://localhost:3000/api/lodge", { data: { action: "maintenance-done", room: 3 } });
await browser.close();
console.log("t116 evidence shots saved");
