// t117 evidence shots — owner menu bills, owner lodge bills, dashboard donuts, stacked login
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
const BASE = "http://localhost:3000";
const OWNER = { name: "Imperial", role: "owner", email: "spiceowner@gmail.com" };
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

await page.goto(BASE, { waitUntil: "domcontentloaded" });
await page.evaluate((x) => localStorage.setItem("fx-auth", JSON.stringify(x)), OWNER);
await page.goto(BASE, { waitUntil: "domcontentloaded" });
await page.waitForTimeout(2500);

await page.getByRole("button", { name: "Menu Manager" }).first().click();
await page.waitForTimeout(2000);
await page.locator('[data-testid="menu-latest-bills"]').scrollIntoViewIfNeeded();
await page.waitForTimeout(400);
await page.screenshot({ path: "download/verify-t117-menu-bills.png" });

await page.getByRole("button", { name: "Lodge Front Desk" }).first().click();
await page.waitForTimeout(2200);
await page.locator('[data-testid="lodge-latest-bills"]').scrollIntoViewIfNeeded();
await page.waitForTimeout(400);
await page.screenshot({ path: "download/verify-t117-lodge-bills.png" });

await page.getByRole("button", { name: "Live Dashboard" }).first().click();
await page.waitForTimeout(2500);
await page.locator('[data-testid="rev-split-donut-rest"]').scrollIntoViewIfNeeded();
await page.waitForTimeout(500);
await page.screenshot({ path: "download/verify-t117-revenue-split-donuts.png" });

await page.evaluate(() => localStorage.removeItem("fx-auth"));
await page.goto(BASE, { waitUntil: "domcontentloaded" });
await page.waitForTimeout(1500);
await page.getByRole("button", { name: /sign in/i }).first().click().catch(() => {});
await page.waitForTimeout(1000);
await page.screenshot({ path: "download/verify-t117-login-stacked.png" });

console.log("evidence shots saved");
await browser.close();
