#!/usr/bin/env python3
"""t98 — rearrange the ALL-scope live dashboard:
   1. donuts (REVENUE SPLIT + LODGE WALL) move ABOVE the line graph
   2. RESTAURANT AND LODGE heading drops between donuts and line graph
   3. horizontal task-rate bars section lands just above TEAM
"""
import re, sys

P = "src/components/dashboard-view.tsx"
s = open(P).read()

# ── capture the donuts block + the books-heading that follows it ─────────────
donut_start = '          <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">\n            <div className="fx-card p-5" data-testid="revenue-split-card">'
head_end = '          {/* t91 — the two-book divider the owner asked to keep */}\n          <div className="books-head fx-pop-in" data-testid="books-heading">\n            <span className="bh-t">{ic(UtensilsCrossed, "h-5 w-5")}RESTAURANT AND LODGE</span>\n            <span className="bh-sub">TWO BOOKS · SIDE BY SIDE</span>\n            <span className="hline" />\n          </div>'

i0 = s.index(donut_start)
i1 = s.index(head_end) + len(head_end)
block = s[i0:i1]
# strip the block (plus one following blank line) from its old spot
s = s[:i0] + s[i1:].lstrip("\n").__class__() + s[i1:].lstrip("\n") if False else s[:i0] + s[i1 + 1:]  # drop the \n right after
# tidy: collapse the leftover blank gap where the block used to be
s = s.replace("\n\n\n          <section>\n            <SecHead icon={ic(Wallet)} title={`REVENUE BREAKDOWN", "\n\n          <section>\n            <SecHead icon={ic(Wallet)} title={`REVENUE BREAKDOWN")

# ── insert donuts + heading ABOVE the line graph (REVENUE TREND section) ────
trend_marker = "          <section>\n            <SecHead icon={ic(Banknote)} title={`REVENUE TREND"
if trend_marker not in s:
    sys.exit("REVENUE TREND marker not found")
inject = (
    block
    + "\n\n          {/* t98 — the two-book divider now sits between the donuts and the line graph */}\n"
)
s = s.replace(trend_marker, inject + trend_marker, 1)

# ── horizontal task-rate bars just above TEAM ────────────────────────────────
team_marker = "          <section>\n            <SecHead icon={ic(Users)} title={`TEAM"
if team_marker not in s:
    sys.exit("TEAM marker not found")
tasks_section = '''          {/* t98 — the tasks board's double bars, now horizontal, side by side above the team */}
          <section>
            <SecHead icon={ic(ListChecks)} title={`TASKS · COMPLETION & BUDGET · ${period}`} sub="HORIZONTAL RATE BARS · PER BOOK · FROM THE TASKS BOARD" />
            <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
              <TaskRateCard book="rest" title="RESTAURANT" stats={restTaskStats} />
              <TaskRateCard book="lodge" title="LODGE" stats={lodgeTaskStats} />
            </div>
          </section>

'''
s = s.replace(team_marker, tasks_section + team_marker, 1)

open(P, "w").write(s)
print("rearranged OK")
