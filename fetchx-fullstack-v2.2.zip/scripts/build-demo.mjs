/* Task 100 — build download/fetchx-live-demo.html (v2):
 *   · 27 states re-captured from the t99 app (tasks + settings added)
 *   · CSS purged against used class tokens + minified      (702KB → ~200KB)
 *   · @font-face kept only for latin/latin-ext/fallback     (~480KB → ~150KB)
 *   · state DOM gzip-packed, decoded in-browser via DecompressionStream
 *   · mobile: runtime wires the captured bottom nav + injected settings gear
 * Run: node scripts/build-demo.mjs
 */
import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";

const CAP = "/home/z/my-project/scripts/capture";
const OUT = "/home/z/my-project/download/fetchx-live-demo.html";

/* ── 1 · app.css — subset @font-face, inline kept fonts ── */
let css = fs.readFileSync(`${CAP}/app.css`, "utf8");
const fontMap = {};
for (const f of fs.readdirSync(CAP).filter((n) => n.startsWith("font-"))) {
  fontMap[f.slice(5)] = `${CAP}/${f}`;
}
const KEEP_RANGE = /(0000-00FF|0-FF|0100-02BA|100-2BA|20B9)/i;
let droppedFaces = 0, keptFaces = 0, fontBytes = 0;
for (const m of [...css.matchAll(/@font-face\s*{[^}]*}/g)].reverse()) {
  const block = m[0];
  const fam = (/font-family:\s*([^;]+);/.exec(block)?.[1] || "").trim().replace(/^['"]|['"]$/g, "");
  const ur = (/unicode-range:\s*([^;]+);/.exec(block)?.[1] || "").trim();
  const url = /url\((["']?)([^)"']+\.woff2)\1\)/.exec(block);
  const isNextjsDev = fam.startsWith("__nextjs");
  const rangeKeep = !ur || KEEP_RANGE.test(ur);
  if (isNextjsDev || !rangeKeep) {
    css = css.slice(0, m.index) + css.slice(m.index + block.length);
    droppedFaces++;
    continue;
  }
  keptFaces++;
  if (url) {
    const base = path.basename(url[2]);
    if (fontMap[base]) {
      const b64 = fs.readFileSync(fontMap[base]).toString("base64");
      fontBytes += b64.length;
      css = css.replace(url[0], `url(data:font/woff2;base64,${b64})`);
    }
  }
}
console.log(`fonts: kept ${keptFaces} faces (dropped ${droppedFaces})`);

/* ── 2 · states ── */
const STATES = [
  "landing", "landing-modal",
  "dash-all-today", "dash-all-7d", "dash-all-1m", "dash-all-3m", "dash-all-1y",
  "dash-rest-today", "dash-rest-7d", "dash-rest-1m", "dash-rest-3m", "dash-rest-1y",
  "dash-lodge-today", "dash-lodge-7d", "dash-lodge-1m", "dash-lodge-3m", "dash-lodge-1y",
  "menu", "expenses", "tasks", "lodge", "manage", "settings", "ai-open",
  "reception-pos", "reception-attendance", "reception-lodge", "reception-attendance-lodge",
];
const stateHtml = {};
let totalHtml = 0;
for (const id of STATES) {
  let html = fs.readFileSync(`${CAP}/state-${id}.html`, "utf8");
  // entrance classes were pre-strip targets: below-fold .fx-rise would stay
  // invisible in a static file — freeze everything visible
  html = html.replace(/\s*fx-rise/g, "").replace(/\s*fx-in\b/g, "");
  // minify: collapse runs of whitespace between tags to one space
  html = html.replace(/>\s+</g, "> <").replace(/\s{2,}/g, " ");
  totalHtml += html.length;
  stateHtml[id] = html;
}
console.log(`${STATES.length} states, ${(totalHtml / 1048576).toFixed(2)}MB of captured DOM`);

/* ── 2b · inline the theme-preview screenshots as data URIs ──
   the settings state carries <img src="/theme-previews/…"> — a single-file
   demo has no server, so every reference becomes an inlined jpeg. t104 — the
   demo uses the SHRUNK copies (theme-previews-demo, 640px) to stay
   download-safe; the full-stack app keeps the full-size ones. */
const PREV_FULL = "/home/z/my-project/public/theme-previews";
const PREV_SMALL = "/home/z/my-project/public/theme-previews-demo";
const smallFiles = fs.existsSync(PREV_SMALL) ? fs.readdirSync(PREV_SMALL).filter((f) => f.endsWith(".jpg")) : [];
const PREV_DIR = smallFiles.length >= 40 ? PREV_SMALL : PREV_FULL;
if (PREV_DIR === PREV_FULL) console.warn("WARN: shrunk preview set missing — inlining FULL-size shots");
const prevCache = new Map();
let prevMissing = 0;
for (const id of Object.keys(stateHtml)) {
  stateHtml[id] = stateHtml[id].replace(/src="\/theme-previews\/([^"]+)"/g, (m, file) => {
    if (!prevCache.has(file)) {
      const p = `${PREV_DIR}/${file}`;
      if (!fs.existsSync(p)) { prevMissing++; return m; }
      prevCache.set(file, `data:image/jpeg;base64,${fs.readFileSync(p).toString("base64")}`);
    }
    return `src="${prevCache.get(file)}"`;
  });
}
if (prevMissing) console.warn(`WARN: ${prevMissing} theme previews missing from ${PREV_DIR}`);
console.log(`theme previews inlined: ${prevCache.size}`);

/* ── 3 · CSS purge against every class token the demo can ever render ── */
const used = new Set();
const harvest = (html) => {
  for (const m of html.matchAll(/class="([^"]*)"/g)) {
    for (const tk of m[1].split(/\s+/)) if (tk) used.add(tk);
  }
};
for (const id of STATES) harvest(stateHtml[id]);
const runtime = fs.readFileSync(`${CAP}/demo-runtime.js`, "utf8");
for (const m of runtime.matchAll(/"([^"]*)"/g)) {
  for (const tk of m[1].split(/\s+/)) if (/^[A-Za-z0-9_][\w.\\/:#[\]()%$,-]*$/.test(tk) && /[A-Za-z]/.test(tk)) used.add(tk);
}
["on", "open", "hot", "fin", "in", "done"].forEach((c) => used.add(c));
console.log(`used class tokens: ${used.size}`);

const KEEP_SEL = /^(html|body|\*|:root|::?[-a-z]+(?:\([^)]*\))?|@?\[.*\]|#fx-[\w-]+|from|to|\d+%|[\w-]+)$/i;
function selectorKeeps(sel) {
  const parts = sel.split(",");
  return parts.some((raw) => {
    const s = raw.trim();
    if (!s || KEEP_SEL.test(s)) return true;
    if (!/\./.test(s)) return true; // element / attribute selectors stay
    // every class token in the selector must be used somewhere
    const toks = s.match(/\.[A-Za-z0-9_\\/:#[\]().%$-]+/g) || [];
    if (!toks.length) return true;
    return toks.every((t) => {
      const cls = t.slice(1).replace(/\\(.)/g, "$1");
      if (cls.includes("[")) return true; // arbitrary variants — keep
      return used.has(cls);
    });
  });
}
let itCount = 0;
function purgeCss(src) {
  let out = "", i = 0;
  const n = src.length;
  const readBalanced = () => {
    // i must sit on '{' — returns inner text, leaves i past the matching '}'
    let depth = 0;
    i++;
    const start = i;
    while (i < n) {
      if (src[i] === "{") depth++;
      else if (src[i] === "}") {
        if (!depth) { const inner = src.slice(start, i); i++; return inner; }
        depth--;
      }
      i++;
    }
    return src.slice(start);
  };
  while (i < n) {
    if (src.startsWith("/*", i)) { const e = src.indexOf("*/", i); i = e < 0 ? n : e + 2; continue; }
    const brace = src.indexOf("{", i);
    if (brace < 0) { out += src.slice(i); break; }
    const pre = src.slice(i, brace).trim();
    i = brace; // park ON the '{' — readBalanced consumes it and leaves i past '}'
    const inner = readBalanced();
    if (globalThis.__FX_PROBE !== false && itCount < 3) {
      itCount++;
      console.log(`probe ${itCount}: pre=${JSON.stringify(pre.slice(0, 40))} innerHead=${JSON.stringify(inner.slice(0, 60))}`);
    }
    if (pre.startsWith("@")) {
      const at = pre.split(/\s/)[0].toLowerCase();
      const flat = inner.replace(/\s+/g, " ").trim();
      if (at === "@media" || at === "@supports") {
        const processed = purgeCss(inner);
        if (processed.replace(/[{}\s]/g, "")) out += pre + "{" + processed + "}";
      } else if (at === "@font-face" || at.startsWith("@keyframes")) {
        out += pre + "{" + flat + "}";
      } else {
        out += pre + "{" + flat + "}";
      }
    } else if (selectorKeeps(pre)) {
      out += pre + "{" + inner.replace(/\s+/g, " ").trim() + "}";
    }
  }
  return out;
}
css = purgeCss(css);
css = css.replace(/\s*!important/g, "!important").replace(/;\}/g, "}");
console.log(`fonts: kept ${keptFaces} faces (dropped ${droppedFaces}), css purged → ${(css.length / 1024).toFixed(0)}KB`);

/* ── 4 · AI seed ── */
const aiSeed = JSON.parse(fs.readFileSync(`${CAP}/ai-seed.json`, "utf8"));

/* ── 5 · gzip states → base64 map ── */
const packed = {};
for (const id of STATES) {
  packed[id] = zlib.gzipSync(Buffer.from(stateHtml[id], "utf8"), { level: 9 }).toString("base64");
}
const packedJson = JSON.stringify(packed);
console.log(`states packed: ${(packedJson.length / 1024).toFixed(0)}KB base64-gzip`);

/* ── 6 · hydrator (runs before the runtime) ── */
const hydrator = `
(async function () {
  var el = document.getElementById("fx-states");
  var map = JSON.parse(el.textContent || el.innerText);
  var box = document.getElementById("fx-templates");
  var ids = Object.keys(map);
  for (var i = 0; i < ids.length; i++) {
    var b64 = map[ids[i]];
    var bin = atob(b64);
    var bytes = new Uint8Array(bin.length);
    for (var j = 0; j < bin.length; j++) bytes[j] = bin.charCodeAt(j);
    var text = "";
    try {
      var stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("gzip"));
      text = await new Response(stream).text();
    } catch (e) {
      document.getElementById("fx-stage").innerHTML =
        '<div style="padding:40px;font-family:monospace;color:#b00020">This browser lacks DecompressionStream — please use a current Chrome, Edge, Safari or Firefox.</div>';
      return;
    }
    var tpl = document.createElement("template");
    tpl.setAttribute("data-state", ids[i]);
    tpl.innerHTML = text;
    box.appendChild(tpl);
  }
  el.remove();
  if (window.FX_START) window.FX_START();
})();`;

/* ── 7 · glue css ── */
const glue = `
/* demo glue */
#fx-stage { min-height: 100vh; }
#fx-stage:empty::after {
  content: "LOADING FETCH-X DEMO…"; display: grid; place-items: center; min-height: 100vh;
  font: 800 12px/1 ui-monospace, monospace; letter-spacing: .18em; color: var(--fx-muted);
}
#fx-templates { display: none; }
#fx-toast {
  position: fixed; left: 50%; bottom: 26px; transform: translate(-50%, 16px);
  z-index: 9999; max-width: min(560px, calc(100vw - 32px));
  background: var(--fx-ink); color: var(--fx-page);
  font-size: 11px; font-weight: 800; letter-spacing: .1em; text-align: center;
  padding: 11px 18px; border-radius: 99px;
  box-shadow: 3px 4px 0 0 rgba(28,24,64,.35);
  opacity: 0; pointer-events: none; transition: all .25s cubic-bezier(.22,1,.36,1);
}
#fx-toast.on { opacity: 1; transform: translate(-50%, 0); }
.fx-thinking::after { content: ""; display: inline-block; width: 1.2em; text-align: left; animation: fxdots 1.2s steps(4) infinite; }
@keyframes fxdots { 0% { content: ""; } 25% { content: "."; } 50% { content: ".."; } 75% { content: "..."; } }
.fx-sub-hint { margin-top: 4px; font-size: 10px; font-weight: 800; letter-spacing: .08em; color: var(--fx-muted); text-align: center; }
`;

/* ── 8 · assemble ── */
const favicon = `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Crect width='24' height='24' rx='6' fill='%235b4fe9'/%3E%3Cpath d='M19 10l-7-3.5L5 10l7 3.5L19 10z' fill='none' stroke='white' stroke-width='1.6' stroke-linejoin='round'/%3E%3Cpath d='M8.5 12.5v3c0 1 1.6 1.8 3.5 1.8s3.5-.8 3.5-1.8v-3' fill='none' stroke='white' stroke-width='1.6' stroke-linecap='round'/%3E%3C/svg%3E`;
const html = `<!DOCTYPE html>
<html lang="en" class="light" style="color-scheme: light;">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Fetch-X — Live Product Demo</title>
<meta name="description" content="Fetch-X — the restaurant OS that watches the bills so nobody has to. Interactive offline demo: three accounts, live dashboard, POS, lodge wall and the AI copilot. Phone friendly." />
<link rel="icon" href="${favicon}" />
<style>
${css}
</style>
<style>
${glue}
</style>
</head>
<body class="inter_fe8b9d92-module__LINzvG__variable geist_mono_8d43a2aa-module__8Li5zG__variable antialiased bg-background text-foreground font-sans">
<div id="fx-stage"></div>
<div id="fx-templates"></div>
<script type="application/json" id="fx-states">${packedJson}</script>
<script>
${hydrator}
</script>
<script>
var AI_SEED = ${JSON.stringify(aiSeed)};
${runtime}
</script>
</body>
</html>`;
fs.writeFileSync(OUT, html);
console.log(`WROTE ${OUT} — ${(fs.statSync(OUT).size / 1048576).toFixed(2)}MB`);
