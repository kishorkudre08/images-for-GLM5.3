/* t115 verification — "cross check the recent version and update the current full stack":
 *   1. the OWNER carries the MENU MANAGER — no POS Billing nav item at all
 *      (reception is there for billing — said 1000 times)
 *   2. the Menu Manager has NO billing dock, NO bills feed, NO expense entry
 *      (the non-needed expenses — told 100 times)
 *   3. deleting a dish or a category opens a WARNING that stays LOCKED for
 *      10 seconds before the delete can fire
 *   4. the OPTION to delete a category exists again (guard: no live dishes)
 *   5. the restaurant reception keeps POS Billing exactly as it was
 * Run: node scripts/verify-t115.mjs
 */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
import fs from "node:fs";

const BASE = "http://localhost:3000";
const SHOT = "/home/z/my-project/download";
let idx = 0;
const results = [];
const note = (name, pass, detail = "") => {
  results.push({ name, pass, detail });
  console.log(`${pass ? "PASS" : "FAIL"}  ${name}${detail ? `  — ${detail}` : ""}`);
};
const shot = async (page, name) => {
  idx += 1;
  await page.screenshot({ path: `${SHOT}/verify-t115-${String(idx).padStart(2, "0")}-${name}.png` }).catch(() => {});
};
const login = async (page, email, role, name = "Imperial") => {
  await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
  await page.evaluate(
    ([e, r, n]) => localStorage.setItem("fx-auth", JSON.stringify({ name: n, role: r, email: e })),
    [email, role, name],
  );
  await page.reload({ waitUntil: "domcontentloaded" });
  await page.waitForTimeout(2600);
};

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1920, height: 1000 } });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push("pageerror: " + String(e).slice(0, 200)));
page.on("console", (m) => {
  const t = m.text();
  if (m.type() === "error" && !/40[1349]/.test(t)) errors.push(t.slice(0, 200));
});

/* ── 0 · idempotency — sweep leftovers from any earlier crashed run ── */
{
  const ds = await page.request.get(`${BASE}/api/menu`).then((r) => r.json()).catch(() => []);
  for (const d of Array.isArray(ds) ? ds : []) {
    if (d.active && ["QA Lock Dish", "QA Temp Dish"].includes(d.name))
      await page.request.delete(`${BASE}/api/menu/${d.id}`).catch(() => {});
  }
  const cs = await page.request.get(`${BASE}/api/categories`).then((r) => r.json()).catch(() => []);
  for (const c of Array.isArray(cs) ? cs : []) {
    if (c.name === "QA Temp Section") await page.request.delete(`${BASE}/api/categories?id=${c.id}`).catch(() => {});
  }
}

/* ── 1 · owner session — the nav itself ── */
await login(page, "spiceowner@gmail.com", "owner");
await page.waitForTimeout(1500);

const navState = await page.evaluate(() => {
  const btns = [...document.querySelectorAll("aside nav button")].map((b) => (b.textContent || "").trim());
  return {
    labels: btns,
    hasMenu: btns.some((t) => t.includes("Menu Manager")),
    hasPos: btns.some((t) => t.includes("POS Billing")),
  };
});
note("owner nav: Menu Manager present", navState.hasMenu, navState.labels.join(" | "));
note("owner nav: NO POS Billing for the owner (reception bills — said 1000 times)", !navState.hasPos);
await shot(page, "owner-nav");

/* ── 2 · the Menu Manager view — menu control only ── */
await page.evaluate(() => {
  const btns = [...document.querySelectorAll("nav button")];
  btns.find((b) => b.textContent.includes("Menu Manager"))?.click();
});
await page.waitForTimeout(2200);
const menu = await page.evaluate(() => ({
  band: [...document.querySelectorAll(".fx-label")].some((el) => el.textContent.includes("MENU MANAGER")),
  title: !!document.querySelector("h1") && document.querySelector("h1").textContent.includes("Menu Manager"),
  noDock: ![...document.querySelectorAll("button")].some((b) => /GENERATE BILL/.test(b.textContent || "")),
  noFeed: !document.body.textContent.includes("RESTAURANT BILLS · TAP TO REPRINT"),
  noExpenses: !document.querySelector('[data-testid="station-expenses-rest"]'),
  addCat: !!document.querySelector('[data-testid="pos-add-category"]'),
  blocks: document.querySelectorAll('[data-testid^="pos-add-dish-"]').length,
  catDeleteBtns: document.querySelectorAll('[data-testid^="pos-cat-delete-"]').length,
  footnote10s: document.body.textContent.includes("LOCKED for 10 seconds"),
}));
note("menu manager: TIER 03 · MENU MANAGER band + title", menu.band && menu.title);
note("menu manager: NO billing dock (no GENERATE BILL)", menu.noDock);
note("menu manager: NO restaurant bills feed", menu.noFeed);
note("menu manager: NO expense entry (the non-needed expenses — gone)", menu.noExpenses);
note("menu manager: ADD CATEGORY on the row", menu.addCat);
note("menu manager: add-dish block in every section", menu.blocks >= 5, `${menu.blocks} blocks`);
note("menu manager: every section carries a DELETE option", menu.catDeleteBtns >= 5, `${menu.catDeleteBtns} delete buttons`);
note("menu manager: footnote declares the 10-second lock", menu.footnote10s);
await shot(page, "menu-manager");

/* ── 3 · dish delete — WARNING + 10s lock ── */
const made = await page.request
  .post(`${BASE}/api/menu`, { data: { name: "QA Lock Dish", price: 99, category: "Starters", veg: true } })
  .then((r) => r.json())
  .catch(() => null);
note("fixture: temp dish created via API", !!made?.id, made?.id ?? "none");
await page.reload({ waitUntil: "domcontentloaded" });
await page.waitForTimeout(1800);
await page.evaluate(() => {
  const btns = [...document.querySelectorAll("nav button")];
  btns.find((b) => b.textContent.includes("Menu Manager"))?.click();
});
await page.waitForTimeout(1600);
await page.locator('[data-testid="pos-dish-delete-qa-lock-dish"]').first().click();
await page.waitForTimeout(500);
const dw = await page.evaluate(() => {
  const dlg = document.querySelector('[data-testid="pos-delete-dish-modal"]');
  const btn = document.querySelector('[data-testid="pos-delete-dish-confirm"]');
  return {
    up: !!dlg,
    asks: !!dlg && dlg.textContent.includes("Remove “QA Lock Dish” from the menu?"),
    warns: !!dlg && dlg.textContent.includes("THIS CANNOT BE UNDONE"),
    label: btn ? btn.textContent.trim() : "",
    disabled: btn ? btn.hasAttribute("disabled") : true,
    keepIt: !!document.querySelector('[data-testid="pos-delete-dish-cancel"]'),
  };
});
note("dish delete: WARNING dialog opens, names the dish", dw.up && dw.asks);
note("dish delete: warning strip present", dw.warns);
note("dish delete: KEEP IT escape hatch", dw.keepIt);
note("dish delete: confirm is LOCKED (disabled) with a countdown", dw.disabled && /LOCKED · \d+s/.test(dw.label), dw.label);
await shot(page, "dish-warning-locked");
await page.waitForTimeout(10600);
const dw2 = await page.evaluate(() => {
  const btn = document.querySelector('[data-testid="pos-delete-dish-confirm"]');
  return { label: btn ? btn.textContent.trim() : "", disabled: btn ? btn.hasAttribute("disabled") : true };
});
note("dish delete: after 10s the delete UNLOCKS", !dw2.disabled && /YES, DELETE/.test(dw2.label), dw2.label);
await page.getByTestId("pos-delete-dish-confirm").click();
await page.waitForTimeout(1500);
const dishGone = await page.evaluate(() => !document.querySelector('[data-testid="pos-dish-owner-qa-lock-dish"]'));
const dishToast = await page.evaluate(() => document.body.textContent.includes("removed from the menu"));
note("dish delete: unlocked delete removes the dish + toast", dishGone && dishToast);
await shot(page, "dish-deleted");

/* ── 4 · category delete — the OPTION is back, guarded ── */
const cat = await page.request
  .post(`${BASE}/api/categories`, { data: { name: "QA Temp Section" } })
  .then((r) => r.json())
  .catch(() => null);
note("fixture: temp section created via API", !!cat?.id, cat?.id ?? "none");
await page.request
  .post(`${BASE}/api/menu`, { data: { name: "QA Temp Dish", price: 50, category: "QA Temp Section", veg: true } })
  .then((r) => r.json())
  .catch(() => null);
await page.reload({ waitUntil: "domcontentloaded" });
await page.waitForTimeout(1800);
await page.evaluate(() => {
  const btns = [...document.querySelectorAll("nav button")];
  btns.find((b) => b.textContent.includes("Menu Manager"))?.click();
});
await page.waitForTimeout(1600);
await page.locator('[data-testid="pos-cat-delete-qa-temp-section"]').first().click();
await page.waitForTimeout(500);
const cw = await page.evaluate(() => {
  const dlg = document.querySelector('[data-testid="pos-delete-cat-modal"]');
  return {
    up: !!dlg,
    guarded: !!dlg && dlg.textContent.includes("still has 1 live dish"),
    label: (document.querySelector('[data-testid="pos-delete-cat-confirm"]') || {}).textContent?.trim() ?? "",
  };
});
note("category delete: WARNING dialog opens for the section", cw.up);
note("category delete: the guard is explained up front (1 live dish)", cw.guarded);
/* KEEP IT — no need to burn 10s on the blocked path */
await page.getByTestId("pos-delete-cat-cancel").click();
await page.waitForTimeout(400);

/* soft-remove the dish via API, then delete the section through the UI */
const cats = await page.request.get(`${BASE}/api/categories`).then((r) => r.json()).catch(() => []);
const secId = (Array.isArray(cats) ? cats : []).find((c) => c.name === "QA Temp Section")?.id;
const allDishes = await page.request.get(`${BASE}/api/menu`).then((r) => r.json()).catch(() => []);
const tmpDish = (Array.isArray(allDishes) ? allDishes : []).find((d) => d.name === "QA Temp Dish" && d.active);
if (tmpDish) await page.request.delete(`${BASE}/api/menu/${tmpDish.id}`).catch(() => {});
await page.reload({ waitUntil: "domcontentloaded" });
await page.waitForTimeout(1800);
await page.evaluate(() => {
  const btns = [...document.querySelectorAll("nav button")];
  btns.find((b) => b.textContent.includes("Menu Manager"))?.click();
});
await page.waitForTimeout(1600);
const stillThere = await page.evaluate(() => !!document.querySelector('[data-testid="pos-cat-delete-qa-temp-section"]'));
note("category delete: empty section still offers the delete option", stillThere);
if (stillThere && secId) {
  await page.locator('[data-testid="pos-cat-delete-qa-temp-section"]').first().click();
  await page.waitForTimeout(500);
  await page.waitForTimeout(10600); // the 10s lock
  await page.getByTestId("pos-delete-cat-confirm").click();
  await page.waitForTimeout(1500);
  const secGone = await page.evaluate(() => !document.querySelector('[data-testid="pos-cat-delete-qa-temp-section"]'));
  const secToast = await page.evaluate(() => document.body.textContent.includes("deleted"));
  note("category delete: unlocked delete removes the section (+purge toast)", secGone && secToast);
} else {
  note("category delete: unlocked delete removes the section (+purge toast)", false, "section or id missing");
}
await shot(page, "section-deleted");

/* ── 5 · the restaurant reception keeps POS Billing exactly as it was ── */
await login(page, "spicerestaurant@gmail.com", "reception_restaurant");
await page.waitForTimeout(2000);
const rest = await page.evaluate(() => ({
  hasPos: [...document.querySelectorAll("aside nav button")].some((b) => (b.textContent || "").includes("POS Billing")),
  noMenu: ![...document.querySelectorAll("aside nav button")].some((b) => (b.textContent || "").includes("Menu Manager")),
  dock: [...document.querySelectorAll("button")].some((b) => /GENERATE BILL/.test(b.textContent || "")),
  feed: document.body.textContent.includes("RESTAURANT BILLS · TAP TO REPRINT"),
  stn: !!document.querySelector('[data-testid="station-expenses-rest"]'),
  noMenuControls: !document.querySelector('[data-testid="pos-add-category"]'),
  noDel: !document.querySelector('[data-testid^="pos-cat-delete-"]'),
}));
note("reception: POS Billing nav stays (no Menu Manager here)", rest.hasPos && rest.noMenu, JSON.stringify(rest));
note("reception: billing dock + bills feed intact", rest.dock && rest.feed);
note("reception: own station expense entry intact", rest.stn);
note("reception: still no menu controls", rest.noMenuControls && rest.noDel);
await shot(page, "reception-pos");

/* ── 6 · owner phone bar — Menu Manager, no POS ── */
await page.setViewportSize({ width: 667, height: 375 });
await login(page, "spiceowner@gmail.com", "owner");
await page.waitForTimeout(1800);
const bar = await page.evaluate(() => {
  const el = document.querySelector('nav[aria-label="Main mobile"]');
  return el ? [...el.querySelectorAll("button")].map((b) => b.getAttribute("aria-label")) : [];
});
note("owner phone bar: Menu Manager replaces POS Billing", bar.includes("Menu Manager") && !bar.includes("POS Billing"), bar.join(" | "));
await shot(page, "owner-phone-bar");

/* ── 7 · console ── */
note("zero console/page errors", errors.length === 0, errors.slice(0, 3).join(" | "));

/* ── report ── */
const passed = results.filter((r) => r.pass).length;
const report = { task: "t115", passed, total: results.length, results, errors };
fs.writeFileSync(`${SHOT}/verify-t115-report.json`, JSON.stringify(report, null, 2));
console.log(`\n${passed}/${results.length} PASS  → download/verify-t115-report.json`);
await browser.close();
process.exit(passed === results.length ? 0 : 1);
