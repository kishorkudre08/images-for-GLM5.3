/* t96 demo warm-up — create real, plausible today-activity so the TASK PULSE
 * section is alive in the captured demo: one OPEN turnaround (room 12) and
 * one DONE turnaround (room 13). The 3 carry-over rooms (35/54/56) stay as-is.
 * Run: node scripts/demo-warmup.mjs
 */
const BASE = "http://localhost:3000";
const post = async (body) => {
  const r = await fetch(`${BASE}/api/lodge`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  return { status: r.status, ...(await r.json()) };
};
const get = (p) => fetch(`${BASE}${p}`).then((r) => r.json());

const lodge = await get("/api/lodge");
const pick = (n) => {
  const r = lodge.rooms.find((x) => x.number === n);
  if (!r) throw new Error(`room ${n} missing`);
  if (r.status !== "avl") throw new Error(`room ${n} not avl (${r.status})`);
  return n;
};

/* 1 · the OPEN task — guest checked out this morning, room still amber */
const roomOpen = pick(12);
console.log("checkin", roomOpen, await post({ action: "checkin", room: roomOpen, name: "Anitha Prabhu", phone: "9845012345" }));
const co1 = await post({ action: "checkout", room: roomOpen });
console.log("checkout", roomOpen, co1.ok, "bill L-" + co1.bill?.number);

/* 2 · the DONE task — checked out and already turned around */
const roomDone = pick(13);
console.log("checkin", roomDone, await post({ action: "checkin", room: roomDone, name: "Ravi Chandran", phone: "9845012346" }));
const co2 = await post({ action: "checkout", room: roomDone });
console.log("checkout", roomDone, co2.ok, "bill L-" + co2.bill?.number);
console.log("maintenance-done", roomDone, await post({ action: "maintenance-done", room: roomDone }));

const t = await get("/api/dashboard?range=today").then((d) => d.tasks);
console.log("TASKS:", JSON.stringify({ createdToday: t.createdToday, completedToday: t.completedToday, completionRatePct: t.completionRatePct, pendingNow: t.pendingNow, carryover: t.carryover, roomsReady: t.roomsReady, readinessPct: t.readinessPct }, null, 2));
console.log("open tasks:", t.tasks.filter((x) => x.status === "in-progress").map((x) => `room ${x.room} L-${x.billNumber}`));
