#!/usr/bin/env python3
"""t103 — inject per-theme tinted background tokens into every
html[data-fx-theme] block in globals.css (light + dark). The combo's own
lighter colour becomes the light-mode page; its darker colour the dark-mode
page — never white, never black."""
import re

PATH = "/home/z/my-project/src/app/globals.css"
src = open(PATH).read()

# page, surf, line, lav, ink, muted, hard — per theme, light then dark
BG = {
  "dragonfruit": {
    "light": dict(page="#f7e4f1", surf="#fcebf5", line="#e9c9de", lav="#efd3e6", ink="#4a1040", muted="#a4799a", hard="#8e1454"),
    "dark":  dict(page="#31123a", surf="#3c1846", line="#562664", lav="#482052", ink="#f8e6f3", muted="#b58cae", hard="#1d0a23"),
  },
  "lime": {
    "light": dict(page="#eaf4d8", surf="#f3f9e6", line="#d3e5b4", lav="#dfecc4", ink="#1f3308", muted="#7d8a67", hard="#3f5c0a"),
    "dark":  dict(page="#1c2712", surf="#243119", line="#35482a", lav="#2c3c20", ink="#eef6dc", muted="#9fac90", hard="#0f160a"),
  },
  "emerald": {
    "light": dict(page="#eff3d9", surf="#f7f8e6", line="#d9e0b8", lav="#e4e9c6", ink="#0c2f22", muted="#7f8a70", hard="#0a5138"),
    "dark":  dict(page="#0c2a1d", surf="#123427", line="#1f4a38", lav="#17402f", ink="#e8f2e0", muted="#90a894", hard="#061a12"),
  },
  "iris": {
    "light": dict(page="#faf0cb", surf="#fdf7de", line="#ecdfa8", lav="#f2e6b4", ink="#2f2404", muted="#96895f", hard="#8f6c05"),
    "dark":  dict(page="#221e4d", surf="#2b2660", line="#3e3780", lav="#322c68", ink="#faf0c8", muted="#a29dc8", hard="#15123a"),
  },
  "blaze": {
    "light": dict(page="#f7ecd6", surf="#fcf4e2", line="#ead9b4", lav="#f0e2c2", ink="#3a1c05", muted="#a08f70", hard="#9a3c06"),
    "dark":  dict(page="#2f1a0c", surf="#3a2212", line="#54321c", lav="#452917", ink="#f9ecd4", muted="#b39c7e", hard="#1c0f06"),
  },
  "neon": {
    "light": dict(page="#e4f5e4", surf="#eefaf0", line="#c4e4c9", lav="#d5ecd9", ink="#0a2913", muted="#6f8a76", hard="#127a3c"),
    "dark":  dict(page="#161d18", surf="#1e2822", line="#2e3b32", lav="#253028", ink="#e2f3e5", muted="#93a89a", hard="#0b0f0c"),
  },
  "cherry": {
    "light": dict(page="#f9e7e7", surf="#fceeee", line="#eccdcd", lav="#f2d8d8", ink="#3d0d16", muted="#a07c80", hard="#8f1030"),
    "dark":  dict(page="#2c0e17", surf="#38131f", line="#501e2d", lav="#421723", ink="#f9e5e8", muted="#b18e94", hard="#19060c"),
  },
  "azure": {
    "light": dict(page="#e2effa", surf="#ecf5fc", line="#c4dcec", lav="#d0e5f4", ink="#0a2440", muted="#6f8ba0", hard="#075a8c"),
    "dark":  dict(page="#0d1e3c", surf="#13284c", line="#1f3a68", lav="#182f57", ink="#e2eefb", muted="#8ba3c4", hard="#071228"),
  },
  "cyanreef": {
    "light": dict(page="#e0f3f5", surf="#ebf8f9", line="#c2e2e6", lav="#cfeaed", ink="#072a33", muted="#6f919a", hard="#066a80"),
    "dark":  dict(page="#0b232b", surf="#112e38", line="#1c4452", lav="#163844", ink="#e0f3f6", muted="#8facb5", hard="#051419"),
  },
}

ORDER = ["page", "surf", "line", "lav", "ink", "muted", "hard"]


def block_text(t, mode):
    d = BG[t][mode]
    return "\n  ".join(f"--fx-{k}: {d[k]};" for k in ORDER)


count = 0
for theme, modes in BG.items():
    for mode in ("light", "dark"):
        if mode == "light":
            sel = f'html[data-fx-theme="{theme}"] {{'
        else:
            sel = f'html.dark[data-fx-theme="{theme}"] {{'
        idx = src.find(sel)
        assert idx >= 0, f"selector missing: {sel}"
        # find end of this block
        end = src.find("}", idx)
        injection = "\n  /* t103 — the combo's own lighter/darker colour is the page */\n  " + block_text(theme, mode) + "\n"
        src = src[:end] + injection + src[end:]
        count += 1

open(PATH, "w").write(src)
print(f"injected background tokens into {count} theme blocks")
