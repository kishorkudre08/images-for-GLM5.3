// t118 verify — the six new things, end to end:
//   (1) NET PROFIT joins the two REVENUE SPLIT donuts (the ring now accounts
//       for every rupee: costs first, the owner's take last),
//   (2) the lodge looks ALIVE — guests in-house, maintenance rooms, a fat
//       lodge cost book (the wall was left all-free by the t116 fixture),
//   (3) the floating AI button is OWNER-ONLY (gone from both receptions),
//   (4) the FLOATING TASK TRACKER is back on every screen in all three
//       accounts, with the SETTINGS on/off switch,
//   (5) BOTH receptions carry an EXPENSES side-panel item — their own book's
//       expenses page (3 types, naming, cost entry — the old one),
//   (6) nothing else moved: the desks keep their station expenses, the
//       counter keeps reprint/undo.
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;

const BASE = "http://localhost:3000";
const OWNER = { name: "Imperial", role: "owner", email: "spiceowner@gmail.com" };
const REST = { name: "Imperial", role: "reception_restaurant", email: "spicerestaurant@gmail.com" };
const LODGE = { name: "Imperial", role: "reception_lodge", email: "spicelodge@gmail.com" };

let pass = 0, fail = 0;
const ok = (cond, name) => {
  if (cond) { pass++; console.log("  ✓", name); }
  else { fail++; console.log("  ✗ FAIL:", name); }
};

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(String(e).slice(0, 150)));

const login = async (u) => {
  await page.goto(BASE, { waitUntil: "domcontentloaded" });
  await page.evaluate((x) => localStorage.setItem("fx-auth", JSON.stringify(x)), u);
  await page.goto(BASE, { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(2500);
};
const money = (s) => Number(String(s).replace(/[^\d.]/g, "")) || 0;

/* ── 1 · NET PROFIT slice in both REVENUE SPLIT donuts ───────────────────── */
console.log("1 · REVENUE SPLIT DONUTS — NET PROFIT");
await login(OWNER);
const donuts = await page.evaluate(() => {
  const grab = (t) => document.querySelector(`[data-testid="rev-split-donut-${t}"]`);
  const read = (t) => {
    const el = grab(t);
    if (!el) return null;
    const rows = [...el.querySelectorAll(".dl-row")].map((r) => r.textContent || "");
    const center = el.querySelector(".dc-v")?.textContent || "";
    return { rows, center, text: el.textContent || "" };
  };
  return { rest: read("rest"), lodge: read("lodge") };
});
ok(!!donuts.rest && !!donuts.lodge, "both split donuts render (ALL scope)");
for (const [k, d] of [["restaurant", donuts.rest], ["lodge", donuts.lodge]]) {
  if (!d) continue;
  const netRow = d.rows.find((r) => /NET PROFIT/.test(r));
  const lossNote = /AT A LOSS/.test(d.text);
  ok(!!netRow || lossNote, `${k} donut splits into costs + net profit${lossNote ? " (loss note — costs outweighed revenue in this window)" : " (legend: " + d.rows.length + " rows)"}`);
  const four = ["RAW MATERIALS", "UPGRADES", "MAINTENANCE", "EMPLOYEE SALARIES"].every((h) => d.text.includes(h));
  ok(four, `${k} donut keeps the four cost heads`);
  const sum = d.rows.reduce((s, r) => s + money(r), 0);
  const center = money(d.center);
  if (netRow) {
    ok(Math.abs(sum - center) <= 2, `${k} ring accounts for EVERY rupee (legend Σ ₹${sum.toLocaleString("en-IN")} ≈ centre ₹${center.toLocaleString("en-IN")})`);
    ok(money(netRow) > 0, `${k} net profit is positive (₹${money(netRow).toLocaleString("en-IN")})`);
  } else {
    ok(lossNote && sum > center, `${k} loss note matches (costs ₹${sum.toLocaleString("en-IN")} > revenue ₹${center.toLocaleString("en-IN")})`);
  }
}
/* REST + LODGE scopes carry the slice too */
await page.getByRole("tab", { name: "RESTAURANT" }).first().click().catch(() => {});
await page.waitForTimeout(2200);
ok(/NET PROFIT|AT A LOSS/.test((await page.locator('[data-testid="rev-split-donut-rest"]').textContent().catch(() => "")) || ""), "RESTAURANT scope — net profit on the ring (or the loss note)");
await page.getByRole("tab", { name: "LODGE" }).first().click().catch(() => {});
await page.waitForTimeout(2200);
ok(/NET PROFIT|AT A LOSS/.test((await page.locator('[data-testid="rev-split-donut-lodge"]').textContent().catch(() => "")) || ""), "LODGE scope — net profit on the ring (or the loss note)");

/* ── 2 · the lodge looks ALIVE ─────────────────────────────────────────────── */
console.log("2 · LODGE — IN-HOUSE GUESTS, MAINTENANCE, COST BOOK");
await page.getByRole("button", { name: "Lodge Front Desk" }).first().click();
await page.waitForTimeout(2500);
const wall = await page.evaluate(() => {
  const occ = [...document.querySelectorAll('button[aria-label$="— occupied"]')].length;
  const mnt = [...document.querySelectorAll('button[aria-label$="— under maintenance"]')].length;
  const free = [...document.querySelectorAll('button[aria-label$="— available"]')].length;
  return { occ, mnt, free };
});
ok(wall.occ >= 40, `wall shows guests in-house (${wall.occ} occupied rooms)`);
ok(wall.mnt >= 1, `wall shows maintenance rooms (${wall.mnt})`);
ok(wall.occ + wall.mnt + wall.free >= 100, `full wall renders (${wall.occ + wall.mnt + wall.free} rooms)`);
const filled = await page.evaluate(() => {
  const chip = [...document.querySelectorAll(".mut-chip")].map((c) => c.textContent || "").find((t) => /% FILLED/.test(t));
  const m = chip?.match(/(\d+)% FILLED/);
  return m ? Number(m[1]) : 0;
});
ok(filled >= 40, `wall chip says ${filled}% FILLED`);
/* the owner's tap-a-room dialog still shows the resident for an occupied room */
await page.locator('button[aria-label$="— occupied"]').first().click();
await page.waitForTimeout(700);
const resident = await page.evaluate(() => document.querySelector('[data-testid="owner-room-resident"]')?.textContent || "");
ok(/CHECKED IN|IN HOUSE|RESIDENT|ROOM/i.test(resident) && resident.length > 10, "occupied room card shows the resident");
await page.keyboard.press("Escape");
/* the lodge cost book is no longer a ghost — the LODGE band shows costs */
await page.getByRole("button", { name: "Live Dashboard" }).first().click();
await page.waitForTimeout(2500);
const lodgeCosts = await page.evaluate(() => {
  const numify = (s) => Number(String(s).replace(/[^\d.]/g, "")) || 0;
  const el = document.querySelector('[data-testid="rev-split-donut-lodge"]');
  const rows = [...(el?.querySelectorAll(".dl-row") || [])].map((r) => r.textContent || "");
  const raw = rows.find((r) => /RAW MATERIALS/.test(r));
  return { raw: raw ? numify(raw) : 0 };
});
ok(lodgeCosts.raw > 0, `lodge cost book alive — RAW MATERIALS ₹${lodgeCosts.raw.toLocaleString("en-IN")} in the ring`);

/* ── 3 · AI is owner-only ──────────────────────────────────────────────────── */
console.log("3 · AI — OWNER ONLY");
ok(await page.locator('[data-testid="ai-fab"]').isVisible().catch(() => false), "owner keeps the floating AI button");

/* ── 4 · the FLOATING TASK TRACKER — all three accounts + settings switch ── */
console.log("4 · FLOATING TASK TRACKER");
ok(await page.locator('[data-testid="task-fab"]').isVisible().catch(() => false), "tracker floats for the owner");
await page.locator('[data-testid="task-fab"]').click();
await page.waitForTimeout(800);
ok(await page.locator('[data-testid="task-tracker-panel"]').isVisible().catch(() => false), "tracker panel opens");
const headTxt = await page.locator('[data-testid="task-tracker-panel"]').textContent().catch(() => "");
ok(/BOTH BOOKS/.test(headTxt || ""), `owner tracker watches BOTH BOOKS ("${(headTxt || "").slice(0, 60)}…")`);
const trackerRows = await page.locator('[data-testid="task-tracker-row"]').count();
ok(trackerRows > 0, `tracker lists tasks (${trackerRows} rows)`);
await page.locator('[data-testid="task-tracker-open-board"]').click();
await page.waitForTimeout(1400);
ok((await page.getByRole("button", { name: "Tasks" }).first().getAttribute("aria-current")) === "page", "tracker jumps to the full Tasks board");
/* settings switch — hide, walk around, bring it back */
await page.getByRole("button", { name: /settings/i }).first().click();
await page.waitForTimeout(1200);
const sw = page.locator('[data-testid="task-fab-toggle"]');
ok((await sw.textContent().catch(() => "") || "").includes("SHOWING"), "settings switch says SHOWING");
await sw.click();
await page.waitForTimeout(400);
ok((await page.locator('[data-testid="task-fab"]').count()) === 0, "switch OFF — the floating tracker disappears (here)");
const stored = await page.evaluate(() => localStorage.getItem("fx-task-fab"));
ok(stored === "0", "switch persisted (fx-task-fab=0)");
await page.getByRole("button", { name: "Live Dashboard" }).first().click();
await page.waitForTimeout(1500);
ok((await page.locator('[data-testid="task-fab"]').count()) === 0, "tracker stays hidden on other screens");
await page.getByRole("button", { name: /settings/i }).first().click();
await page.waitForTimeout(1200);
await page.locator('[data-testid="task-fab-toggle"]').click();
await page.waitForTimeout(400);
ok((await page.locator('[data-testid="task-fab"]').count()) === 1, "switch ON — the tracker returns");
/* receptions: their own book, no AI */
await login(REST);
ok((await page.locator('[data-testid="ai-fab"]').count()) === 0, "restaurant reception has NO AI button");
ok(await page.locator('[data-testid="task-fab"]').isVisible().catch(() => false), "tracker floats for the restaurant reception");
await page.locator('[data-testid="task-fab"]').click();
await page.waitForTimeout(800);
const restHead = await page.locator('[data-testid="task-tracker-panel"]').textContent().catch(() => "");
ok(/RESTAURANT/.test(restHead || "") && !/BOTH BOOKS/.test(restHead || ""), "restaurant reception watches ITS book only");
await page.locator('button[aria-label="Collapse the floating task tracker"]').click();
await login(LODGE);
ok((await page.locator('[data-testid="ai-fab"]').count()) === 0, "lodge reception has NO AI button");
ok(await page.locator('[data-testid="task-fab"]').isVisible().catch(() => false), "tracker floats for the lodge reception");
await page.locator('[data-testid="task-fab"]').click();
await page.waitForTimeout(800);
const lodgeHead = await page.locator('[data-testid="task-tracker-panel"]').textContent().catch(() => "");
ok(/LODGE/.test(lodgeHead || "") && !/BOTH BOOKS/.test(lodgeHead || ""), "lodge reception watches ITS book only");
await page.locator('button[aria-label="Collapse the floating task tracker"]').click();

/* ── 5 · EXPENSES in both receptions' side panel ─────────────────────────── */
console.log("5 · RECEPTIONS — EXPENSES SIDE PANEL");
await login(REST);
ok(await page.getByRole("button", { name: "Expenses" }).first().isVisible().catch(() => false), "restaurant reception has an EXPENSES nav item");
await page.getByRole("button", { name: "Expenses" }).first().click();
await page.waitForTimeout(1800);
ok((await page.locator('[data-testid="exp-entry-book-rest"]').textContent().catch(() => "") || "").includes("THIS DESK"), "entry book locked: RESTAURANT · THIS DESK");
ok((await page.locator('[data-testid="exp-entry-book-lodge"]').count()) === 0, "no LODGE toggle for the restaurant desk");
const restForms = await page.evaluate(() =>
  ["raw_material", "upgrade", "maintenance"].every((k) =>
    document.querySelector(`[data-testid="exp-entry-label-${k}"]`) && document.querySelector(`[data-testid="exp-entry-amount-${k}"]`) && document.querySelector(`[data-testid="exp-add-${k}"]`),
  ),
);
ok(restForms, "3 types × (naming + cost + ADD) — the old entry section");
ok((await page.locator('[data-testid="exp-book-all"]').count()) === 0, "ledger has no book filter (it IS the restaurant book)");
/* add an entry end-to-end */
await page.locator('[data-testid="exp-entry-label-raw_material"]').fill("Morning tea stock");
await page.locator('[data-testid="exp-entry-amount-raw_material"]').fill("250");
await page.locator('[data-testid="exp-add-raw_material"]').click();
await page.waitForTimeout(1800);
const restToast = await page.evaluate(() => document.body.innerText);
ok(/Raw material cost of ₹250 recorded/.test(restToast), "entry toast fired");
ok(/RESTAURANT book/.test(restToast), "toast names the RESTAURANT book");
ok((await page.evaluate(() => (document.body.innerText || "").includes("Morning tea stock"))), "the new entry is in the ledger");
await login(LODGE);
ok(await page.getByRole("button", { name: "Expenses" }).first().isVisible().catch(() => false), "lodge reception has an EXPENSES nav item");
await page.getByRole("button", { name: "Expenses" }).first().click();
await page.waitForTimeout(1800);
ok((await page.locator('[data-testid="exp-entry-book-lodge"]').textContent().catch(() => "") || "").includes("THIS DESK"), "entry book locked: LODGE · THIS DESK");
ok((await page.locator('[data-testid="exp-entry-book-rest"]').count()) === 0, "no RESTAURANT toggle for the lodge desk");
await page.locator('[data-testid="exp-entry-label-maintenance"]').fill("Corridor light fix");
await page.locator('[data-testid="exp-entry-amount-maintenance"]').fill("300");
await page.locator('[data-testid="exp-add-maintenance"]').click();
await page.waitForTimeout(1800);
const lodgeToast = await page.evaluate(() => document.body.innerText);
ok(/Maintenance cost of ₹300 recorded/.test(lodgeToast) && /LODGE book/.test(lodgeToast), "lodge entry lands in the LODGE book");
ok((await page.evaluate(() => (document.body.innerText || "").includes("Corridor light fix"))), "the new entry is in the ledger");

/* ── 6 · hygiene ───────────────────────────────────────────────────────────── */
console.log("6 · HYGIENE");
ok(errors.length === 0, `zero page errors (${errors.length})`);
console.log(`\nRESULT: ${pass}/${pass + fail}`);
await browser.close();
process.exit(fail ? 1 : 0);
