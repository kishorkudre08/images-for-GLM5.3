/* Task 94 verification — t104 update: THREE accounts (the developer account
 * is gone entirely), modal login per role, role gating, restored motion layer.
 * Screenshots → download/verify-task94-*.png
 * Run: node scripts/verify-t94.mjs
 */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
import fs from "node:fs";

const BASE = "http://localhost:3000";
const SHOT = "/home/z/my-project/download";
let idx = 0;
const results = [];
const note = (name, pass, detail = "") => {
  results.push({ name, pass, detail });
  console.log(`${pass ? "PASS" : "FAIL"}  ${name}${detail ? `  — ${detail}` : ""}`);
};
const shot = async (page, name) => {
  idx += 1;
  await page.screenshot({ path: `${SHOT}/verify-task94-${String(idx).padStart(2, "0")}-${name}.png` }).catch(() => {});
};

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push("pageerror: " + String(e).slice(0, 200)));
page.on("console", (m) => {
  const t = m.text();
  if (m.type() === "error" && !/40[134]/.test(t)) errors.push(t.slice(0, 200));
});

/* form login through the modal */
async function loginViaModal(email, pass) {
  await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
  await page.getByRole("button", { name: "Sign In" }).first().click();
  await page.waitForTimeout(400);
  await page.locator("#lk-email").fill(email);
  await page.locator("#lk-pass").fill(pass);
  await page.getByRole("button", { name: /^Sign In$/ }).last().click();
  await page.waitForTimeout(2600);
}

/* ── 1 · storefront shows the three accounts — and ONLY them ── */
await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
await page.waitForTimeout(2000);
const body = (await page.textContent("body")) || "";
for (const t of ["OWNER", "RESTAURANT RECEPTION", "LODGE RECEPTION"]) {
  note(`landing lists ${t}`, body.includes(t));
}
note("developer account is gone from the landing", !body.includes("DEVELOPER") && !body.includes("spice1234"));
await page.evaluate(() => document.querySelector("#features")?.scrollIntoView());
await page.waitForTimeout(900);
await shot(page, "landing-3-accounts");

/* ── 2 · owner via modal login → full nav ── */
await loginViaModal("spiceowner@gmail.com", "spiceowner");
const navCount = await page.locator("aside nav button").count();
note("owner sees all 6 nav items (t97 added TASKS)", navCount === 6, `n=${navCount}`);
note("dashboard loaded", await page.getByTestId("books-heading").isVisible().catch(() => false));
note("no developer-view pill in sidebar", !((await page.textContent("aside")) || "").includes("DEVELOPER VIEW"));
await shot(page, "owner-dashboard");

/* ── 3 · sign out returns straight to the storefront ── */
await page.getByRole("button", { name: /sign out/i }).first().click();
await page.waitForTimeout(1500);
note("sign out returns to the storefront", ((await page.textContent("body")) || "").includes("Restaurant management"));

/* ── 4 · restaurant reception → POS only ── */
await loginViaModal("spicerestaurant@gmail.com", "spicerestaurant");
const restNav = await page.locator("aside nav button").count();
note("restaurant reception sees 2 nav items (POS + TASKS t97)", restNav === 2, `n=${restNav}`);
const hasDash = ((await page.textContent("body")) || "").includes("BUSINESS-WIDE ANALYTICS");
note("restaurant reception has no owner dashboard", !hasDash);
await shot(page, "reception-restaurant-pos");

/* ── 5 · lodge reception → front desk only ── */
await page.getByRole("button", { name: /sign out/i }).first().click();
await page.waitForTimeout(1500);
await loginViaModal("spicelodge@gmail.com", "spicelodge");
const lodgeNav = await page.locator("aside nav button").count();
note("lodge reception sees 2 nav items (LODGE + TASKS t97)", lodgeNav === 2, `n=${lodgeNav}`);
note("front desk wall loaded", ((await page.textContent("body")) || "").includes("Lodge Front Desk"));
await shot(page, "reception-lodge-desk");

/* ── 6 · sign out → storefront ── */
await page.getByRole("button", { name: /sign out/i }).first().click();
await page.waitForTimeout(1500);
const backOnLanding = ((await page.textContent("body")) || "").includes("Restaurant management");
note("sign out returns to storefront", backOnLanding);

/* ── 7 · motion layer: cursor-follow + entrances ── */
await page.evaluate(() =>
  localStorage.setItem("fx-auth", JSON.stringify({ name: "Imperial", role: "owner", email: "spiceowner@gmail.com" })),
);
await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
await page.waitForTimeout(3000);
/* t99 — the follow vars live on the HOVERED element now (only one card
   follows at a time), so hover a real card with the actual pointer */
await page.waitForSelector('[data-testid="revenue-split-card"]', { timeout: 15000 }).catch(() => {});
await page.evaluate(() => document.querySelector('[data-testid="revenue-split-card"]')?.scrollIntoView({ block: "center" }));
await page.waitForTimeout(600);
const box94 = await page.locator('[data-testid="revenue-split-card"]').boundingBox().catch(() => null);
const before = "0";
if (box94) await page.mouse.move(box94.x + box94.width * 0.6, box94.y + box94.height * 0.5);
await page.waitForTimeout(450);
const after = await page.evaluate(
  () =>
    (document.querySelector('[data-testid="revenue-split-card"]') ?? document.querySelector("[data-fx-motion]"))?.style.getPropertyValue("--mx") || "0",
);
note("mouse drives --mx/--my CSS vars", before !== after, `--mx ${before} → ${after}`);
/* t98 — the drift rides the standalone `translate` property now, so hover
   transforms on the same card compose instead of being overwritten */
const tform = await page.evaluate(() => {
  const el = document.querySelector("[data-fx-motion]");
  if (!el) return "missing";
  return getComputedStyle(el).translate;
});
note("parallax drift applied to [data-fx-motion] (translate)", tform !== "none" && tform.trim() !== "", tform.slice(0, 60));
const entrance = await page.evaluate(() => {
  const total = document.querySelectorAll(".fx-rise").length;
  const done = document.querySelectorAll(".fx-rise.fx-in, .fx-rise:not(.fx-in)").length;
  const hidden = Array.from(document.querySelectorAll(".fx-rise")).filter(
    (el) => getComputedStyle(el).opacity === "0" && el.getBoundingClientRect().top < 800,
  ).length;
  return { total, done, hidden };
});
note("entrance pop fired (no stuck invisible cards)", entrance.hidden === 0, JSON.stringify(entrance));
await shot(page, "motion-parallax-dashboard");

/* ── 8 · regressions: wrong password + wall donut still sums to 100 ── */
await page.evaluate(() => localStorage.clear());
await loginViaModal("spiceowner@gmail.com", "nope");
const errTxt = ((await page.textContent("body")) || "").match(/Wrong email or password/);
note("wrong password rejected", !!errTxt);
await page.evaluate(() =>
  localStorage.setItem("fx-auth", JSON.stringify({ name: "Imperial", role: "owner", email: "spiceowner@gmail.com" })),
);
await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
await page.waitForTimeout(3000);
const sum = await page.evaluate(() => {
  let s = 0;
  document.querySelectorAll('[data-testid^="lroomdash-"]').forEach((r) => (s += parseFloat(r.getAttribute("data-amt") || "0")));
  return Math.round(s * 10) / 10;
});
note("wall donut still sums to 100 rooms", Math.abs(sum - 100) < 0.001, `sum=${sum}`);
note("no page/console errors", errors.length === 0, errors.slice(0, 3).join(" | "));

const failed = results.filter((r) => !r.pass);
console.log(`\n${results.length - failed.length}/${results.length} PASS`);
fs.writeFileSync(`${SHOT}/verify-task94-report.json`, JSON.stringify(results, null, 2));
await browser.close();
process.exit(failed.length ? 1 : 0);
