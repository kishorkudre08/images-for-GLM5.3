/* t112 — FINAL gallery shape verification (user sketch + no-crop thumbs)
   · the 10 theme blocks stack VERTICALLY — ONE theme per row on desktop AND
     phone landscape (each block full column width, like the sketch's stack
     of wide rounded rectangles)
   · INSIDE each block the 4 REAL screenshots flow LEFT → RIGHT in one strip
     (same y, x ascending), each in an 8:5 no-crop frame (object-contain —
     the whole page shot visible, ~165px tall at desktop cell width)
   · order unchanged: prelogin light > dash light > prelogin dark > dash dark
   screenshots → download/verify-t108-*.png */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;

const BASE = "http://127.0.0.1:3000";
const OUT = "/home/z/my-project/download";
let pass = 0, fail = 0;
const ok = (cond, msg) => { if (cond) { pass++; console.log(`  PASS ${msg}`); } else { fail++; console.log(`  FAIL ${msg}`); } };

const browser = await chromium.launch();

/* ── 1. desktop 1440×900 — owner, settings gallery ─────────────────────── */
const d = await browser.newPage({ viewport: { width: 1440, height: 900 } });
d.on("pageerror", (e) => { fail++; console.log(`  FAIL pageerror: ${e.message}`); });
await d.addInitScript(() => localStorage.setItem("fx-auth", JSON.stringify({ name: "Imperial", role: "owner", email: "spiceowner@gmail.com" })));
await d.goto(BASE, { waitUntil: "networkidle" });
await d.waitForTimeout(1800);
await d.locator('[data-testid="settings-btn"]').click();
await d.waitForTimeout(700);
await d.evaluate(() => document.querySelector('[data-testid="settings-themes"]')?.scrollIntoView());
await d.waitForTimeout(900); // let lazy imgs + pop-in settle
await d.screenshot({ path: `${OUT}/verify-t108-gallery-desktop.png` });

// one theme per ROW: exactly 1 block on the first row, 10 blocks total
const rowInfo = await d.evaluate(() => {
  const blocks = [...document.querySelectorAll('[data-testid="settings-themes"] [role="button"][aria-pressed]')];
  const tops = blocks.map(b => Math.round(b.getBoundingClientRect().top));
  const firstRow = tops.filter(t => Math.abs(t - tops[0]) < 4).length;
  const stacked = blocks.every((b, i) => i === 0 || Math.round(b.getBoundingClientRect().top) > tops[i - 1]);
  return { count: blocks.length, firstRow, stacked };
});
ok(rowInfo.count === 10, `10 theme blocks render (${rowInfo.count})`);
ok(rowInfo.firstRow === 1, `ONE theme per row — the sketch's vertical stack (${rowInfo.firstRow} on the first row)`);
ok(rowInfo.stacked, "blocks stack top → bottom (y ascending)");

// inside each block the 4 shots flow LEFT → RIGHT in ONE strip
const shot = await d.evaluate(() => {
  const card = document.querySelector('[data-testid="settings-theme-classic"]');
  const cells = [...card.querySelectorAll(":scope > div > figure")];
  const rects = cells.map(c => { const r = c.getBoundingClientRect(); const img = c.querySelector("img"); return { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height), imgH: img ? Math.round(img.getBoundingClientRect().height) : 0, nat: img ? img.naturalWidth : 0 }; });
  return { cells: rects.length, rects, sameY: rects.every(r => Math.abs(r.y - rects[0].y) < 4), xAsc: rects.every((r, i) => i === 0 || r.x > rects[i - 1].x) };
});
ok(shot.cells === 4, `each block holds exactly 4 shot cells (${shot.cells})`);
ok(shot.sameY, "4 shots share ONE strip row (same y)");
ok(shot.xAsc, "shots flow LEFT → RIGHT (x ascending)");
ok(shot.rects.every(r => r.imgH >= 140 && r.imgH <= 200), `thumbs in 8:5 no-crop frames — whole shot visible (${shot.rects.map(r => r.imgH).join(",")})`);
ok(shot.rects.every(r => r.nat > 400), "all 4 are real screenshots (naturalWidth > 400)");

// size: full-width row like the sketch, compact height
const size = await d.evaluate(() => {
  const card = document.querySelector('[data-testid="settings-theme-classic"]').getBoundingClientRect();
  const wrap = document.querySelector('[data-testid="settings-themes"]').getBoundingClientRect();
  return { cardW: Math.round(card.width), cardH: Math.round(card.height), wrapW: Math.round(wrap.width) };
});
ok(size.cardW >= size.wrapW * 0.95, `each block spans the full row like the sketch: ${size.cardW}px / ${size.wrapW}px`);
ok(size.cardH < 300, `row stays compact: ${size.cardH}px tall (< 300px)`);

// overflow guard
const overflow = await d.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
ok(overflow <= 0, `no horizontal overflow on desktop (${overflow}px)`);

/* ── 2. phone landscape 667×375 — one per row, gate must NOT fire ───────── */
const p = await browser.newPage({ viewport: { width: 667, height: 375 }, hasTouch: true, isMobile: true });
p.on("pageerror", (e) => { fail++; console.log(`  FAIL pageerror: ${e.message}`); });
await p.addInitScript(() => localStorage.setItem("fx-auth", JSON.stringify({ name: "Imperial", role: "owner", email: "spiceowner@gmail.com" })));
await p.goto(BASE, { waitUntil: "networkidle" });
await p.waitForTimeout(1800);
await p.locator('[data-testid="settings-btn-mobile"]').click();
await p.waitForTimeout(700);
await p.evaluate(() => document.querySelector('[data-testid="settings-themes"]')?.scrollIntoView());
await p.waitForTimeout(900);
await p.screenshot({ path: `${OUT}/verify-t108-gallery-phone.png` });
const phone = await p.evaluate(() => {
  const blocks = [...document.querySelectorAll('[data-testid="settings-themes"] [role="button"][aria-pressed]')];
  const tops = blocks.map(b => Math.round(b.getBoundingClientRect().top));
  const firstRow = tops.filter(t => Math.abs(t - tops[0]) < 4).length;
  const gate = document.querySelector(".fx-rotate-gate");
  const gateVisible = gate && getComputedStyle(gate).display !== "none";
  return { firstRow, gateVisible, over: document.documentElement.scrollWidth - document.documentElement.clientWidth };
});
ok(!phone.gateVisible, "landscape phone shows the app (rotate gate hidden)");
ok(phone.firstRow === 1, `phone landscape: still ONE theme per row (${phone.firstRow} on the first row)`);
ok(phone.over <= 0, `no horizontal overflow on phone landscape (${phone.over}px)`);

await browser.close();
console.log(`\nRESULT: ${pass} pass / ${fail} fail`);
process.exit(fail ? 1 : 0);
