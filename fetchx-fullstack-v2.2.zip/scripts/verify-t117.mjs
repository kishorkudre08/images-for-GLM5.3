// t117 verify — the owner reads the latest bills, the dashboard splits revenue,
// the login stacks, and the floating AI option is back everywhere:
//   (1) login: email + password stack one below another (desktop),
//   (2) owner Menu Manager: collapsible LATEST RESTAURANT BILLS — last 50,
//       strictly read-only (no reprint, no undo),
//   (3) owner Lodge Front Desk: collapsible LATEST LODGE BILLS — same rules,
//       monitor intact (no check-in / no expenses / no reset),
//   (4) the floating AI option is visible on EVERY screen in all three
//       accounts — including the POS screen where it used to vanish,
//   (5) dashboard: a REVENUE SPLIT donut (raw materials · upgrades ·
//       maintenance · employee salaries) sits just above each book's
//       REVENUE BREAKDOWN band card — in all three scopes,
//   (6) receptions: expense entry sections intact (3 types, naming, cost).
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;

const BASE = "http://localhost:3000";
const OWNER = { name: "Imperial", role: "owner", email: "spiceowner@gmail.com" };
const REST = { name: "Imperial", role: "reception_restaurant", email: "spicerestaurant@gmail.com" };
const LODGE = { name: "Imperial", role: "reception_lodge", email: "spicelodge@gmail.com" };

let pass = 0, fail = 0;
const ok = (cond, name) => {
  if (cond) { pass++; console.log("  ✓", name); }
  else { fail++; console.log("  ✗ FAIL:", name); }
};

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(String(e).slice(0, 150)));

const login = async (u) => {
  await page.goto(BASE, { waitUntil: "domcontentloaded" });
  await page.evaluate((x) => localStorage.setItem("fx-auth", JSON.stringify(x)), u);
  await page.goto(BASE, { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(2500);
};

/* ── 1 · login: email and password one below another ─────────────────────── */
console.log("1 · LOGIN STACK");
await page.goto(BASE, { waitUntil: "domcontentloaded" });
await page.getByRole("button", { name: /sign in/i }).first().click().catch(() => {});
await page.waitForTimeout(1200);
const emailBox = await page.locator("#lk-email").boundingBox().catch(() => null);
const passBox = await page.locator("#lk-pass").boundingBox().catch(() => null);
ok(!!emailBox && !!passBox, "login modal shows both fields");
if (emailBox && passBox) {
  ok(passBox.y > emailBox.y + emailBox.height * 0.5, `password sits BELOW email (pass.y=${Math.round(passBox.y)} > email.y=${Math.round(emailBox.y)})`);
  ok(Math.abs(passBox.x - emailBox.x) < 10, "both fields share one column");
}

/* ── 2 · owner Menu Manager — collapsible latest restaurant bills ────────── */
console.log("2 · OWNER MENU MANAGER — LATEST RESTAURANT BILLS");
await login(OWNER);
ok(await page.getByRole("button", { name: "Menu Manager" }).first().isVisible().catch(() => false), "owner nav runs Menu Manager");
ok(!(await page.getByRole("button", { name: "POS Billing" }).first().isVisible().catch(() => false)), "owner has no POS Billing");
await page.getByRole("button", { name: "Menu Manager" }).first().click();
await page.waitForTimeout(1800);
const mb = page.locator('[data-testid="menu-latest-bills"]');
ok(await mb.isVisible().catch(() => false), "LATEST RESTAURANT BILLS block renders");
const mToggle = page.locator('[data-testid="menu-latest-bills-toggle"]');
ok((await mToggle.getAttribute("aria-expanded")) === "true", "block starts expanded (collapsible)");
const mChip = await mb.locator(".mut-chip").first().textContent().catch(() => "");
ok(/READ ONLY/.test(mChip || ""), `chip says READ ONLY ("${(mChip || "").trim()}")`);
const mRows = await mb.locator(".feed-row").count();
ok(mRows > 0, `feed shows bills (${mRows} rows)`);
ok(mRows <= 50, "feed capped at the last 50");
ok((await mb.locator('[title="Tap to reprint"]').count()) === 0, "no reprint action for the owner");
ok((await mb.locator(".f-undo").count()) === 0, "no UNDO action for the owner");
await mToggle.click();
await page.waitForTimeout(300);
ok((await mToggle.getAttribute("aria-expanded")) === "false" && (await mb.locator(".feed-row").count()) === 0, "collapses on tap");
await mToggle.click();
await page.waitForTimeout(300);
ok((await mb.locator(".feed-row").count()) > 0, "expands again");
/* the floating option lives on this screen too */
ok(await page.locator('[data-testid="ai-fab"]').isVisible().catch(() => false), "floating AI option visible on Menu Manager");

/* ── 3 · owner Lodge Front Desk — collapsible latest lodge bills ─────────── */
console.log("3 · OWNER LODGE — LATEST LODGE BILLS");
await page.getByRole("button", { name: "Lodge Front Desk" }).first().click();
await page.waitForTimeout(2200);
const lb = page.locator('[data-testid="lodge-latest-bills"]');
ok(await lb.isVisible().catch(() => false), "LATEST LODGE BILLS block renders");
const lToggle = page.locator('[data-testid="lodge-latest-bills-toggle"]');
ok((await lToggle.getAttribute("aria-expanded")) === "true", "block starts expanded (collapsible)");
const lChip = await lb.locator(".mut-chip").first().textContent().catch(() => "");
ok(/READ ONLY/.test(lChip || ""), `chip says READ ONLY ("${(lChip || "").trim()}")`);
ok((await lb.locator(".feed-row").count()) > 0, `feed shows stays (${await lb.locator(".feed-row").count()} rows)`);
ok((await lb.locator('[title="Tap to reprint"]').count()) === 0 && (await lb.locator(".f-undo").count()) === 0, "no reprint / no UNDO for the owner");
await lToggle.click();
await page.waitForTimeout(300);
ok((await lToggle.getAttribute("aria-expanded")) === "false" && (await lb.locator(".feed-row").count()) === 0, "collapses on tap");
await lToggle.click();
await page.waitForTimeout(300);
/* t116 monitor guards still hold */
const bodyText = await page.locator("body").textContent();
ok(!/ENTER NEW GUEST/.test(bodyText || "") && !/RESET WALL/.test(bodyText || "") && (await page.locator('[data-testid^="stn-kind-"]').count()) === 0, "monitor intact — no check-in / reset / expenses");
ok(await page.locator('[data-testid="ai-fab"]').isVisible().catch(() => false), "floating AI option visible on owner lodge");

/* ── 4 · dashboard — revenue-split donuts above the breakdown bands ──────── */
console.log("4 · DASHBOARD — REVENUE SPLIT DONUTS");
await page.getByRole("button", { name: "Live Dashboard" }).first().click();
await page.waitForTimeout(2500);
ok(await page.locator('[data-testid="rev-split-donut-rest"]').isVisible().catch(() => false), "restaurant split donut renders (ALL scope)");
ok(await page.locator('[data-testid="rev-split-donut-lodge"]').isVisible().catch(() => false), "lodge split donut renders (ALL scope)");
const heads = await page.evaluate(() => {
  const grab = (t) => [...document.querySelectorAll('[data-testid^="rev-split-donut-"]')].find((d) => d.dataset.testid === t);
  const leg = (t) => (grab(t)?.textContent || "");
  return { rest: leg("rev-split-donut-rest"), lodge: leg("rev-split-donut-lodge") };
});
ok(/RAW MATERIALS/.test(heads.rest) && /UPGRADES/.test(heads.rest) && /MAINTENANCE/.test(heads.rest) && /EMPLOYEE SALARIES/.test(heads.rest), "restaurant donut splits into raw / upgrades / maintenance / salaries");
ok(/RAW MATERIALS/.test(heads.lodge) && /UPGRADES/.test(heads.lodge) && /MAINTENANCE/.test(heads.lodge) && /EMPLOYEE SALARIES/.test(heads.lodge), "lodge donut splits into raw / upgrades / maintenance / salaries");
const order = await page.evaluate(() => {
  const y = (el) => el.getBoundingClientRect().top;
  const donutRest = document.querySelector('[data-testid="rev-split-donut-rest"]');
  const donutLodge = document.querySelector('[data-testid="rev-split-donut-lodge"]');
  const cards = [...document.querySelectorAll(".fx-card")];
  const bookRest = cards.find((c) => c.querySelector(".fx-label")?.textContent?.includes("RESTAURANT BOOK"));
  const bookLodge = cards.find((c) => c.querySelector(".fx-label")?.textContent?.includes("LODGE BOOK"));
  return bookRest && bookLodge && donutRest && donutLodge
    ? { rest: y(donutRest) < y(bookRest), lodge: y(donutLodge) < y(bookLodge) }
    : null;
});
ok(!!order && order.rest, "restaurant donut sits ABOVE its band card");
ok(!!order && order.lodge, "lodge donut sits ABOVE its band card");
/* restaurant scope */
await page.getByRole("tab", { name: "RESTAURANT" }).first().click().catch(async () => {
  await page.locator('[role=tablist][aria-label="Business view"] [role=tab]').first().click();
});
await page.waitForTimeout(2200);
const restOrder = await page.evaluate(() => {
  const d = document.querySelector('[data-testid="rev-split-donut-rest"]');
  const cards = [...document.querySelectorAll(".fx-card")];
  const book = cards.find((c) => /REVENUE BREAKDOWN/.test(c.querySelector(".fx-label")?.textContent || ""));
  return d && book ? d.getBoundingClientRect().top < book.getBoundingClientRect().top : null;
});
ok(restOrder === true, "RESTAURANT scope — donut above the breakdown");
/* lodge scope */
await page.getByRole("tab", { name: "LODGE" }).first().click().catch(() => {});
await page.waitForTimeout(2200);
const lodgeOrder = await page.evaluate(() => {
  const d = document.querySelector('[data-testid="rev-split-donut-lodge"]');
  const cards = [...document.querySelectorAll(".fx-card")];
  const book = cards.find((c) => /REVENUE BREAKDOWN/.test(c.querySelector(".fx-label")?.textContent || ""));
  return d && book ? d.getBoundingClientRect().top < book.getBoundingClientRect().top : null;
});
ok(lodgeOrder === true, "LODGE scope — donut above the breakdown");
/* t118 — the AI panel still opens for the OWNER (FAB → panel, FAB goes away) */
await page.locator('[data-testid="ai-fab"]').click();
await page.waitForTimeout(900);
const fabOwnerAfter = await page.locator('[data-testid="ai-fab"]').count();
const asideOpenOwner = await page.locator("aside").first().isVisible().catch(() => false);
ok(fabOwnerAfter === 0 && asideOpenOwner, "owner FAB opens the AI panel");
await page.locator('button[title="Collapse panel"]').click().catch(() => {});

/* ── 5 · receptions — expense entry intact + AI owner-only + tracker floats ── */
console.log("5 · RECEPTIONS — EXPENSE ENTRY + OWNER-ONLY AI + TASK TRACKER");
await login(REST);
await page.waitForTimeout(1500);
ok((await page.locator('[data-testid="ai-fab"]').count()) === 0, "NO floating AI button on the reception POS (AI is owner-only)");
ok(await page.locator('[data-testid="task-fab"]').isVisible().catch(() => false), "floating TASK TRACKER floats on the reception POS");
const stnRest = await page.evaluate(() => ({
  kinds: ["raw_material", "upgrade", "maintenance"].filter((k) => document.querySelector(`[data-testid="stn-kind-${k}-rest"]`)).length,
  label: !!document.querySelector('[data-testid="stn-label-rest"]'),
  amount: !!document.querySelector('[data-testid="stn-amount-rest"]'),
  add: !!document.querySelector('[data-testid="stn-add-rest"]'),
}));
ok(stnRest.kinds === 3 && stnRest.label && stnRest.amount && stnRest.add, `restaurant desk expense entry: 3 types + naming + cost + ADD (${JSON.stringify(stnRest)})`);
await login(LODGE);
await page.getByRole("button", { name: "Lodge Front Desk" }).first().click().catch(() => {});
await page.waitForTimeout(1800);
ok((await page.locator('[data-testid="ai-fab"]').count()) === 0, "NO floating AI button on the lodge desk (AI is owner-only)");
ok(await page.locator('[data-testid="task-fab"]').isVisible().catch(() => false), "floating TASK TRACKER floats on the lodge desk");
const stnLodge = await page.evaluate(() => ({
  kinds: ["raw_material", "upgrade", "maintenance"].filter((k) => document.querySelector(`[data-testid="stn-kind-${k}-lodge"]`)).length,
  label: !!document.querySelector('[data-testid="stn-label-lodge"]'),
  amount: !!document.querySelector('[data-testid="stn-amount-lodge"]'),
  add: !!document.querySelector('[data-testid="stn-add-lodge"]'),
}));
ok(stnLodge.kinds === 3 && stnLodge.label && stnLodge.amount && stnLodge.add, `lodge desk expense entry: 3 types + naming + cost + ADD (${JSON.stringify(stnLodge)})`);
/* counter feed untouched — reprint + UNDO still on the desks */
await login(REST);
await page.waitForTimeout(1500);
const counterFeed = await page.evaluate(() => {
  const txt = document.body.textContent || "";
  return { feed: /RESTAURANT BILLS · TAP TO REPRINT/.test(txt), undo: !!document.querySelector(".f-undo") };
});
ok(counterFeed.feed && counterFeed.undo, "counter keeps TAP TO REPRINT + UNDO (unchanged)");

ok(errors.length === 0, `zero page errors (${errors.length})`);
console.log(`\nRESULT: ${pass}/${pass + fail}`);
await browser.close();
process.exit(fail ? 1 : 0);
