import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
await db.taskUpdate.deleteMany();
await db.task.deleteMany();
await db.expense.deleteMany({ where: { via: "task" } });
console.log("task tables + crown expenses cleaned");
await db.$disconnect();
