/* Task 76 verification — theme gallery, universal theming, persistence,
 * AI operations data + regressions. Screenshots → download/verify-task76-*.png
 * Run: node scripts/verify-t76.mjs
 */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
import fs from "node:fs";

const BASE = "http://localhost:3000";
const SHOT = "/home/z/my-project/download";
let idx = 0;
const results = [];
const note = (name, pass, detail = "") => {
  results.push({ name, pass, detail });
  console.log(`${pass ? "PASS" : "FAIL"}  ${name}${detail ? `  — ${detail}` : ""}`);
};
const shot = async (page, name) => {
  idx += 1;
  await page.screenshot({ path: `${SHOT}/verify-task76-${String(idx).padStart(2, "0")}-${name}.png` }).catch(() => {});
};

const attr = (page) => page.evaluate(() => document.documentElement.dataset.fxTheme || "classic");
const style = (page, sel, prop) =>
  page.evaluate(([s, p]) => {
    const el = document.querySelector(s);
    return el ? getComputedStyle(el)[p] : null;
  }, [sel, prop]);

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(String(e).slice(0, 200)));
page.on("console", (m) => m.type() === "error" && errors.push(m.text().slice(0, 200)));

/* ── A · landing classic ── */
await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
await page.waitForTimeout(1500);
note("landing classic attr", (await attr(page)) === "classic");
await shot(page, "landing-classic");

/* ── B · sign in + dashboard classic regression ── */
await page.getByRole("button", { name: "Sign In" }).first().click();
const dlg = page.getByRole("dialog", { name: "Sign in" });
await dlg.waitFor({ timeout: 10000 });
await dlg.locator("#lk-email").fill("spice1234@gmail.com");
await dlg.locator("#lk-pass").fill("spice1234");
await dlg.getByRole("button", { name: /Sign In/i }).last().click();
await page.waitForTimeout(2500);
note("dashboard loaded", await page.locator(".fx-band").count() > 0);
note("dashboard attr classic", (await attr(page)) === "classic");
const numBgClassic = await style(page, ".fx-band span", "backgroundColor");
note("tier chip purple (classic)", numBgClassic === "rgb(91, 79, 233)", numBgClassic);
note("THEME button on dashboard", (await page.getByLabel("Open theme gallery").count()) > 0);
// net-profit sign colour (today runs negative at this hour — expect rose; log either)
const netInfo = await page.evaluate(() => {
  const el = [...document.querySelectorAll(".net-mini")].find((x) => x.textContent.includes("NET PROFIT"));
  return el ? { text: el.textContent.trim(), color: getComputedStyle(el).color } : null;
});
if (netInfo) {
  const isRose = netInfo.color === "rgb(225, 29, 72)";
  const negative = /-\s?₹|₹\s?-|−/.test(netInfo.text) || netInfo.text.includes("-2") || netInfo.text.includes("-3");
  note("net-profit colour matches sign", isRose === negative || (negative ? isRose : !isRose), `${netInfo.text} → ${netInfo.color}`);
} else note("net-profit line present", false, "not found");
await shot(page, "dashboard-classic");

/* ── C · THEME → gallery ── */
await page.getByLabel("Open theme gallery").click();
await page.waitForURL("**/theme", { timeout: 15000 });
await page.waitForTimeout(1200);
note("theme page title", (await page.getByRole("heading", { name: "Theme Gallery" }).count()) > 0);
const cards = await page.locator(".fx-card").count();
note("5 combo cards", cards === 5, `found ${cards}`);
const minis = await page.locator("figure").count();
note("15 previews (5×light+dark+mono)", minis === 15, `found ${minis}`);
note("PICKING FOR account", (await page.getByText("PICKING FOR · IMPERIAL").count()) > 0);
await shot(page, "theme-gallery");

/* ── D · apply dragonfruit ── */
await page.locator(".fx-card", { hasText: "Dragon Fruit + Night Violet" }).getByRole("button", { name: "USE THIS THEME" }).click();
await page.waitForTimeout(700);
note("attr = dragonfruit", (await attr(page)) === "dragonfruit");
note("CURRENT badge moved", (await page.locator(".fx-card", { hasText: "Dragon Fruit + Night Violet" }).getByText("CURRENT").count()) > 0);
await shot(page, "theme-gallery-dragonfruit");

/* ── E · universal across sections ── */
await page.getByLabel("Back to the console").click();
await page.waitForURL(BASE + "/", { timeout: 15000 });
await page.waitForTimeout(2200);
const numBgDragon = await style(page, ".fx-band span", "backgroundColor");
note("dashboard tier chip pink", numBgDragon === "rgb(200, 30, 120)", numBgDragon);
const dotStyle = await page.evaluate(() => document.querySelector('[role="tab"] .scope-dot')?.getAttribute("style") ?? "");
note("scope dot themed", dotStyle.includes("rgb(214, 36, 127)") || dotStyle.includes("#d6247f"), dotStyle);
const stroke = await page.evaluate(() => document.querySelector(".recharts-area-curve")?.getAttribute("stroke") ?? "");
note("chart stroke themed", stroke.toLowerCase().includes("d6247f"), stroke);
await shot(page, "dashboard-dragonfruit");

for (const [nav, key] of [["POS Billing", "pos"], ["Expenses", "expenses"], ["Lodge Front Desk", "lodge"], ["Management", "management"]]) {
  await page.getByRole("button", { name: nav, exact: false }).first().click();
  await page.waitForTimeout(1600);
  note(`THEME button on ${key}`, (await page.getByLabel("Open theme gallery").count()) > 0);
  await shot(page, `${key}-dragonfruit`);
}

/* ── F · persistence across reload ── */
await page.reload({ waitUntil: "domcontentloaded" });
await page.waitForTimeout(2200);
note("persists after reload", (await attr(page)) === "dragonfruit");

/* ── G · dark mode under dragonfruit ── */
await page.getByLabel("Toggle dark mode").first().click();
await page.waitForTimeout(1200);
const darkBg = await style(page, ".fx-band span", "backgroundColor");
note("dark dragonfruit chip", darkBg === "rgb(214, 77, 146)", darkBg);
await shot(page, "dashboard-dragonfruit-dark");
await page.getByLabel("Toggle dark mode").first().click();
await page.waitForTimeout(900);

/* ── H · iris (butter yellow) + emerald + lime ── */
await page.getByLabel("Open theme gallery").click();
await page.waitForURL("**/theme", { timeout: 15000 });
await page.waitForTimeout(900);
await page.locator(".fx-card", { hasText: "Butter Yellow + Royal Iris" }).getByRole("button", { name: "USE THIS THEME" }).click();
await page.waitForTimeout(600);
await shot(page, "theme-gallery-iris");
await page.getByLabel("Back to the console").click();
await page.waitForURL(BASE + "/", { timeout: 15000 });
await page.waitForTimeout(1500);
await page.getByRole("button", { name: "POS Billing", exact: false }).first().click();
await page.waitForTimeout(1500);
const genBtn = await page.evaluate(() => {
  const b = [...document.querySelectorAll("button")].find((x) => /GENERATE BILL/.textContent ?? /GENERATE BILL/.test(x.textContent));
  if (!b) return null;
  const cs = getComputedStyle(b);
  return { bg: cs.backgroundColor, fg: cs.color };
});
note("iris: butter button bg", genBtn?.bg === "rgb(245, 197, 30)", genBtn?.bg ?? "no button");
note("iris: dark text on butter", genBtn?.fg === "rgb(37, 28, 2)", genBtn?.fg ?? "");
await shot(page, "pos-iris");

for (const t of ["Emerald Ink + Champagne", "Lime Spark + Graphite"]) {
  await page.getByLabel("Open theme gallery").click();
  await page.waitForURL("**/theme", { timeout: 15000 });
  await page.waitForTimeout(900);
  await page.locator(".fx-card", { hasText: t }).getByRole("button", { name: "USE THIS THEME" }).click();
  await page.waitForTimeout(600);
  await page.getByLabel("Back to the console").click();
  await page.waitForURL(BASE + "/", { timeout: 15000 });
  await page.waitForTimeout(1200);
  await page.getByRole("button", { name: "Live Dashboard", exact: false }).first().click();
  await page.waitForTimeout(1800);
  await shot(page, `dashboard-${t.split(" ")[0].toLowerCase()}`);
}

/* ── I · back to classic, then AI ops question ── */
await page.getByLabel("Open theme gallery").click();
await page.waitForURL("**/theme", { timeout: 15000 });
await page.waitForTimeout(900);
await page.locator(".fx-card", { hasText: "Fetch-X Classic" }).getByRole("button", { name: "USE THIS THEME" }).click();
await page.waitForTimeout(600);
note("restored classic", (await attr(page)) === "classic");
await page.getByLabel("Back to the console").click();
await page.waitForURL(BASE + "/", { timeout: 15000 });
await page.waitForTimeout(1800);
const numBgRestored = await style(page, ".fx-band span", "backgroundColor");
note("purple restored", numBgRestored === "rgb(91, 79, 233)", numBgRestored);

await page.getByLabel("Open Fetch-X AI assistant").click();
await page.waitForTimeout(900);
await page.getByLabel("Ask the AI copilot").fill("What is my housekeeping task completion right now, and my budget utilization for this month per book?");
await page.getByLabel("Send message").click();
await page.waitForTimeout(30000);
const aiText = await page.evaluate(() => {
  const bubbles = [...document.querySelectorAll(".ai-md")];
  return bubbles.length ? bubbles[bubbles.length - 1].textContent.slice(0, 900) : "";
});
const aiOk = aiText.length > 80 && /%|₹/.test(aiText) && /task|housekeep|budget|utili/i.test(aiText);
note("AI answers task+budget", aiOk, aiText.slice(0, 160).replace(/\n/g, " "));
await shot(page, "ai-operations-answer");
await page.getByLabel("Collapse AI panel").click().catch(() => {});

/* ── J · sign-out → sign-in persistence ── */
await page.getByRole("button", { name: "Sign out", exact: false }).first().click();
await page.waitForTimeout(1200);
await page.getByRole("button", { name: "Sign In" }).first().click();
const dlg2 = page.getByRole("dialog", { name: "Sign in" });
await dlg2.waitFor({ timeout: 10000 });
await dlg2.locator("#lk-email").fill("spice1234@gmail.com");
await dlg2.locator("#lk-pass").fill("spice1234");
await dlg2.getByRole("button", { name: /Sign In/i }).last().click();
await page.waitForTimeout(2500);
const stored = await page.evaluate(() => localStorage.getItem("fx-theme:spice1234@gmail.com"));
note("account theme stored", stored === "classic", `fx-theme:spice1234@gmail.com = ${stored}`);

/* ── K · regression sweep ── */
const tabs = page.getByRole("tablist", { name: "Business view" }).getByRole("tab");
for (let i = 0; i < await tabs.count(); i++) {
  await tabs.nth(i).click();
  await page.waitForTimeout(1400);
}
note("scope tabs still cycle", true, `${await tabs.count()} tabs`);
await page.getByRole("tab", { name: "ALL BUSINESS" }).click();
await page.waitForTimeout(1200);
await page.getByRole("button", { name: "POS Billing", exact: false }).first().click();
await page.waitForTimeout(1500);
const tile = page.locator(".fx-tile").first();
await tile.click();
await page.waitForTimeout(700);
note("pos cart adds", (await page.getByText("1 ITEM", { exact: false }).count()) > 0);
await shot(page, "pos-regression");
await page.getByRole("button", { name: "Lodge Front Desk", exact: false }).first().click();
await page.waitForTimeout(1800);
const rooms = await page.locator("button[aria-label^='Room']").count();
note("lodge wall 100 rooms", rooms === 100, `${rooms} room buttons`);
await shot(page, "lodge-regression");

const realErrors = errors.filter((e) => !/Autofill|Download the React DevTools/i.test(e));
note("no console/page errors", realErrors.length === 0, realErrors.slice(0, 3).join(" | "));

await browser.close();
const pass = results.filter((r) => r.pass).length;
console.log(`\n══════ TASK 76 VERIFY: ${pass}/${results.length} PASS ══════`);
fs.writeFileSync("/home/z/my-project/scripts/verify-t76-report.json", JSON.stringify({ results, errors: realErrors }, null, 2));
process.exit(pass === results.length ? 0 : 1);
