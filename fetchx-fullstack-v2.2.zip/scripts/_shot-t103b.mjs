import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
const b = await chromium.launch();
const ctx = await b.newContext({ viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(String(e)));

const prep = async (authed, themeId, mode) => {
  await page.goto("http://localhost:3000/", { waitUntil: "domcontentloaded", timeout: 90000 });
  await page.evaluate(([a, t, m]) => {
    localStorage.setItem("theme", m);
    localStorage.setItem("fx-theme:guest", t);
    if (a) {
      localStorage.setItem("fx-auth", JSON.stringify({ name: "Imperial", role: "owner", email: "spiceowner@gmail.com" }));
      localStorage.setItem("fx-theme:spiceowner@gmail.com", t);
    } else localStorage.removeItem("fx-auth");
  }, [authed, themeId, mode]);
  await page.reload({ waitUntil: "domcontentloaded" });
};

/* landing light under classic (tinted lavender) */
await prep(false, "classic", "light");
await page.waitForSelector("text=finally intelligent", { timeout: 90000 });
await page.waitForTimeout(1200);
console.log("landing bg:", await page.evaluate(() => getComputedStyle(document.body).backgroundColor));
await page.screenshot({ path: "/home/z/my-project/download/t103-landing-classic-light.png" });

/* owner → dashboard + settings under neon light (mint) */
await prep(true, "neon", "light");
await page.waitForSelector("text=Live Dashboard", { timeout: 90000 });
await page.waitForTimeout(1500);
console.log("neon dash bg:", await page.evaluate(() => getComputedStyle(document.body).backgroundColor));
await page.screenshot({ path: "/home/z/my-project/download/t103-dash-neon-light.png" });
await page.click('[data-testid="settings-btn"]');
await page.waitForTimeout(1500);
await page.evaluate(() => document.querySelector('[data-testid="settings-themes"]').scrollIntoView());
await page.waitForTimeout(500);
await page.screenshot({ path: "/home/z/my-project/download/t103-settings-neon-light.png" });

/* dark mode under emerald (deep green page) */
await prep(true, "emerald", "dark");
await page.waitForSelector("text=Live Dashboard", { timeout: 90000 });
await page.waitForTimeout(1800);
console.log("emerald dark bg:", await page.evaluate(() => getComputedStyle(document.body).backgroundColor));
await page.screenshot({ path: "/home/z/my-project/download/t103-dash-emerald-dark.png" });
await page.click('[data-testid="settings-btn"]');
await page.waitForTimeout(1500);
await page.evaluate(() => document.querySelector('[data-testid="settings-themes"]').scrollIntoView());
await page.waitForTimeout(500);
await page.screenshot({ path: "/home/z/my-project/download/t103-settings-emerald-dark.png" });

console.log("page errors:", errors.length, errors.slice(0, 2).join(" | "));
await b.close();
console.log("done");
