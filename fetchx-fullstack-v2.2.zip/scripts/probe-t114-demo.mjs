// t114 demo probe — what do receptions see inside fetchx-live-demo.html?
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
page.on("pageerror", (e) => console.log("PAGEERROR:", String(e).slice(0, 200)));

await page.goto("file:///home/z/my-project/download/fetchx-live-demo.html", { waitUntil: "domcontentloaded" });
await page.waitForTimeout(1800);

// open the sign-in modal, then fill reception credentials
await page.locator('button:has-text("Sign In"), button:has-text("SIGN IN")').first().click();
await page.waitForTimeout(900);
const email = page.locator('input[type="email"], input[placeholder*="mail" i]').first();
const hasEmail = await email.count();
console.log("email input found:", hasEmail);
if (hasEmail) {
  await email.fill("spicerestaurant@gmail.com");
  const pwInput = page.locator('input[type="password"]').first();
  if (await pwInput.count()) await pwInput.fill("spicerestaurant");
  await page.locator('[role="dialog"] button:has-text("SIGN IN"), [role="dialog"] button:has-text("Sign in"), [role="dialog"] button[type="submit"]').last().click();
  await page.waitForTimeout(2200);
}

// inventory: nav labels + section labels on the landing view (POS for reception)
const inv = await page.evaluate(() => {
  const navBtns = [...document.querySelectorAll("aside button, nav button")].map((b) => (b.textContent || "").trim()).filter(Boolean);
  const labels = [...document.querySelectorAll(".fx-label")].map((e) => e.textContent.trim());
  return { navBtns, labels };
});
console.log("NAV:", JSON.stringify(inv.navBtns));
console.log("LABELS:", JSON.stringify(inv.labels));
await page.screenshot({ path: "download/verify-t114-demo-rest.png", fullPage: true });

await browser.close();
console.log("DONE");
