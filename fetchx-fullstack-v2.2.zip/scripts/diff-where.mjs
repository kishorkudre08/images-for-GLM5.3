/* locate WHERE landing-modal differs: ref vs demo screenshot */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
import sharp from "/home/z/.npm-global/lib/node_modules/sharp/dist/index.cjs";

const b = await chromium.launch();
const p = await (await b.newContext({ viewport: { width: 1440, height: 900 } })).newPage();
await p.goto("file:///home/z/my-project/download/fetchx-live-demo.html", { waitUntil: "domcontentloaded" });
await p.waitForTimeout(1500);
await p.evaluate(() => window.FX_DEMO.show("landing-modal"));
await p.waitForTimeout(900);
const buf = await p.screenshot();
await b.close();

const A = await sharp("/home/z/my-project/scripts/capture/ref-landing-modal.png").ensureAlpha().raw().toBuffer({ resolveWithObject: true });
const B = await sharp(buf).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
const { width: W, height: H } = A.info;
const T = 24;
const rows = new Array(H).fill(0), cols = new Array(W).fill(0);
let total = 0;
for (let y = 0; y < H; y++) {
  for (let x = 0; x < W; x++) {
    const i = (y * W + x) * 4;
    if (Math.abs(A.data[i] - B.data[i]) > T || Math.abs(A.data[i + 1] - B.data[i + 1]) > T || Math.abs(A.data[i + 2] - B.data[i + 2]) > T) {
      rows[y]++; cols[x]++; total++;
    }
  }
}
const hot = (arr, label) => arr.map((v, i) => [i, v]).filter(([, v]) => v > 40).slice(0, 40).map(([i, v]) => `${label}${i}:${v}`).join(" ");
console.log("total diff px:", total, `(${((total / (W * H)) * 100).toFixed(2)}%)`);
console.log("hot rows:", hot(rows, "y"));
console.log("hot cols:", hot(cols, "x"));
