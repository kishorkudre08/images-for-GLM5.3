/* t96 demo verification — the standalone fetchx-live-demo.html carries the
 * TASK PULSE section with working expand/complete interactions + the AI chip.
 * Run: node scripts/verify-demo-t96.mjs
 */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
import fs from "node:fs";

const FILE = "/home/z/my-project/download/fetchx-live-demo.html";
const SHOT = "/home/z/my-project/download";
const results = [];
const note = (name, pass, detail = "") => {
  results.push({ name, pass, detail });
  console.log(`${pass ? "PASS" : "FAIL"}  ${name}${detail ? `  — ${detail}` : ""}`);
};

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(String(e).slice(0, 160)));

await page.goto(`file://${FILE}`, { waitUntil: "domcontentloaded", timeout: 60000 });
await page.waitForTimeout(1200);

/* owner dashboard via Live Demo */
await page.evaluate(() => window.FX_DEMO.show("dash-all-today"));
await page.waitForTimeout(800);
const pulse = await page.locator('[data-testid="task-pulse"]').isVisible().catch(() => false);
note("demo: TASK PULSE section renders", pulse);
const cards = await page.locator('[data-testid^="task-card-"]').count();
note("demo: task cards present (1 open + 3 carry-over + 1 done)", cards >= 4, `cards=${cards}`);
const pct = ((await page.locator('[data-testid="task-completion-pct"]').textContent().catch(() => "")) || "").trim();
note("demo: completion 50%", pct === "50%", pct);

/* expand the open room-12 card */
const card12 = page.locator('[data-testid="task-card-12"]');
const expandable = await card12.count();
await card12.locator(".task-top").click().catch(() => {});
await page.waitForTimeout(450);
const bodyOpen = await card12.evaluate((el) => el.classList.contains("open")).catch(() => false);
note("demo: card expands on click", expandable === 1 && bodyOpen);
const bodyText = ((await card12.textContent().catch(() => "")) || "");
note("demo: expanded body shows bill + lever", /L-11822/.test(bodyText) && /MAINTENANCE DONE/.test(bodyText));
await page.locator('[data-testid="task-pulse"]').scrollIntoViewIfNeeded().catch(() => {});
await page.screenshot({ path: `${SHOT}/verify-task96-demo-01-section.png` }).catch(() => {});

/* the maintenance-done lever flips the card in the demo */
await card12.locator('[data-testid="task-complete-12"]').click().catch(() => {});
await page.waitForTimeout(400);
const flipped = await card12.evaluate((el) => {
  const chip = el.querySelector(".task-chip");
  return chip && chip.classList.contains("done") && /DONE/.test(chip.textContent || "");
}).catch(() => false);
const toastTxt = ((await page.locator("#fx-toast").textContent().catch(() => "")) || "");
note("demo: complete lever flips card + toast", flipped && /GREEN AGAIN/.test(toastTxt), toastTxt.trim().slice(0, 60));
await page.screenshot({ path: `${SHOT}/verify-task96-demo-02-complete.png` }).catch(() => {});

/* front desk strip */
await page.evaluate(() => window.FX_DEMO.show("reception-lodge"));
await page.waitForTimeout(800);
const desk = await page.locator('[data-testid="desk-task-pulse"]').isVisible().catch(() => false);
const deskCards = await page.locator('[data-testid^="desk-task-card-"]').count();
note("demo: front-desk strip renders with open work", desk && deskCards >= 3, `cards=${deskCards}`);
await page.locator('[data-testid="desk-task-pulse"]').scrollIntoViewIfNeeded().catch(() => {});
await page.screenshot({ path: `${SHOT}/verify-task96-demo-03-desk.png` }).catch(() => {});

/* AI chip answers the housekeeping preset */
await page.evaluate(() => window.FX_DEMO.show("ai-open"));
await page.waitForTimeout(600);
await page.locator("aside button", { hasText: "How is my housekeeping doing today?" }).first().click().catch(() => {});
await page.waitForTimeout(1900);
const md = ((await page.locator("aside .ai-md").last().textContent().catch(() => "")) || "");
note("demo: AI chip answers housekeeping from seed", /TASK PULSE|50%|96%/.test(md), md.slice(0, 80).replace(/\n/g, " "));
await page.screenshot({ path: `${SHOT}/verify-task96-demo-04-ai.png` }).catch(() => {});

note("demo: zero page errors", errors.length === 0, errors.slice(0, 2).join("|"));

await browser.close();
const report = { task: "96-demo", when: new Date().toISOString(), pass: results.filter((r) => r.pass).length, total: results.length, results };
fs.writeFileSync(`${SHOT}/verify-task96-demo-report.json`, JSON.stringify(report, null, 2));
console.log(`\n══════ DEMO VERIFY: ${report.pass}/${report.total} PASS ══════`);
process.exit(report.pass === report.total ? 0 : 1);
