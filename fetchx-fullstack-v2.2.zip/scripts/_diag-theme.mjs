import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
const b = await chromium.launch();
const p = await (await b.newContext({ viewport: { width: 1100, height: 760 } })).newPage();
await p.goto("http://localhost:3000/", { waitUntil: "domcontentloaded" });
await p.evaluate(() => { localStorage.setItem("fx-theme:guest", "cherry"); localStorage.setItem("theme", "light"); localStorage.removeItem("fx-auth"); });
await p.goto("http://localhost:3000/", { waitUntil: "networkidle" });
await p.waitForTimeout(1500);
const r = await p.evaluate(() => ({
  ds: document.documentElement.dataset.fxTheme,
  purple: getComputedStyle(document.documentElement).getPropertyValue("--fx-purple").trim(),
  cherryCss: [...document.styleSheets].some((s) => { try { return [...s.cssRules].some((x) => (x.cssText || "").includes('data-fx-theme="cherry"')); } catch (e) { return false; } }),
}));
console.log(JSON.stringify(r, null, 1));
await b.close();
