/* t99 verification — the fix batch:
 *   1. pre-login page CONTAINED again; the credentials page (after Get Started) stretched
 *   2. "upgrade" expense type everywhere: task add/done chips, API, ledger tag
 *   3. mouse follow: only the hovered card drifts (element-level vars), settles on leave
 *   4. HIGH-intensity hover pop on any card (translateY -7 · scale 1.032 · deep shadow)
 *   5. owner expenses: ENTER EXPENSES gone → 3-metric donut + today…1y window + ledger kind filter
 *   6. tasks: pulse animation removed, ONE task per column
 *   7. settings = whole page (gear beside theme toggle)
 *   8. lodge donut centre label stays inside the ring; yearly wall shows realistic rooms
 * Screenshots → download/verify-task99-*.png
 * Run: node scripts/verify-t99.mjs
 */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
import fs from "node:fs";

const BASE = "http://localhost:3000";
const SHOT = "/home/z/my-project/download";
let idx = 0;
const results = [];
const note = (name, pass, detail = "") => {
  results.push({ name, pass, detail });
  console.log(`${pass ? "PASS" : "FAIL"}  ${name}${detail ? `  — ${detail}` : ""}`);
};
const shot = async (page, name) => {
  idx += 1;
  await page.screenshot({ path: `${SHOT}/verify-task99-${String(idx).padStart(2, "0")}-${name}.png` }).catch(() => {});
};
const login = async (page, email, role, name = "Imperial") => {
  await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
  await page.evaluate(
    ([e, r, n]) => localStorage.setItem("fx-auth", JSON.stringify({ name: n, role: r, email: e })),
    [email, role, name],
  );
  await page.reload({ waitUntil: "domcontentloaded" });
  await page.waitForTimeout(2600);
};

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1920, height: 1000 } });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push("pageerror: " + String(e).slice(0, 200)));
page.on("console", (m) => {
  const t = m.text();
  if (m.type() === "error" && !/40[134]/.test(t)) errors.push(t.slice(0, 200));
});

/* ═══ 1 · pre-login: contained page, stretched credentials modal ═══ */
await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
await page.waitForTimeout(1600);
const pre = await page.evaluate(() => {
  const section = document.querySelector("section#about > div");
  const sec = section ? section.getBoundingClientRect() : null;
  return { contained: !!sec && sec.width > 900 && sec.width < 1300, w: sec ? Math.round(sec.width) : 0 };
});
note("pre-login page back to a contained measure (not edge-to-edge)", pre.contained, `section width ${pre.w}px @1920`);
await page.locator("#home button", { hasText: "Get Started" }).first().click();
await page.waitForTimeout(700);
const modal = await page.evaluate(() => {
  const m = document.querySelector('[role="dialog"][aria-modal="true"] > .fx-card');
  return m ? { w: Math.round(m.getBoundingClientRect().width), email: !!m.querySelector("#lk-email"), pass: !!m.querySelector("#lk-pass") } : null;
});
note(
  "credentials page (after Get Started) is stretched wider",
  !!modal && modal.w >= 540 && modal.w <= 660 && modal.email && modal.pass,
  `modal width ${modal?.w ?? 0}px`,
);
await shot(page, "credentials-page-wide");
await page.mouse.move(960, 990); // park the cursor off the card
await page.evaluate(() => document.querySelector('[role="dialog"][aria-modal="true"]')?.dispatchEvent(new MouseEvent("mousedown", { bubbles: true })));
await page.waitForTimeout(400);

/* ═══ 2 · upgrade expense type — API end-to-end ═══ */
const probeTitle = `t99 probe upgrade ${Date.now()}`;
const created = await page.request
  .post(`${BASE}/api/tasks`, {
    data: {
      title: probeTitle,
      book: "rest",
      deadline: new Date(Date.now() + 7 * 86_400_000).toISOString(),
      maxBudget: 1500,
      kind: "upgrade",
      description: "t99 probe — upgrade kind accepted end to end",
    },
  })
  .then((r) => r.status());
note("tasks API accepts kind=upgrade on create", created === 201, `POST → ${created}`);
const allTasks = await page.request.get(`${BASE}/api/tasks`).then((r) => r.json()).catch(() => ({ tasks: [] }));
const probe = (allTasks.tasks ?? []).find((t) => t.title === probeTitle);
note("upgrade task persisted with its kind", probe?.kind === "upgrade", probe ? String(probe.kind) : "missing");
if (probe) {
  const doneRes = await page.request
    .patch(`${BASE}/api/tasks`, {
      data: { id: probe.id, action: "done", cost: 1200, kind: "upgrade", author: "PRIYA", role: "reception" },
    })
    .then((r) => r.status());
  note("upgrade task closes with a spend", doneRes === 200, `PATCH → ${doneRes}`);
  const upg = await page.request
    .get(`${BASE}/api/expenses?kind=upgrade&limit=100`)
    .then((r) => r.json())
    .catch(() => []);
  const crownRow = (Array.isArray(upg) ? upg : []).find((x) => x.via === "task" && (x.label ?? "").includes("t99 probe"));
  note("closed upgrade spend auto-registers as a crown expense", !!crownRow, crownRow ? `₹${crownRow.amount}` : "missing");
}

/* ═══ 3 · owner session → live dashboard ═══ */
await login(page, "spiceowner@gmail.com", "owner");
await page.waitForTimeout(2400);

/* 3a · mouse follow — one card only, settles back */
const follow = await page.evaluate(async () => {
  const card = document.querySelector('[data-testid="revenue-split-card"]');
  const wall = document.querySelector('[data-testid="room-status-dash"]');
  if (!card || !wall) return { ok: false };
  const fire = (x, y) => window.dispatchEvent(new MouseEvent("mousemove", { clientX: x, clientY: y }));
  const r = card.getBoundingClientRect();
  fire(Math.round(r.left + r.width * 0.75), Math.round(r.top + r.height * 0.6));
  await new Promise((res) => setTimeout(res, 350));
  const mine = parseFloat(card.style.getPropertyValue("--mx") || "0");
  const theirs = parseFloat(wall.style.getPropertyValue("--mx") || "0");
  fire(15, 15);
  await new Promise((res) => setTimeout(res, 350));
  const settled = parseFloat(card.style.getPropertyValue("--mx") || "0");
  return { ok: true, mine, theirs, settled };
});
note(
  "mouse follow: hovered card carries --mx, neighbour stays at 0, settles on leave",
  follow.ok && Math.abs(follow.mine) > 0.05 && follow.theirs === 0 && follow.settled === 0,
  `mine ${follow.mine} · neighbour ${follow.theirs} · settled ${follow.settled}`,
);

/* 3b · HIGH-intensity hover pop (real pointer over a card) */
const splitBox = await page.locator('[data-testid="revenue-split-card"]').boundingBox();
if (splitBox) await page.mouse.move(splitBox.x + splitBox.width * 0.5, splitBox.y + splitBox.height * 0.5);
await page.waitForTimeout(450);
const pop = await page.evaluate(() => {
  const card = document.querySelector('[data-testid="revenue-split-card"]');
  const t = getComputedStyle(card).transform;
  const m = t.match(/matrix\(([^)]+)\)/);
  const v = m ? m[1].split(",").map(parseFloat) : [];
  return { scale: v[0] ?? 1, ty: v[5] ?? 0, shadow: getComputedStyle(card).boxShadow };
});
note(
  "hover pop is HIGH intensity (lift −7 · scale 1.032)",
  pop.scale > 1.02 && pop.ty <= -4,
  `scale ${pop.scale.toFixed(3)} · ty ${pop.ty}px`,
);
note("hover pop deepens the hard shadow", pop.shadow.includes("11px") || pop.shadow.includes("15px"), pop.shadow.slice(0, 60));
await page.mouse.move(10, 10);
await page.waitForTimeout(400);

/* 3c · yearly wall — realistic rooms, centre label inside the ring */
await page.locator('[role="tablist"][aria-label="Dashboard time range"] button', { hasText: "1 YEAR" }).click();
await page.waitForTimeout(1800);
const wallY = await page.evaluate(() => {
  const g = document.querySelector('[data-testid="lroomdash-guests"]');
  const label = document.querySelector('[data-testid="room-status-donut-dash"] .donut-c .fx-label');
  const rows = ["free", "guests", "mnt"].map((k) => document.querySelector(`[data-testid="lroomdash-${k}"]`));
  const amt = g ? Number(g.dataset.amt) : -1;
  const sum = rows.reduce((s, r) => s + (r ? Number(r.dataset.amt) : 0), 0);
  const overflow = label ? label.scrollWidth - label.clientWidth : 99;
  return { amt, sum, overflow, labelTxt: label?.textContent ?? "" };
});
note(
  "yearly wall generalised: guests slice is a realistic fill",
  wallY.amt >= 40 && wallY.amt <= 90,
  `${wallY.amt} of 100 rooms (was ~8)`,
);
note("wall slices still sum to the 100-room house", wallY.sum === 100, String(wallY.sum));
note(
  "lodge donut centre label stays inside the ring",
  wallY.overflow <= 1,
  `"${wallY.labelTxt}" overflow ${wallY.overflow}px`,
);
await page.evaluate(() => document.querySelector('[data-testid="room-status-dash"]')?.scrollIntoView({ block: "center" }));
await page.waitForTimeout(600);
await shot(page, "yearly-wall-realistic");

/* ═══ 4 · tasks — one per column, no pulse, upgrade chips ═══ */
await page.evaluate(() => {
  const btns = [...document.querySelectorAll("aside nav button")];
  btns.find((b) => b.textContent.toLowerCase().includes("tasks"))?.click();
});
await page.waitForTimeout(2400);
const board = await page.evaluate(() => {
  const cards = [...document.querySelectorAll(".tk-card")].slice(0, 3).map((c) => {
    const r = c.getBoundingClientRect();
    return { x: Math.round(r.left), y: Math.round(r.top) };
  });
  const stacked =
    cards.length >= 2 &&
    cards.slice(1).every((c, i) => c.y > cards[i].y && Math.abs(c.x - cards[i].x) < 8);
  const runBar = document.querySelector(".tk-cbar i.run, .tk-cbar i.late");
  const anim = runBar ? getComputedStyle(runBar).animationName : "none";
  return { count: document.querySelectorAll(".tk-card").length, stacked, anim, cards };
});
note("tasks board renders the year of work", board.count > 5, `${board.count} cards in window`);
note("ONE task per column (single-column list)", board.stacked, JSON.stringify(board.cards));
note("pulse animation removed from task bars", board.anim === "none", `animationName=${board.anim}`);
await page.evaluate(() => document.querySelector(".tk-card")?.scrollIntoView({ block: "center" }));
await shot(page, "tasks-single-column");

/* upgrade chip in the owner's add-task modal */
await page.getByTestId("task-add-btn").click();
await page.waitForTimeout(600);
const addKinds = await page.evaluate(() =>
  ["raw_material", "upgrade", "maintenance"].filter((k) => document.querySelector(`[data-testid="task-kind-${k}"]`)).length,
);
note("add-task modal: all 3 expense types (raw/upgrades/maintenance)", addKinds === 3, `${addKinds}/3`);
await shot(page, "add-task-three-kinds");
await page.keyboard.press("Escape");
await page.waitForTimeout(400);

/* ═══ 5 · owner expenses — donut + window + filters (summary view) ═══ */
await page.evaluate(() => {
  const btns = [...document.querySelectorAll("aside nav button")];
  btns.find((b) => b.textContent.toLowerCase().includes("expenses"))?.click();
});
await page.waitForTimeout(2200);
const exp = await page.evaluate(() => {
  const split = document.querySelector('[data-testid="exp-cost-split"]');
  const legend = ["raw_material", "upgrade", "maintenance"].filter((k) => document.querySelector(`[data-testid="exp-split-${k}"]`)).length;
  const ranges = ["today", "7d", "1m", "3m", "1y"].filter((k) => document.querySelector(`[data-testid="exp-range-${k}"]`)).length;
  const kinds = ["all", "raw_material", "upgrade", "maintenance"].filter((k) => document.querySelector(`[data-testid="exp-kind-${k}"]`)).length;
  return {
    enterGone: !document.body.textContent.includes("ENTER EXPENSES FOR"),
    split: !!split,
    legend,
    ranges,
    kinds,
    total: split?.querySelector(".dc-v")?.textContent ?? "",
  };
});
note("expenses: ENTER EXPENSES block replaced by the 3-metric donut", exp.enterGone && exp.split && exp.legend === 3, `slices ${exp.legend}/3 · total ${exp.total}`);
note("expenses: today/7d/month/3m/1y toggle present", exp.ranges === 5, `${exp.ranges}/5`);
note("expenses: ledger carries the 3-expenses filter", exp.kinds === 4, `${exp.kinds}/4 chips`);
await page.evaluate(() => document.querySelector('[data-testid="exp-cost-split"]')?.scrollIntoView({ block: "center" }));
await page.waitForTimeout(500);
await shot(page, "expenses-3-metric-donut");

/* window toggle actually re-scopes: TODAY vs 1 YEAR differ */
const winProbe = await page.evaluate(async () => {
  const read = () => Number(document.querySelector(".mut-chip")?.textContent.match(/\d+/)?.[0] ?? 0);
  const t = read();
  return { t };
});
await page.getByTestId("exp-range-1y").click();
await page.waitForTimeout(500);
const win1y = await page.evaluate(() => Number(document.querySelector(".mut-chip")?.textContent.match(/\d+/)?.[0] ?? 0));
await page.getByTestId("exp-range-today").click();
await page.waitForTimeout(500);
const winToday = await page.evaluate(() => Number(document.querySelector(".mut-chip")?.textContent.match(/\d+/)?.[0] ?? 0));
await page.getByTestId("exp-range-1m").click();
await page.waitForTimeout(400);
note("window toggle re-scopes the whole section", win1y > winToday, `1y=${win1y} entries · today=${winToday} entries · (probe ${winProbe.t})`);

/* ═══ 6 · settings — the whole page ═══ */
const gearVisible = await page.getByTestId("settings-btn").isVisible().catch(() => false);
await page.getByTestId("settings-btn").click();
await page.waitForTimeout(700);
const settings = await page.evaluate(() => ({
  view: !!document.querySelector('[data-testid="settings-view"]'),
  themes: document.querySelectorAll('[data-testid^="settings-theme-"]').length,
  popGone: !document.querySelector('[data-testid="settings-pop"]'),
  nameInput: !!document.querySelector('[data-testid="settings-name-input"]'),
}));
note("settings opens a WHOLE PAGE (gear beside the theme toggle)", gearVisible && settings.view && settings.popGone, JSON.stringify(settings));
note("settings page shows the theme gallery + profile name change", settings.themes >= 4 && settings.nameInput, `${settings.themes} themes`);
await shot(page, "settings-full-page");

/* ═══ 7 · console errors ═══ */
note("zero console/page errors", errors.length === 0, errors.slice(0, 3).join(" | "));

/* ═══ report ═══ */
const passed = results.filter((r) => r.pass).length;
const report = { task: "t99", passed, total: results.length, results, errors };
fs.writeFileSync(`${SHOT}/verify-task99-report.json`, JSON.stringify(report, null, 2));
console.log(`\n${passed}/${results.length} PASS  → download/verify-task99-report.json`);
await browser.close();
process.exit(passed === results.length ? 0 : 1);
