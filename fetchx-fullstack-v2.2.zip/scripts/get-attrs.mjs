import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
const b = await chromium.launch();
const p = await (await b.newContext({ viewport: { width: 1440, height: 900 } })).newPage();
await p.goto("http://localhost:3000", { waitUntil: "domcontentloaded" });
await p.waitForTimeout(2500);
const attrs = await p.evaluate(() => ({
  htmlOpen: document.documentElement.outerHTML.slice(0, document.documentElement.outerHTML.indexOf(">") + 1),
  bodyCls: document.body.className,
}));
console.log(JSON.stringify(attrs, null, 1));
await b.close();
