import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
const b = await chromium.launch();
const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
const page = await ctx.newPage();
await page.addInitScript(() => {
  localStorage.setItem("fx-auth", JSON.stringify({ name: "Imperial", role: "owner", email: "spiceowner@gmail.com" }));
});
const errs = [];
page.on("pageerror", (e) => errs.push(String(e)));
await page.goto("http://localhost:3000/", { waitUntil: "networkidle", timeout: 90000 }).catch((e) => console.log("goto err:", String(e).slice(0, 80)));
await page.waitForSelector("text=Live Dashboard", { timeout: 60000 }).catch((e) => console.log("wait err:", String(e).slice(0, 80)));
await page.waitForTimeout(2000);
const r0 = await page.evaluate(() => ({
  auth: !!localStorage.getItem("fx-auth"),
  hasNav: !!document.querySelector('nav[aria-label="Main mobile"]'),
  bodyText: (document.body.textContent || "").slice(0, 120),
}));
console.log("R0:", JSON.stringify(r0));
console.log("ERRS:", errs.slice(0, 3));
const r = await page.evaluate(() => {
  const rules = [];
  for (const sheet of document.styleSheets) {
    try {
      for (const rule of sheet.cssRules) {
        const sel = rule.selectorText || "";
        if (sel.includes('data-fx-theme="blaze"')) {
          rules.push({
            sel: sel.slice(0, 70),
            page: rule.style ? rule.style.getPropertyValue("--fx-page") : "?",
            decls: rule.style ? rule.style.length : -1,
          });
        }
      }
    } catch (e) { /* cross-origin */ }
  }
  return {
    ds: document.documentElement.dataset.fxTheme,
    htmlPage: getComputedStyle(document.documentElement).getPropertyValue("--fx-page").trim(),
    bodyBg: getComputedStyle(document.body).backgroundColor,
    blazeRuleCount: rules.length,
    blazeRules: rules.slice(0, 4),
  };
});
console.log(JSON.stringify(r, null, 1));
await b.close();
