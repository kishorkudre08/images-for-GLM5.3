/* Task 93c — pixel-verify fetchx-live-demo.html against the live app.
 * Every captured state is replayed from the standalone file at the same
 * viewport and diffed pixel-by-pixel (sharp) vs the reference screenshots.
 * Then the full interaction surface is exercised.
 * Run: node scripts/verify-t93.mjs
 */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
import sharp from "/home/z/.npm-global/lib/node_modules/sharp/dist/index.cjs";
import fs from "node:fs";

const FILE = "file:///home/z/my-project/download/fetchx-live-demo.html";
const CAP = "/home/z/my-project/scripts/capture";
const SHOT = "/home/z/my-project/download";
const results = [];
let idx = 0;
const note = (name, pass, detail = "") => {
  results.push({ name, pass, detail: String(detail).slice(0, 300) });
  console.log(`${pass ? "PASS" : "FAIL"}  ${name}${detail ? `  — ${String(detail).slice(0, 160)}` : ""}`);
};
const shot = async (page, name) => {
  idx += 1;
  await page.screenshot({ path: `${SHOT}/verify-task93-${String(idx).padStart(2, "0")}-${name}.png` }).catch(() => {});
};

async function diffPct(refPath, testBuf) {
  const a = await sharp(refPath).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  const b = await sharp(testBuf).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  if (a.info.width !== b.info.width || a.info.height !== b.info.height) return { pct: 100, note: `size ${a.info.width}x${a.info.height} vs ${b.info.width}x${b.info.height}` };
  const T = 24;
  let diff = 0;
  const n = a.data.length;
  for (let i = 0; i < n; i += 4) {
    if (Math.abs(a.data[i] - b.data[i]) > T || Math.abs(a.data[i + 1] - b.data[i + 1]) > T || Math.abs(a.data[i + 2] - b.data[i + 2]) > T) diff++;
  }
  return { pct: (diff / (n / 4)) * 100 };
}

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push("pageerror: " + String(e).slice(0, 200)));
page.on("console", (m) => {
  const t = m.text();
  if (m.type() === "error" && !/net::|failed to fetch/i.test(t)) errors.push(t.slice(0, 160));
});

await page.goto(FILE, { waitUntil: "domcontentloaded", timeout: 60000 });
await page.waitForTimeout(1800);

/* ── 1 · pixel diffs for every captured state ── */
const STATES = [
  "landing", "landing-modal", "devconsole",
  "dash-all-today", "dash-all-7d", "dash-all-1m", "dash-all-3m", "dash-all-1y",
  "dash-rest-today", "dash-rest-1m", "dash-lodge-today", "dash-lodge-1y",
  "pos", "expenses", "lodge", "manage", "ai-open",
  "reception-pos", "reception-lodge",
];
let worst = { id: "-", pct: 0 };
for (const id of STATES) {
  await page.evaluate((s) => window.FX_DEMO.show(s), id);
  await page.waitForTimeout(id === "landing" ? 1500 : 900);
  const buf = await page.screenshot();
  const ref = `${CAP}/ref-${id}.png`;
  if (!fs.existsSync(ref)) { note(`diff ${id}`, false, "no reference"); continue; }
  const { pct, note: sz } = await diffPct(ref, buf);
  note(`pixel diff ${id}`, pct < 2.0, `${pct.toFixed(2)}% different${sz ? " (" + sz + ")" : ""}`);
  if (pct > worst.pct) worst = { id, pct };
  if (["landing", "dash-all-today", "lodge"].includes(id)) await shot(page, id);
}

/* ── 2 · login flows ── */
await page.evaluate(() => window.FX_DEMO.show("landing"));
await page.waitForTimeout(600);
await page.getByRole("button", { name: "Sign In" }).first().click();
await page.waitForTimeout(400);
await page.locator("#lk-email").fill("spiceowner@gmail.com");
await page.locator("#lk-pass").fill("nope");
await page.keyboard.press("Enter");
await page.waitForTimeout(500);
note("wrong password shows inline error", await page.locator(".jk-shake").isVisible().catch(() => false));
await shot(page, "login-error");

await page.locator("#lk-pass").fill("spiceowner");
await page.keyboard.press("Enter");
await page.waitForTimeout(900);
note("owner login lands on dashboard", (await page.evaluate(() => window.FX_DEMO.state())) === "dash-all-today");
note("dashboard books heading present", await page.getByTestId("books-heading").isVisible().catch(() => false));

/* ── 3 · dashboard tabs + scope switching ── */
await page.getByRole("tab", { name: "1 MONTH", exact: true }).click();
await page.waitForTimeout(700);
note("range tab switches state", (await page.evaluate(() => window.FX_DEMO.state())) === "dash-all-1m");
await page.getByRole("tab", { name: "LODGE", exact: true }).click();
await page.waitForTimeout(700);
note("scope chip switches state", (await page.evaluate(() => window.FX_DEMO.state())) === "dash-lodge-1m");
const wallSum = await page.evaluate(() => {
  let s = 0;
  document.querySelectorAll('[data-testid^="lroomdash-"]').forEach((r) => (s += parseFloat(r.getAttribute("data-amt") || "0")));
  return Math.round(s * 10) / 10;
});
note("wall donut still sums to 100 rooms in demo", Math.abs(wallSum - 100) < 0.001, `sum=${wallSum}`);

/* ── 4 · AI copilot: seeded chips + subscribe prompt ── */
await page.getByRole("tab", { name: "TODAY", exact: true }).click();
await page.waitForTimeout(600);
await page.evaluate(() => window.FX_DEMO.show("ai-open"));
await page.waitForTimeout(600);
await page.locator('aside button:has-text("Summarize my sales for this period")').first().click();
await page.waitForTimeout(1800);
const aiMd = await page.locator('aside .ai-md').count();
note("seeded chip renders hardcoded answer", aiMd > 0, `${aiMd} rich bubbles`);
const aiText = ((await page.locator("aside .ai-md").first().textContent().catch(() => "")) || "");
note("answer carries real seeded figures", /₹|revenue|ROOMS/i.test(aiText));
await shot(page, "ai-seeded-answer");

await page.locator('input[aria-label="Ask the AI copilot"]').fill("What is my best selling dish this week?");
await page.keyboard.press("Enter");
await page.waitForTimeout(1900);
const subTxt = ((await page.locator("aside .ai-md").last().textContent().catch(() => "")) || "");
note("free question → subscribe prompt", /contact fetch-x to purchase the subscription/i.test(subTxt));
await shot(page, "ai-subscribe-prompt");

/* ── 5 · developer console flow ── */
await page.evaluate(() => window.FX_DEMO.show("devconsole"));
await page.waitForTimeout(500);
for (const t of ["dev-acct-owner", "dev-acct-reception-restaurant", "dev-acct-reception-lodge"]) {
  note(`console card ${t}`, await page.getByTestId(t).isVisible().catch(() => false));
}
await page.getByTestId("dev-acct-owner").getByRole("button", { name: /OPEN OWNER/ }).click();
await page.waitForTimeout(700);
note("dev console opens owner dashboard", (await page.evaluate(() => window.FX_DEMO.state())) === "dash-all-today");

/* ── 6 · receptions ── */
await page.evaluate(() => window.FX_DEMO.show("reception-pos"));
await page.waitForTimeout(500);
const restNav = await page.locator("aside nav button").count();
note("restaurant reception: POS only", restNav === 1, `n=${restNav}`);
await page.evaluate(() => window.FX_DEMO.show("reception-lodge"));
await page.waitForTimeout(500);
const lodgeNav = await page.locator("aside nav button").count();
note("lodge reception: LODGE only", lodgeNav === 1, `n=${lodgeNav}`);

/* ── 7 · offline check: no external requests needed ── */
let external = [];
page.on("request", (r) => { if (!r.url().startsWith("file:") && !r.url().startsWith("data:")) external.push(r.url()); });
await page.evaluate(() => window.FX_DEMO.show("landing"));
await page.waitForTimeout(1200);
note("fully offline (no network requests)", external.length === 0, external.slice(0, 2).join(" "));

note("no page errors", errors.length === 0, errors.slice(0, 3).join(" | "));
console.log(`\nworst pixel diff: ${worst.id} ${worst.pct.toFixed(2)}%`);

const failed = results.filter((r) => !r.pass);
console.log(`${results.length - failed.length}/${results.length} PASS`);
fs.writeFileSync(`${SHOT}/verify-task93-report.json`, JSON.stringify(results, null, 2));
await browser.close();
process.exit(failed.length ? 1 : 0);
