/* t101 verify — phone bottom nav (Instagram-style, constant) + settings
 * theme gallery (1 theme per column × 4 stacked page previews, fixed order).
 * t105 — phones are LANDSCAPE-only now: portrait 390×844 must show the
 * rotate gate, landscape 667×375 must clear it and keep the whole suite.
 * Run: node scripts/verify-t101.mjs
 */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
import fs from "node:fs";

const BASE = "http://localhost:3000";
const OUT = "/home/z/my-project/download";
const OWNER = { name: "Imperial", role: "owner", email: "spiceowner@gmail.com" };
const REST = { name: "Imperial", role: "reception_restaurant", email: "spicerestaurant@gmail.com" };

let pass = 0, fail = 0;
const ok = (cond, label) => {
  if (cond) { pass++; console.log(`  PASS  ${label}`); }
  else { fail++; console.log(`  FAIL  ${label}`); }
};

const browser = await chromium.launch();
const errors = [];

/* ══ t105 · portrait phone 390×844 — the landscape gate ══ */
const ctx = await browser.newContext({
  viewport: { width: 390, height: 844 },
  deviceScaleFactor: 2,
  isMobile: true,
  hasTouch: true,
});
const page = await ctx.newPage();
page.on("pageerror", (e) => errors.push("phone: " + String(e)));
await page.addInitScript((u) => localStorage.setItem("fx-auth", JSON.stringify(u)), OWNER);

console.log("── PHONE · portrait 390×844 → landscape gate ──");
await page.goto(BASE, { waitUntil: "networkidle", timeout: 30000 }).catch(() => {});
await page.waitForTimeout(2200);

const gate = page.locator(".fx-rotate-gate");
ok(await gate.isVisible(), "portrait phone (390×844) sees the rotate gate");
const gateBox = await gate.boundingBox();
ok(!!gateBox && Math.round(gateBox.width) === 390 && Math.round(gateBox.height) >= 800,
  `gate covers the whole portrait screen (${gateBox ? Math.round(gateBox.width) + "×" + Math.round(gateBox.height) : "none"})`);
const gateText = (await gate.textContent().catch(() => "")) || "";
ok(/rotate your phone/i.test(gateText) && /landscape/i.test(gateText), "gate tells the user to rotate to landscape");
await page.screenshot({ path: `${OUT}/verify-t105-gate-portrait.png` });

/* rotate the SAME page to landscape 667×375 (iPhone SE class) → gate clears */
await page.setViewportSize({ width: 667, height: 375 });
await page.waitForTimeout(700);
ok(!(await gate.isVisible()), "rotating to landscape 667×375 clears the gate");

console.log("── PHONE · owner bottom nav (landscape 667×375) ──");
await page.goto(BASE, { waitUntil: "networkidle", timeout: 30000 }).catch(() => {});
await page.waitForTimeout(2200);

const bar = page.locator('nav[aria-label="Main mobile"]');
ok(await bar.isVisible(), "mobile bottom nav is visible on load");

const barInfo = await bar.evaluate((el) => {
  const r = el.getBoundingClientRect();
  const btns = [...el.querySelectorAll(":scope > button")];
  const icons = btns.map((b) => (b.querySelector("svg") ? 1 : 0)).reduce((a, b) => a + b, 0);
  return {
    bottom: Math.round(window.innerHeight - r.bottom),
    width: Math.round(r.width),
    h: Math.round(r.height),
    btns: btns.length,
    icons,
    labels: btns.map((b) => b.getAttribute("aria-label")),
    texts: [...el.querySelectorAll("button")].map((b) => (b.textContent || "").trim()).filter(Boolean).length,
  };
});
ok(barInfo.bottom === 0, `nav sits flush at the bottom (gap=${barInfo.bottom}px)`);
ok(barInfo.btns === 7 && barInfo.icons === 7, `7 icon buttons (6 sections + settings) — got ${barInfo.btns}/${barInfo.icons}`);
ok(barInfo.texts === 7, "icon + tiny section label on every button (discoverable switching)");
ok(barInfo.width === 667, `bar spans the full 667px landscape width (got ${barInfo.width})`);
ok(barInfo.h >= 52 && barInfo.h <= 80, `comfortable touch height (${barInfo.h}px)`);

/* constant across the owner's 6 sections */
const OWNER_LABELS = ["Live Dashboard", "Tasks", "Menu Manager", "Expenses", "Lodge Front Desk", "Employee"]; // t113 — Employee · t115 — Menu Manager replaces POS Billing
for (const label of OWNER_LABELS) {
  await bar.locator(`button[aria-label="${label}"]`).click();
  await page.waitForTimeout(650);
  const visible = await bar.isVisible();
  const active = await bar.locator(`button[aria-current="page"]`).getAttribute("aria-label");
  ok(visible && active === label, `nav constant & '${label}' activates from the bar`);
}
await page.screenshot({ path: `${OUT}/verify-t101-phone-nav-management.png` });

/* settings from the bar */
await page.locator('[data-testid="settings-btn-mobile"]').click();
await page.waitForTimeout(700);
ok(await page.locator('[data-testid="settings-view"]').isVisible(), "gear in the bar opens the settings page");
ok(await bar.isVisible(), "nav still constant on the settings page");

console.log("── PHONE · settings theme gallery ──");
const THEMES = ["classic", "dragonfruit", "lime", "emerald", "iris", "blaze", "neon", "cherry", "azure", "cyanreef"];
const ORDER = ["light-prelogin", "light-dashboard", "dark-prelogin", "dark-dashboard"]; // t104 — 1×4 vertical rectangle per theme
let colCount = 0, orderOK = true, sizeOK = true, imgOK = true;
for (const id of THEMES) {
  const col = page.locator(`[data-testid="settings-theme-${id}"]`);
  if (await col.count()) colCount++;
  const boxes = [];
  for (const k of ORDER) {
    const b = page.locator(`[data-testid="settings-theme-${id}-${k}"]`);
    if (!(await b.count())) { orderOK = false; continue; }
    const r = await b.evaluate((el) => {
      el.scrollIntoView({ block: "center" });
      const q = el.getBoundingClientRect();
      const img = el.querySelector("img");
      return { w: Math.round(q.width), h: Math.round(q.height), vis: q.height > 40 && q.width > 100, imgLoaded: !!img && img.complete && img.naturalWidth > 0, tall: !!img && img.naturalHeight > img.naturalWidth * 0.4 };
    });
    if (!r.vis) sizeOK = false;
    if (!r.imgLoaded) imgOK = false;
    boxes.push(k);
  }
  const domOrder = await col.evaluate((el) => {
    const ids = [...el.querySelectorAll("[data-testid]")].map((e) => e.dataset.testid).filter((s) => s.includes("prelogin") || s.includes("dashboard"));
    return ids;
  });
  const want = ORDER.map((k) => `settings-theme-${id}-${k}`);
  if (JSON.stringify(domOrder) !== JSON.stringify(want)) orderOK = false;
  if (boxes.length !== 4) orderOK = false;
}
ok(colCount === 10, `10 theme blocks (1 theme per column) — got ${colCount}`);
ok(orderOK, "every block stacks the 4 previews in the 1×4 order light-prelogin > light-dashboard > dark-prelogin > dark-dashboard");
ok(sizeOK, "all 40 preview blocks render at readable size");
ok(imgOK, "all 40 previews are REAL screenshots (<img> loaded with natural pixels)");

/* apply a theme from the gallery */
const before = await page.evaluate(() => document.documentElement.dataset.fxTheme);
await page.locator('[data-testid="settings-theme-emerald"]').click();
await page.waitForTimeout(600);
const after = await page.evaluate(() => document.documentElement.dataset.fxTheme);
ok(after === "emerald" && before !== "emerald", `tapping a column applies the theme (${before || "default(classic)"} → ${after})`);
await page.evaluate(() => document.querySelector('[data-testid="settings-themes"]').scrollIntoView());
await page.waitForTimeout(400);
await page.screenshot({ path: `${OUT}/verify-t101-phone-themes.png`, fullPage: false });
const fullShot = await page.evaluate(() => {
  const el = document.querySelector('[data-testid="settings-themes"]');
  el.scrollIntoView();
  return el.getBoundingClientRect().height;
});
await page.screenshot({ path: `${OUT}/verify-t101-phone-themes-top.png` });
ok(fullShot > 800, `gallery is a tall visible wall (themes card ≈ ${Math.round(fullShot)}px)`);
await page.locator('[data-testid="settings-theme-classic"]').click();
await page.waitForTimeout(400);

/* receptions: 3 sections + settings in the bar — fresh context so the
   owner init-script can't stomp the session. t113 — Attendance joins. */
const rctx = await browser.newContext({ viewport: { width: 667, height: 375 }, isMobile: true, hasTouch: true });
const rpage = await rctx.newPage();
rpage.on("pageerror", (e) => errors.push("rest-phone: " + String(e)));
await rpage.addInitScript((u) => localStorage.setItem("fx-auth", JSON.stringify(u)), REST);
await rpage.goto(BASE, { waitUntil: "networkidle" }).catch(() => {});
await rpage.waitForTimeout(1800);
const rbar = rpage.locator('nav[aria-label="Main mobile"]');
const restInfo = await rbar.evaluate((el) => [...el.querySelectorAll(":scope > button")].map((b) => b.getAttribute("aria-label")));
ok(restInfo.length === 4 && restInfo.includes("POS Billing") && restInfo.includes("Tasks") && restInfo.includes("Attendance"), `restaurant reception bar = Tasks + POS + Attendance + settings (got ${restInfo.join("|")})`);

/* t113 — the Attendance view opens with its register */
await rbar.locator('button[aria-label="Attendance"]').click();
await rpage.waitForTimeout(900);
const att = await rpage.evaluate(() => ({
  view: !!document.querySelector('[data-testid="attendance-view"]'),
  date: !!document.querySelector('[data-testid="attendance-date"]'),
  all: !!document.querySelector('[data-testid="attendance-all-present"]') && !!document.querySelector('[data-testid="attendance-all-absent"]'),
  noLate: !/LATE/i.test(document.querySelector('[data-testid="attendance-view"]')?.textContent ?? ""),
}));
ok(att.view && att.date && att.all, "reception opens Attendance: register + date selector + quick actions");
ok(att.noLate, "no late mechanism anywhere in the register (by request)");

/* zero horizontal overflow anywhere on phone */
const over = await page.evaluate(() => {
  const d = document.documentElement;
  return Math.max(d.scrollWidth, document.body.scrollWidth) - window.innerWidth;
});
ok(over <= 0, `no horizontal overflow at 667×375 landscape (over=${over}px)`);

/* ══ desktop context — gallery sanity ══ */
const dctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const dpage = await dctx.newPage();
dpage.on("pageerror", (e) => errors.push("desktop: " + String(e)));
await dpage.addInitScript((u) => localStorage.setItem("fx-auth", JSON.stringify(u)), OWNER);
await dpage.goto(BASE, { waitUntil: "networkidle", timeout: 30000 }).catch(() => {});
await dpage.waitForTimeout(1800);
ok(!(await dpage.locator('nav[aria-label="Main mobile"]').isVisible()), "desktop keeps the sidebar, no mobile bar");
ok(!(await dpage.locator(".fx-rotate-gate").isVisible()), "desktop (1440×900) never shows the rotate gate");
await dpage.locator('[data-testid="settings-btn"]').click();
await dpage.waitForTimeout(700);
const dCols = await dpage.locator('[data-testid="settings-themes"] [role="button"][aria-pressed]').count();
ok(dCols === 10, `desktop gallery shows 10 one-per-column themes (${dCols})`);
await dpage.evaluate(() => document.querySelector('[data-testid="settings-themes"]').scrollIntoView());
await dpage.waitForTimeout(400);
await dpage.screenshot({ path: `${OUT}/verify-t101-desktop-themes.png` });
/* hover drift works on a preview block (independent motion) — t104: the
   THEME BLOCK carries fx-card (hover pop), each shot cell its own fx-pop-in */
const themeBlock = dpage.locator('[data-testid="settings-theme-classic"]');
await themeBlock.hover();
await dpage.waitForTimeout(500);
const hovered = await themeBlock.evaluate((el) => el.classList.contains("fx-card") && el.classList.contains("fx-pop-in"));
ok(hovered, "theme blocks carry their own motion classes (fx-card + fx-pop-in)");
const cellMotion = await dpage.locator('[data-testid="settings-theme-classic-light-dashboard"]').evaluate((el) => el.classList.contains("fx-pop-in"));
ok(cellMotion, "each preview cell pops in on its own (fx-pop-in)");

/* ══ t104 — the developer account is gone from the storefront ══ */
const lctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const lpage = await lctx.newPage();
lpage.on("pageerror", (e) => errors.push("landing: " + String(e)));
await lpage.goto(BASE, { waitUntil: "networkidle", timeout: 30000 }).catch(() => {});
await lpage.waitForTimeout(1500);
const ltext = (await lpage.locator("body").textContent()) || "";
ok(!ltext.includes("spice1234"), "no developer email (spice1234) anywhere on the landing");
ok(!/DEVELOPER/.test(ltext.replace(/DEVELOPER VIEW/g, "")), "no DEVELOPER account row on the landing");
ok(await lpage.getByText("Demo access — all three accounts").isVisible(), "demo-access heading says all three accounts");
const rowCount = await lpage.locator("code.fx-num").count();
ok(rowCount >= 6, `demo table shows 3 accounts × (email+password) — got ${rowCount} code chips`);
await lpage.getByRole("button", { name: "Sign In" }).first().click();
await lpage.waitForTimeout(800);
const mtext = (await lpage.locator("body").textContent()) || "";
ok(!mtext.includes("spice1234"), "no developer row in the sign-in modal tap-to-fill");
await lpage.screenshot({ path: `${OUT}/verify-t104-landing-modal.png` });
await lctx.close();

ok(errors.length === 0, `zero page errors (${errors.length})`);
if (errors.length) console.log(errors.slice(0, 5).join("\n"));

await browser.close();
console.log(`\nRESULT: ${pass}/${pass + fail} PASS`);
fs.writeFileSync(`${OUT}/verify-t101-report.json`, JSON.stringify({ pass, fail, at: new Date().toISOString() }, null, 2));
process.exit(fail ? 1 : 0);
