/* Task 93a — capture the REAL app: rendered DOM per state, compiled CSS,
 * webfonts, and reference screenshots. Output → scripts/capture/.
 * Run: node scripts/capture-demo.mjs
 */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
import fs from "node:fs";

const BASE = "http://localhost:3000";
const OUT = "/home/z/my-project/scripts/capture";
fs.mkdirSync(OUT, { recursive: true });

const OWNER = { name: "Imperial", role: "owner", email: "spiceowner@gmail.com" };
const REST = { name: "Imperial", role: "reception_restaurant", email: "spicerestaurant@gmail.com" };
const LODGE = { name: "Imperial", role: "reception_lodge", email: "spicelodge@gmail.com" };

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();

const settle = async (ms = 2600) => {
  await page.waitForLoadState("networkidle", { timeout: 20000 }).catch(() => {});
  await page.waitForTimeout(ms);
};

const grab = async (id) => {
  // neutralize the mouse parallax so refs are reproducible (demo opens at 0/0)
  await page.evaluate(() => {
    document.documentElement.style.setProperty("--mx", "0");
    document.documentElement.style.setProperty("--my", "0");
  });
  await page.waitForTimeout(450);
  const html = await page.evaluate(() => {
    const clone = document.body.cloneNode(true);
    clone.querySelectorAll("script").forEach((s) => s.remove());
    // freeze the sidebar heartbeat text so capture == replay
    return clone.innerHTML;
  });
  const attrs = await page.evaluate(() => {
    const d = document.documentElement;
    return { lang: d.lang, cls: d.className, ds: { ...d.dataset }, bodyCls: document.body.className };
  });
  fs.writeFileSync(`${OUT}/state-${id}.html`, html);
  console.log("captured", id, `${(html.length / 1024).toFixed(0)}KB`);
  return attrs;
};

const shotRef = async (id) => {
  await page.screenshot({ path: `${OUT}/ref-${id}.png` }).catch(() => {});
};

/* ── 1 · landing (modal closed) ── */
await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
await settle(2800);
await grab("landing");
await shotRef("landing");

/* ── 2 · landing with the sign-in modal open ── */
await page.getByRole("button", { name: "Sign In" }).first().click();
await settle(700);
await grab("landing-modal");
await shotRef("landing-modal");

/* ── 3 · owner dashboard — ALL × 5 ranges, then REST × 5, LODGE × 5 ── */
await page.evaluate((u) => localStorage.setItem("fx-auth", JSON.stringify(u)), OWNER);
await page.goto(BASE, { waitUntil: "domcontentloaded" });
await settle(3200);
const TABS = ["TODAY", "7 DAYS", "1 MONTH", "3 MONTHS", "1 YEAR"];
const KEYS = ["today", "7d", "1m", "3m", "1y"];
const SCOPES = [["all", "ALL BUSINESS"], ["rest", "RESTAURANT"], ["lodge", "LODGE"]];
for (const [scopeId, scopeLabel] of SCOPES) {
  if (scopeId !== "all") {
    await page.getByRole("tab", { name: scopeLabel, exact: true }).click();
    await settle(2000);
  }
  for (let i = 0; i < TABS.length; i++) {
    await page.getByRole("tab", { name: TABS[i], exact: true }).click();
    await settle(2000);
    await grab(`dash-${scopeId}-${KEYS[i]}`);
    await shotRef(`dash-${scopeId}-${KEYS[i]}`);
  }
}

/* ── 4 · other owner stations ── */
const NAVS = [
  ["Menu Manager", "menu"], // t115 — the owner no longer carries POS Billing
  ["Expenses", "expenses"],
  ["Tasks", "tasks"],
  ["Lodge Front Desk", "lodge"],
  ["Employee", "manage"],
];
for (const [label, id] of NAVS) {
  await page.getByRole("button", { name: new RegExp(`^${label}`) }).first().click();
  await settle(2200);
  await grab(id);
  await shotRef(id);
}

/* ── 4b · settings page (gear button beside the theme toggle) ── */
await page.locator('[data-testid="settings-btn"]').first().click();
await settle(2200);
await grab("settings");
await shotRef("settings");

/* ── 5 · AI copilot open on the dashboard ── */
await page.getByRole("button", { name: "Live Dashboard" }).first().click();
await settle(2500);
await page.locator('[data-testid="ai-fab"], button:has-text("ASK FETCH-X"), button[aria-label*="AI" i]').first().click({ timeout: 8000 }).catch(async () => {
  // fallback: any floating action button bottom-right
  await page.evaluate(() => {
    const btns = [...document.querySelectorAll("button")];
    const fab = btns.find((b) => /ask|copilot|fetch-x/i.test(b.getAttribute("aria-label") || "") || /ASK/i.test(b.textContent || ""));
    fab?.click();
  });
});
await settle(900);
const aiOpen = await page.evaluate(() => !!document.querySelector(".ai-md, [class*=ai-panel], [class*=ai-wrap]"));
console.log("ai panel open detected:", aiOpen);
await grab("ai-open");
await shotRef("ai-open");

/* ── 6 · reception sessions ── */
await page.evaluate((u) => localStorage.setItem("fx-auth", JSON.stringify(u)), REST);
await page.goto(BASE, { waitUntil: "domcontentloaded" });
await settle();
await grab("reception-pos");
await shotRef("reception-pos");

/* t113 — the receptions' 4th section: attendance register */
await page.getByRole("button", { name: "Attendance" }).first().click();
await settle(2000);
await grab("reception-attendance");
await shotRef("reception-attendance");

await page.evaluate((u) => localStorage.setItem("fx-auth", JSON.stringify(u)), LODGE);
await page.goto(BASE, { waitUntil: "domcontentloaded" });
await settle();
await grab("reception-lodge");
await shotRef("reception-lodge");

await page.getByRole("button", { name: "Attendance" }).first().click();
await settle(2000);
await grab("reception-attendance-lodge");
await shotRef("reception-attendance-lodge");

/* ── 7 · stylesheets + webfonts ── */
await page.evaluate((u) => localStorage.setItem("fx-auth", JSON.stringify(u)), OWNER);
await page.goto(BASE, { waitUntil: "domcontentloaded" });
await settle(1500);
const css = await page.evaluate(async () => {
  const urls = [...document.querySelectorAll('link[rel="stylesheet"]')].map((l) => l.href);
  const inline = [...document.querySelectorAll("style")].map((s) => s.textContent);
  const fetched = [];
  for (const u of urls) {
    try {
      fetched.push(await (await fetch(u)).text());
    } catch {}
  }
  return { urls, fetched, inline };
});
console.log("stylesheets:", css.urls.length, "inline:", css.inline.length);
fs.writeFileSync(`${OUT}/app.css`, [...css.fetched, ...css.inline].join("\n\n/* ─── */\n\n"));
fs.writeFileSync(`${OUT}/css-urls.json`, JSON.stringify(css.urls, null, 2));

/* font URLs from the CSS */
const fontUrls = [...new Set((fs.readFileSync(`${OUT}/app.css`, "utf8").match(/url\(([^)]+\.woff2)\)/g) || []).map((m) => m.slice(4, -1)))];
console.log("fonts:", fontUrls.length);
let n = 0;
for (const u of fontUrls) {
  /* prod build emits relative font urls (`../media/…`) — normalise to absolute */
  const abs = u.startsWith("http") ? u : new URL(u, BASE + "/").href;
  const buf = Buffer.from(await (await fetch(abs)).arrayBuffer());
  const name = u.split("/").pop();
  fs.writeFileSync(`${OUT}/font-${name}`, buf);
  n++;
}
console.log("fonts saved:", n);

await browser.close();
console.log("CAPTURE DONE");
