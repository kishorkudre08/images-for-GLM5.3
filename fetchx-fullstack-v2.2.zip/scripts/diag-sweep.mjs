/* Task 77 — full-site diagnostic sweep (user away: find loops, visual & logical bugs).
 * Walks landing → sign-in → every view × scope × theme, captures console/page errors,
 * failed requests, slow renders and re-render loop heuristics. Screenshots → download/.
 * Run: node scripts/diag-sweep.mjs
 */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
import fs from "node:fs";

const BASE = "http://localhost:3000";
const SHOT_DIR = "/home/z/my-project/download";
const issues = [];
const notes = [];
let shotIdx = 0;

const shot = async (page, name) => {
  shotIdx += 1;
  const file = `${SHOT_DIR}/diag-${String(shotIdx).padStart(2, "0")}-${name}.png`;
  await page.screenshot({ path: file, fullPage: false }).catch(() => {});
  notes.push(`shot ${file}`);
};

function attach(page, bucket) {
  page.on("console", (m) => {
    const t = m.type();
    if (t === "error" || t === "warning") {
      const txt = m.text().slice(0, 300);
      if (bucket) bucket.push({ kind: t, txt });
    }
  });
  page.on("pageerror", (e) => bucket && bucket.push({ kind: "pageerror", txt: String(e).slice(0, 300) }));
  page.on("requestfailed", (r) =>
    bucket && bucket.push({ kind: "requestfailed", txt: `${r.method()} ${r.url()} :: ${r.failure()?.errorText}`.slice(0, 300) }),
  );
  page.on("response", (r) => {
    if (r.status() >= 400 && bucket) bucket.push({ kind: `http-${r.status()}`, txt: r.url().slice(0, 300) });
  });
}

/* count DOM mutations for 2.5s on a "resting" page — re-render loops never rest */
async function loopProbe(page) {
  return page.evaluate(
    () =>
      new Promise((res) => {
        let n = 0;
        const ro = new MutationObserver((m) => (n += m.length));
        ro.observe(document.body, { childList: true, subtree: true, attributes: true, characterData: true });
        setTimeout(() => {
          ro.disconnect();
          res(n);
        }, 2500);
      }),
  );
}

const step = async (label, fn) => {
  const t0 = Date.now();
  const errs = [];
  try {
    await fn(errs);
  } catch (e) {
    errs.push({ kind: "step-error", txt: String(e).slice(0, 400) });
  }
  const ms = Date.now() - t0;
  const real = errs.filter((e) => !/Autofill|Download the React DevTools/i.test(e.txt));
  if (real.length) issues.push({ label, ms, errors: real });
  console.log(`[${String(ms).padStart(5)}ms] ${label}${real.length ? `  ⚠ ${real.length} issue(s)` : "  ok"}`);
};

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();
attach(page, null); // collect globally too

/* ── 1 · landing ── */
await step("landing light", async () => {
  await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 45000 });
  await page.waitForTimeout(1500);
  await shot(page, "landing-light");
});
await step("landing dark", async () => {
  const btn = page.getByLabel("Toggle dark mode");
  if (await btn.count()) await btn.first().click();
  await page.waitForTimeout(900);
  await shot(page, "landing-dark");
  const back = page.getByLabel("Toggle dark mode");
  if (await back.count()) await back.first().click();
});

/* ── 2 · sign in ── */
await step("sign-in flow", async () => {
  await page.getByRole("button", { name: "Sign In" }).first().click();
  const dlg = page.getByRole("dialog", { name: "Sign in" });
  await dlg.waitFor({ timeout: 10000 });
  await dlg.locator("#lk-email").fill("spice1234@gmail.com");
  await dlg.locator("#lk-pass").fill("spice1234");
  await dlg.getByRole("button", { name: /Sign In/i }).last().click();
  await page.waitForTimeout(2500);
  await shot(page, "dashboard-all-scope");
});

/* ── 3 · dashboard: scopes + ranges + loop probe ── */
await step("dashboard loop probe", async () => {
  const n = await loopProbe(page);
  notes.push(`dashboard mutation count over 2.5s idle: ${n}`);
  if (n > 400) issues.push({ label: "dashboard-loop-probe", errors: [{ kind: "render-loop", txt: `${n} mutations while idle` }] });
});
await step("dashboard scope tabs", async (errs) => {
  const tabs = page.getByRole("tablist", { name: "Business view" }).getByRole("tab");
  const count = await tabs.count();
  notes.push(`scope tabs found: ${count}`);
  for (let i = 0; i < count; i++) {
    const t = tabs.nth(i);
    const name = (await t.textContent())?.trim();
    await t.click();
    await page.waitForTimeout(1600);
    await shot(page, `dashboard-scope-${String(name).toLowerCase().replace(/[^a-z]+/g, "-")}`);
  }
});
await step("dashboard range switch", async () => {
  const btn = page.getByRole("button", { name: /THIS WEEK|WEEK/i }).first();
  if (await btn.count()) {
    await btn.click();
    await page.waitForTimeout(1800);
    await shot(page, "dashboard-week");
    await page.getByRole("button", { name: /TODAY/i }).first().click();
    await page.waitForTimeout(1200);
  } else notes.push("no range buttons matched");
});

/* ── 4 · every nav view ── */
const views = ["POS Billing", "Expenses", "Lodge Front Desk", "Management", "Live Dashboard"];
for (const v of views) {
  await step(`view: ${v}`, async (errs) => {
    await page.getByRole("button", { name: v, exact: false }).first().click();
    await page.waitForTimeout(2200);
    await shot(page, `view-${v.toLowerCase().replace(/[^a-z]+/g, "-")}`);
  });
  if (v === "Lodge Front Desk") {
    await step("lodge: room hover/dialog probe", async () => {
      const rooms = page.locator(".fx-pop, [class*=room]");
      const n = await rooms.count();
      notes.push(`lodge room-ish blocks: ${n}`);
    });
  }
  if (v === "Management") {
    await step("management: subsections", async () => {
      const heads = page.locator("button[aria-expanded]");
      const n = await heads.count();
      for (let i = 0; i < Math.min(n, 4); i++) {
        await heads.nth(i).click();
        await page.waitForTimeout(900);
      }
      await shot(page, "management-open");
    });
  }
  if (v === "POS Billing") {
    await step("pos: tile add probe", async () => {
      const tile = page.locator(".fx-tile").first();
      if (await tile.count()) {
        await tile.click();
        await page.waitForTimeout(900);
        await shot(page, "pos-cart");
      } else notes.push("no .fx-tile found");
    });
  }
  if (v === "Expenses") {
    await step("expenses: datepicker probe", async () => {
      const dp = page.getByRole("button", { name: /Pick a date/i }).first();
      if (await dp.count()) {
        await dp.click();
        await page.waitForTimeout(600);
        await shot(page, "expenses-datepicker");
        await page.keyboard.press("Escape");
      } else notes.push("no datepicker found");
    });
  }
}

/* ── 5 · dark mode across a data view ── */
await step("dashboard dark", async () => {
  await page.getByRole("button", { name: "Live Dashboard", exact: false }).first().click();
  await page.waitForTimeout(1500);
  await page.getByLabel("Toggle dark mode").first().click();
  await page.waitForTimeout(1600);
  await shot(page, "dashboard-dark");
  await page.getByLabel("Toggle dark mode").first().click();
});

/* ── 6 · AI copilot ── */
await step("ai copilot roundtrip", async (errs) => {
  const fab = page.getByLabel("Open Fetch-X AI assistant");
  if (!(await fab.count())) {
    notes.push("AI FAB not visible on this view");
    return;
  }
  await fab.first().click();
  await page.waitForTimeout(1200);
  await shot(page, "ai-panel-open");
  const box = page.getByLabel("Ask the AI copilot");
  if (await box.count()) {
    await box.fill("How many bills today?");
    await page.getByLabel("Send message").click();
    const t0 = Date.now();
    await page.waitForTimeout(20000); // generous for LLM
    await shot(page, "ai-answer");
    notes.push(`ai roundtrip waited ${Date.now() - t0}ms`);
    await page.getByLabel("Collapse AI panel").click().catch(() => {});
  }
});

/* ── 7 · mobile viewport sanity ── */
await step("mobile 390px dashboard", async () => {
  const mp = await ctx.newPage();
  attach(mp, null);
  await mp.setViewportSize({ width: 390, height: 844 });
  await mp.goto(BASE, { waitUntil: "domcontentloaded", timeout: 45000 });
  await mp.waitForTimeout(2500);
  await shot(mp, "mobile-dashboard");
  const bodyW = await mp.evaluate(() => document.documentElement.scrollWidth);
  if (bodyW > 400) issues.push({ label: "mobile-horizontal-scroll", errors: [{ kind: "visual", txt: `scrollWidth ${bodyW} > 390` }] });
  await mp.close();
});

await browser.close();

/* ── report ── */
const report = { generatedAt: new Date().toISOString(), issues, notes };
fs.writeFileSync("/home/z/my-project/scripts/diag-report.json", JSON.stringify(report, null, 2));
console.log("\n══════ DIAG SWEEP SUMMARY ══════");
console.log(`steps with issues: ${issues.length}`);
for (const i of issues) {
  console.log(`• ${i.label}`);
  for (const e of i.errors) console.log(`   [${e.kind}] ${e.txt}`);
}
console.log(`\nshots: ${shotIdx}, notes: ${notes.length}`);
