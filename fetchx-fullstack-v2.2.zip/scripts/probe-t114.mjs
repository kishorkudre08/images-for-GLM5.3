// t114 probe — what do BOTH receptions actually see? full-page shots of
// pos / lodge / tasks / attendance + section inventory per view.
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;

const BASE = "http://localhost:3000";
const REST = { name: "Imperial", role: "reception_restaurant", email: "spicerestaurant@gmail.com" };
const LODGE = { name: "Imperial", role: "reception_lodge", email: "spicelodge@gmail.com" };

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
page.on("pageerror", (e) => console.log("PAGEERROR:", String(e).slice(0, 200)));
page.on("console", (m) => { if (m.type() === "error") console.log("CONSOLE-ERR:", m.text().slice(0, 200)); });

async function login(u) {
  await page.goto(BASE, { waitUntil: "domcontentloaded" });
  await page.evaluate((x) => localStorage.setItem("fx-auth", JSON.stringify(x)), u);
  await page.goto(BASE, { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(2500);
}

async function snap(tag) {
  await page.screenshot({ path: `download/verify-t114-${tag}.png`, fullPage: true });
  const inv = await page.evaluate(() => {
    const labels = [...document.querySelectorAll(".fx-label")].map((e) => e.textContent.trim());
    const tests = [...document.querySelectorAll("[data-testid]")].map((e) => e.getAttribute("data-testid"));
    return { labels, tests: tests.filter((t) => /stn-|station|attendance/.test(t)) };
  });
  console.log(`── ${tag}: fx-labels =`, JSON.stringify(inv.labels));
  console.log(`   testids =`, JSON.stringify(inv.tests));
}

await login(REST);
await snap("rest-pos");
await page.getByRole("button", { name: "Attendance" }).first().click();
await page.waitForTimeout(2000);
await snap("rest-attendance");

await login(LODGE);
await snap("lodge-desk");
await page.getByRole("button", { name: "Attendance" }).first().click();
await page.waitForTimeout(2000);
await snap("lodge-attendance");

await browser.close();
console.log("DONE");
