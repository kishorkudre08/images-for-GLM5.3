/* Task 100 — verify the rebuilt fetchx-live-demo.html on desktop + phone.
 * Run: node scripts/verify-demo-t100.mjs
 */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
import fs from "node:fs";

const FILE = "/home/z/my-project/download/fetchx-live-demo.html";
const OUT = "/home/z/my-project/download";
const results = [];
const ok = (name, cond, extra = "") => {
  results.push({ name, pass: !!cond });
  console.log(`${cond ? "✓" : "✗ FAIL"}  ${name}${extra ? " — " + extra : ""}`);
};

const browser = await chromium.launch();

/* ══ 1 · DESKTOP 1440×900 ══ */
{
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  await page.goto("file://" + FILE, { waitUntil: "domcontentloaded" });
  await page.waitForFunction(() => window.FX_START && document.querySelectorAll("template[data-state]").length === 28, null, { timeout: 30000 });
  ok("desktop: 26 states hydrated (devconsole removed)", true);
  await page.waitForTimeout(900);

  ok("desktop: boot state = landing", await page.evaluate(() => window.FX_DEMO.state()) === "landing");
  await page.screenshot({ path: `${OUT}/verify-t100-01-landing.png` });

  await page.evaluate(() => window.FX_DEMO.show("landing-modal"));
  await page.waitForTimeout(400);
  const modalFill = await page.evaluate(() => {
    const codes = [...document.querySelectorAll("#fx-stage code")].map((c) => c.textContent.trim());
    return codes.filter((c) => c.includes("@gmail.com")).length >= 3;
  });
  ok("desktop: modal tap-to-fill chips present", modalFill);
  await page.evaluate(() => window.FX_DEMO.show("landing"));
  await page.waitForTimeout(300);

  /* sign in as owner through the modal form */
  await page.evaluate(() => window.FX_DEMO.show("landing-modal"));
  await page.waitForTimeout(300);
  await page.fill('input[type="email"]', "spiceowner@gmail.com");
  await page.fill('input[type="password"]', "spiceowner");
  await page.click('#fx-stage form button[type="submit"], #fx-stage form button');
  await page.waitForTimeout(600);
  ok("desktop: owner sign-in → dash-all-today", await page.evaluate(() => window.FX_DEMO.state()) === "dash-all-today");
  await page.screenshot({ path: `${OUT}/verify-t100-02-dash.png` });

  /* range + scope switching */
  await page.click('#fx-stage [role="tablist"][aria-label="Dashboard time range"] [role="tab"]:has-text("1 YEAR")');
  await page.waitForTimeout(400);
  ok("desktop: 1 YEAR tab → dash-all-1y", await page.evaluate(() => window.FX_DEMO.state()) === "dash-all-1y");
  await page.click('#fx-stage [role="tablist"][aria-label="Business view"] [role="tab"]:has-text("LODGE")');
  await page.waitForTimeout(400);
  ok("desktop: LODGE scope → dash-lodge-1y", await page.evaluate(() => window.FX_DEMO.state()) === "dash-lodge-1y");

  /* sidebar nav incl. the new Tasks item */
  const navHasTasks = await page.evaluate(() => [...document.querySelectorAll("#fx-stage aside nav button")].some((b) => (b.textContent || "").trim() === "Tasks"));
  ok("desktop: sidebar has Tasks item", navHasTasks);
  await page.click('#fx-stage aside nav button:has-text("Tasks")');
  await page.waitForTimeout(400);
  ok("desktop: Tasks → tasks state", await page.evaluate(() => window.FX_DEMO.state()) === "tasks");
  await page.screenshot({ path: `${OUT}/verify-t100-03-tasks.png` });

  /* settings gear in the desktop sidebar */
  const gearThere = await page.evaluate(() => !!document.querySelector('#fx-stage [data-testid="settings-btn"]'));
  ok("desktop: settings gear present", gearThere);
  await page.click('#fx-stage [data-testid="settings-btn"]');
  await page.waitForTimeout(400);
  ok("desktop: gear → settings state", await page.evaluate(() => window.FX_DEMO.state()) === "settings");
  await page.screenshot({ path: `${OUT}/verify-t100-04-settings.png` });
  const themeBtns = await page.evaluate(() => document.querySelectorAll("#fx-stage [data-testid^='settings-theme-']").length);
  ok("desktop: settings theme gallery renders", themeBtns > 0, `${themeBtns} swatches`);
  await page.click("#fx-stage [data-testid^='settings-theme-']");
  await page.waitForTimeout(250);
  ok("desktop: theme swatch toast", await page.evaluate(() => document.getElementById("fx-toast")?.classList.contains("on") || false));

  /* POS + AI */
  await page.evaluate(() => window.FX_DEMO.show("pos"));
  await page.waitForTimeout(400);
  await page.evaluate(() => window.FX_DEMO.show("dash-all-today"));
  await page.waitForTimeout(300);
  const fab = await page.$('#fx-stage button[aria-label="Open Fetch-X AI assistant"]');
  if (fab) { await fab.click(); await page.waitForTimeout(400); }
  ok("desktop: AI FAB → ai-open", await page.evaluate(() => window.FX_DEMO.state()) === "ai-open");
  const chipAsk = await page.evaluate(() => {
    const seed = (window.AI_SEED || [])[0];
    if (!seed) return false;
    const btn = [...document.querySelectorAll('#fx-stage [aria-label="Fetch-X AI assistant"] button')].find((b) => (b.textContent || "").trim() === seed.q);
    if (btn) btn.click();
    return !!btn;
  });
  await page.waitForTimeout(1800);
  const answered = await page.evaluate(() => !!document.querySelector('#fx-stage .ai-md'));
  ok("desktop: AI chip asks + answer renders", chipAsk && answered);
  await page.screenshot({ path: `${OUT}/verify-t100-05-ai.png` });
  const closeAi = await page.$('#fx-stage button[aria-label="Collapse AI panel"]');
  if (closeAi) { await closeAi.click(); await page.waitForTimeout(300); }
  ok("desktop: AI close → back to dash", await page.evaluate(() => window.FX_DEMO.state()) === "dash-all-today");

  /* lodge reception session */
  await page.evaluate(() => window.FX_DEMO.show("reception-lodge"));
  await page.waitForTimeout(400);
  const lodgeOk = await page.evaluate(() => /WALL|FRONT DESK|ROOMS/i.test(document.querySelector("#fx-stage")?.textContent || ""));
  ok("desktop: lodge reception state renders", lodgeOk);

  ok("desktop: zero page errors", errors.length === 0, errors.slice(0, 2).join(" | "));
  await ctx.close();
}

/* ══ 2 · PHONE 390×844 ══ */
{
  const ctx = await browser.newContext({
    viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true,
  });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  await page.goto("file://" + FILE, { waitUntil: "domcontentloaded" });
  await page.waitForFunction(() => document.querySelectorAll("template[data-state]").length === 28, null, { timeout: 30000 });
  await page.waitForTimeout(900);

  /* t105 — portrait phone hits the landscape gate first */
  const gateOn = await page.evaluate(() => {
    const g = document.querySelector(".fx-rotate-gate");
    return !!g && getComputedStyle(g).display !== "none";
  });
  ok("phone portrait: landscape gate shows before anything else", gateOn);
  await page.setViewportSize({ width: 667, height: 375 });
  await page.waitForTimeout(700);
  const gateOff = await page.evaluate(() => {
    const g = document.querySelector(".fx-rotate-gate");
    return !g || getComputedStyle(g).display === "none";
  });
  ok("phone landscape 667×375: gate cleared, landing reachable", gateOff);
  await page.screenshot({ path: `${OUT}/verify-t100-10-phone-landing.png` });

  const landingOverflow = await page.evaluate(() => Math.max(document.documentElement.scrollWidth, document.body.scrollWidth) - window.innerWidth);
  ok("phone: landing no horizontal overflow", landingOverflow <= 2, `${landingOverflow}px`);

  /* sign in owner */
  await page.evaluate(() => window.FX_DEMO.show("landing-modal"));
  await page.waitForTimeout(300);
  await page.fill('input[type="email"]', "spiceowner@gmail.com");
  await page.fill('input[type="password"]', "spiceowner");
  await page.click('#fx-stage form button[type="submit"], #fx-stage form button');
  await page.waitForTimeout(600);

  const modalOverflow = await page.evaluate(() => Math.max(document.documentElement.scrollWidth, document.body.scrollWidth) - window.innerWidth);
  ok("phone: dashboard no horizontal overflow", modalOverflow <= 2, `${modalOverflow}px`);
  const bottomNavVisible = await page.evaluate(() => {
    const n = document.querySelector('#fx-stage nav[aria-label="Main mobile"]');
    if (!n) return false;
    const r = n.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  });
  ok("phone: bottom nav visible on dashboard", bottomNavVisible);
  await page.screenshot({ path: `${OUT}/verify-t100-11-phone-dash.png` });

  /* bottom nav drives state switches */
  await page.click('#fx-stage nav[aria-label="Main mobile"] button[aria-label="Tasks"]');
  await page.waitForTimeout(400);
  ok("phone: bottom nav TASKS → tasks state", await page.evaluate(() => window.FX_DEMO.state()) === "tasks");
  await page.screenshot({ path: `${OUT}/verify-t100-12-phone-tasks.png` });

  // t115 — the owner's phone bar runs the MENU MANAGER (POS Billing is the reception's)
  const menuBtn = await page.$('#fx-stage nav[aria-label="Main mobile"] button[aria-label="Menu Manager"]');
  ok("phone: owner bottom nav carries Menu Manager (t115)", !!menuBtn);
  if (menuBtn) { await menuBtn.click(); await page.waitForTimeout(400); }
  ok("phone: bottom nav MENU → menu state", await page.evaluate(() => window.FX_DEMO.state()) === "menu");
  await page.screenshot({ path: `${OUT}/verify-t100-13-phone-menu.png` });

  /* captured settings gear in the bar (t101 — no longer injected) */
  const gear = await page.$('#fx-stage nav[aria-label="Main mobile"] button[aria-label="Open settings"]');
  ok("phone: settings gear captured in bottom nav", !!gear);
  if (gear) { await gear.click(); await page.waitForTimeout(400); }
  ok("phone: gear → settings state", await page.evaluate(() => window.FX_DEMO.state()) === "settings");
  await page.screenshot({ path: `${OUT}/verify-t100-14-phone-settings.png` });

  /* dashboard via bottom nav + AI panel fits */
  await page.click('#fx-stage nav[aria-label="Main mobile"] button[aria-label="Live Dashboard"]');
  await page.waitForTimeout(400);
  const fab = await page.$('#fx-stage button[aria-label="Open Fetch-X AI assistant"]');
  if (fab) { await fab.click(); await page.waitForTimeout(400); }
  const aiFits = await page.evaluate(() => {
    const p = document.querySelector('#fx-stage [aria-label="Fetch-X AI assistant"]');
    if (!p) return false;
    const r = p.getBoundingClientRect();
    return r.width <= window.innerWidth + 2 && r.left >= -2;
  });
  ok("phone: AI panel fits viewport", aiFits);
  await page.screenshot({ path: `${OUT}/verify-t100-15-phone-ai.png` });

  /* lodge reception on phone */
  await page.evaluate(() => window.FX_DEMO.show("reception-lodge"));
  await page.waitForTimeout(500);
  const lodgeOverflow = await page.evaluate(() => Math.max(document.documentElement.scrollWidth, document.body.scrollWidth) - window.innerWidth);
  ok("phone: lodge desk no horizontal overflow", lodgeOverflow <= 2, `${lodgeOverflow}px`);
  await page.screenshot({ path: `${OUT}/verify-t100-16-phone-lodge.png` });

  ok("phone: zero page errors", errors.length === 0, errors.slice(0, 2).join(" | "));
  await ctx.close();
}

await browser.close();
const pass = results.filter((r) => r.pass).length;
fs.writeFileSync(`${OUT}/verify-t100-report.json`, JSON.stringify(results, null, 2));
console.log(`\n${pass}/${results.length} PASS`);
if (pass !== results.length) process.exit(1);
