/* t104 probe — dashboard without sidebar + prelogin top at 880px,
 * to finalise the theme-preview crops. */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;

const BASE = "http://localhost:3000";
const OUT = "/home/z/my-project/download";
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 880, height: 900 }, deviceScaleFactor: 1 });
const page = await ctx.newPage();

/* ── prelogin top ── */
await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
await page.waitForSelector("text=finally intelligent", { timeout: 60000 });
await page.waitForTimeout(1500);
await page.screenshot({ path: `${OUT}/probe-prelogin.png`, clip: { x: 0, y: 0, width: 880, height: 620 } });
console.log("prelogin probed");

/* ── dashboard, sidebar hidden ── */
await page.evaluate(() => {
  localStorage.setItem("fx-auth", JSON.stringify({ name: "Imperial", role: "owner", email: "spiceowner@gmail.com" }));
});
await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
await page.waitForSelector("text=Live Dashboard", { timeout: 60000 });
await page.waitForTimeout(2800);
await page.addStyleTag({ content: "aside{display:none!important}" });
await page.waitForTimeout(400);
await page.screenshot({ path: `${OUT}/probe-dash-full.png`, fullPage: false });
/* full page height probe */
const h = await page.evaluate(() => document.querySelector("main")?.scrollHeight || 0);
console.log("main scrollHeight:", h);
await page.screenshot({ path: `${OUT}/probe-dash-top.png`, clip: { x: 0, y: 0, width: 880, height: 760 } });
await browser.close();
console.log("PROBE DONE");
