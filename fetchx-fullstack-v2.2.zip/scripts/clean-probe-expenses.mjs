/* t118 hygiene — repeated verify runs kept writing probe artifacts into the
 * cost books (7× "Signage refresh for the counter" station entries, 7×
 * "TASK · t99 probe upgrade" task spends). They are not real data; they also
 * pushed the restaurant's TODAY window into a fake loss. This removes the
 * probe artifacts (keeping ONE of each as history) so the books tell the
 * truth again. Run: node scripts/clean-probe-expenses.mjs
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const PROBE_PREFIXES = ["TASK · t99 probe upgrade", "Signage refresh for the counter"];

async function main() {
  for (const label of PROBE_PREFIXES) {
    const rows = await db.expense.findMany({
      where: { label: { startsWith: label } },
      orderBy: { spentOn: "asc" },
    });
    if (rows.length <= 1) {
      console.log(`"${label}": ${rows.length} entry — nothing to clean`);
      continue;
    }
    /* keep the earliest, drop the rest (the repeats are verify-run artifacts) */
    const [, ...extras] = rows;
    const res = await db.expense.deleteMany({
      where: { id: { in: extras.map((e) => e.id) } },
    });
    console.log(`"${label}": kept 1, deleted ${res.count} probe artifacts`);
  }
  const d0 = new Date();
  d0.setHours(0, 0, 0, 0);
  for (const book of ["rest", "lodge"]) {
    const today = await db.expense.findMany({ where: { book, spentOn: { gte: d0 } } });
    const sum = today.reduce((s, x) => s + x.amount, 0);
    console.log(`${book} TODAY: ${today.length} entries · ₹${Math.round(sum).toLocaleString("en-IN")}`);
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
