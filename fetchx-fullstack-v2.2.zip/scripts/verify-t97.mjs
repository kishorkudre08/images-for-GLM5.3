/* Task 97 verification — TASKS (owner-forwarded work):
 * add-task modal (book + budget chips + expense type + deadline + description
 * rule), receptions see their book only, post updates, close with cost
 * (never above the owner's assumption), crown expense auto-registered in the
 * ledger, budget/completion graphs, TASK PULSE fully removed, landing page
 * stretched edge-to-edge, four-account + wall regressions.
 * Screenshots → download/verify-task97-*.png
 * Run: node scripts/verify-t97.mjs
 */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
import fs from "node:fs";

const BASE = "http://localhost:3000";
const SHOT = "/home/z/my-project/download";
let idx = 0;
const results = [];
const note = (name, pass, detail = "") => {
  results.push({ name, pass, detail });
  console.log(`${pass ? "PASS" : "FAIL"}  ${name}${detail ? `  — ${detail}` : ""}`);
};
const shot = async (page, name) => {
  idx += 1;
  await page.screenshot({ path: `${SHOT}/verify-task97-${String(idx).padStart(2, "0")}-${name}.png` }).catch(() => {});
};

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push("pageerror: " + String(e).slice(0, 200)));
page.on("console", (m) => {
  const t = m.text();
  if (m.type() === "error" && !/40[134]/.test(t)) errors.push(t.slice(0, 200));
});

const login = async (auth) => {
  await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 60000 });
  await page.evaluate((u) => localStorage.setItem("fx-auth", JSON.stringify(u)), auth);
  await page.reload({ waitUntil: "domcontentloaded" });
  await page.waitForTimeout(3000);
};
const openTasks = async () => {
  await page.getByRole("button", { name: /Tasks/i }).first().click();
  await page.waitForTimeout(1200);
};
const apiTasks = async () => (await (await fetch(`${BASE}/api/tasks`)).json()).tasks;
/* t98 — a full year of seeded tasks shares the board now, so look cards up by title */
const cardIndexOf = async (needle) => {
  const texts = (await page.locator('[data-testid^="tk-card-"]').allTextContents().catch(() => [])) || [];
  return texts.findIndex((t) => t.includes(needle));
};

/* ══ 1 · OWNER — the section, its band and its graphs ══ */
await login({ name: "Imperial", role: "owner", email: "spiceowner@gmail.com" });

const navLabels = await page.locator("aside nav button").allTextContents();
note("owner nav has 6 items incl TASKS", navLabels.length === 6 && navLabels.some((t) => /Tasks/i.test(t)), navLabels.join("|"));

await openTasks();
note("tasks view renders", await page.getByTestId("tasks-view").isVisible().catch(() => false));
const bandTxt = (await page.locator('[data-testid="tasks-view"] .fx-band').textContent().catch(() => "")) || "";
note("tier band reads 02 · OWNER'S TASKS", bandTxt.includes("02") && bandTxt.includes("OWNER'S TASKS"), bandTxt.slice(0, 60));
note("graphs moved out of the tasks section (t98 — they live on the live dashboard)", (await page.getByTestId("tk-graph-budget").count()) === 0 && (await page.getByTestId("tk-graph-completion").count()) === 0);
note("board carries the seeded year history (no empty state)", (await page.getByTestId("tk-empty").count()) === 0);
const rangeTabs = await page.locator('[data-testid^="tk-range-"]').count();
note("tasks time toggle renders 5 windows (today…1y)", rangeTabs === 5, `${rangeTabs}`);
await shot(page, "tasks-board-empty");

/* ══ 2 · ADD TASK — budgeted task blocked without type/description, then valid ══ */
await page.getByTestId("task-add-btn").click();
await page.waitForTimeout(600);
note("add-task modal opens", await page.getByTestId("task-add-modal").isVisible().catch(() => false));

await page.getByTestId("task-book-lodge").click();
await page.getByTestId("task-title-input").fill("Repaint the 12-door wing");
await page.getByTestId("task-budget-input").fill("2000");
const flagTxt = (await page.getByTestId("task-budget-flag").textContent()) || "";
note("budget flag flips to BUDGETED ₹2,000", flagTxt.includes("BUDGETED") && flagTxt.includes("2,000"), flagTxt);

await page.getByTestId("task-submit").click();
await page.waitForTimeout(400);
const errTxt = (await page.getByTestId("task-form-err").textContent().catch(() => "")) || "";
note("blocked without expense type + description", errTxt.includes("expense type"), errTxt.slice(0, 70));
await shot(page, "add-modal-validation");

await page.getByTestId("task-kind-maintenance").click();
await page.getByTestId("task-desc-input").fill("Paint and hardware for the whole 12-doors wing before the season starts.");
await page.getByTestId("task-submit").click();
await page.waitForTimeout(1800);

let tasks = await apiTasks();
const budgeted = tasks.find((t) => t.title === "Repaint the 12-door wing");
note("budgeted task created via UI", !!budgeted && budgeted.maxBudget === 2000 && budgeted.kind === "maintenance" && budgeted.book === "lodge");
const budgetedId = budgeted?.id ?? "";

const repaintIdx = await cardIndexOf("Repaint the 12-door wing");
const cardTxt = repaintIdx >= 0 ? ((await page.getByTestId(`tk-card-${repaintIdx}`).textContent().catch(() => "")) || "") : "";
note("card carries LODGE / MAX ₹2,000 / MAINTENANCE / DUE chips", cardTxt.includes("LODGE") && cardTxt.includes("MAX ₹2,000") && cardTxt.includes("MAINTENANCE") && cardTxt.includes("DUE"), cardTxt.slice(0, 110));
note("forwarding note auto-posted by the owner", cardTxt.includes("max budget of ₹2,000"));

/* ══ 3 · free task for the restaurant ══ */
await page.getByTestId("task-add-btn").click();
await page.waitForTimeout(500);
await page.getByTestId("task-title-input").fill("Quarterly deep-clean of the kitchen exhaust");
await page.getByTestId("task-submit").click();
await page.waitForTimeout(1800);

tasks = await apiTasks();
const free = tasks.find((t) => t.title === "Quarterly deep-clean of the kitchen exhaust");
note("free task created without budget", !!free && free.maxBudget === null && free.book === "rest");
const card1Txt = (await page.locator('[data-testid^="tk-card-"]').allTextContents().catch(() => [])) || [];
note("free task card shows FREE TASK chip", card1Txt.some((t) => t.includes("Quarterly deep-clean") && t.includes("FREE TASK")), `cards=${card1Txt.length}`);

note("owner's board still shows the two forwarded tasks at top", (await page.locator('[data-testid^="tk-card-"]').count()) >= 2);
await shot(page, "tasks-board-two-tasks");

/* ══ 4 · server-side over-budget guard (API level) ══ */
const overRes = await fetch(`${BASE}/api/tasks`, {
  method: "PATCH",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ id: budgetedId, action: "done", cost: 2500, author: "guard-test" }),
});
note("server rejects cost above the owner's assumption", overRes.status === 400, `status=${overRes.status}`);
const overErr = await overRes.json().catch(() => ({}));
note("rejection explains the budget cap", String(overErr.error || "").includes("₹2,000"), String(overErr.error || "").slice(0, 80));

/* ══ 5 · pulse removal regressions on the dashboard ══ */
await page.getByRole("button", { name: /Live Dashboard/i }).first().click();
await page.waitForTimeout(2500);
note("dashboard has no TASK PULSE section", (await page.getByTestId("task-pulse").count()) === 0);
note("dashboard has no pulse cards", (await page.locator('[data-testid^="task-card-"]').count()) === 0);
note("books heading still in place (t91 regression)", await page.getByTestId("books-heading").isVisible().catch(() => false));
const dashSum = await page.evaluate(() =>
  [...document.querySelectorAll('[data-testid^="lroomdash-"]')].reduce((s, el) => s + Number(el.getAttribute("data-amt") || 0), 0),
);
note("wall donut slices still sum to 100", dashSum === 100, `sum=${dashSum}`);

const aiFab = page.getByRole("button", { name: "Open Fetch-X AI assistant" });
if (await aiFab.isVisible().catch(() => false)) {
  await aiFab.click();
  await page.waitForTimeout(800);
  const panelTxt = (await page.locator("body").textContent()) || "";
  note("AI quick-chips: housekeeping pulse chip removed", !panelTxt.includes("How is my housekeeping doing today?"));
  note("AI quick-chips: the original four remain", panelTxt.includes("Summarize my sales for this period") && panelTxt.includes("Tips to grow revenue this month"));
  await shot(page, "ai-panel-no-housekeeping-chip");
  await page.getByRole("button", { name: "Collapse AI panel" }).click().catch(() => {});
  await page.waitForTimeout(400);
}

/* ══ 6 · LODGE RECEPTION — book-locked board, updates, closing with cost ══ */
await login({ name: "Imperial", role: "reception_lodge", email: "spicelodge@gmail.com" });
const lodgeNav = await page.locator("aside nav button").allTextContents();
note("lodge reception nav = LODGE + TASKS only", lodgeNav.length === 2 && /Tasks/i.test(lodgeNav.join(" ")), lodgeNav.join("|"));

await openTasks();
note("reception has no ADD TASK button", (await page.getByTestId("task-add-btn").count()) === 0);
note("reception has no graphs", (await page.getByTestId("tk-graph-budget").count()) === 0 && (await page.getByTestId("tk-graph-completion").count()) === 0);
const lockTxt = (await page.locator('[data-testid="tasks-view"]').textContent().catch(() => "")) || "";
note("board is book-locked to LODGE", lockTxt.includes("YOUR BOOK · LODGE"));
const lodgeCards = await page.locator('[data-testid^="tk-card-"]').count();
const yearStart = Date.now() - 366 * 86_400_000;
const lodgeExpected = tasks.filter((t) => t.book === "lodge" && t.status === "open" && new Date(t.createdAt).getTime() >= yearStart).length;
note("only lodge OPEN tasks visible", lodgeCards === lodgeExpected, `ui=${lodgeCards} api=${lodgeExpected}`);
note("no restaurant task leaked through", !lockTxt.includes("Quarterly deep-clean"));

const lodgeRepaintIdx = await cardIndexOf("Repaint the 12-door wing");
await page.getByTestId(`tk-expand-${lodgeRepaintIdx}`).click();
await page.waitForTimeout(500);
await page.getByTestId(`tk-note-input-${lodgeRepaintIdx}`).fill("Primer coat done — second coat and hardware left for tomorrow.");
await page.getByTestId(`tk-note-send-${lodgeRepaintIdx}`).click();
await page.waitForTimeout(1500);
const notesTxt = (await page.locator('[data-testid="tasks-view"]').textContent().catch(() => "")) || "";
note("update posted and visible to the owner's board", notesTxt.includes("Primer coat done"), "");

await page.getByTestId(`tk-done-btn-${lodgeRepaintIdx}`).click();
await page.waitForTimeout(600);
note("completion modal opens with the owner's assumption", await page.getByTestId("task-done-modal").isVisible().catch(() => false));
const assumTxt = (await page.getByTestId("task-done-assumption").textContent().catch(() => "")) || "";
note("assumption reads ₹2,000 MAX · MAINTENANCE", assumTxt.includes("₹2,000") && assumTxt.includes("MAINTENANCE"), assumTxt.slice(0, 70));

await page.getByTestId("task-cost-input").fill("2500");
await page.waitForTimeout(300);
const overTxt = (await page.getByTestId("task-cost-err").textContent().catch(() => "")) || "";
note("over-budget blocked in the form", overTxt.includes("Above the owner's assumption"));
const submitDisabled = await page.getByTestId("task-done-submit").isDisabled().catch(() => true);
note("submit disabled while over budget", submitDisabled === true);
await shot(page, "done-modal-over-budget");

await page.getByTestId("task-cost-input").fill("1800");
await page.waitForTimeout(300);
const underTxt = (await page.getByTestId("task-cost-under").textContent().catch(() => "")) || "";
note("under-budget hint shows ₹200 saved", underTxt.includes("₹200 UNDER"), underTxt);
await page.getByTestId("task-done-submit").click();
await page.waitForTimeout(2000);

tasks = await apiTasks();
const closedTask = tasks.find((t) => t.id === budgetedId);
note("task closed with actualCost ₹1,800", closedTask?.status === "done" && closedTask?.actualCost === 1800, JSON.stringify({ s: closedTask?.status, c: closedTask?.actualCost }));
// the board defaults to the OPEN filter — flip to DONE to see the closed task
await page.getByRole("button", { name: "DONE", exact: true }).click();
await page.waitForTimeout(800);
const doneTxt = (await page.locator('[data-testid="tasks-view"]').textContent().catch(() => "")) || "";
note("card result line shows the comparison", doneTxt.includes("Repaint room 12 doors") && doneTxt.includes("₹1,800") && doneTxt.includes("₹2,000 ASSUMED") && doneTxt.includes("10% UNDER"));
note("auto-note logged the spend with the crown", doneTxt.includes("owner's crown"));
await shot(page, "lodge-desk-after-close");

/* ══ 7 · OWNER — the crown in the expense ledger ══ */
await login({ name: "Imperial", role: "owner", email: "spiceowner@gmail.com" });
await page.getByRole("button", { name: /Expenses/i }).first().click();
await page.waitForTimeout(1800);
const crownRow = page.locator('[data-testid="exp-crown"]').first();
note("crown chip present in the ledger", await crownRow.isVisible().catch(() => false));
const wingRows = await page.locator('[data-testid="exp-crown"]').evaluateAll((chips) =>
  chips
    .map((c) => c.closest("div.rounded-xl")?.textContent ?? "")
    .filter((t) => t.includes("Repaint the 12-door wing")),
);
note("crown row is the task spend — right amount, book and label", wingRows.some((t) => t.includes("₹1,800") && t.includes("LODGE")), (wingRows[0] ?? "none").slice(0, 120));
await page.getByTestId("exp-crown").first().scrollIntoViewIfNeeded().catch(() => {});
await page.waitForTimeout(500);
await shot(page, "expenses-crown-row");

/* ══ 8 · owner board — status filters reflect the close ══ */
await openTasks();
const openTexts = (await page.locator('[data-testid="tasks-view"]').textContent().catch(() => "")) || "";
note("OPEN filter hides the closed task", !openTexts.includes("Repaint the 12-door wing") && openTexts.includes("Quarterly deep-clean"));
await page.getByRole("button", { name: "DONE", exact: true }).click();
await page.waitForTimeout(600);
const doneTexts = (await page.locator('[data-testid="tasks-view"]').textContent().catch(() => "")) || "";
note("DONE filter shows the closed task with its result", doneTexts.includes("Repaint the 12-door wing") && doneTexts.includes("₹1,800"));
await shot(page, "owner-done-filter");

/* ══ 9 · LANDING — contained again (t99 reversed the stretch; the CREDENTIALS
   page that pops up after Get Started is the stretched one now) ══ */
await page.evaluate(() => localStorage.removeItem("fx-auth"));
await page.goto(BASE, { waitUntil: "networkidle", timeout: 60000 });
await page.waitForTimeout(1500);
const widths = await page.evaluate(() => {
  const w = (el) => (el ? el.getBoundingClientRect().width : 0);
  return {
    vw: window.innerWidth,
    header: w(document.querySelector("header")),
    hero: w(document.querySelector("#home > div")),
    about: w(document.querySelector("#about > div")),
    features: w(document.querySelector("#features > div")),
    footer: w(document.querySelector("footer > div")),
  };
});
const contained = (x) => x > 1100 && x < 1300; // the 1200px measure
note("viewport 1440", widths.vw === 1440, JSON.stringify(widths));
note("header contained + centered (t99)", Math.abs(widths.header - 1216) < 8, `header=${widths.header}`);
note("hero contained", contained(widths.hero), `hero=${widths.hero}`);
note("about contained", contained(widths.about), `about=${widths.about}`);
note("features contained", contained(widths.features), `features=${widths.features}`);
note("footer contained", contained(widths.footer), `footer=${widths.footer}`);
await shot(page, "landing-contained");
await page.screenshot({ path: `${SHOT}/verify-task97-landing-full.png`, fullPage: true }).catch(() => {});

/* ══ 10 · four accounts + developer console regression ══ */
await login({ name: "Fetch-X", role: "developer", email: "spice1234@gmail.com" });
const devTxt = (await page.locator("body").textContent()) || "";
note("developer console with 3 accounts under it", /Developer Console/i.test(devTxt) && devTxt.includes("3 accounts under this developer") && devTxt.includes("RESTAURANT RECEPTION") && devTxt.includes("LODGE RECEPTION"));
await shot(page, "developer-console");

await login({ name: "Imperial", role: "reception_restaurant", email: "spicerestaurant@gmail.com" });
const restNav = await page.locator("aside nav button").allTextContents();
note("restaurant reception nav = POS + TASKS only", restNav.length === 2 && /Tasks/i.test(restNav.join(" ")), restNav.join("|"));
await openTasks();
const restLock = (await page.locator('[data-testid="tasks-view"]').textContent().catch(() => "")) || "";
note("restaurant desk sees its free task", restLock.includes("Quarterly deep-clean") && restLock.includes("YOUR BOOK · RESTAURANT"));
await shot(page, "restaurant-tasks");

/* ══ report ══ */
const passCount = results.filter((r) => r.pass).length;
const summary = { suite: "task97-tasks", total: results.length, passed: passCount, failed: results.length - passCount, errors, results };
fs.writeFileSync(`${SHOT}/verify-task97-report.json`, JSON.stringify(summary, null, 2));
console.log(`\n${passCount}/${results.length} PASS · errors=${errors.length}`);
await browser.close();
process.exit(passCount === results.length && errors.length === 0 ? 0 : 1);
