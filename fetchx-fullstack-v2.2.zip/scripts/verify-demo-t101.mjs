/* Task 101 — verify the rebuilt fetchx-live-demo.html: Instagram-style
 * phone bottom nav (pure icons, aria-label driven) + settings theme gallery
 * with 4 stacked page previews per theme column. Desktop + phone.
 * Run: node scripts/verify-demo-t101.mjs
 */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
import fs from "node:fs";

const FILE = "/home/z/my-project/download/fetchx-live-demo.html";
const OUT = "/home/z/my-project/download";
const results = [];
const ok = (name, cond, extra = "") => {
  results.push({ name, pass: !!cond });
  console.log(`${cond ? "✓" : "✗ FAIL"}  ${name}${extra ? " — " + extra : ""}`);
};

const browser = await chromium.launch();
const ORDER = ["light-prelogin", "light-dashboard", "dark-prelogin", "dark-dashboard"]; // t104 — 1×4 vertical rectangle per theme
const THEMES = ["classic", "dragonfruit", "lime", "emerald", "iris", "blaze", "neon", "cherry", "azure", "cyanreef"];

/* ══ 1 · DESKTOP 1440×900 ══ */
{
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  await page.goto("file://" + FILE, { waitUntil: "domcontentloaded" });
  await page.waitForFunction(() => window.FX_START && document.querySelectorAll("template[data-state]").length === 28, null, { timeout: 30000 });
  ok("desktop: 26 states hydrated (devconsole state removed)", true);
  await page.waitForTimeout(900);
  ok("desktop: boot state = landing", await page.evaluate(() => window.FX_DEMO.state()) === "landing");

  /* sign in as owner */
  await page.evaluate(() => window.FX_DEMO.show("landing-modal"));
  await page.waitForTimeout(300);
  await page.fill('input[type="email"]', "spiceowner@gmail.com");
  await page.fill('input[type="password"]', "spiceowner");
  await page.click('#fx-stage form button[type="submit"], #fx-stage form button');
  await page.waitForTimeout(600);
  ok("desktop: owner sign-in → dash-all-today", await page.evaluate(() => window.FX_DEMO.state()) === "dash-all-today");
  await page.screenshot({ path: `${OUT}/verify-t101-d01-dash.png` });

  /* the per-band THEME button is gone */
  const themeBtn = await page.evaluate(() => !!document.querySelector('#fx-stage [aria-label="Open theme gallery"]'));
  ok("desktop: per-band THEME button removed", !themeBtn);

  /* settings → the 1-column × 4-preview gallery */
  await page.evaluate(() => window.FX_DEMO.show("settings"));
  await page.waitForTimeout(500);
  const gal = await page.evaluate(({ THEMES, ORDER }) => {
    const cols = THEMES.map((id) => !!document.querySelector(`#fx-stage [data-testid="settings-theme-${id}"]`));
    let blocks = 0, orderOK = true;
    for (const id of THEMES) {
      const ids = [...document.querySelectorAll(`#fx-stage [data-testid="settings-theme-${id}"] [data-testid]`)]
        .map((e) => e.getAttribute("data-testid"))
        .filter((s) => s.includes("prelogin") || s.includes("dashboard"));
      const want = ORDER.map((k) => `settings-theme-${id}-${k}`);
      if (JSON.stringify(ids) !== JSON.stringify(want)) orderOK = false;
      blocks += ids.length;
    }
    return { cols, blocks, orderOK };
  }, { THEMES, ORDER });
  ok("desktop: all 10 theme columns render (1 per column)", gal.cols.every(Boolean));
  ok("desktop: every column stacks 4 previews in fixed order", gal.orderOK && gal.blocks === 40, `${gal.blocks} preview blocks`);
  await page.evaluate(() => document.querySelector('#fx-stage [data-testid="settings-themes"]').scrollIntoView());
  await page.waitForTimeout(400);
  await page.screenshot({ path: `${OUT}/verify-t101-d02-themes.png` });

  const toastOn = await page.evaluate(() => {
    document.querySelector('#fx-stage [data-testid="settings-theme-emerald"]').click();
    return new Promise((res) => setTimeout(() => res(!!document.getElementById("fx-toast")?.classList.contains("on")), 250));
  });
  ok("desktop: theme column click → hint toast", toastOn);
  const imgs = await page.evaluate(() =>
    [...document.querySelectorAll("#fx-stage img")].map((i) => ({ src: i.getAttribute("src") || "", ok: i.complete && i.naturalWidth > 0 })),
  );
  ok("desktop: gallery ships the 40 REAL screenshots inlined", imgs.length === 40 && imgs.every((i) => i.ok && i.src.startsWith("data:image/jpeg")), `${imgs.filter((i) => i.ok).length}/40 loaded`);

  ok("desktop: zero page errors", errors.length === 0, errors.slice(0, 2).join(" | "));
  await ctx.close();
}

/* ══ 2 · PHONE 390×844 ══ */
{
  const ctx = await browser.newContext({
    viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true,
  });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  await page.goto("file://" + FILE, { waitUntil: "domcontentloaded" });
  await page.waitForFunction(() => document.querySelectorAll("template[data-state]").length === 28, null, { timeout: 30000 });
  await page.waitForTimeout(900);

  /* t105 — portrait phone: the demo ships the landscape gate too */
  const gateVis = await page.evaluate(() => {
    const g = document.querySelector(".fx-rotate-gate");
    return !!g && getComputedStyle(g).display !== "none";
  });
  ok("phone portrait: rotate gate covers the demo", gateVis);
  await page.screenshot({ path: `${OUT}/verify-t105-demo-gate-portrait.png` });
  await page.setViewportSize({ width: 667, height: 375 });
  await page.waitForTimeout(700);
  const gateGone = await page.evaluate(() => {
    const g = document.querySelector(".fx-rotate-gate");
    return !g || getComputedStyle(g).display === "none";
  });
  ok("phone landscape 667×375: gate cleared", gateGone);

  /* sign in owner */
  await page.evaluate(() => window.FX_DEMO.show("landing-modal"));
  await page.waitForTimeout(300);
  await page.fill('input[type="email"]', "spiceowner@gmail.com");
  await page.fill('input[type="password"]', "spiceowner");
  await page.click('#fx-stage form button[type="submit"], #fx-stage form button');
  await page.waitForTimeout(600);

  const nav = await page.evaluate(() => {
    const n = document.querySelector('#fx-stage nav[aria-label="Main mobile"]');
    if (!n) return null;
    const r = n.getBoundingClientRect();
    const btns = [...n.querySelectorAll(":scope > button")];
    return {
      visible: r.width > 0 && r.height > 0 && Math.round(window.innerHeight - r.bottom) === 0,
      flush: Math.round(window.innerHeight - r.bottom),
      btns: btns.length,
      labels: btns.map((b) => b.getAttribute("aria-label")),
      textless: btns.every((b) => !(b.textContent || "").trim()),
      over: Math.max(document.documentElement.scrollWidth, document.body.scrollWidth) - window.innerWidth,
    };
  });
  ok("phone: bottom nav visible & flush at bottom", nav && nav.visible, `gap=${nav ? nav.flush : "?"}px`);
  ok("phone: 7 buttons, each icon + tiny label", nav && nav.btns === 7 && !nav.textless);
  ok("phone: bar carries 6 sections + settings aria-labels", nav && ["Live Dashboard", "Tasks", "Menu Manager", "Expenses", "Lodge Front Desk", "Employee", "Open settings"].every((l) => nav.labels.includes(l)));
  await page.screenshot({ path: `${OUT}/verify-t101-p01-dash.png` });

  /* aria-label-driven switching (the runtime's new matching) */
  const clickNav = async (label) => {
    await page.evaluate((l) => {
      const b = [...document.querySelectorAll('#fx-stage nav[aria-label="Main mobile"] button')].find((x) => x.getAttribute("aria-label") === l);
      b.click();
    }, label);
    await page.waitForTimeout(450);
  };
  await clickNav("Tasks");
  ok("phone: nav TASKS → tasks state", await page.evaluate(() => window.FX_DEMO.state()) === "tasks");
  await clickNav("Menu Manager");
  ok("phone: nav MENU → menu state", await page.evaluate(() => window.FX_DEMO.state()) === "menu");
  await clickNav("Expenses");
  ok("phone: nav EXPENSES → expenses state", await page.evaluate(() => window.FX_DEMO.state()) === "expenses");
  await page.screenshot({ path: `${OUT}/verify-t101-p02-expenses.png` });

  /* captured settings gear in the bar opens settings */
  await clickNav("Open settings");
  ok("phone: bar gear → settings state", await page.evaluate(() => window.FX_DEMO.state()) === "settings");
  await page.waitForTimeout(300);

  /* gallery previews visible on the phone */
  const phoneGal = await page.evaluate((ORDER) => {
    let vis = 0, orderOK = true;
    for (const k of ORDER) {
      const el = document.querySelector(`#fx-stage [data-testid="settings-theme-classic-${k}"]`);
      if (!el) { orderOK = false; continue; }
      el.scrollIntoView({ block: "center" });
      const r = el.getBoundingClientRect();
      if (r.height > 40 && r.width > 100) vis++;
    }
    const themeBtn = !!document.querySelector('#fx-stage [aria-label="Open theme gallery"]');
    return { vis, orderOK, themeBtn, over: Math.max(document.documentElement.scrollWidth, document.body.scrollWidth) - window.innerWidth };
  }, ORDER);
  ok("phone: 4 preview blocks visible per theme", phoneGal.orderOK && phoneGal.vis === 4, `${phoneGal.vis}/4`);
  ok("phone: per-band THEME button removed here too", !phoneGal.themeBtn);
  ok("phone: no horizontal overflow on settings", phoneGal.over <= 2, `${phoneGal.over}px`);
  await page.screenshot({ path: `${OUT}/verify-t101-p03-themes.png` });

  /* back to dashboard via the bar, AI panel still fits */
  await clickNav("Live Dashboard");
  ok("phone: nav DASHBOARD → dash state", /^dash-/.test(await page.evaluate(() => window.FX_DEMO.state())));
  const fab = await page.$('#fx-stage button[aria-label="Open Fetch-X AI assistant"]');
  if (fab) { await fab.click(); await page.waitForTimeout(400); }
  const aiFits = await page.evaluate(() => {
    const p = document.querySelector('#fx-stage [aria-label="Fetch-X AI assistant"]');
    if (!p) return false;
    const r = p.getBoundingClientRect();
    return r.width <= window.innerWidth + 2 && r.left >= -2;
  });
  ok("phone: AI panel fits viewport", aiFits);

  /* lodge reception on phone */
  await page.evaluate(() => window.FX_DEMO.show("reception-lodge"));
  await page.waitForTimeout(500);
  const lodgeOverflow = await page.evaluate(() => Math.max(document.documentElement.scrollWidth, document.body.scrollWidth) - window.innerWidth);
  ok("phone: lodge desk no horizontal overflow", lodgeOverflow <= 2, `${lodgeOverflow}px`);
  await page.screenshot({ path: `${OUT}/verify-t101-p04-lodge.png` });

  ok("phone: zero page errors", errors.length === 0, errors.slice(0, 2).join(" | "));
  await ctx.close();
}

await browser.close();
const pass = results.filter((r) => r.pass).length;
fs.writeFileSync(`${OUT}/verify-t101-demo-report.json`, JSON.stringify(results, null, 2));
console.log(`\n${pass}/${results.length} PASS`);
if (pass !== results.length) process.exit(1);
