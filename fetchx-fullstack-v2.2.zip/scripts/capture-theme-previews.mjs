/* t104 — capture REAL page previews for the settings theme gallery.
 * For EVERY theme: light prelogin top → light live-dashboard top →
 * dark prelogin top → dark live-dashboard top (the user's fixed order).
 * t104 crops match the user's reference screenshot:
 *   · prelogin   @1100px wide — navbar + hero + paragraph + CTAs + checks
 *   · dashboard  @880px  wide — sidebar NATIVELY hidden below lg (md-grid
 *     keeps the stat duo side by side), tier band + chips + stat duo
 * Output: public/theme-previews/{id}-{light|dark}-{prelogin|dashboard}.jpg
 * Run: node scripts/capture-theme-previews.mjs
 */
import pw from "/home/z/.npm-global/lib/node_modules/playwright/index.js";
const { chromium } = pw;
import fs from "node:fs";

const BASE = "http://localhost:3000";
const OUT = "/home/z/my-project/public/theme-previews";
fs.mkdirSync(OUT, { recursive: true });

const THEMES = JSON.parse(fs.readFileSync("/home/z/my-project/scripts/capture/theme-ids.json", "utf8"));

const browser = await chromium.launch();

async function shoot(id, mode) {
  /* ── prelogin top — 1100 wide, full hero ── */
  {
    const ctx = await browser.newContext({ viewport: { width: 1100, height: 760 }, deviceScaleFactor: 1 });
    const page = await ctx.newPage();
    const prep = async () => {
      for (let i = 0; i < 3; i++) {
        await page.goto(BASE + "/", { waitUntil: "load", timeout: 60000 }).catch(() => {});
        try {
          await page.evaluate(({ themeId, mode2 }) => {
            localStorage.setItem("fx-theme:guest", themeId);
            localStorage.setItem("theme", mode2);
            localStorage.removeItem("fx-auth");
          }, { themeId: id, mode2: mode });
          return;
        } catch (e) {
          await page.waitForTimeout(2500); // prod-server hiccup — retry
        }
      }
    };
    await prep();
    await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 90000 });
    await page.waitForSelector("text=finally intelligent", { timeout: 90000 });
    await page.waitForTimeout(1600);
    await page.screenshot({ path: `${OUT}/${id}-${mode}-prelogin.jpg`, type: "jpeg", quality: 50, clip: { x: 0, y: 0, width: 1100, height: 560 } });
    console.log("shot", `${id}-${mode}-prelogin.jpg`);
    await ctx.close();
  }

  /* ── live dashboard top — 880 wide, sidebar hidden natively below lg ── */
  {
    const ctx = await browser.newContext({ viewport: { width: 880, height: 900 }, deviceScaleFactor: 1 });
    const page = await ctx.newPage();
    const prep = async () => {
      for (let i = 0; i < 3; i++) {
        await page.goto(BASE + "/", { waitUntil: "load", timeout: 60000 }).catch(() => {});
        try {
          await page.evaluate(({ themeId, mode2 }) => {
            const who = "spiceowner@gmail.com";
            localStorage.setItem("fx-theme:" + who, themeId);
            localStorage.setItem("fx-theme:guest", themeId);
            localStorage.setItem("theme", mode2);
            localStorage.setItem("fx-auth", JSON.stringify({ name: "Imperial", role: "owner", email: who }));
          }, { themeId: id, mode2: mode });
          return;
        } catch (e) {
          await page.waitForTimeout(2500);
        }
      }
    };
    await prep();
    await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 90000 });
    await page.waitForSelector("text=Live Dashboard", { timeout: 90000 });
    await page.waitForTimeout(2800);
    /* sidebar is `hidden md:flex` — still visible at 880px; hide it so the
       shot is the main column only (tier band + chips + stat duo) */
    await page.addStyleTag({ content: "aside{display:none!important}" });
    await page.waitForTimeout(400);
    await page.screenshot({ path: `${OUT}/${id}-${mode}-dashboard.jpg`, type: "jpeg", quality: 50, clip: { x: 0, y: 0, width: 880, height: 620 } });
    console.log("shot", `${id}-${mode}-dashboard.jpg`);
    await ctx.close();
  }
}

for (const id of THEMES) {
  await shoot(id, "light");
  await shoot(id, "dark");
}

await browser.close();
const files = fs.readdirSync(OUT).filter((f) => f.endsWith(".jpg"));
const kb = files.reduce((s, f) => s + fs.statSync(`${OUT}/${f}`).size, 0) / 1024;
console.log(`DONE — ${files.length} images, ${kb.toFixed(0)}KB total`);
