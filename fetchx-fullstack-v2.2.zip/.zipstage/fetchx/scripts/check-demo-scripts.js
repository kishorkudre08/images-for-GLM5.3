/* Syntax-check every <script> block in fetchx-demo.html via node's vm compiler */
const fs = require("fs");
const vm = require("vm");
const file = "/home/z/my-project/download/fetchx-demo.html";
const html = fs.readFileSync(file, "utf8");
const re = /<script[^>]*>([\s\S]*?)<\/script>/gi;
let m, i = 0, fail = 0;
while ((m = re.exec(html)) !== null) {
  i++;
  const code = m[1];
  if (!code.trim()) { console.log(`script #${i}: (empty) OK`); continue; }
  try {
    new vm.Script(code, { filename: `block-${i}.js` });
    console.log(`script #${i}: OK (${code.split("\n").length} lines)`);
  } catch (e) {
    fail++;
    console.log(`script #${i}: SYNTAX ERROR -> ${e.message}`);
    const lines = code.split("\n");
    const ln = parseInt((e.stack.match(/block-\d+\.js:(\d+)/) || [])[1] || "0", 10);
    if (ln) {
      for (let k = Math.max(0, ln - 3); k < Math.min(lines.length, ln + 2); k++) {
        console.log(`   ${k + 1}: ${lines[k]}`);
      }
    }
  }
}
console.log(fail ? `\n${fail} BLOCK(S) FAILED` : `\nALL ${i} SCRIPT BLOCKS PASS`);
process.exit(fail ? 1 : 0);
