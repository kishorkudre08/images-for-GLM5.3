const { PrismaClient } = require("@prisma/client");
const p = new PrismaClient();
(async () => {
  const dishes = await p.dish.findMany({ orderBy: { category: "asc" } });
  const bills = await p.bill.findMany({ include: { items: true }, orderBy: { number: "desc" }, take: 12 });
  const billCount = await p.bill.count();
  const employees = await p.employee.findMany();
  const expenses = await p.expense.findMany();
  console.log(JSON.stringify({ dishCount: dishes.length, billCount, employees: employees.length, expenses: expenses.length }, null, 0));
  console.log("DISHES:", JSON.stringify(dishes));
  console.log("BILLS:", JSON.stringify(bills));
  console.log("EMPLOYEES:", JSON.stringify(employees));
  console.log("EXPENSES:", JSON.stringify(expenses));
  await p.$disconnect();
})().catch(e => { console.error(e.message); process.exit(1); });
