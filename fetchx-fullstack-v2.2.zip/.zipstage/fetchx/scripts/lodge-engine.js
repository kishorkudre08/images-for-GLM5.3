/* ═══════════════ LODGE (lodge-view) — Imperial Spices Hotel · 100 rooms ═══════════════
   Front desk: statuses, check-ins/outs, housekeeping, bookings, folios & charts.
   Mirrors the full-stack lodge-view.tsx 1:1.                                             */
"use strict";
var lodgeBuilt = false;
var LODGE_ST = {avl:"AVAILABLE", occ:"OCCUPIED", res:"RESERVED", dirty:"DIRTY", mnt:"MAINTENANCE"};
var LODGE_ROOM_STATE = {};
var lodgeFilter = "all", lodgeQuery = "", lodgeBkSeq = 6100;

/* ── date helpers — everything is relative to TODAY, so the demo never goes stale ── */
function dOff(n){ var d = new Date(); d.setHours(12,0,0,0); return new Date(d.getTime()+n*86400000); }
function dLabel(n){ return dOff(n).toLocaleDateString("en-IN",{timeZone:"Asia/Calcutta",day:"numeric",month:"short"}); }
function lodgeBooking(rm){
  var list = LODGE_BOOKINGS.filter(function(b){ return b.rm===rm; });
  var order = {in:0, arr:1, out:2};
  list.sort(function(a,b){ return order[a.st]-order[b.st]; });
  return list[0] || null;
}
function lodgeStats(){
  var occ=0, avl=0, dirty=0, mnt=0, res=0;
  Object.keys(LODGE_ROOM_STATE).forEach(function(k){
    var st = LODGE_ROOM_STATE[k].st;
    if (st==="occ") occ++; else if (st==="avl") avl++; else if (st==="dirty") dirty++;
    else if (st==="mnt") mnt++; else if (st==="res") res++;
  });
  var rev=0, guests=0, dep=0;
  LODGE_BOOKINGS.forEach(function(b){
    if (b.st==="in"){ rev += LODGE_TYPES[b.t].rate; guests += b.gx; if (b.ci+b.nts===0) dep++; }
  });
  return {occ:occ, avl:avl, dirty:dirty, mnt:mnt, res:res, rev:rev, guests:guests, dep:dep,
          adr: occ ? Math.round(rev/occ) : 0, revpar: Math.round(rev/100), stayover: occ-dep};
}
function firstEta(){
  var etas = LODGE_BOOKINGS.filter(function(b){ return b.st==="arr"; }).map(function(b){ return b.eta; });
  return etas.length ? hourLabel(Math.min.apply(null,etas)) : "—";
}
/* folio = room + extras + GST (12% · 18% above ₹7,500/night — Indian hotel tax slabs) */
function folioOf(b){
  var room = b.nts*LODGE_TYPES[b.t].rate, extras = (b.mb||0)+(b.ld||0)+(b.dn||0);
  var pct = LODGE_TYPES[b.t].rate>7500 ? 18 : 12;
  var tax = Math.round(room*pct/100);
  return {room:room, extras:extras, tax:tax, total:room+extras+tax, pct:pct};
}
function folRow(l,v){ return '<div class="lk-row"><span>'+l+'</span><b class="fx-num">'+inr(v)+"</b></div>"; }
function lkItem(l,v){ return '<div class="lk-i"><span class="fx-label">'+l+'</span><b>'+v+"</b></div>"; }

/* ── view skeleton ──────────────────────────────────────────────────── */
function renderLodge(force){
  if (lodgeBuilt && !force) return; lodgeBuilt = true;
  if (!Object.keys(LODGE_ROOM_STATE).length){
    LODGE_ROOMS.forEach(function(r){ LODGE_ROOM_STATE[r[0]] = {t:r[1], st:r[2]}; });
  }
  var el = $("#viewLodge");
  el.innerHTML = tier("03","TIER 03 · LODGE OPERATIONS","Lodge Front Desk","100 rooms across 5 floors — check-ins, housekeeping and room revenue in one live view.",
      {liveDot:true, html:'<span id="lodgeTag"></span>'})
    + '<div class="grid-4" id="lStats1"></div><div class="grid-4" id="lStats2" style="margin-top:14px"></div>'
    + '<div class="fx-card fxc" style="margin-top:20px">'
    +   '<div class="c-head"><span class="fx-label">'+ic("hotel",14)+'FRONT DESK · ALL ROOMS</span>'
    +   '<button class="mini-btn" id="lodgeNew">'+ic("plus",14)+'NEW BOOKING</button></div>'
    +   '<div class="lodge-filters" id="lFilters"></div>'
    +   '<div class="pos-search" style="margin-top:14px;max-width:340px">'+ic("search",16)+'<input class="inp" id="lodgeQ" placeholder="Search room number or guest…" aria-label="Search rooms" /></div>'
    +   '<div id="lRooms"></div></div>'
    + '<div class="grid-2" style="margin-top:20px"><div class="fx-card fxc" id="lOcc"></div><div class="fx-card fxc" id="lRev"></div></div>'
    + '<div class="fx-card fxc" style="margin-top:20px" id="lBookings"></div>';
  $("#lodgeQ").addEventListener("input",function(){ lodgeQuery=this.value; paintLodgeRooms(); });
  $("#lodgeNew").addEventListener("click",function(){ openBookModal(null, null); });
  paintLodgeAll();
}
function paintLodgeAll(){
  paintLodgeKpis(); paintLodgeFilters(); paintLodgeRooms(); paintLodgeCharts(); paintLodgeBookings();
}
function refreshLodge(){
  paintLodgeKpis(); paintLodgeFilters(); paintLodgeRooms(); paintLodgeBookings();
}

/* ── KPI strip (2×4) ────────────────────────────────────────────────── */
function paintLodgeKpis(){
  var s = lodgeStats();
  $("#lodgeTag").innerHTML = s.occ+" ROOMS TONIGHT · "+s.avl+" READY";
  $("#lStats1").innerHTML =
    stat("OCCUPANCY TONIGHT", s.occ+"%", "hotel", null, s.occ+" OF 100 ROOMS SOLD")+
    stat("ROOM REVENUE · TONIGHT", inr(s.rev), "banknote", null, "ADR "+inr(s.adr)+" × "+s.occ+" ROOMS")+
    stat("ADR · TONIGHT", inr(s.adr), "tup", null, "AVERAGE DAILY RATE")+
    stat("REVPAR · TODAY", inr(s.revpar), "rupee", null, "ROOM REVENUE ÷ 100 ROOMS");
  $("#lStats2").innerHTML =
    stat("ARRIVALS TODAY", String(s.res), "arrow", null, "FIRST ETA · "+firstEta())+
    stat("DEPARTURES TODAY", String(s.dep), "receipt", null, "DUE OUT BY 12 NOON")+
    stat("IN-HOUSE GUESTS", String(s.guests), "users", null, "STAYOVERS · "+s.stayover+" ROOMS")+
    stat("HOUSEKEEPING", s.dirty+" DIRTY", "wrench", null, s.avl+" CLEAN & READY · "+s.mnt+" MAINTENANCE");
}

/* ── status filter chips ────────────────────────────────────────────── */
function paintLodgeFilters(){
  var c = {all:0, avl:0, occ:0, res:0, dirty:0, mnt:0};
  Object.keys(LODGE_ROOM_STATE).forEach(function(k){ var st = LODGE_ROOM_STATE[k].st; c.all++; c[st]++; });
  var defs = [["all","ALL"],["avl","AVAILABLE"],["occ","OCCUPIED"],["res","RESERVED"],["dirty","DIRTY"],["mnt","MAINTENANCE"]];
  $("#lFilters").innerHTML = defs.map(function(d){
    return '<button data-lf="'+d[0]+'" class="'+(lodgeFilter===d[0]?"on":"")+'">'+d[1]+" · "+c[d[0]]+"</button>";
  }).join("");
  $$("[data-lf]").forEach(function(b){
    b.addEventListener("click",function(){ lodgeFilter=b.getAttribute("data-lf"); paintLodgeFilters(); paintLodgeRooms(); });
  });
}

/* ── rooms grid, grouped by floor ───────────────────────────────────── */
function roomCard(n){
  var r = LODGE_ROOM_STATE[n], t = LODGE_TYPES[r.t], b = lodgeBooking(n), sub = "", guest = "—";
  if (r.st==="occ" && b){
    var due = b.ci+b.nts;
    guest = esc(b.g);
    sub = "NIGHT "+(1-b.ci)+" OF "+b.nts+" · "+(due===0 ? "DUE OUT TODAY" : "DUE "+dLabel(due).toUpperCase());
  } else if (r.st==="res" && b){
    guest = esc(b.g);
    sub = "ARRIVES "+hourLabel(b.eta).toUpperCase()+" · "+b.nts+" NIGHT"+(b.nts===1?"":"S");
  } else if (r.st==="dirty"){
    guest = b ? esc(b.g) : "CHECKED OUT";
    sub = "OUT THIS MORNING · CLEANING";
  } else if (r.st==="mnt"){
    sub = (LODGE_MNT_NOTES[n] || "Under maintenance").toUpperCase();
  } else {
    sub = "CLEAN & READY";
  }
  return '<button class="room-card st-'+r.st+'" data-room="'+n+'" aria-label="Room '+n+" "+LODGE_ST[r.st]+'">'
    + '<span class="rc-top"><span class="rc-num fx-num">'+n+'</span><span class="rc-pill stp-'+r.st+'">'+LODGE_ST[r.st]+"</span></span>"
    + '<span class="rc-type">'+esc(t.name)+" · "+inr(t.rate)+"</span>"
    + '<span class="rc-guest">'+guest+"</span>"
    + '<span class="rc-sub">'+esc(sub)+"</span></button>";
}
function paintLodgeRooms(){
  var q = lodgeQuery.trim().toLowerCase();
  var floors = {}, total = {}, flTypes = {};
  Object.keys(LODGE_ROOM_STATE).forEach(function(k){
    var n = Number(k), r = LODGE_ROOM_STATE[k], fl = Math.floor(n/100);
    total[fl] = (total[fl]||0)+1;
    flTypes[fl] = flTypes[fl]||{}; flTypes[fl][r.t] = true;
    var bkk = lodgeBooking(n);
    var g = bkk ? bkk.g.toLowerCase() : "";
    var hit = (lodgeFilter==="all" || r.st===lodgeFilter) && (!q || String(n).indexOf(q)>-1 || g.indexOf(q)>-1);
    if (hit){ (floors[fl] = floors[fl]||[]).push(n); }
  });
  var html = "";
  [1,2,3,4,5].forEach(function(fl){
    var list = floors[fl] || [];
    if (!list.length) return;
    list.sort(function(a,b){ return a-b; });
    var tl = Object.keys(flTypes[fl]).map(function(t){ return LODGE_TYPES[t].name.toUpperCase(); }).join(" · ");
    var occAll = Object.keys(LODGE_ROOM_STATE).filter(function(k){
      return Math.floor(Number(k)/100)===fl && LODGE_ROOM_STATE[k].st==="occ";
    }).length;
    html += '<div class="floor-head"><span class="fx-label">FLOOR '+fl+' · '+esc(tl)+'</span><span class="hline"></span><span class="mut-chip">'+occAll+"/"+(total[fl]||0)+" TONIGHT</span></div>"
          + '<div class="room-grid">'+list.map(roomCard).join("")+"</div>";
  });
  $("#lRooms").innerHTML = html || '<p style="padding:36px 0;text-align:center;font-size:13px;font-weight:600;color:var(--fx-muted)">No rooms match — clear the search or filters.</p>';
  $$("[data-room]").forEach(function(btn){
    btn.addEventListener("click",function(){ openRoomModal(Number(btn.getAttribute("data-room"))); });
  });
}

/* ── charts: occupancy trend + revenue by room type ─────────────────── */
function paintLodgeCharts(){
  var s = lodgeStats();
  var labels = [];
  for (var i=6;i>=0;i--) labels.push(dLabel(-i));
  $("#lOcc").innerHTML =
    '<div class="c-head"><span class="fx-label">'+ic("tup",14)+'OCCUPANCY · LAST 7 DAYS</span><span class="mut-chip">TONIGHT '+s.occ+"%</span></div>"
    +'<div class="chart-w" id="chOcc"></div>';
  $("#chOcc").innerHTML = lineChart(labels, LODGE_TREND, 1, $("#chOcc").clientWidth, function(v){ return Math.round(v)+"%"; });
  var rows = Object.keys(LODGE_TYPES).map(function(t){
    var T = LODGE_TYPES[t], n = 0;
    Object.keys(LODGE_ROOM_STATE).forEach(function(k){ if (LODGE_ROOM_STATE[k].t===t) n++; });
    return {name:T.name, n:n, avg:T.occ, rev:Math.round(n*T.rate*(T.occ/100)*30)};
  });
  var maxR = Math.max.apply(null, rows.map(function(r){ return r.rev; }));
  $("#lRev").innerHTML =
    '<div class="c-head"><span class="fx-label">'+ic("banknote",14)+'ROOM REVENUE BY TYPE · THIS MONTH</span><span class="mut-chip">PROJECTED · 30 NIGHTS</span></div>'
    +'<div class="rank-list">'+rows.map(function(r,i){
      return '<div class="rank"><span class="rk-n fx-num">'+String(i+1).padStart(2,"0")+'</span><div class="rk-main"><div class="rk-top"><span class="rk-name">'+esc(r.name)+' · '+r.n+' ROOMS</span><span class="rk-rev fx-num">'+inr(r.rev)+'</span></div><div class="rk-bar-w"><span class="rk-bar"><i style="width:'+Math.max(5,Math.round(r.rev/maxR*100))+'%"></i></span><span class="rk-qty">'+r.avg+"% FULL</span></div></div></div>";
    }).join("")+"</div>";
}

/* ── reservations & folios table ────────────────────────────────────── */
function paintLodgeBookings(){
  var order = {in:0, arr:1, up:2, out:3};
  var list = LODGE_BOOKINGS.slice().sort(function(a,b){
    return order[a.st]-order[b.st] || (a.rm||999)-(b.rm||999) || a.ci-b.ci;
  });
  var STLBL = {in:"IN-HOUSE", arr:"ARRIVING", up:"UPCOMING", out:"CHECKED OUT"};
  var inN = list.filter(function(b){ return b.st==="in"; }).length;
  $("#lBookings").innerHTML =
    '<div class="c-head"><span class="fx-label">'+ic("clip",14)+'RESERVATIONS &amp; FOLIOS · '+list.length+'</span><span class="mut-chip">'+inN+" IN-HOUSE</span></div>"
    +'<div class="bk-wrap fxscroll"><table class="bk-table"><thead><tr><th>GUEST</th><th>ROOM</th><th>TYPE</th><th>CHECK-IN</th><th>CHECK-OUT</th><th>NIGHTS</th><th>SOURCE</th><th>STATUS</th><th>FOLIO</th></tr></thead><tbody>'
    + list.map(function(b){
        var t = LODGE_TYPES[b.t], f = folioOf(b), folio;
        if (b.st==="in") folio = '<b class="fx-num">'+inr(f.total)+'</b><span class="bk-sub">RUNNING</span>';
        else if (b.st==="arr") folio = '<span class="fx-num">≈ '+inr(f.total)+"</span>";
        else if (b.st==="out") folio = '<b class="fx-num">'+inr(f.total)+'</b><span class="bk-sub">SETTLED</span>';
        else folio = '<span class="bk-dim">—</span>';
        return "<tr><td><b>"+esc(b.g)+'</b><span class="bk-sub">'+esc(b.ph)+"</span></td>"
          +'<td class="fx-num">'+(b.rm ? "#"+b.rm : '<span class="bk-dim">—</span>')+"</td>"
          +"<td>"+esc(t.name)+"</td>"
          +'<td class="fx-num">'+dLabel(b.ci)+"</td>"
          +'<td class="fx-num">'+dLabel(b.ci+b.nts)+"</td>"
          +'<td class="fx-num">'+b.nts+"</td>"
          +"<td>"+esc(b.src)+"</td>"
          +'<td><span class="bk-pill bk-'+b.st+'">'+STLBL[b.st]+"</span></td>"
          +"<td>"+folio+"</td></tr>";
      }).join("")+"</tbody></table></div>"
    +'<p class="note" style="margin-top:10px">Tap any room card above to check a guest in or out, mark housekeeping done or flag maintenance. Folio = room + extras + GST (12% · 18% above ₹7,500/night). Restaurant tabs flow in from the Imperial Spice POS.</p>';
}

/* ── room modal (details + actions) ─────────────────────────────────── */
function openRoomModal(n){
  var r = LODGE_ROOM_STATE[n], t = LODGE_TYPES[r.t], b = lodgeBooking(n), body = "", acts = "";
  if (r.st==="occ" && b){
    var f = folioOf(b);
    body = '<div class="lk-grid">'
      + lkItem("GUEST", esc(b.g)) + lkItem("CONTACT", esc(b.ph)) + lkItem("PARTY", b.gx+" GUESTS")
      + lkItem("CHECK-IN", dLabel(b.ci)) + lkItem("CHECK-OUT", dLabel(b.ci+b.nts)+(b.ci+b.nts===0?" · TODAY":"")) + lkItem("SOURCE", esc(b.src))
      + "</div>"
      + '<div class="lk-folio"><span class="fx-label">RUNNING FOLIO · ROOM '+n+"</span>"
      + folRow("Room · "+b.nts+" night"+(b.nts===1?"":"s")+" × "+inr(t.rate), f.room)
      + (b.mb ? folRow("Mini-bar", b.mb) : "")
      + (b.ld ? folRow("Laundry", b.ld) : "")
      + (b.dn ? folRow("Restaurant tab · Imperial Spice", b.dn) : "")
      + folRow("GST "+f.pct+"% · room", f.tax)
      + '<div class="lk-fol-tot"><span>TOTAL</span><span class="fx-num">'+inr(f.total)+"</span></div></div>";
    acts = '<button class="btnp" data-lact="out">'+ic("logout",14)+'CHECK OUT · SETTLE '+inr(f.total)+"</button>";
  } else if (r.st==="res" && b){
    var fe = folioOf(b);
    body = '<div class="lk-grid">'
      + lkItem("GUEST", esc(b.g)) + lkItem("CONTACT", esc(b.ph)) + lkItem("PARTY", b.gx+" GUESTS")
      + lkItem("ARRIVES", "TODAY · "+hourLabel(b.eta)) + lkItem("NIGHTS", String(b.nts)) + lkItem("SOURCE", esc(b.src))
      + "</div>"
      + '<p class="note" style="margin-top:14px">Advance received · room held. Estimated folio '+inr(fe.total)+" for "+b.nts+" night"+(b.nts===1?"":"s")+".</p>";
    acts = '<button class="btnp" data-lact="in">'+ic("check",14)+'CHECK IN '+esc(b.g.split(" ")[0].toUpperCase())+"</button>"
         + '<button class="btng" data-lact="cancel">CANCEL BOOKING</button>';
  } else if (r.st==="dirty"){
    body = '<p class="note" style="margin-top:14px">Checked out this morning'+(b ? " — last guest "+esc(b.g) : "")+". Waiting on housekeeping before it can be sold again.</p>";
    acts = '<button class="btnp" data-lact="clean">'+ic("sprout",14)+'MARK CLEANED</button>';
  } else if (r.st==="mnt"){
    body = '<p class="note" style="margin-top:14px">'+esc(LODGE_MNT_NOTES[n] || "Blocked for maintenance.")+" — room is out of order.</p>";
    acts = '<button class="btng" data-lact="fix">'+ic("wrench",14)+'MARK AVAILABLE</button>';
  } else {
    body = '<p class="note" style="margin-top:14px">Clean and ready to sell — reserve it for a walk-in or block it for maintenance.</p>';
    acts = '<button class="btnp" data-lact="book">'+ic("plus",14)+'BOOK THIS ROOM</button>'
         + '<button class="btng" data-lact="mnt">'+ic("wrench",14)+'FLAG MAINTENANCE</button>';
  }
  $("#lodgeModal").innerHTML =
    '<div class="mc-top"><div><h3>Room '+n+' · '+esc(t.name)+'</h3><p class="mc-sub">'+inr(t.rate)+" / night · Floor "+Math.floor(n/100)+'</p></div>'
    +'<span class="rc-pill stp-'+r.st+'" style="margin-top:6px">'+LODGE_ST[r.st]+'</span>'
    +'<button class="mc-x" data-lclose aria-label="Close">'+ic("x",16)+"</button></div>"
    + body + '<div class="lk-acts">'+acts+"</div>";
  $("#lodgeOv").style.display = "grid";
  $$("[data-lclose]").forEach(function(x){ x.addEventListener("click",closeLodgeModal); });
  $$("#lodgeModal [data-lact]").forEach(function(btn){
    btn.addEventListener("click",function(){ lodgeAction(btn.getAttribute("data-lact"), n); });
  });
}
function closeLodgeModal(){ $("#lodgeOv").style.display = "none"; }

/* ── state changes ──────────────────────────────────────────────────── */
function lodgeAction(act, n){
  var r = LODGE_ROOM_STATE[n], b = lodgeBooking(n);
  if (act==="out" && b){
    var f = folioOf(b);
    b.st = "out"; r.st = "dirty";
    closeLodgeModal(); refreshLodge();
    toast("Room "+n+" checked out", "Folio settled "+inr(f.total)+" · "+b.g+" · housekeeping notified.");
  } else if (act==="in" && b){
    b.st = "in"; r.st = "occ";
    closeLodgeModal(); refreshLodge();
    toast("Room "+n+" checked in", b.g+" · "+b.nts+" night"+(b.nts===1?"":"s")+" · folio started.");
  } else if (act==="cancel" && b){
    var i = LODGE_BOOKINGS.indexOf(b); if (i>-1) LODGE_BOOKINGS.splice(i,1);
    r.st = "avl";
    closeLodgeModal(); refreshLodge();
    toast("Booking cancelled", "Room "+n+" is available again.");
  } else if (act==="clean"){
    r.st = "avl";
    closeLodgeModal(); refreshLodge();
    toast("Room "+n+" cleaned", "Back on the ready rack.");
  } else if (act==="fix"){
    r.st = "avl";
    closeLodgeModal(); refreshLodge();
    toast("Room "+n+" back in service", "Marked available for sale.");
  } else if (act==="mnt"){
    r.st = "mnt";
    closeLodgeModal(); refreshLodge();
    toast("Room "+n+" flagged for maintenance", "Blocked from sale until it reopens.");
  } else if (act==="book"){
    openBookModal(r.t, n);
  }
}

/* ── new booking modal ──────────────────────────────────────────────── */
function openBookModal(prefType, forRoom){
  var tKeys = Object.keys(LODGE_TYPES);
  var avail = {};
  tKeys.forEach(function(t){
    avail[t] = Object.keys(LODGE_ROOM_STATE).filter(function(k){
      var r = LODGE_ROOM_STATE[k]; return r.t===t && r.st==="avl";
    }).length;
  });
  $("#lodgeModal").innerHTML =
    '<div class="mc-top"><div><h3>New booking</h3><p class="mc-sub">Check-in today · room auto-assigned.</p></div>'
    +'<button class="mc-x" data-lclose aria-label="Close">'+ic("x",16)+"</button></div>"
    +'<form id="bkForm"><div class="lk-grid">'
    +'<div style="grid-column:1/-1"><label class="fx-label" for="bkN">GUEST NAME</label><input class="inp" id="bkN" required placeholder="Full name" style="width:100%;margin-top:6px" /></div>'
    +'<div><label class="fx-label" for="bkP">PHONE</label><input class="inp" id="bkP" required placeholder="+91 …" style="width:100%;margin-top:6px" /></div>'
    +'<div><label class="fx-label" for="bkNts">NIGHTS</label><input class="inp fx-num" id="bkNts" type="number" min="1" max="30" value="1" style="width:100%;margin-top:6px" /></div>'
    +'<div style="grid-column:1/-1"><label class="fx-label" for="bkT">ROOM TYPE</label><select class="inp" id="bkT" style="width:100%;margin-top:6px">'
    + tKeys.map(function(t){
        return '<option value="'+t+'"'+(t===(prefType||"std")?" selected":"")+">"+esc(LODGE_TYPES[t].name)+" · "+inr(LODGE_TYPES[t].rate)+"/night · "+avail[t]+" FREE</option>";
      }).join("")
    +'</select></div>'
    +'<div style="grid-column:1/-1"><label class="fx-label" for="bkS">SOURCE</label><select class="inp" id="bkS" style="width:100%;margin-top:6px">'
    + ["Walk-in","Phone","Website","MakeMyTrip","Booking.com","Corporate"].map(function(s){ return "<option>"+s+"</option>"; }).join("")
    +"</select></div></div>"
    +'<button type="submit" class="btnp" style="width:100%;margin-top:16px">'+ic("check",14)+'RESERVE ROOM · TONIGHT</button></form>';
  $("#lodgeOv").style.display = "grid";
  $$("[data-lclose]").forEach(function(x){ x.addEventListener("click",closeLodgeModal); });
  $("#bkForm").addEventListener("submit",function(e){
    e.preventDefault();
    var g = $("#bkN").value.trim(), ph = $("#bkP").value.trim(), t = $("#bkT").value;
    var nts = Math.max(1, Number($("#bkNts").value)||1), src = $("#bkS").value;
    if (!g || !ph){ toast("Missing details","Guest name and phone are required."); return; }
    var free = Object.keys(LODGE_ROOM_STATE).filter(function(k){
      var r = LODGE_ROOM_STATE[k]; return r.t===t && r.st==="avl";
    }).map(Number).sort(function(a,b){ return a-b; });
    var n = (forRoom && LODGE_ROOM_STATE[forRoom] && LODGE_ROOM_STATE[forRoom].t===t && LODGE_ROOM_STATE[forRoom].st==="avl") ? forRoom : free[0];
    if (!n){ toast("Sold out — no "+LODGE_TYPES[t].name+" free","Every "+LODGE_TYPES[t].name+" room is taken tonight. Pick another type."); return; }
    LODGE_ROOM_STATE[n].st = "res";
    LODGE_BOOKINGS.push({id:"BK-"+(++lodgeBkSeq), g:g, ph:ph, t:t, rm:n, ci:0, nts:nts, gx:1, src:src, st:"arr", mb:0, ld:0, dn:0,
      eta: Math.min(22, Math.max(11, new Date().getHours()+1))});
    closeLodgeModal(); refreshLodge();
    toast("Room "+n+" reserved", LODGE_TYPES[t].name+" · "+nts+" night"+(nts===1?"":"s")+" · "+g+" arrives today.");
  });
  setTimeout(function(){ var f = $("#bkN"); if (f) f.focus(); },80);
}

/* overlay close: backdrop + Escape */
$("#lodgeOv").addEventListener("click",function(e){ if (e.target===this) this.style.display="none"; });
window.addEventListener("keydown",function(e){
  if (e.key==="Escape" && $("#lodgeOv").style.display==="grid") closeLodgeModal();
});
