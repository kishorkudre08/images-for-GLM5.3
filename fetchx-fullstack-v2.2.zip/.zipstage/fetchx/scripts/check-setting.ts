import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const rows = await db.setting.findMany();
console.log(JSON.stringify(rows, null, 2));
await db.$disconnect();
