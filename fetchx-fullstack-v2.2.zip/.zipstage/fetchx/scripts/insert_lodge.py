# Inserts the LODGE module into download/fetchx-demo.html
# - data literal (from scripts/lodge-data.js)
# - CSS/HTML already inserted via Edit; this script patches JS blocks with assertions
import io, sys, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEMO = os.path.join(ROOT, "download", "fetchx-demo.html")
DATA = os.path.join(ROOT, "scripts", "lodge-data.js")

src = io.open(DEMO, encoding="utf-8").read()
data = io.open(DATA, encoding="utf-8").read().strip()

def must(cond, msg):
    if not cond:
        print("FAIL:", msg); sys.exit(1)

def sub1(old, new, tag):
    global src
    must(old in src, "anchor missing: " + tag)
    must(src.count(old) == 1, "anchor not unique: " + tag)
    src = src.replace(old, new, 1)
    print("ok:", tag)

must("LODGE_TYPES" not in src, "lodge already inserted")

# 1 ── data literal into script 1, before the dashboard dataset comment
sub1("/* ── Dashboard dataset — five ranges (auto-fed story) ─────────────────",
     data + "\n\n/* ── Dashboard dataset — five ranges (auto-fed story) ─────────────────",
     "data literal")

# 2 ── NAV entry (sidebar + mobile)
sub1('''  {id:"pos", label:"POS Billing", short:"POS", tip:"Cashier terminal", icon:"receipt"},
  {id:"management", label:"Management", short:"MANAGE", tip:"Team, costs & menu", icon:"clip"}''',
     '''  {id:"pos", label:"POS Billing", short:"POS", tip:"Cashier terminal", icon:"receipt"},
  {id:"lodge", label:"Lodge", short:"LODGE", tip:"Front desk & rooms", icon:"hotel"},
  {id:"management", label:"Management", short:"MANAGE", tip:"Team, costs & menu", icon:"clip"}''',
     "NAV entry")

# 3 ── view id map
sub1('  var ids = {dashboard:"viewDash", pos:"viewPos", management:"viewManage"};',
     '  var ids = {dashboard:"viewDash", pos:"viewPos", lodge:"viewLodge", management:"viewManage"};',
     "showView ids")

# 4 ── renderView branch
sub1('''  if (v==="dashboard") renderDash(force);
  else if (v==="pos") renderPos(force);
  else if (v==="management") renderManage(force);''',
     '''  if (v==="dashboard") renderDash(force);
  else if (v==="pos") renderPos(force);
  else if (v==="lodge") renderLodge(force);
  else if (v==="management") renderManage(force);''',
     "renderView branch")

# 5 ── refreshAll
sub1("  dashBuilt = false; posBuilt = false; mgmtBuilt = false;",
     "  dashBuilt = false; posBuilt = false; lodgeBuilt = false; mgmtBuilt = false;",
     "refreshAll")

# 6 ── management tier renumber 03 → 04
sub1('tier("03","TIER 03 · RESTAURANT MANAGEMENT"',
     'tier("04","TIER 04 · RESTAURANT MANAGEMENT"',
     "management tier renumber")

# 7 ── chartFrame tick formatter (occupancy % chart reuses the engine)
sub1("function chartFrame(labels, values, every, h, w){",
     "function chartFrame(labels, values, every, h, w, tickFmt){",
     "chartFrame param")
sub1('''" text-anchor="end">'+fmtAxisINR(v)+"</text>";''',
     '''" text-anchor="end">'+(tickFmt||fmtAxisINR)(v)+"</text>";''',
     "chartFrame tick fmt")
sub1('''function lineChart(labels, values, every, w){
  var f = chartFrame(labels, values, every, 220, w);''',
     '''function lineChart(labels, values, every, w, tickFmt){
  var f = chartFrame(labels, values, every, 220, w, tickFmt);''',
     "lineChart passthrough")

# 8 ── repaint lodge charts after AI drag / window resize
sub1('''    if (shellReady){
      if (currentView==="dashboard") paintDash();
      else if (currentView==="pos") paintPosGrid();
    }''',
     '''    if (shellReady){
      if (currentView==="dashboard") paintDash();
      else if (currentView==="pos") paintPosGrid();
      else if (currentView==="lodge") paintLodgeCharts();
    }''',
     "ai resize repaint")
sub1('''    if (currentView==="dashboard") paintDash();
    else if (currentView==="pos") paintPosGrid();
  },200);''',
     '''    if (currentView==="dashboard") paintDash();
    else if (currentView==="pos") paintPosGrid();
    else if (currentView==="lodge") paintLodgeCharts();
  },200);''',
     "window resize repaint")

io.open(DEMO, "w", encoding="utf-8").write(src)
print("ALL DEMO JS WIRING DONE")
