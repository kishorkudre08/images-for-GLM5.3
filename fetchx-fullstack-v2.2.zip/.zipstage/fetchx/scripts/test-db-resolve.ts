// Standalone probe for src/lib/db.ts — runs a REAL query through the REAL client.
// Usage: DATABASE_URL="file:..." bun scripts/test-db-resolve.ts
export {};
const t0 = Date.now();
const mod = await import("../src/lib/db");
const bills = await mod.db.bill.count();
const rooms = await mod.db.room.count();
console.log(`RESULT bills=${bills} rooms=${rooms} in ${Date.now() - t0}ms`);
await mod.db.$disconnect();
