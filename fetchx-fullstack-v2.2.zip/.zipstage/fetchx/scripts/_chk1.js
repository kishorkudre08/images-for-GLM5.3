
/* ═══════════════ LANDING WIRING (landing-view.tsx) ═══════════════ */
(function landing(){
  /* reveal on scroll */
  var io = new IntersectionObserver(function(es){
    es.forEach(function(e){ if(e.isIntersecting){ e.target.classList.add("in"); io.unobserve(e.target);} });
  },{threshold:.12});
  $$(".rv").forEach(function(el){ io.observe(el); });

  /* scroll-spy for nav links */
  var links = $("#lnavLinks");
  if (links){
    window.addEventListener("scroll",function(){
      if ($("#landing").style.display==="none") return;
      var y = window.scrollY+160, cur="home";
      $$("a",links).forEach(function(a){
        var id = a.getAttribute("href").slice(1);
        var s = document.getElementById(id);
        if (s && s.offsetTop<=y) cur=id;
      });
      $$("a",links).forEach(function(a){ a.classList.toggle("on", a.getAttribute("href")==="#"+cur); });
    },{passive:true});
  }

  /* CountUp stats */
  var cio = new IntersectionObserver(function(es){
    es.forEach(function(e){
      if (!e.isIntersecting) return;
      var el = e.target; cio.unobserve(el);
      var to = parseFloat(el.getAttribute("data-count")), dec = parseInt(el.getAttribute("data-dec")||"0",10);
      var pre = el.getAttribute("data-pre")||"", suf = el.getAttribute("data-suf")||"";
      var t0 = performance.now(), dur = 1300;
      function tick(n){
        var p = Math.min(1,(n-t0)/dur), ease = 1-Math.pow(1-p,3), v = to*ease;
        el.textContent = pre + v.toLocaleString("en-IN",{minimumFractionDigits:dec,maximumFractionDigits:dec}) + suf;
        if (p<1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
    });
  },{threshold:.3});
  $$("[data-count]").forEach(function(el){ cio.observe(el); });

  /* auth modal */
  var ov = $("#authOv"), err = $("#authErr"), shakeKey = 0;
  function openModal(prefill){
    err.style.display="none";
    if (prefill){ $("#lk-email").value="spice1234@gmail.com"; $("#lk-pass").value="spice1234"; }
    ov.style.display="grid";
    setTimeout(function(){ $("#lk-email").focus(); },80);
  }
  document.addEventListener("click",function(e){
    var b;
    if ((b = e.target.closest ? e.target.closest("[data-open-auth]") : null)){ openModal(b.hasAttribute("data-prefill")); return; }
    if (e.target.closest ? e.target.closest("[data-close-auth]") : null){ ov.style.display="none"; return; }
    if (e.target.closest ? e.target.closest("[data-prefill]") : null){
      $("#lk-email").value="spice1234@gmail.com"; $("#lk-pass").value="spice1234"; err.style.display="none"; return;
    }
    if (e.target.closest ? e.target.closest("[data-demo]") : null){
      $("#lk-email").value="spice1234@gmail.com"; $("#lk-pass").value="spice1234"; ov.style.display="grid";
      err.style.display="none";
      var go = $("#authGo"); go.disabled=true; go.innerHTML='<svg class="spin" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> Loading demo…';
      setTimeout(function(){ go.disabled=false; go.innerHTML='Sign In '+ic("arrow",16); enterApp(); },700);
      return;
    }
    if (e.target===ov) ov.style.display="none";
  });
  window.addEventListener("keydown",function(e){ if (e.key==="Escape" && ov.style.display==="grid") ov.style.display="none"; });

  $("#authForm").addEventListener("submit",function(e){
    e.preventDefault();
    var em = $("#lk-email").value.trim().toLowerCase(), pw = $("#lk-pass").value;
    function fail(msg){ err.textContent=msg; err.style.display="block"; err.classList.remove("jk-shake"); void err.offsetWidth; err.classList.add("jk-shake"); }
    if (!em || !pw){ fail("Enter both email and password."); return; }
    if (em!=="spice1234@gmail.com" || pw!=="spice1234"){ fail("Wrong email or password."); return; }
    var go = $("#authGo"); go.disabled=true;
    go.innerHTML='<svg class="spin" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> Signing in as IMPERIAL…';
    setTimeout(function(){
      go.disabled=false; go.innerHTML='Sign In '+ic("arrow",16);
      enterApp();
    },650);
  });
})();

/* ═══════════════ APP SHELL (page.tsx) ═══════════════ */
var currentView = "dashboard";
var currentRange = "today";
var USER = {name:"Imperial", role:"owner"};
var NAV = [
  {id:"dashboard", label:"Live Dashboard", short:"DASHBOARD", tip:"Owner intelligence", icon:"chart"},
  {id:"pos", label:"POS Billing", short:"POS", tip:"Cashier terminal", icon:"receipt"},
  {id:"lodge", label:"Lodge", short:"LODGE", tip:"Front desk & rooms", icon:"hotel"},
  {id:"management", label:"Management", short:"MANAGE", tip:"Team, costs & menu", icon:"clip"}
];

function enterApp(){
  try{ sessionStorage.setItem("fx-auth-demo","1"); }catch(e){}
  $("#landing").style.display="none";
  $("#splash").style.display="grid";
  setTimeout(function(){
    $("#splash").style.display="none";
    $("#app").style.display="flex";
    initShell();
    showView("dashboard");
  },450);
}
function exitApp(){
  try{ sessionStorage.removeItem("fx-auth-demo"); }catch(e){}
  $("#app").style.display="none";
  $("#landing").style.display="block";
  window.scrollTo(0,0);
}
var shellReady = false;
function initShell(){
  if (shellReady) return; shellReady = true;
  /* sidebar identity */
  $("#sbMark").textContent = hotelInitials(HOTEL.name);
  $("#sbName").textContent = upperName();
  $("#sbUser").textContent = USER.name.toUpperCase()+" · "+USER.role.toUpperCase();
  /* rail button */
  var railHtml = function(){ $("#railBtn").innerHTML = ic($("#sb").classList.contains("rail")?"chevR":"chevL",16); };
  $("#railBtn").addEventListener("click",function(){
    $("#sb").classList.toggle("rail"); railHtml();
    try{localStorage.setItem("fx-sidebar",$("#sb").classList.contains("rail")?"1":"0")}catch(e){}
  });
  try{ if (localStorage.getItem("fx-sidebar")==="1"){ $("#sb").classList.add("rail"); } }catch(e){}
  railHtml();
  /* sign out */
  $("#signOut").insertAdjacentHTML("afterbegin", ic("logout",14));
  $("#signOut").addEventListener("click",exitApp);
  /* desktop nav */
  $("#sbNav").innerHTML = NAV.map(function(n){
    return '<button class="nav-b" data-nav="'+n.id+'" title="'+esc(n.tip)+'">'+ic(n.icon,18)+'<span class="nb-t">'+esc(n.label)+"</span></button>";
  }).join("");
  /* mobile nav */
  $("#mnav").innerHTML = NAV.map(function(n){
    return '<button data-nav="'+n.id+'">'+ic(n.icon,18)+"<span>"+esc(n.short)+"</span></button>";
  }).join("") + '<span class="mnav-tgl"><button class="tgl" data-theme title="Dark / light mode" aria-label="Toggle dark mode"></button></span>';
  applyThemeIcons();
  $$("[data-nav]").forEach(function(b){
    b.addEventListener("click",function(){ showView(b.getAttribute("data-nav")); });
  });
  /* AI panel wiring */
  $("#aiFab").addEventListener("click",function(){ $("#aiPanel").classList.add("on"); $("#aiFab").style.display="none"; });
  $("#aiClose").addEventListener("click",function(){
    $("#aiPanel").classList.remove("on");
    $("#aiFab").style.display = currentView==="pos" ? "none" : "grid";
  });
  $("#aiClear").addEventListener("click",function(){ aiMsgs=[]; renderAiEmpty(); });
  $("#aiForm").addEventListener("submit",function(e){ e.preventDefault(); aiSend($("#aiInput").value); });
  renderAiEmpty();
}
function showView(v, force){
  currentView = v;
  var ids = {dashboard:"viewDash", pos:"viewPos", lodge:"viewLodge", management:"viewManage"};
  Object.keys(ids).forEach(function(k){
    $("#"+ids[k]).style.display = k===v ? "" : "none";
  });
  $$("[data-nav]").forEach(function(b){ b.classList.toggle("on", b.getAttribute("data-nav")===v); });
  $("#aiFab").style.display = (v==="pos" || $("#aiPanel").classList.contains("on")) ? "none" : "grid";
  renderView(v, force);
  $("#main").scrollTop = 0;
}
function renderView(v, force){
  if (v==="dashboard") renderDash(force);
  else if (v==="pos") renderPos(force);
  else if (v==="lodge") renderLodge(force);
  else if (v==="management") renderManage(force);
}
/* data changed somewhere → rebuild whichever view is on screen, lazily the rest */
function refreshAll(){
  dashBuilt = false; posBuilt = false; lodgeBuilt = false; mgmtBuilt = false;
  renderView(currentView, true);
}

/* ═══════════════ DASHBOARD (dashboard-view.tsx) ═══════════════ */
var dashBuilt = false;
var undoArm = null, undoTimer = null;
function deltaChip(pct,vs){
  var r = Math.round(pct);
  return {text:(r>=0?"+":"")+r+"% vs "+vs, up:r>=0};
}
function renderDash(force){
  if (dashBuilt && !force) return; dashBuilt = true;
  var el = $("#viewDash");
  /* tier band */
  el.innerHTML = tier("01","TIER 01 · OWNER INTELLIGENCE","Live Dashboard","Auto-fed by every generated bill — zero data entry, forever.",
      {liveDot:true, html:'LIVE · UPDATED '+istTime(new Date())})
    + '<div class="fx-card rtabs" role="tablist" aria-label="Dashboard time range" id="rtabs"></div>'
    + '<div class="grid-4" id="dStats"></div>'
    + '<div class="fx-card fxc" id="dHourly"></div>'
    + '<div class="grid-2"><div class="fx-card fxc" id="dBuckets"></div><div class="fx-card fxc" id="dItems"></div></div>'
    + '<div class="grid-2"><div class="fx-card fxc" id="dBreakdown"></div><div class="fx-card fxc" id="dTeam"></div></div>'
    + '<div class="grid-mix"><div class="fx-card fxc" id="dMix"></div><div class="fx-card fxc" id="dBills"></div></div>';
  paintDash();
}
function paintDash(){
  var key = currentRange, R = RANGES[key], s = R.stats, b = bucketData(key), costs = costsData(key);
  /* range tabs */
  $("#rtabs").innerHTML = Object.keys(RANGES).map(function(k){
    return '<button role="tab" data-range="'+k+'" class="'+(k===key?"on":"")+'">'+RANGES[k].short+"</button>";
  }).join("");
  $$("[data-range]").forEach(function(btn){
    btn.addEventListener("click",function(){
      currentRange = btn.getAttribute("data-range");
      $("#aiRangeNote") && ($("#aiRangeNote").textContent = "DATA RANGE · "+RANGES[currentRange].period);
      paintDash();
    });
  });
  /* stat strip */
  var ts = key==="today" ? todayStats() : null;
  var rev = ts ? ts.revenue : s.revenue, bills = ts ? ts.bills : s.bills, items = ts ? ts.items : s.items;
  var avg = Math.round(rev/Math.max(1,bills));
  var revD = deltaChip(s.revDelta, R.prev), billD = deltaChip(s.billDelta, R.prev);
  $("#dStats").innerHTML =
    stat("REVENUE · "+R.period, inr(rev), "banknote", revD, "vs previous period")+
    stat("BILLS · "+R.period, num(bills), "receipt", billD, "counting every generated bill")+
    stat("AVG TICKET", inr(avg), "tup", null, "revenue ÷ bills")+
    stat("ITEMS SOLD · "+R.period, num(items), "bag", null, s.discounts>0 ? "DISCOUNTS GIVEN · "+inr(s.discounts) : "LIFETIME · "+inr(ALL_TIME.revenue)+" / "+num(ALL_TIME.bills)+" BILLS");
  /* hourly rhythm */
  var hPeak = HOURLY.values.indexOf(Math.max.apply(null,HOURLY.values)), hQuiet = HOURLY.values.indexOf(Math.min.apply(null,HOURLY.values));
  $("#dHourly").innerHTML =
    '<div class="c-head"><span class="fx-label">'+ic("clock",14)+'HOURLY RHYTHM · AVG REVENUE PER HOUR</span><span style="display:flex;flex-wrap:wrap;gap:6px">'
    +'<span class="pk-chip">'+ic("flame",12)+'PEAK · '+HOURLY.labels[hPeak].toUpperCase()+'</span>'
    +'<span class="pk-chip mut">'+ic("tdn",12)+'QUIET · '+HOURLY.labels[hQuiet].toUpperCase()+"</span></span></div>"
    +'<p class="note" style="margin-top:4px">'+(key==="today"?"Today's hours as they fill in — live from the POS, bill by bill.":"The steady shape of a day — every hour averaged across the "+R.period.toLowerCase()+".")+"</p>"
    +'<div class="chart-w" id="chHourly"></div>';
  $("#chHourly").innerHTML = lineChart(HOURLY.labels,HOURLY.values,2,$("#chHourly").clientWidth);
  /* revenue chart */
  $("#dBuckets").innerHTML =
    '<div class="c-head"><span class="fx-label">'+R.title+'</span><span class="pk-chip">'+ic("flame",12)+R.peak+" · "+esc(b.peak).toUpperCase()+"</span></div>"
    +'<div class="chart-w tall" id="chBuckets"></div>';
  $("#chBuckets").innerHTML = areaChart(b.labels,b.values,R.every,$("#chBuckets").clientWidth);
  /* items sold */
  var its = itemsData(key), maxQ = its[0].qty;
  $("#dItems").innerHTML =
    '<div class="c-head"><span class="fx-label">ITEMS SOLD · '+R.period+'</span><span class="mut-chip">'+its.length+" DISHES</span></div>"
    +'<div class="rank-list fxscroll" style="max-height:260px;min-height:200px;overflow-y:auto;padding-right:4px">'
    + its.map(function(d,i){
      return '<div class="rank"><span class="rk-n fx-num">'+String(i+1).padStart(2,"0")+'</span><div class="rk-main"><div class="rk-top"><span class="rk-name">'+esc(d.name)+'</span><span class="rk-rev fx-num">'+inr(d.revenue)+'</span></div><div class="rk-bar-w"><span class="rk-bar"><i style="width:'+Math.max(5,Math.round(d.qty/maxQ*100))+'%"></i></span><span class="rk-qty">'+d.qty+" sold</span></div></div></div>";
    }).join("")+"</div>";
  /* revenue breakdown */
  var rows = [
    {l:"EMPLOYEE SALARIES", v:costs.salaries, c:"var(--fx-amber)", note:EMPS.filter(function(e){return e.a}).length+" STAFF · PRORATED"},
    {l:"RAW MATERIALS", v:costs.raw, c:"#0d9488", note:"FROM MANAGEMENT ENTRIES"},
    {l:"MAINTENANCE", v:costs.maint, c:"var(--fx-rose)", note:"FROM MANAGEMENT ENTRIES"}
  ];
  $("#dBreakdown").innerHTML =
    '<div class="c-head"><span class="fx-label">'+ic("wallet",14)+'REVENUE BREAKDOWN · '+R.period+'</span>'+(costs.marginPct!==null?'<span class="mut-chip">'+costs.marginPct+"% MARGIN</span>":"")+"</div>"
    +'<div class="bd-rows"><div class="bd-row"><div class="bd-top"><span class="bd-l">REVENUE</span><span class="bd-v rev fx-num">'+inr(rev)+'</span></div><div class="bd-bar"><i style="width:100%;background:var(--fx-purple)"></i></div></div>'
    + rows.map(function(r){
      return '<div class="bd-row"><div class="bd-top"><span class="bd-l">'+r.l+'<span class="bd-note">'+r.note+'</span></span><span class="bd-v fx-num">− '+inr(r.v)+'</span></div><div class="bd-bar"><i style="width:'+Math.min(100,rev>0?Math.round(r.v/rev*100):0)+"%;background:"+r.c+'"></i></div></div>';
    }).join("")+"</div>"
    +'<div class="bd-total"><span class="fx-label">NET PROFIT · '+R.period+'</span><span class="bt-v fx-num" style="color:'+(costs.profit>=0?"var(--fx-green)":"var(--fx-rose)")+'">'+inr(costs.profit)+"</span></div>";
  /* team */
  var staff = EMPS.filter(function(e){return e.a});
  $("#dTeam").innerHTML =
    '<div class="c-head"><span class="fx-label">'+ic("users",14)+'TEAM · '+staff.length+' EMPLOYEES</span><span class="mut-chip">'+inr(monthlySalary())+" / MONTH</span></div>"
    +'<div class="team-list fxscroll" style="max-height:190px;overflow-y:auto;padding-right:4px">'
    + staff.map(function(e){
      return '<div class="emp-row"><span class="eav">'+esc(e.n.slice(0,1).toUpperCase())+'</span><span class="e-main"><span class="e-n">'+esc(e.n)+'</span><span class="e-r">'+esc(e.r)+'</span></span><span class="e-s fx-num">'+inr(e.s)+'<span class="per">/MO</span></span></div>';
    }).join("")+"</div>"
    +'<div class="bd-total"><span class="fx-label">TEAM COST · '+R.period+"</span><span class=\"bt-v fx-num\">"+inr(monthlySalary()/({"today":30,"7d":30/7,"1m":1,"3m":1/3,"1y":1/12}[key]))+"</span></div>";
  /* category mix */
  var total = rev;
  $("#dMix").innerHTML =
    '<span class="fx-label">CATEGORY MIX · '+R.period+"</span>"
    +'<div class="donut-w">'+donutSvg(R.mix,rev)+'<div class="donut-c"><div><div class="dc-v fx-num">'+inr(total)+'</div><div class="fx-label">PERIOD</div></div></div></div>'
    +'<div class="legend">'+R.mix.map(function(m,i){
      return '<div class="lg-row"><span class="lg-dot" style="background:'+PIE_COLORS[i]+'"></span><span class="lg-cat">'+esc(m[0])+'</span><span class="lg-pct">'+m[1]+"%</span></div>";
    }).join("")+"</div>";
  /* latest bills */
  $("#dBills").innerHTML =
    '<span class="fx-label">LATEST BILLS · TAP TO REPRINT · UNDO REMOVES IT</span>'
    +'<div class="bill-list fxscroll" style="max-height:330px;overflow-y:auto;padding-right:4px">'
    + BILLS.map(function(bill){
      var armed = undoArm===bill.id;
      return '<div class="bill-row"><button class="b-main" data-print="'+bill.id+'" aria-label="Reprint bill number '+bill.number+'">'
        +'<span class="b-ic">'+ic("receipt",16)+"</span>"
        +'<span style="min-width:0;flex:1"><span class="b-t">Bill #'+bill.number+" · "+inr2(bill.total)+'</span><span class="b-s">'+bill.items.map(function(i){return i.qty+"× "+esc(i.name)}).join(", ")+"</span></span>"
        +'<span class="b-time"><span class="bt-t">'+istTime(bill.createdAt)+"</span>"+ic("arrow",14)+"</span></button>"
        +'<button class="undo-b'+(armed?" arm":"")+'" data-undo="'+bill.id+'" aria-label="Undo bill number '+bill.number+'">'+ic("undo",12)+(armed?"SURE?":"UNDO")+"</button></div>";
    }).join("")+"</div>";
  wireBillActions();
}
function stat(label,value,icon,delta,footnote){
  return '<div class="fx-card stat"><div class="s-top"><span class="fx-label">'+esc(label)+'</span><span class="s-ic">'+ic(icon,16)+'</span></div><div class="s-val fx-num">'+value+'</div><div class="s-sub">'+(delta?'<span class="'+(delta.up?"s-up":"s-dn")+'">'+esc(delta.text)+"</span>":'<span class="s-mut">'+esc(footnote||"")+"</span>")+"</div></div>";
}
function wireBillActions(){
  $$("[data-print]").forEach(function(b){
    b.addEventListener("click",function(){
      var bill = BILLS.filter(function(x){return x.id===b.getAttribute("data-print")})[0];
      if (bill) openReceipt(bill);
    });
  });
  $$("[data-undo]").forEach(function(b){
    b.addEventListener("click",function(){
      var id = b.getAttribute("data-undo");
      if (undoArm===id){
        clearTimeout(undoTimer);
        var idx = BILLS.findIndex(function(x){return x.id===id});
        if (idx>-1){
          var bill = BILLS[idx];
          BILLS.splice(idx,1);
          LIVE.todayBills -= 1; LIVE.todayRevenue -= bill.total; LIVE.todayItems -= bill.itemCount;
          toast("Bill #"+bill.number+" undone","Removed everywhere — totals, trends & top dishes recompute instantly.");
        }
        undoArm = null; paintDash();
      } else {
        undoArm = id;
        clearTimeout(undoTimer);
        undoTimer = setTimeout(function(){ undoArm=null; paintDash(); },3000);
        paintDash();
      }
    });
  });
}

/* ── SVG charts (Recharts look: dashed grid, purple line, soft area) ── */
function smoothPath(pts){
  if (pts.length<2) return "";
  var d = "M"+pts[0][0]+","+pts[0][1];
  for (var i=0;i<pts.length-1;i++){
    var p0 = pts[Math.max(0,i-1)], p1 = pts[i], p2 = pts[i+1], p3 = pts[Math.min(pts.length-1,i+2)];
    var c1x = p1[0]+(p2[0]-p0[0])/6, c1y = p1[1]+(p2[1]-p0[1])/6;
    var c2x = p2[0]-(p3[0]-p1[0])/6, c2y = p2[1]-(p3[1]-p1[1])/6;
    d += " C"+c1x.toFixed(1)+","+c1y.toFixed(1)+" "+c2x.toFixed(1)+","+c2y.toFixed(1)+" "+p2[0].toFixed(1)+","+p2[1].toFixed(1);
  }
  return d;
}
function chartFrame(labels, values, every, h, w, tickFmt){
  var W = Math.max(320, w||0) || 600, H=h||220, pl=46, pr=10, pt=10, pb=26;
  var max = Math.max.apply(null, values), min = 0;
  max = max*1.08 || 1;
  var iw = W-pl-pr, ih = H-pt-pb;
  var fr = [0, 1/3, 2/3, 1];
  var pts = values.map(function(v,i){ return [pl+iw*i/(values.length-1), pt+ih*(1-(v-min)/(max-min))]; });
  var gridY = fr.map(function(f){ return pt+ih*(1-f); });
  var g = '<svg viewBox="0 0 '+W+" "+H+'" preserveAspectRatio="none">';
  g += '<g class="cgrid">';
  gridY.forEach(function(y){ g += '<line x1="'+pl+'" x2="'+(W-pr)+'" y1="'+y+'" y2="'+y+'"/>'; });
  g += "</g>";
  gridY.forEach(function(y,i){
    var v = max*fr[i];
    g += '<text class="ctick" x="'+(pl-8)+'" y="'+(y+3)+'" text-anchor="end">'+(tickFmt||fmtAxisINR)(v)+"</text>";
  });
  labels.forEach(function(l,i){
    if (every>0 && i%every!==0) return;
    if (every===0 && labels.length>10 && i%Math.ceil(labels.length/10)!==0) return;
    var x = pl+iw*i/(labels.length-1);
    g += '<text class="ctick" x="'+x+'" y="'+(H-8)+'" text-anchor="middle">'+esc(String(l))+"</text>";
  });
  return {svg:g, pts:pts, W:W, H:H, pl:pl, iw:iw};
}
function lineChart(labels, values, every, w, tickFmt){
  var f = chartFrame(labels, values, every, 220, w, tickFmt);
  var dots = f.pts.map(function(p){ return '<circle cx="'+p[0].toFixed(1)+'" cy="'+p[1].toFixed(1)+'" r="2.5" fill="#5b4fe9"/>'; }).join("");
  return f.svg+'<path d="'+smoothPath(f.pts)+'" fill="none" stroke="#5b4fe9" stroke-width="2.5" vector-effect="non-scaling-stroke"/>'+dots+"</svg>";
}
function areaChart(labels, values, every, w){
  var f = chartFrame(labels, values, every, 260, w);
  var area = smoothPath(f.pts)+" L"+f.pts[f.pts.length-1][0].toFixed(1)+","+(f.H-26)+" L"+f.pts[0][0].toFixed(1)+","+(f.H-26)+" Z";
  return f.svg+'<defs><linearGradient id="fxArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#5b4fe9" stop-opacity=".35"/><stop offset="100%" stop-color="#5b4fe9" stop-opacity=".02"/></linearGradient></defs>'
    +'<path d="'+area+'" fill="url(#fxArea)"/>'
    +'<path d="'+smoothPath(f.pts)+'" fill="none" stroke="#5b4fe9" stroke-width="2.5" vector-effect="non-scaling-stroke"/></svg>';
}
function donutSvg(mix, total){
  var R=70, C=2*Math.PI*R, off=0, segs="";
  mix.forEach(function(m,i){
    var frac = m[1]/100, len = C*frac;
    segs += '<circle r="'+R+'" cx="95" cy="95" fill="none" stroke="'+PIE_COLORS[i]+'" stroke-width="26" stroke-dasharray="'+len.toFixed(1)+" "+(C-len).toFixed(1)+'" stroke-dashoffset="'+(-off).toFixed(1)+'" transform="rotate(-90 95 95)"/>';
    off += len;
  });
  return '<svg viewBox="0 0 190 190" style="width:100%;height:100%">'+segs+"</svg>";
}
