
/* ═══════════════ POS (pos-view.tsx) — zero-entry billing ═══════════════ */
var GST_RATE = 0.05;
var posBuilt = false;
var cart = {}, discount = 0, posQuery = "", posCat = "All";
function cartLines(){
  return Object.keys(cart).map(function(id){
    var d = DISHES.filter(function(x){return x.id===id})[0];
    return d ? {d:d, q:cart[id]} : null;
  }).filter(Boolean);
}
function renderPos(force){
  if (posBuilt && !force) return; posBuilt = true;
  $("#viewPos").innerHTML =
    tier("02","TIER 02 · CASHIER BILLING","POS Terminal","Tap dishes → generate the bill. Everything else — prices, totals, timestamp, database — happens by itself.",
      {html: esc(upperName())+" · PURE VEG · <span id='posCount'></span> LIVE DISHES"})
    + '<div class="fx-card fxc"><div style="display:flex;flex-wrap:wrap;align-items:center;gap:12px">'
    +   '<div class="pos-search">'+ic("search",16)+'<input class="inp" id="posQ" placeholder="Search dishes…" aria-label="Search dishes" /></div>'
    +   '<span class="fx-label" id="posShown" style="display:none"></span></div>'
    +   '<div class="cat-chips" id="posCats"></div><div class="dish-grid fxscroll" id="posGrid"></div></div>'
    +   '<div class="dock-w"><div class="fx-card dock" id="dock"></div></div>';
  $("#posQ").addEventListener("input",function(){ posQuery=this.value; paintPosGrid(); });
  paintPosAll();
}
function paintPosAll(){
  var cats = ["All"].concat(CATS);
  $("#posCats").innerHTML = cats.map(function(c){
    return '<button data-cat="'+esc(c)+'" class="'+(c===posCat?"on":"")+'">'+esc(c.toUpperCase())+"</button>";
  }).join("");
  $$("[data-cat]").forEach(function(b){
    b.addEventListener("click",function(){ posCat=b.getAttribute("data-cat"); paintPosAll(); });
  });
  $("#posCount").textContent = String(DISHES.filter(function(d){return d.active}).length);
  paintPosGrid();
  paintDock();
}
function paintPosGrid(){
  var q = posQuery.trim().toLowerCase();
  var list = DISHES.filter(function(d){
    return d.active && (posCat==="All"||d.c===posCat) && d.n.toLowerCase().indexOf(q)>-1;
  });
  $("#posGrid").innerHTML = list.map(function(d){
    var qty = cart[d.id]||0;
    return '<button class="fx-tile tile-in '+(qty>0?"in-cart":"")+'" data-dish="'+d.id+'">'
      + (qty>0?'<span class="qty-badge">'+qty+"</span>":"")
      + '<span class="t-name-w">'+veg(true)+'<span class="t-name">'+esc(d.n)+"</span></span>"
      + '<span class="t-foot"><span class="t-price fx-num">'+inr(d.p)+"</span>"
      + (qty===0
          ? '<span class="t-add">'+ic("plus",16)+"</span>"
          : '<span class="stp"><span class="mns" data-mns="'+d.id+'">'+ic("minus",14)+'</span><span class="dc-qty fx-num">'+qty+'</span><span class="pls" data-pls="'+d.id+'">'+ic("plus",14)+"</span></span>")
      + "</span></button>";
  }).join("") + (list.length===0?'<p style="grid-column:1/-1;padding:48px 0;text-align:center;font-size:13px;font-weight:600;color:var(--fx-muted)">No dishes match “'+esc(posQuery)+'”.</p>':"");
  $("#posShown").textContent = list.length+" SHOWN";
  $("#posShown").style.display = window.innerWidth>=768 ? "block":"none";
  $$("[data-dish]").forEach(function(b){
    b.addEventListener("click",function(e){
      if (e.target.closest("[data-mns],[data-pls]")) return;
      var id = b.getAttribute("data-dish");
      cart[id] = (cart[id]||0)+1; paintPosGrid(); paintDock();
    });
  });
  $$("[data-pls]").forEach(function(s){ s.addEventListener("click",function(e){ e.stopPropagation(); var id=s.getAttribute("data-pls"); cart[id]++; paintPosGrid(); paintDock(); }); });
  $$("[data-mns]").forEach(function(s){ s.addEventListener("click",function(e){ e.stopPropagation(); var id=s.getAttribute("data-mns"); if(--cart[id]<=0) delete cart[id]; paintPosGrid(); paintDock(); }); });
}
function paintDock(){
  var lines = cartLines();
  var subtotal = lines.reduce(function(s,l){return s+l.d.p*l.q},0);
  var disc = Math.min(discount||0, subtotal), taxable = subtotal-disc;
  var tax = Math.round(taxable*GST_RATE*100)/100, total = taxable+tax;
  var items = lines.reduce(function(s,l){return s+l.q},0);
  var dock = $("#dock"); if (!dock) return;
  dock.innerHTML =
    '<div class="d-head"><div><div class="fx-label">CURRENT BILL · '+esc(upperName())+'</div><div style="font-size:12.5px;font-weight:700;color:var(--fx-ink)">Counter 01 · '+istDateLong()+'</div></div>'
    +'<span class="d-count">'+items+" ITEM"+(items===1?"":"S")+'</span>'
    +'<span class="d-note">'+(LIVE.todayBills+RANGES["today"].stats.bills)+" BILLS TODAY · AUTO-RECORDED</span></div>"
    +'<div class="d-chips fxscroll">'+(lines.length===0
      ? '<p class="d-empty">Cart is empty — tap dishes above and they land here. The bill writes itself to the database.</p>'
      : lines.map(function(l){
          return '<div class="d-chip">'+veg(true)+'<span class="dc-n">'+esc(l.d.n)+'</span><span class="dc-q"><button class="qm" data-dmns="'+l.d.id+'" aria-label="Decrease '+esc(l.d.n)+'">'+ic("minus",12)+'</button><span class="dc-qty fx-num">'+l.q+'</span><button class="qp" data-dpls="'+l.d.id+'" aria-label="Increase '+esc(l.d.n)+'">'+ic("plus",12)+'</button></span><span class="dc-amt fx-num">'+inr(l.d.p*l.q)+'</span><button class="dc-x" data-drm="'+l.d.id+'" aria-label="Remove '+esc(l.d.n)+'">'+ic("trash",14)+"</button></div>";
        }).join(""))+"</div>"
    +'<div class="d-totals">'
    +'<span class="dt-item">SUBTOTAL <b class="fx-num" id="dtSub">'+inr2(subtotal)+"</b></span>"
    +'<span class="dt-item">GST 5% <b class="fx-num" id="dtTax">'+inr2(tax)+"</b></span>"
    +'<label class="dt-item">DISCOUNT ₹ <input id="discIn" type="number" min="0" value="'+(discount||"")+'" placeholder="0" aria-label="Discount in rupees" /></label>'
    +'<span class="dt-total"><span class="fx-label">TOTAL</span><b id="dtTot">'+inr2(total)+"</b></span>"
    +'<button class="gen-b" id="genBtn"'+(lines.length===0?" disabled":"")+'>'+ic("zap",16)+' <span id="dtGen">GENERATE BILL · '+inr2(total)+"</span></button></div>";
  $$("[data-dpls]").forEach(function(s){ s.addEventListener("click",function(){ var id=s.getAttribute("data-dpls"); cart[id]++; paintPosGrid(); paintDock(); }); });
  $$("[data-dmns]").forEach(function(s){ s.addEventListener("click",function(){ var id=s.getAttribute("data-dmns"); if(--cart[id]<=0) delete cart[id]; paintPosGrid(); paintDock(); }); });
  $$("[data-drm]").forEach(function(s){ s.addEventListener("click",function(){ delete cart[s.getAttribute("data-drm")]; paintPosGrid(); paintDock(); }); });
  $("#discIn").addEventListener("input",function(){ discount = Math.max(0, Number(this.value)||0); updateDockTotals(); });
  $("#genBtn").addEventListener("click",generateBill);
}
/* recalc totals in place — the discount field never loses focus while typing */
function updateDockTotals(){
  var lines = cartLines();
  var subtotal = lines.reduce(function(s,l){return s+l.d.p*l.q},0);
  var disc = Math.min(discount||0, subtotal), taxable = subtotal-disc;
  var tax = Math.round(taxable*GST_RATE*100)/100, total = taxable+tax;
  var sub = $("#dtSub"), tx = $("#dtTax"), tt = $("#dtTot"), gb = $("#dtGen");
  if (sub) sub.textContent = inr2(subtotal);
  if (tx) tx.textContent = inr2(tax);
  if (tt) tt.textContent = inr2(total);
  if (gb) gb.textContent = "GENERATE BILL · "+inr2(total);
}
function generateBill(){
  var lines = cartLines(); if (!lines.length) return;
  var gen = $("#genBtn"); gen.disabled = true;
  gen.innerHTML = '<svg class="spin" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> SAVING BILL…';
  setTimeout(function(){
    var subtotal = lines.reduce(function(s,l){return s+l.d.p*l.q},0);
    var disc = Math.min(discount||0, subtotal), taxable = subtotal-disc;
    var tax = Math.round(taxable*GST_RATE*100)/100, total = Math.round((taxable+tax)*100)/100;
    var count = lines.reduce(function(s,l){return s+l.q},0);
    LIVE.lastBillNumber += 1;
    var bill = {id:"b"+LIVE.lastBillNumber, number:LIVE.lastBillNumber, subtotal:subtotal, discount:disc, tax:tax, total:total,
      itemCount:count, createdAt:new Date().toISOString(),
      items:lines.map(function(l){return {id:l.d.id,name:l.d.n,qty:l.q,price:l.d.p,category:l.d.c}})};
    BILLS.unshift(bill); if (BILLS.length>9) BILLS.pop();
    LIVE.todayBills++; LIVE.todayRevenue += total; LIVE.todayItems += count;
    cart = {}; discount = 0;
    dashBuilt = false; renderDash(true); dashBuilt = true;
    posBuilt = false; renderPos(true); posBuilt = true;  // refresh dock count + tiles
    openReceipt(bill);
    toast("Bill #"+bill.number+" saved · "+HOTEL.name, count+" item(s) auto-fed to the database — no entry needed.");
  },800);
}

/* ═══════════════ RECEIPT (receipt-dialog.tsx) ═══════════════ */
function openReceipt(bill){
  var cgst = bill.tax/2, sgst = bill.tax-cgst;
  $("#rcptCard").innerHTML =
    '<div class="rcpt-sheet"><div class="r-c"><div class="r-h">'+esc(upperName())+'</div><div class="r-tag">'+esc(HOTEL.tagline)+'</div>'
    +'<div class="r-sub">'+esc(HOTEL.address)+" · "+esc(HOTEL.phone)+'</div>'
    +'<div class="r-legal">GSTIN: '+esc(HOTEL.gstin)+" · "+esc(HOTEL.fssai)+"</div></div>"
    +'<div class="rc-sep"></div>'
    +'<div class="r-meta"><span>BILL #'+bill.number+"</span><span>"+istDateTime(bill.createdAt)+'</span></div>'
    +'<div class="r-meta" style="font-size:10.5px;color:#555"><span>'+esc(HOTEL.cashier)+"</span><span>DINE-IN / TAKEAWAY</span></div>"
    +'<div class="rc-sep"></div>'
    +"<table><thead><tr><th>#</th><th>ITEM</th><th class=\"c\">QTY</th><th class=\"r\">RATE</th><th class=\"r\">AMT</th></tr></thead><tbody>"
    + bill.items.map(function(it,i){
        return "<tr><td class=\"m\">"+(i+1)+".</td><td>"+esc(it.name)+'<span class="cat">'+esc(it.category)+"</span></td><td class=\"c\">"+it.qty+'</td><td class="r">'+inr2(it.price)+'</td><td class="r">'+inr2(it.qty*it.price)+"</td></tr>";
      }).join("")
    +"</tbody></table><div class=\"rc-sep\"></div>"
    +'<div class="r-tot"><span>SUBTOTAL ('+bill.itemCount+' items)</span><span>'+inr2(bill.subtotal)+'</span></div>'
    +'<div class="r-tot"><span>DISCOUNT</span><span>− '+inr2(bill.discount)+'</span></div>'
    +'<div class="r-tot dim"><span>CGST @ 2.5%</span><span>'+inr2(cgst)+'</span></div>'
    +'<div class="r-tot dim"><span>SGST @ 2.5%</span><span>'+inr2(sgst)+'</span></div>'
    +'<div class="rc-sep"></div><div class="r-grand"><span>GRAND TOTAL</span><span>'+inr2(bill.total)+"</span></div>"
    +'<div class="rc-sep"></div><div class="r-foot">TAXES AS APPLICABLE · THIS IS A COMPUTER-GENERATED BILL'
    +'<div class="r-thanks">THANK YOU · VISIT AGAIN</div><div class="r-pw">'+PLATFORM.receiptLine+" · ZERO-ENTRY BILLING</div></div></div>"
    +'<div class="rcpt-acts"><button class="btng" onclick="window.print()">'+ic("printer",13)+"PRINT</button><button class=\"btnp\" id=\"rcptClose\">DONE</button></div>";
  $("#rcptOv").classList.add("on");
  $("#rcptClose").addEventListener("click",function(){ $("#rcptOv").classList.remove("on"); });
}
$("#rcptOv").addEventListener("click",function(e){ if (e.target===this) this.classList.remove("on"); });

/* ═══════════════ MANAGEMENT (management-view.tsx) ═══════════════ */
var mgmtBuilt = false;
var msecOpen = {emp:true, raw:true, maint:true, menu:false, prof:false};
var confirmArm = {};
function renderManage(force){
  if (mgmtBuilt && !force) return; mgmtBuilt = true;
  $("#viewManage").innerHTML =
    tier("04","TIER 04 · RESTAURANT MANAGEMENT","Management","Team, costs & menu in four tidy subsections. Everything here flows into the dashboard automatically — the dashboard does every calculation by itself.",
      {html:'<span id="mgTag"></span>'})
    + '<div class="fx-card msec" style="margin-top:20px" id="secEmp"></div>'
    + '<div class="mgrid" style="margin-top:20px"><div class="fx-card msec" id="secRaw"></div><div class="fx-card msec" id="secMaint"></div></div>'
    + '<div class="fx-card msec" style="margin-top:20px" id="secMenu"></div>'
    + '<div class="fx-card msec" style="margin-top:20px" id="secProf"></div>';
  paintManage();
}
function msecHead(sec, num, icon, title, badge){
  return '<button class="mhead" data-sec="'+sec+'"><span class="mh-num">'+ic(icon,14)+"</span>"
    +'<span class="mh-mid"><span class="mh-t">'+esc(title)+'</span><span class="mh-s">'+badge+"</span></span>"
    +'<span class="mcar">'+ic("chevD",15)+"</span></button>";
}
function wireMsec(){
  $$("[data-sec]").forEach(function(b){
    b.addEventListener("click",function(){
      var k = b.getAttribute("data-sec");
      msecOpen[k] = !msecOpen[k];
      b.parentElement.classList.toggle("open", msecOpen[k]);
    });
  });
}
function paintManage(){
  var act = EMPS.filter(function(e){return e.a}), rem = EMPS.filter(function(e){return !e.a});
  var monthly = act.reduce(function(s,e){return s+e.s},0);
  var mRaw = monthlyRaw(), mMnt = monthlyMaint();
  var actDishes = DISHES.filter(function(d){return d.active});
  $("#mgTag").textContent = act.length+" EMPLOYEES · "+actDishes.length+" LIVE DISHES";
  /* 01 · EMPLOYEE LIST */
  $("#secEmp").classList.toggle("open", msecOpen.emp);
  $("#secEmp").innerHTML = msecHead("emp","01","users","EMPLOYEE LIST", act.length+" STAFF · "+inr(monthly)+"/MO")
    + '<div class="mbody">'
    + '<div class="addrow"><input class="inp" id="empN" placeholder="Name…" style="flex:1.2;min-width:150px" /><input class="inp" id="empR" placeholder="Role e.g. Cook" style="flex:1;min-width:130px" /><input class="inp fx-num" id="empS" type="number" min="0" placeholder="₹/month" style="width:110px" /><button class="mini-btn" id="empAdd">'+ic("plus",14)+"ADD</button></div>"
    + '<div class="rowlist fxscroll">'+ act.map(empRow).join("") + (act.length===0?'<p style="padding:32px 0;text-align:center;font-size:13px;font-weight:600;color:var(--fx-muted)">No employees yet — add your team above.</p>':"") + "</div>"
    + (rem.length?'<button class="ghosty" id="showRem" style="margin-top:8px">SHOW REMOVED STAFF ('+rem.length+')</button><div id="remList" class="rowlist fxscroll" style="display:none;max-height:180px">'+rem.map(empRow).join("")+"</div>":"")
    + '<p class="note" style="margin-top:8px">EDIT changes name, role or salary. Salaries flow into the dashboard automatically — day = ÷30, week = ÷30×7, year = ×12.</p></div>';
  /* 02 · RAW MATERIALS */
  $("#secRaw").classList.toggle("open", msecOpen.raw);
  $("#secRaw").innerHTML = msecHead("raw","02","sprout","RAW MATERIALS","THIS MONTH · "+inr(mRaw))
    + '<div class="mbody"><div class="addrow"><input class="inp" id="rawL" placeholder="What? e.g. vegetables, rice, oil…" style="flex:1;min-width:180px" /><input class="inp fx-num" id="rawA" type="number" min="0" placeholder="₹" style="width:104px" /><input class="inp fx-num" id="rawD" type="date" style="width:140px" /><button class="mini-btn" id="rawAdd">'+ic("plus",14)+"ADD</button></div>"
    + '<div class="rowlist fxscroll" style="max-height:300px">'+ EXP_RAW.map(function(x){return expRow(x,"raw")}).join("") + "</div>"
    + '<p class="note" style="margin-top:8px">Every entry flows into the dashboard\'s raw-material cost split for its period.</p></div>';
  /* 03 · MAINTENANCE */
  $("#secMaint").classList.toggle("open", msecOpen.maint);
  $("#secMaint").innerHTML = msecHead("maint","03","wrench","MAINTENANCE","THIS MONTH · "+inr(mMnt))
    + '<div class="mbody"><div class="addrow"><input class="inp" id="mntL" placeholder="What? e.g. gas cylinder, repairs, pest control…" style="flex:1;min-width:180px" /><input class="inp fx-num" id="mntA" type="number" min="0" placeholder="₹" style="width:104px" /><input class="inp fx-num" id="mntD" type="date" style="width:140px" /><button class="mini-btn" id="mntAdd">'+ic("plus",14)+"ADD</button></div>"
    + '<div class="rowlist fxscroll" style="max-height:300px">'+ EXP_MAINT.map(function(x){return expRow(x,"maint")}).join("") + "</div>"
    + '<p class="note" style="margin-top:8px">Every entry flows into the dashboard\'s maintenance cost split for its period.</p></div>';
  /* 04 · MENU & SECTIONS */
  $("#secMenu").classList.toggle("open", msecOpen.menu);
  var menuCats = CATS.map(function(c){
    var list = DISHES.filter(function(d){return d.c===c});
    if (!list.length) return "";
    return '<div class="menu-cat"><div class="mc-h"><b>'+esc(c.toUpperCase())+'</b><span class="mut-chip">'+list.filter(function(d){return d.active}).length+'</span><span class="hline"></span></div>'
      + '<div class="menu-items">'+ list.map(dishRow).join("") +"</div></div>";
  }).join("");
  $("#secMenu").innerHTML = msecHead("menu","04","utensils","MENU & SECTIONS", actDishes.length+" DISHES · "+CATS.length+" SECTIONS")
    + '<div class="mbody">'
    + '<div class="addrow" style="border:1px dashed var(--fx-line);border-radius:16px;background:var(--fx-lav);padding:12px">'+ic("grid",16)+'<span style="font-size:11px;font-weight:800;letter-spacing:.08em">ADD SECTION</span><input class="inp" id="catN" placeholder="New category — e.g. Rice, Ice Cream, Smoothies…" style="flex:1;min-width:200px;background:var(--fx-surf)" /><button class="mini-btn" id="catAdd" style="margin-left:0">'+ic("plus",14)+"CREATE</button></div>"
    + '<div class="addrow" style="margin-top:12px"><input class="inp" id="dishN" placeholder="Dish name…" style="flex:1.4;min-width:160px" /><input class="inp fx-num" id="dishP" type="number" min="0" placeholder="₹ Price" style="width:110px" /><select class="inp" id="dishC" style="width:auto;min-width:150px">'+CATS.map(function(c){return "<option>"+esc(c)+"</option>"}).join("")+'</select><button class="mini-btn" id="dishAdd">'+ic("plus",14)+"ADD DISH</button></div>"
    + '<div class="menu-grid">'+menuCats+"</div>"
    + '<p class="note" style="margin-top:16px">EDIT renames a dish or changes its price — the dish keeps its full sales history, and old bills stay exactly as printed.</p></div>';
  /* 05 · HOTEL PROFILE */
  $("#secProf").classList.toggle("open", msecOpen.prof);
  $("#secProf").innerHTML = '<button class="mhead" data-sec="prof"><span class="mh-num">'+ic("hotel",14)+"</span>"
    +'<span class="mh-mid"><span class="mh-t">HOTEL PROFILE</span><span class="mh-s">TENANT IDENTITY · EDITABLE</span></span>'
    +'<span class="mut-chip" style="margin-left:auto;max-width:240px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc(upperName())+'</span><span class="mcar">'+ic("chevD",15)+"</span></button>"
    + '<div class="mbody"><div class="addrow"><input class="inp" id="profName" value="'+esc(HOTEL.name)+'" style="flex:1;min-width:180px" /><button class="mini-btn" id="profSave">'+ic("save",14)+"SAVE NAME</button></div>"
    + '<p class="note" style="margin-top:10px">This name is a <b>tenant variable</b> — it flows onto every bill, PDF and dashboard inside your app. The Fetch-X platform brand never changes.</p></div>';
  wireManageActions();
  wireMsec();
}
function empRow(e){
  var armed = confirmArm["emp:"+e.id];
  return '<div class="trow'+(e.a?"":" dim")+'"><span class="av">'+esc(e.n.slice(0,1).toUpperCase())+'</span><div class="t-main"><span class="t-name">'+esc(e.n)+'</span><span class="t-sub">'+esc(e.r)+"</span></div>"
    +'<span class="t-end fx-num">'+inr(e.s)+'<span class="per">/MO</span></span>'
    +'<span class="row-acts">'+(e.a
      ? '<button class="ra edit" data-empedit="'+e.id+'">'+ic("pencil",12)+'</button><button class="ra" data-empdel="'+e.id+'">'+(armed?"SURE?":"REMOVE")+"</button>"
      : '<button class="ra edit" data-empback="'+e.id+'">RESTORE</button>')+"</span></div>";
}
function expRow(x, kind){
  var armed = confirmArm[kind+":"+x.id];
  var color = kind==="raw"?"#0d9488":"var(--fx-amber)";
  var label = kind==="raw"?"RAW MATERIAL":"MAINTENANCE";
  return '<div class="trow"><span class="dot" style="background:'+color+'"></span><div class="t-main"><span class="t-name">'+esc(x.l)+'</span><span class="t-sub">'+label+" · "+new Date(x.d+"T12:00:00").toLocaleDateString("en-IN",{timeZone:"Asia/Calcutta",day:"numeric",month:"short"})+"</span></div>"
    +'<span class="t-end fx-num">'+inr(x.a)+"</span>"
    +'<span class="row-acts"><button class="ra" data-'+kind+'del="'+x.id+'">'+(armed?"SURE?":"REMOVE")+"</button></span></div>";
}
function dishRow(d){
  var armed = confirmArm["dish:"+d.id];
  return '<div class="mi'+(d.active?"":" dim")+'">'+veg(true)+'<span class="mi-n">'+esc(d.n)+(d.active?"":' <span class="ina-chip">INACTIVE</span>')+"</span>"
    +'<span class="mi-p fx-num">'+inr(d.p)+"</span>"
    +'<span class="row-acts">'+(d.active
      ? '<button class="ra" data-dishdel="'+d.id+'">'+(armed?"SURE?":"REMOVE")+"</button>"
      : '<button class="ra edit" data-dishback="'+d.id+'">RESTORE</button>')+"</span></div>";
}
function arm(key, fn){
  if (confirmArm[key]){ delete confirmArm[key]; fn(); return true; }
  confirmArm[key] = true;
  setTimeout(function(){ if (confirmArm[key]){ delete confirmArm[key]; paintManage(); } },3000);
  return false;
}
function todayStr(){ return new Date().toISOString().slice(0,10); }
function wireManageActions(){
  $$("[data-empdel]").forEach(function(b){ b.addEventListener("click",function(){
    var id = b.getAttribute("data-empdel");
    if (arm("emp:"+id,function(){
      var e = EMPS.filter(function(x){return x.id===id})[0]; e.a=false;
      toast(e.n+" removed","Salaries leave every dashboard range instantly.");
      refreshAll();
    })) return;
    paintManage();
  }); });
  $$("[data-empback]").forEach(function(b){ b.addEventListener("click",function(){
    var e = EMPS.filter(function(x){return x.id===b.getAttribute("data-empback")})[0]; e.a=true;
    toast(e.n+" restored","Back on the roster.");
    refreshAll();
  }); });
  $("#empAdd").addEventListener("click",function(){
    var n = $("#empN").value.trim(), r = $("#empR").value.trim()||"Staff", s = Number($("#empS").value);
    if (!n || !Number.isFinite(s) || s<=0){ toast("Missing details","Employee needs a name and a monthly salary above zero."); return; }
    EMPS.push({id:"e"+Date.now(), n:n, r:r, s:s, a:true});
    toast(n+" joined the team","Salary flows into the dashboard automatically.");
    refreshAll();
  });
  $$("[data-rawdel]").forEach(function(b){ b.addEventListener("click",function(){
    var id = b.getAttribute("data-rawdel");
    if (arm("raw:"+id,function(){
      var i = EXP_RAW.findIndex(function(x){return x.id===id}); if (i>-1) EXP_RAW.splice(i,1);
      toast("Entry deleted","Raw-material costs recompute in the dashboard.");
      refreshAll();
    })) return;
    paintManage();
  }); });
  $$("[data-maintdel]").forEach(function(b){ b.addEventListener("click",function(){
    var id = b.getAttribute("data-maintdel");
    if (arm("maint:"+id,function(){
      var i = EXP_MAINT.findIndex(function(x){return x.id===id}); if (i>-1) EXP_MAINT.splice(i,1);
      toast("Entry deleted","Maintenance costs recompute in the dashboard.");
      refreshAll();
    })) return;
    paintManage();
  }); });
  var addExp = function(kind){
    var l = $("#"+(kind==="raw"?"rawL":"mntL")).value.trim(), a = Number($("#"+(kind==="raw"?"rawA":"mntA")).value), d = $("#"+(kind==="raw"?"rawD":"mntD")).value || todayStr();
    if (!Number.isFinite(a) || a<=0){ toast("Amount needed","Enter the cost amount above zero."); return; }
    var row = {id:(kind==="raw"?"r":"m")+Date.now(), l:l|| (kind==="raw"?"Raw material":"Maintenance"), a:a, d:d};
    (kind==="raw"?EXP_RAW:EXP_MAINT).unshift(row);
    toast((kind==="raw"?"Raw material":"Maintenance")+" cost of "+inr(a)+" recorded","Flows into the dashboard cost split.");
    refreshAll();
  };
  $("#rawAdd").addEventListener("click",function(){ addExp("raw"); });
  $("#mntAdd").addEventListener("click",function(){ addExp("maint"); });
  $("#catAdd").addEventListener("click",function(){
    var n = $("#catN").value.trim();
    if (!n){ toast("Section name needed","Examples: Rice, Ice Cream, Smoothies, Combos…"); return; }
    if (CATS.indexOf(n)===-1) CATS.push(n);
    toast("Section “"+n+"” created","Add the first dish below.");
    refreshAll();
  });
  $("#dishAdd").addEventListener("click",function(){
    var n = $("#dishN").value.trim(), p = Number($("#dishP").value), c = $("#dishC").value;
    if (!n || !Number.isFinite(p) || p<=0){ toast("Missing details","Dish needs a name and a price above zero."); return; }
    DISHES.push({id:"d"+Date.now(), n:n, p:p, c:c, veg:true, active:true});
    toast(n+" added to "+c,"Instantly live on the POS.");
    refreshAll();
  });
  $$("[data-dishdel]").forEach(function(b){ b.addEventListener("click",function(){
    var id = b.getAttribute("data-dishdel");
    if (arm("dish:"+id,function(){
      var d = DISHES.filter(function(x){return x.id===id})[0]; d.active=false;
      toast(d.name+" removed from POS","Old bills keep their frozen snapshots — history intact.");
      refreshAll();
    })) return;
    paintManage();
  }); });
  $$("[data-dishback]").forEach(function(b){ b.addEventListener("click",function(){
    var d = DISHES.filter(function(x){return x.id===b.getAttribute("data-dishback")})[0]; d.active=true;
    toast(d.name+" is live again","Back on the POS.");
    refreshAll();
  }); });
  $("#profSave").addEventListener("click",function(){
    var v = $("#profName").value.trim();
    if (v.length<2){ toast("Could not rename","Name needs at least 2 characters."); return; }
    HOTEL.name = v;
    $("#sbMark").textContent = hotelInitials(v);
    $("#sbName").textContent = v.toUpperCase();
    toast("Hotel renamed — every screen now says “"+v+"”","The tenant identity flows everywhere. Fetch-X stays fixed.");
    refreshAll();
  });
  var sr = $("#showRem");
  if (sr) sr.addEventListener("click",function(){
    var l = $("#remList"); l.style.display = l.style.display==="none" ? "" : "none";
    sr.textContent = l.style.display==="none" ? "SHOW REMOVED STAFF ("+EMPS.filter(function(e){return !e.a}).length+")" : "HIDE REMOVED STAFF";
  });
}
