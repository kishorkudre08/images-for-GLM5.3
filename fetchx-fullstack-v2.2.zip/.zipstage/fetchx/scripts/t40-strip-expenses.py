#!/usr/bin/env python3
"""Task 40: remove the EXPENSES section from management-view.tsx (moved to
expenses-view.tsx) and renumber the remaining sections (05 tier, 01 emp,
02 menu, 03 rooms)."""
import re, sys

P = "/home/z/my-project/src/components/management-view.tsx"
src = open(P, encoding="utf-8").read()

def cut_between(s, start_marker, end_marker, keep_end=True):
    """Delete lines from start_marker (inclusive) to end_marker (exclusive)."""
    i = s.index(start_marker)
    j = s.index(end_marker, i)
    return s[:i] + (s[j:] if keep_end else "")

# 1 ── imports: drop Wrench / Carrot / Wallet / FxDatePicker / Expense type
for line in ("  Wrench,\n", "  Carrot,\n", "  Wallet,\n"):
    assert line in src, line
    src = src.replace(line, "", 1)
rep = [
    ('import { TierBand, VegDot, FxDatePicker } from "@/components/fx";',
     'import { TierBand, VegDot } from "@/components/fx";'),
    ('import type { Category, Dish, Employee, Expense } from "@/lib/types";',
     'import type { Category, Dish, Employee } from "@/lib/types";'),
]
for old, new in rep:
    assert old in src, old
    src = src.replace(old, new, 1)

# 2 ── module helpers: todayStr / istDayLabel / ExpenseKind
old = '''const todayStr = () => new Date().toISOString().slice(0, 10);
const istDayLabel = (iso: string) =>
  new Date(iso).toLocaleDateString("en-IN", { timeZone: "Asia/Kolkata", day: "numeric", month: "short" });

type ExpenseKind = "raw_material" | "maintenance";

'''
assert old in src
src = src.replace(old, "", 1)

# 3 ── state: expenses lists gone
old = '''  const [rawCosts, setRawCosts] = React.useState<Expense[]>([]);
  const [maintCosts, setMaintCosts] = React.useState<Expense[]>([]);
'''
assert old in src
src = src.replace(old, "", 1)

# 4 ── loadOps: employees + categories only
old = '''      const [e, r, m, c] = await Promise.all([
        fetch("/api/employees").then((x) => x.json()),
        fetch("/api/expenses?kind=raw_material&limit=200").then((x) => x.json()),
        fetch("/api/expenses?kind=maintenance&limit=200").then((x) => x.json()),
        fetch("/api/categories").then((x) => x.json()),
      ]);
      setEmployees(Array.isArray(e) ? e : []);
      setRawCosts(Array.isArray(r) ? r : []);
      setMaintCosts(Array.isArray(m) ? m : []);
      setCategories(Array.isArray(c) ? c : []);
'''
new = '''      const [e, c] = await Promise.all([
        fetch("/api/employees").then((x) => x.json()),
        fetch("/api/categories").then((x) => x.json()),
      ]);
      setEmployees(Array.isArray(e) ? e : []);
      setCategories(Array.isArray(c) ? c : []);
'''
assert old in src
src = src.replace(old, new, 1)

# 5 ── month sums (expenses badge) gone
old = '''  const monthKey = todayStr().slice(0, 7);
  const monthSum = (list: Expense[]) =>
    list.filter((x) => x.spentOn.slice(0, 7) === monthKey).reduce((s, x) => s + x.amount, 0);
  const monthRaw = monthSum(rawCosts);
  const monthMaint = monthSum(maintCosts);

'''
assert old in src
src = src.replace(old, "", 1)

# 6 ── collapsible state: exp key gone
old = '''    emp: true,
    exp: true,
'''
assert old in src
src = src.replace(old, "    emp: true,\n", 1)

# 7 ── EXPENSES book state block gone
old = '''  // ── EXPENSES book state — the toggle filters the mixed feed; new entries go ──
  // to whichever book the "NEW ENTRIES" selector points at.
  const [expBook, setExpBook] = React.useState<"all" | "rest" | "lodge">("all");
  const [expNewBook, setExpNewBook] = React.useState<"rest" | "lodge">("rest");

'''
assert old in src
src = src.replace(old, "", 1)

# 8 ── the whole expenses code block (draft state → expensesBody)
src = cut_between(
    src,
    "  // ══ 02 / 03 · RAW MATERIALS & MAINTENANCE ══",
    "  // ══ 04 · ROOMS & RATES — the level categorizer (live-validated draft) ══",
)

# 9 ── the EXPENSES render card gone
src = cut_between(
    src,
    '      {/* ── 02 · EXPENSES — raw materials + maintenance in one mixed feed ── */}',
    '      {/* ── 03 · MENU & SECTIONS (collapsed by default) ── */}',
)

# 10 ── renumber what is left
ren = [
    ('num="04"\n        eyebrow="TIER 04 · RESTAURANT MANAGEMENT"',
     'num="05"\n        eyebrow="TIER 05 · RESTAURANT MANAGEMENT"'),
    ('sub="Team, expenses, menu & room rates in four tidy subsections.',
     'sub="Team, menu & room rates in three tidy subsections.'),
    ('// ══ 04 · ROOMS & RATES — the level categorizer (live-validated draft) ══',
     '// ══ 03 · ROOMS & RATES — the level categorizer (live-validated draft) ══'),
    ('// ══ 04 · MENU & SECTIONS (collapsible) ══',
     '// ══ 02 · MENU & SECTIONS (collapsible) ══'),
    ('{/* ── 03 · MENU & SECTIONS (collapsed by default) ── */}',
     '{/* ── 02 · MENU & SECTIONS (collapsed by default) ── */}'),
    ('{sectionHead("03", <UtensilsCrossed className="h-3.5 w-3.5" />, "MENU & SECTIONS"',
     '{sectionHead("02", <UtensilsCrossed className="h-3.5 w-3.5" />, "MENU & SECTIONS"'),
    ('{/* ── 04 · ROOMS & RATES — the level categorizer (live-validated) ── */}',
     '{/* ── 03 · ROOMS & RATES — the level categorizer (live-validated) ── */}'),
    ('{sectionHead("04", <BedDouble className="h-3.5 w-3.5" />, "ROOMS & RATES"',
     '{sectionHead("03", <BedDouble className="h-3.5 w-3.5" />, "ROOMS & RATES"'),
]
for old, new in ren:
    assert old in src, old
    src = src.replace(old, new, 1)

# 11 ── collapse triple blank lines left behind by the cuts
src = re.sub(r"\n{3,}", "\n\n", src)

open(P, "w", encoding="utf-8").write(src)
print("OK — management-view.tsx rewritten:", len(src.splitlines()), "lines")
