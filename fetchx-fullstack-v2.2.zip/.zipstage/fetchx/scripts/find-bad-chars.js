const fs = require("fs");
const s = fs.readFileSync("scripts/demo-extracted.js", "utf8");
const lines = s.split("\n");
const bad = /[\u2018\u2019\u201C\u201D\u00A0\u2028\u2029\u200B\uFEFF]/;
lines.forEach((l, i) => {
  const m = l.match(bad);
  if (m) console.log("LINE", i + 1, "char U+" + m[0].charCodeAt(0).toString(16).toUpperCase(), JSON.stringify(l.slice(Math.max(0, m.index - 40), m.index + 40)));
});
// also report unbalanced quotes per line heuristically for lines with odd counts of '
lines.forEach((l, i) => {
  const sq = (l.match(/'/g) || []).length;
  if (sq % 2 === 1) console.log("ODD-SQ LINE", i + 1, l.slice(0, 120));
});
