// Task 40 — verify successive bill numbering (gap fill after undo)
const BASE = "http://localhost:3000";

async function j(path, opts) {
  const r = await fetch(BASE + path, opts);
  const out = await r.json().catch(() => ({}));
  return { status: r.status, out };
}

const menu = (await j("/api/menu")).out.filter((d) => d.active);
const pick = (n) =>
  menu
    .slice(0, n)
    .map((d) => ({ dishId: d.id, qty: 1 }));

// ── restaurant ────────────────────────────────────────────────────────────
const before = (await j("/api/bills?limit=5")).out.map((b) => b.number);
console.log("restaurant recent numbers before:", before.join(", "));

const b1 = await j("/api/bills", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ items: pick(2) }),
});
console.log("created bill #", b1.out.number, "total", b1.out.total);

// tear it (same as feed UNDO)
await j(`/api/bills/${b1.out.id}`, { method: "DELETE" });
console.log("deleted bill #", b1.out.number);

const b2 = await j("/api/bills", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ items: pick(1) }),
});
console.log("re-created bill #", b2.out.number, "== reused?", b2.out.number === b1.out.number ? "YES ✓" : "NO ✗");

// clean the test bill so the demo data stays untouched
await j(`/api/bills/${b2.out.id}`, { method: "DELETE" });
const after = (await j("/api/bills?limit=5")).out.map((b) => b.number);
console.log("restaurant recent numbers after:", after.join(", "));

// ── lodge ─────────────────────────────────────────────────────────────────
const wall = await j("/api/lodge");
const lv = wall.out.levels[0];
const freeRoom = wall.out.rooms.find((r) => r.status === "avl" && r.number >= lv.from && r.number <= lv.to);
console.log("lodge free room for test:", freeRoom?.number);

const lb1num = (await j("/api/lodge")).out.bills[0].number; // newest existing
const ci = await j("/api/lodge", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ action: "checkin", room: freeRoom.number, name: "Test Numbering", phone: "9800000000" }),
});
const co1 = await j("/api/lodge", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ action: "checkout", room: freeRoom.number }),
});
console.log("stay bill L-", co1.out.bill?.number, "(newest before was L-" + lb1num + ")");
await j("/api/lodge", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ action: "bill-undo", number: co1.out.bill.number }),
});
console.log("undid L-", co1.out.bill.number);
// checkin + checkout again → number must be reused
await j("/api/lodge", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ action: "checkin", room: freeRoom.number, name: "Test Numbering", phone: "9800000000" }),
});
const co2 = await j("/api/lodge", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ action: "checkout", room: freeRoom.number }),
});
console.log(
  "re-created stay bill L-",
  co2.out.bill?.number,
  "== reused?",
  co2.out.bill.number === co1.out.bill.number ? "YES ✓" : "NO ✗",
);
// clean up: undo again + housekeeping
await j("/api/lodge", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ action: "bill-undo", number: co2.out.bill.number }),
});
await j("/api/lodge", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ action: "maintenance-done", room: freeRoom.number }),
});
console.log("cleanup done — room", freeRoom.number, "back to free");
