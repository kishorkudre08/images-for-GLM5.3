# Inserts scripts/lodge-engine.js as a new <script> block before the AI block
import io, sys, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEMO = os.path.join(ROOT, "download", "fetchx-demo.html")
ENGINE = os.path.join(ROOT, "scripts", "lodge-engine.js")

src = io.open(DEMO, encoding="utf-8").read()
engine = io.open(ENGINE, encoding="utf-8").read().strip()

ANCHOR = "/* ═══════════════ FETCH-X AI (ai-panel.tsx 1:1)"
if "renderLodge" in src and src.count("function renderLodge") == 1:
    print("engine already inserted"); sys.exit(0)

assert src.count(ANCHOR) == 1, "AI anchor missing/ambiguous"
src = src.replace(ANCHOR, "</script>\n<script>\n" + engine + "\n</script>\n<script>\n" + ANCHOR, 1)
io.open(DEMO, "w", encoding="utf-8").write(src)
print("engine inserted")
