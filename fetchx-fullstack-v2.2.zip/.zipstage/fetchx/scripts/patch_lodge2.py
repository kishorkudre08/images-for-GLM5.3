#!/usr/bin/env python3
# Task 23 — replace the Task-22 lodge module with the minimal 100-room wall:
# green number = available (tap -> check-in form), grey-black = occupied
# (tap -> discount + exit time -> hotel-style receipt). AI untouched.
import io, re, sys

PATH = "/home/z/my-project/download/fetchx-demo.html"
src = io.open(PATH, encoding="utf-8").read()
orig_len = len(src)

def cut(s, a, b, what):
    """replace s[a:b) — asserts both anchors exist exactly once"""
    assert s.count(a) == 1, "start anchor not unique (%s): %d" % (what, s.count(a))
    assert s.count(b) == 1, "end anchor not unique (%s): %d" % (what, s.count(b))
    ia, ib = s.index(a), s.index(b)
    assert ia < ib, "anchors out of order (%s)" % what
    return ia, ib

# ── 1. CSS block ──────────────────────────────────────────────────────────
CSS_A = "/* ═══════════ LODGE (lodge-view) — Imperial Spices Hotel · 100 rooms ═══════════ */"
CSS_B = "/* chart bits */"
NEW_CSS = """/* ═══════════ LODGE — Imperial Spices Hotel · 100-room wall ═══════════
   Green number = available (tap → check-in) · grey-black = occupied
   (tap → discount + exit time → hotel-style bill). Rate tiers:
   rooms 1–40 = ₹2,499/24h · 41–80 = ₹2,999/24h · 81–100 = ₹3,999/24h. */
.lg-band{display:flex;align-items:center;gap:10px;margin-top:24px}
.lg-band:first-child{margin-top:4px}
.lg-band .hline{height:1px;flex:1;border-top:1px dashed var(--fx-line)}
.lg-grid{display:grid;grid-template-columns:repeat(10,1fr);gap:8px;margin-top:12px}
.lg-cell{position:relative;display:grid;place-items:center;aspect-ratio:1/1;border-radius:12px;border:1px solid transparent;transition:transform .12s,box-shadow .12s}
.lg-cell:hover{transform:translateY(-2px);box-shadow:2px 3px 0 0 var(--fx-hard)}
.lg-num{font-size:clamp(12px,1.5vw,17px);font-weight:800;letter-spacing:-.01em}
.lg-cell.st-avl{background:color-mix(in srgb,var(--fx-green) 10%,transparent);border-color:color-mix(in srgb,var(--fx-green) 34%,transparent)}
.lg-cell.st-avl .lg-num{color:var(--fx-green)}
.lg-cell.st-occ{background:#232228;border-color:#3b3843}
.lg-cell.st-occ .lg-num{color:#8f8c9c}
.lg-dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin:0 5px 1px 0;vertical-align:middle}
.lg-d-avl{background:var(--fx-green)}
.lg-d-occ{background:#232228;border:1px solid #3b3843}
.lg-info{display:grid;grid-template-columns:1fr 1fr;gap:12px 16px;border:1px dashed var(--fx-line);border-radius:14px;background:var(--fx-page);padding:14px 16px}
.lg-info .lg-i .fx-label{display:block}
.lg-info .lg-i b{font-size:13px;font-weight:800;color:var(--fx-ink);overflow-wrap:anywhere}
#lodgeOv .modal-card{width:100%;max-width:440px;max-height:92vh;overflow-y:auto}
@media(max-width:640px){.lg-grid{grid-template-columns:repeat(5,1fr);gap:7px}}

"""
ia, ib = cut(src, CSS_A, CSS_B, "css")
src = src[:ia] + NEW_CSS + src[ib:]

# ── 2. remove old LODGE_* data literals ───────────────────────────────────
DATA_A = "/* ── Lodge dataset — Imperial Spices Hotel · 100 rooms · 5 floors ─────"
DATA_B = "/* ── Dashboard dataset"
ia, ib = cut(src, DATA_A, DATA_B, "data")
src = src[:ia] + src[ib:]

# ── 3. replace the whole lodge engine script block ────────────────────────
ENG_A = "<script>\n/* ═══════════════ LODGE (lodge-view) — Imperial Spices Hotel · 100 rooms ═══════════════"
ENG_B = "<script>\n/* ═══════════════ FETCH-X AI (ai-panel.tsx 1:1) — same panel, replies locked ═══ */"
ia, ib = cut(src, ENG_A, ENG_B, "engine")

NEW_ENGINE = """<script>
/* ═══════════════ LODGE — Imperial Spices Hotel · 100-room wall ═══════════════
   One wall, two moves. Green number = available → tap opens the check-in form
   (Name · Phone number · Entry time). Grey-black number = occupied → tap opens
   the exit form (Discount · Exit timing) and generates the bill exactly like
   the restaurant receipts: per started 24-hour block, then discount, then 5%
   GST (CGST 2.5% + SGST 2.5%), printed on the same thermal sheet.
   Rates: rooms 1–40 = ₹2,499/24h · 41–80 = ₹2,999/24h · 81–100 = ₹3,999/24h. */
"use strict";
var lodgeBuilt = false;
var LG_KEY = "fx-lodge-demo", LG_SEQ_KEY = "fx-lodge-bseq";
var LG_TIERS = [
  {from:1,  to:40,  rate:2499, label:"ROOMS 1 – 40"},
  {from:41, to:80,  rate:2999, label:"ROOMS 41 – 80"},
  {from:81, to:100, rate:3999, label:"ROOMS 81 – 100"}
];
function lgTier(n){ return n<=40 ? LG_TIERS[0] : n<=80 ? LG_TIERS[1] : LG_TIERS[2]; }

/* ── state — survives refresh so the demo keeps its data entries ────── */
var LG = {};
function lgLoad(){
  var raw = null;
  try{ raw = JSON.parse(localStorage.getItem(LG_KEY) || "null"); }catch(e){}
  if (raw && typeof raw === "object"){
    Object.keys(raw).forEach(function(k){
      var r = raw[k], n = Number(k);
      if (n>=1 && n<=100 && r && (r.st==="avl" || r.st==="occ")) LG[n] = r;
    });
  }
  for (var n=1; n<=100; n++){ if (!LG[n]) LG[n] = {st:"avl"}; }
}
function lgSave(){ try{ localStorage.setItem(LG_KEY, JSON.stringify(LG)); }catch(e){} }
function lgNextBill(){
  var s = 5001;
  try{ s = Number(localStorage.getItem(LG_SEQ_KEY)) || 5001; localStorage.setItem(LG_SEQ_KEY, String(s+1)); }catch(e){}
  return s;
}
function lgCounts(){
  var avl=0, occ=0, rev=0, n;
  for (n=1; n<=100; n++){ if (LG[n].st==="occ"){ occ++; rev += lgTier(n).rate; } else avl++; }
  return {avl:avl, occ:occ, rev:rev};
}

/* ── wall ───────────────────────────────────────────────────────────── */
function renderLodge(force){
  if (lodgeBuilt && !force) return; lodgeBuilt = true;
  lgLoad();
  $("#viewLodge").innerHTML =
    tier("03","TIER 03 · LODGE","Lodge Front Desk","100 rooms, one wall — green is free, grey-black is occupied. Tap a green number to check a guest in; tap a grey-black number to settle the stay and generate the bill.",
      {liveDot:true, html:'<span id="lgTag"></span><button class="mini-btn" id="lgReset" style="height:34px;padding:0 12px">'+ic("rotate",13)+'RESET WALL</button>'})
    + '<div class="fx-card fxc" style="margin-top:20px" id="lgWall"></div>';
  $("#lgReset").addEventListener("click",function(){
    var b = this;
    if (b.getAttribute("data-arm") !== "1"){
      b.setAttribute("data-arm","1"); b.innerHTML = ic("trash",13)+"SURE? TAP AGAIN";
      setTimeout(function(){ b.removeAttribute("data-arm"); b.innerHTML = ic("rotate",13)+"RESET WALL"; },3000);
      return;
    }
    for (var n=1; n<=100; n++) LG[n] = {st:"avl"};
    lgSave(); paintLodge();
    toast("Wall reset","All 100 rooms are available again.");
  });
  paintLodge();
}
function lgCell(n){
  var r = LG[n], occ = r.st === "occ", t = lgTier(n);
  var tip = occ
    ? "Room "+n+" · "+r.name+" · tap to check out & generate the bill"
    : "Room "+n+" · "+inr(t.rate)+" per 24 hours · tap to check in";
  return '<button class="lg-cell'+(occ?" st-occ":" st-avl")+'" data-lg="'+n+'" aria-label="Room '+n+(occ?" — occupied":" — available")+'" title="'+esc(tip)+'"><span class="lg-num fx-num">'+n+"</span></button>";
}
function paintLodge(){
  var c = lgCounts(), html = "", t, n, occ;
  $("#lgTag").innerHTML = '<i class="lg-dot lg-d-avl"></i>'+c.avl+' FREE&nbsp;&nbsp;<i class="lg-dot lg-d-occ"></i>'+c.occ+' OCCUPIED&nbsp;&nbsp;·&nbsp;&nbsp;'+inr(c.rev)+' / NIGHT';
  for (var i=0; i<LG_TIERS.length; i++){
    t = LG_TIERS[i]; occ = 0;
    for (n=t.from; n<=t.to; n++) if (LG[n].st === "occ") occ++;
    html += '<div class="lg-band"><span class="fx-label">'+t.label+" · "+inr(t.rate)+' / 24 HOURS</span><span class="hline"></span><span class="mut-chip">'+(t.to-t.from+1-occ)+" FREE · "+occ+" SOLD</span></div>"
          + '<div class="lg-grid">';
    for (n=t.from; n<=t.to; n++) html += lgCell(n);
    html += "</div>";
  }
  html += '<p class="note" style="margin-top:16px">Every stay bills per started 24-hour block — '+inr(2499)+" for rooms 1–40, "+inr(2999)+" for 41–80, "+inr(3999)+" for 81–100 — then discount, then 5% GST, on the same receipt as the restaurant.</p>";
  $("#lgWall").innerHTML = html;
  $$("[data-lg]").forEach(function(b){
    b.addEventListener("click",function(){ openLodgeForm(Number(b.getAttribute("data-lg"))); });
  });
}

/* ── forms ──────────────────────────────────────────────────────────── */
function openLodgeForm(n){ if (LG[n].st === "occ") openCheckOut(n); else openCheckIn(n); }
function closeLodgeModal(){ $("#lodgeOv").style.display = "none"; }
function lgShell(title, sub, body){
  $("#lodgeModal").innerHTML =
    '<div class="mc-top"><div><h3>'+title+'</h3><p class="mc-sub">'+sub+'</p></div>'
    +'<button class="mc-x" data-lclose aria-label="Close">'+ic("x",16)+"</button></div>"
    + body;
  $("#lodgeOv").style.display = "grid";
  $$("[data-lclose]").forEach(function(x){ x.addEventListener("click",closeLodgeModal); });
}
/* datetime-local value in LOCAL time (ISO slice would leak UTC) */
function dtLocal(d){
  function p(x){ return (x<10?"0":"")+x; }
  return d.getFullYear()+"-"+p(d.getMonth()+1)+"-"+p(d.getDate())+"T"+p(d.getHours())+":"+p(d.getMinutes());
}
function openCheckIn(n){
  var t = lgTier(n);
  lgShell("Room "+n+" · check in", inr(t.rate)+" per 24 hours · entry time starts the first block.",
    '<form id="lgForm">'
    +'<div><label class="fx-label" for="lgName">NAME</label><input class="inp" id="lgName" required autocomplete="off" placeholder="Guest full name" style="width:100%;margin-top:6px" /></div>'
    +'<div style="margin-top:12px"><label class="fx-label" for="lgPhone">PHONE NUMBER</label><input class="inp fx-num" id="lgPhone" required inputmode="tel" autocomplete="off" placeholder="10-digit mobile" style="width:100%;margin-top:6px" /></div>'
    +'<div style="margin-top:12px"><label class="fx-label" for="lgEntry">ENTRY TIME</label><input class="inp" id="lgEntry" type="datetime-local" value="'+dtLocal(new Date())+'" style="width:100%;margin-top:6px" /></div>'
    +'<button type="submit" class="btnp" style="width:100%;margin-top:16px">'+ic("check",14)+'CHECK IN · ROOM '+n+"</button></form>");
  setTimeout(function(){ var f = $("#lgName"); if (f) f.focus(); },80);
  $("#lgForm").addEventListener("submit",function(e){
    e.preventDefault();
    var name = $("#lgName").value.trim();
    var phone = $("#lgPhone").value.trim();
    var entryV = $("#lgEntry").value;
    if (name.length < 2){ toast("Name needed","Enter the guest's name to check in."); return; }
    if (phone.replace(/\\D/g,"").length < 10){ toast("Phone number needed","Enter a valid 10-digit mobile number."); return; }
    var ts = entryV ? new Date(entryV).getTime() : Date.now();
    if (!Number.isFinite(ts)) ts = Date.now();
    LG[n] = {st:"occ", name:name, phone:phone, entry:ts};
    lgSave(); closeLodgeModal(); paintLodge();
    toast("Room "+n+" checked in", name+" · from "+istTime(ts)+" · "+inr(t.rate)+" / 24 hours.");
  });
}
function openCheckOut(n){
  var t = lgTier(n), r = LG[n];
  lgShell("Room "+n+" · check out", "Bill = started 24-hour blocks × "+inr(t.rate)+", minus discount, plus 5% GST.",
    '<div class="lg-info">'
    +'<div class="lg-i"><span class="fx-label">GUEST</span><b>'+esc(r.name)+"</b></div>"
    +'<div class="lg-i"><span class="fx-label">PHONE</span><b class="fx-num">'+esc(r.phone)+"</b></div>"
    +'<div class="lg-i"><span class="fx-label">ENTRY</span><b>'+istDateTime(r.entry)+"</b></div>"
    +'<div class="lg-i"><span class="fx-label">RATE</span><b class="fx-num">'+inr(t.rate)+" / 24 h</b></div></div>"
    +'<form id="lgForm">'
    +'<div style="margin-top:14px"><label class="fx-label" for="lgExit">EXIT TIME</label><input class="inp" id="lgExit" type="datetime-local" value="'+dtLocal(new Date())+'" style="width:100%;margin-top:6px" /></div>'
    +'<div style="margin-top:12px"><label class="fx-label" for="lgDisc">DISCOUNT ₹</label><input class="inp fx-num" id="lgDisc" type="number" min="0" step="1" placeholder="0" style="width:100%;margin-top:6px" /></div>'
    +'<button type="submit" class="btnp" style="width:100%;margin-top:16px">'+ic("receipt",14)+'GENERATE BILL</button></form>');
  setTimeout(function(){ var f = $("#lgDisc"); if (f) f.focus(); },80);
  $("#lgForm").addEventListener("submit",function(e){
    e.preventDefault();
    var exitV = $("#lgExit").value;
    var exit = exitV ? new Date(exitV).getTime() : Date.now();
    if (!Number.isFinite(exit)) exit = Date.now();
    var hours = (exit - r.entry) / 3600000;
    if (hours <= 0){ toast("Exit time is before entry","Fix the exit time — it must be after "+istDateTime(r.entry)+"."); return; }
    var blocks = Math.max(1, Math.ceil(hours/24));
    var rate = t.rate, subtotal = blocks*rate;
    var disc = Math.min(Math.max(0, Math.round(Number($("#lgDisc").value)||0)), subtotal);
    var taxable = subtotal - disc;
    var tax = Math.round(taxable*5)/100, total = Math.round((taxable+tax)*100)/100;
    var guest = r.name, phone = r.phone, entryTs = r.entry, billNo = "L-"+lgNextBill();
    LG[n] = {st:"avl"}; lgSave(); closeLodgeModal(); paintLodge();
    openReceipt({
      number: billNo, createdAt: exit,
      items: [{name:"Room "+n+" · "+blocks+" × 24 hour"+(blocks===1?"":"s"), category:"LODGE · "+inr(rate)+" / 24 H", qty:blocks, price:rate}],
      itemCount: blocks, subtotal: subtotal, discount: disc, tax: tax, total: total,
      meta2: guest+" · "+phone, meta3: "LODGE · ROOM "+n,
      itemLabel: blocks+" × 24 hour"+(blocks===1?"":"s")+" @ "+inr(rate)
    });
    toast("Room "+n+" billed", inr2(total)+" · "+guest+" · room is free again.");
  });
}

/* overlay close: backdrop + Escape */
$("#lodgeOv").addEventListener("click",function(e){ if (e.target===this) this.style.display="none"; });
window.addEventListener("keydown",function(e){
  if (e.key==="Escape" && $("#lodgeOv").style.display==="grid") closeLodgeModal();
});
</script>
"""
src = src[:ia] + NEW_ENGINE + src[ib:]

# ── 4. openReceipt: lodge-aware meta + subtotal label ────────────────────
OLD_META = """+'<div class="r-meta" style="font-size:10.5px;color:#555"><span>'+esc(HOTEL.cashier)+"</span><span>DINE-IN / TAKEAWAY</span></div>\""""
NEW_META = """+'<div class="r-meta" style="font-size:10.5px;color:#555"><span>'+esc(bill.meta2 || HOTEL.cashier)+"</span><span>"+esc(bill.meta3 || "DINE-IN / TAKEAWAY")+"</span></div>\""""
assert src.count(OLD_META) == 1, "receipt meta anchor: %d" % src.count(OLD_META)
src = src.replace(OLD_META, NEW_META)

OLD_SUB = """+'<div class="r-tot"><span>SUBTOTAL ('+bill.itemCount+' items)</span><span>'+inr2(bill.subtotal)+'</span></div>'"""
NEW_SUB = """+'<div class="r-tot"><span>SUBTOTAL ('+esc(bill.itemLabel || bill.itemCount+' items')+')</span><span>'+inr2(bill.subtotal)+'</span></div>'"""
assert src.count(OLD_SUB) == 1, "receipt subtotal anchor: %d" % src.count(OLD_SUB)
src = src.replace(OLD_SUB, NEW_SUB)

# ── 5. drop paintLodgeCharts() from the two repaint chains ───────────────
OLD_CHAIN = '      else if (currentView==="pos") paintPosGrid();\n      else if (currentView==="lodge") paintLodgeCharts();'
NEW_CHAIN = '      else if (currentView==="pos") paintPosGrid();'
assert src.count(OLD_CHAIN) == 1, "drag chain anchor: %d" % src.count(OLD_CHAIN)
src = src.replace(OLD_CHAIN, NEW_CHAIN)

OLD_CHAIN2 = '    if (currentView==="dashboard") paintDash();\n    else if (currentView==="pos") paintPosGrid();\n    else if (currentView==="lodge") paintLodgeCharts();'
NEW_CHAIN2 = '    if (currentView==="dashboard") paintDash();\n    else if (currentView==="pos") paintPosGrid();'
assert src.count(OLD_CHAIN2) == 1, "resize chain anchor: %d" % src.count(OLD_CHAIN2)
src = src.replace(OLD_CHAIN2, NEW_CHAIN2)

io.open(PATH, "w", encoding="utf-8").write(src)
print("OK  %d -> %d bytes" % (orig_len, len(src)))
