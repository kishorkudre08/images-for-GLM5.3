/**
 * Task 40 — the IST calendar rolled over: the bills seeded as "today" are now
 * dated yesterday, so the TODAY dashboard reads ₹0. This re-seeds a living
 * business for the CURRENT IST day:
 *  - ~34 restaurant bills spread 7:00 AM → now (real menu items, 5% GST)
 *  - 5 lodge stay bills via the REAL front-desk API paths (backdated check-ins,
 *    morning check-outs, housekeeping done) — exercises the new gap-free
 *    numbering end to end.
 * Deterministic (mulberry32). Run: bun scripts/t40-seed-today.ts
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

// deterministic RNG so re-runs produce the same shape
function mulberry32(a: number) {
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rnd = mulberry32(20260922);
const pick = <T,>(arr: T[]) => arr[Math.floor(rnd() * arr.length)];

const IST = "+05:30";
const todayIST = new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Kolkata" }); // yyyy-mm-dd
const at = (h: number, m: number) => new Date(`${todayIST}T${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:00${IST}`);

async function main() {
  /* ── restaurant bills today ────────────────────────────────────────────── */
  const dishes = await db.dish.findMany({ where: { active: true } });
  const maxAgg = await db.bill.aggregate({ _max: { number: true } });
  let number = (maxAgg._max.number ?? 1000) + 1; // series is dense — max+1

  const nowIST = new Date();
  const lastH = Math.max(20, nowIST.getHours() - 1); // IST-ish bound for spread
  let created = 0;
  for (let h = 7; h <= Math.min(lastH, 20) && created < 34; h++) {
    const n = h === 7 ? 2 : h === 20 ? 3 : 2 + Math.floor(rnd() * 3); // 2-4 per hour
    for (let k = 0; k < n && created < 34; k++) {
      const lineCount = rnd() < 0.55 ? 1 : rnd() < 0.85 ? 2 : 3;
      const chosen = new Map<string, { dishId: string; name: string; category: string; price: number; qty: number }>();
      while (chosen.size < lineCount) {
        const d = pick(dishes);
        const qty = rnd() < 0.7 ? 1 : 2;
        const prev = chosen.get(d.id);
        chosen.set(d.id, { dishId: d.id, name: d.name, category: d.category, price: d.price, qty: (prev?.qty ?? 0) + qty });
      }
      const lines = [...chosen.values()];
      const subtotal = lines.reduce((s, l) => s + l.qty * l.price, 0);
      const tax = Math.round(subtotal * 0.05 * 100) / 100;
      const total = Math.round((subtotal + tax) * 100) / 100;
      const createdAt = at(h, Math.floor(rnd() * 59));
      if (createdAt.getTime() > Date.now()) continue; // never in the future
      await db.bill.create({
        data: {
          number: number++,
          subtotal,
          discount: 0,
          tax,
          total,
          itemCount: lines.reduce((s, l) => s + l.qty, 0),
          createdAt,
          items: { create: lines.map((l) => ({ dishId: l.dishId, name: l.name, category: l.category, qty: l.qty, price: l.price })) },
        },
      });
      created++;
    }
  }
  console.log("restaurant bills created today:", created, "(numbers", number - created, "→", number - 1 + ")");

  /* ── lodge stays today via the real API ────────────────────────────────── */
  const BASE = "http://localhost:3000";
  const post = (body: unknown) =>
    fetch(`${BASE}/api/lodge`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }).then((r) => r.json());

  const levels = [
    { from: 1, to: 40, rate: 2499, name: "BASIC" },
    { from: 41, to: 80, rate: 2999, name: "STANDARD" },
    { from: 81, to: 100, rate: 3999, name: "LUXURY" },
  ];
  const guests = ["Dattatreya Nayak", "Sushma Bhat", "Chandrashekar Rao", "Leelavathi Kamat", "Ganesh Amin"];
  const free = (await db.room.findMany({ where: { status: "avl" }, orderBy: { number: "asc" } })).map((r) => r.number);
  let stays = 0;
  for (let i = 0; i < 5; i++) {
    const room = free[i * 7 + 3];
    if (!room) break;
    const ci = at(6 + i, 15 + i * 4); // checked in early morning
    const co = at(10 + i, 20 + i * 6); // checked out late morning
    if (co.getTime() > Date.now()) continue;
    const in1 = await post({ action: "checkin", room, name: guests[i], phone: "98450000" + String(100 + i).slice(-2), checkInAt: ci.toISOString() });
    if (!in1.ok) { console.log("checkin skip room", room, in1.error); continue; }
    const out = await post({ action: "checkout", room, checkOutAt: co.toISOString() });
    if (out.ok) {
      stays++;
      await post({ action: "maintenance-done", room }); // housekeeping done → green again
      console.log(`stay L-${out.bill.number} room ${room} ${guests[i]} ₹${out.bill.total}`);
    } else {
      console.log("checkout failed room", room, out.error);
    }
  }
  console.log("lodge stays created today:", stays);

  const bills = await db.bill.count();
  console.log("total restaurant bills now:", bills);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
