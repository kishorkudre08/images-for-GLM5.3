// Reset demo data: wipe ALL bills + dishes, reseed Jaya's Kitchen pure-veg menu.
// Run: bun scripts/reset-data.ts
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  const bills = await db.bill.deleteMany({});
  const dishes = await db.dish.deleteMany({});
  console.log(`Deleted ${bills.count} bills and ${dishes.count} dishes.`);
  await db.dish.createMany({
    data: (await import("./seed")).MENU.map(([name, price, category]) => ({
      name,
      price,
      category,
      veg: true,
    })),
  });
  console.log(`Seeded ${(await import("./seed")).MENU.length} pure-veg dishes.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
