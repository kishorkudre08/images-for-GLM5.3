// Regression: the real Z.ai fallback still works in the sandbox (config present).
// Usage: bun scripts/test-ai-real.ts
export {};
const { aiChat } = await import("../src/lib/ai-client");
const reply = await aiChat([
  { role: "system", content: "Answer in one short sentence." },
  { role: "user", content: "Reply with exactly: ZAI-OK" },
]);
console.log("RESULT:", reply.slice(0, 80));
