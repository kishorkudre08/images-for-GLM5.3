/* Emits src/lib/lodge-data.ts from scripts/lodge-data.json so the full-stack
   app embeds the exact same lodge dataset as the demo HTML. */
"use strict";
const fs = require("fs");
const d = JSON.parse(fs.readFileSync(__dirname + "/lodge-data.json", "utf8"));

const ts = `// ═══════════════════════════════════════════════════════════════════════════
// LODGE DATASET — Imperial Spices Hotel · 100 rooms · 5 floors.
// Deterministic literal so every screen (and the client demo) agrees on the
// numbers. Check-in dates are OFFSETS from today, so the demo never goes stale.
//   Room statuses:  avl available · occ occupied · res reserved (arriving today)
//                   dirty checkout-cleaning · mnt maintenance
//   Booking states: in in-house · arr arriving today · up upcoming · out checked-out
//   ci = check-in offset in days from today (−2 = two nights ago) · nts = nights
//   mb / ld / dn = running folio extras (mini-bar / laundry / restaurant tab)
// ═══════════════════════════════════════════════════════════════════════════

export type LodgeTypeId = "std" | "dlx" | "clb" | "sui" | "pre";
export type LodgeStatus = "avl" | "occ" | "res" | "dirty" | "mnt";
export type BookingState = "in" | "arr" | "up" | "out";

export type LodgeBooking = {
  id: string;
  g: string; // guest name
  ph: string; // phone
  t: LodgeTypeId;
  rm: number | null; // room number (null until check-in for upcoming bookings)
  ci: number; // check-in day offset
  nts: number; // nights
  gx: number; // guests in party
  src: string; // booking source
  st: BookingState;
  mb: number;
  ld: number;
  dn: number;
  eta: number; // arrival hour (0 when not arriving today)
};

export const LODGE_TYPES: Record<LodgeTypeId, { name: string; rate: number; occ: number }> = {
${Object.entries(d.types)
  .map(([k, v]) => {
    const t = v;
    return `  ${k}: { name: "${t.name}", rate: ${t.rate}, occ: ${t.occ} },`;
  })
  .join("\n")}
};

export const LODGE_ROOMS: Array<[number, LodgeTypeId, LodgeStatus]> = [
${d.rooms.map((r) => `  [${r[0]}, "${r[1]}", "${r[2]}"],`).join("\n")}
];

export const LODGE_BOOKINGS: LodgeBooking[] = [
${d.bookings
  .map(
    (b) =>
      `  { id: "${b.id}", g: "${b.g}", ph: "${b.ph}", t: "${b.t}", rm: ${b.rm}, ci: ${b.ci}, nts: ${b.nts}, gx: ${b.gx}, src: "${b.src}", st: "${b.st}", mb: ${b.mb}, ld: ${b.ld}, dn: ${b.dn}, eta: ${b.eta} },`,
  )
  .join("\n")}
];

export const LODGE_MNT_NOTES: Record<number, string> = {
${Object.entries(d.mntNotes)
  .map(([k, v]) => `  ${k}: "${v}",`)
  .join("\n")}
};

/** Occupancy % over the last 7 days — today is the last entry. */
export const LODGE_TREND = [${d.trend.join(", ")}];

/** "21 Sep" — a date offset in days from today (IST). */
export function lodgeDateLabel(offset: number): string {
  const d = new Date();
  d.setHours(12, 0, 0, 0);
  return new Date(d.getTime() + offset * 86400000).toLocaleDateString("en-IN", {
    timeZone: "Asia/Calcutta",
    day: "numeric",
    month: "short",
  });
}

/** Running folio: room + extras + GST (12% · 18% above ₹7,500/night). */
export function folioOf(b: LodgeBooking, rates: Record<LodgeTypeId, { rate: number }>): {
  room: number;
  extras: number;
  tax: number;
  total: number;
  pct: number;
} {
  const room = b.nts * rates[b.t].rate;
  const extras = (b.mb || 0) + (b.ld || 0) + (b.dn || 0);
  const pct = rates[b.t].rate > 7500 ? 18 : 12;
  const tax = Math.round((room * pct) / 100);
  return { room, extras, tax, total: room + extras + tax, pct };
}
`;

fs.writeFileSync(__dirname + "/../src/lib/lodge-data.ts", ts);
console.log("wrote src/lib/lodge-data.ts —", d.rooms.length, "rooms,", d.bookings.length, "bookings");
