// Tests for ai-client.ts provider behaviour (bun test scripts/test-ai-hint.test.ts)
import { test, expect, mock } from "bun:test";

// Simulate a machine WITHOUT .z-ai-config — exactly what the owner's Windows
// PC throws when no Groq key is configured and the Z.ai fallback is hit.
mock.module("z-ai-web-dev-sdk", () => ({
  default: class {
    static async create() {
      throw new Error(
        "Configuration file not found or invalid. Please create .z-ai-config in your project, home directory, or /etc.",
      );
    }
  },
}));

const { aiChat } = await import("../src/lib/ai-client");

test("missing Z.ai config returns the friendly setup hint (no throw)", async () => {
  const out = await aiChat([{ role: "user", content: "hi" }]);
  expect(out).toContain("AI copilot is not configured");
  expect(out).toContain("GROQ_API_KEY");
  expect(out).toContain("npm run dev:w");
});
