const fs = require("fs");
const html = fs.readFileSync("download/fetchx-demo.html", "utf8");
const m = html.match(/<script>([\s\S]*?)<\/script>/);
if (!m) { console.log("NO SCRIPT FOUND"); process.exit(1); }
fs.writeFileSync("scripts/demo-extracted.js", m[1]);
console.log("extracted", m[1].length, "chars");
