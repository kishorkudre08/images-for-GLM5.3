
/* ═══════════════ FETCH-X AI (ai-panel.tsx 1:1) — same panel, replies locked ═══ */
var aiMsgs = [];
var aiBusy = false;

var QUICK = [
  "Summarize my sales for this period",
  "Which dishes should I promote or reprice?",
  "What are my peak hours and how do I staff them?",
  "Tips to grow revenue this month"
];

/* The reply typed-in questions get — the live AI runs only on the full product */
var LOCKED_REPLY = "To unlock AI on your own restaurant data, email kishorkudre08@gmail.com — purchase the subscription and it's live within a day.";

/* ── scripted showcase answers — ONLY the 4 quick chips run these ── */
function replySales(){
  var s = todayStats();
  var top = RANGES.today.mix[0][0]+" ("+RANGES.today.mix[0][1]+"%)";
  return ["### SALES SUMMARY · TODAY",
    "Here's how "+HOTEL.name+" is doing today — in the full product these numbers come straight from your live bills.",
    "",
    "| METRIC | VALUE | VS YESTERDAY |",
    "| --- | --- | --- |",
    "| Bills generated | "+s.bills+" | +9.8% |",
    "| Net sales | "+inr(s.revenue)+" | +12.4% |",
    "| Avg bill value | "+inr2(s.avg)+" | −2.1% |",
    "| Top category | "+top+" | — |",
    "| Peak hour | "+RANGES.today.peakLabel+" | 3,420 /hr avg |",
    "",
    "**What this means**",
    "- Lunch is carrying the day — never staff the 12–3 PM window with one person.",
    "- Avg bill dipped slightly — nudging one add-on at the counter lifts it right back.",
    "- Ask me *\"Which dishes should I promote or reprice?\"* to push peak-hour ticket size."
  ].join("\n");
}
var REPLY_DISHES = [
  "### MENU PERFORMANCE · LAST 7 DAYS",
  "I compared every dish's orders, revenue and trend. Four need your attention:",
  "",
  "| DISH | ORDERS | REVENUE | TREND | MY CALL |",
  "| --- | --- | --- | --- | --- |",
  "| Paneer Butter Masala | 96 | ₹24,960 | ↑ 18% | **PROMOTE** — hero it tonight |",
  "| Veg Dum Biryani | 71 | ₹16,330 | ↑ 11% | PROMOTE at peak hours |",
  "| Kesari Bath | 38 | ₹2,280 | ↓ 6% | **REPRICE** — bundle with meals |",
  "| Filter Coffee | 24 | ₹1,080 | ↓ 19% | MENU-fatigue — swap or relaunch |",
  "",
  "**Action for this week**",
  "1. Feature the two PROMOTE dishes on the counter board and receipt footer.",
  "2. Bundle Kesari Bath into meals — demand holds even as revenue slips.",
  "3. Filter Coffee is drifting — relaunch it with an offer before removing it."
].join("\n");
var REPLY_HOURS = [
  "### PEAK HOURS & STAFFING · TODAY",
  "Your rush is sharp and predictable — here's the load by window:",
  "",
  "| TIME WINDOW | LOAD | STAFFING CALL |",
  "| --- | --- | --- |",
  "| 9 AM – 12 PM | Steady | 1 cashier |",
  "| 12 PM – 3 PM | **PEAK** | 2 cashiers + 1 runner |",
  "| 3 PM – 7 PM | Light | 1 cashier |",
  "| 7 PM – 11 PM | Rising | 2 cashiers |",
  "",
  "**Why it matters**",
  "- The 12–3 window does the bulk of daily bills — never staff it with one person.",
  "- Queues over 4 minutes are where bills are lost; a runner keeps tables turning.",
  "- In the full version I watch this daily and flag pattern changes automatically."
].join("\n");
var REPLY_GROW = [
  "### REVENUE PLAYBOOK · THIS MONTH",
  "Four moves that fit your current numbers:",
  "",
  "1. **Push combos at peak (est. +6–8%)** — the 12–3 window does the bulk of bills; a ₹99 add-on combo there compounds fast.",
  "2. **Fix the avg-bill dip** — ticket size slipped 2.1% today; train cashiers to offer one add-on before billing.",
  "3. **Reprice slow movers** — Kesari Bath holds orders but loses revenue; it's the clearest reprice case.",
  "4. **Run a weekday lunch offer** — your afternoon curve is strong; a Tue–Thu thali deal pulls offices, not discounts.",
  "",
  "Want any of these broken down dish-by-dish?"
].join("\n");
function chipReply(i){ return [replySales(), REPLY_DISHES, REPLY_HOURS, REPLY_GROW][i] || LOCKED_REPLY; }

/* tiny markdown renderer — headers, bold, italic, code, links, lists, TABLES */
function inlineMd(s){
  var out = esc(s);
  out = out.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g,'<a class="md-a" href="$2">$1</a>');
  out = out.replace(/\*\*([^*]+)\*\*/g,"<strong>$1</strong>");
  out = out.replace(/`([^`]+)`/g,'<code class="md-code">$1</code>');
  out = out.replace(/(^|[\s(])\*([^*\s][^*]*)\*/g,"$1<em>$2</em>");
  return out;
}
function mdRender(text){
  var lines = text.split("\n"), html = "", i = 0, listOpen = false, listType = "ul";
  function closeList(){ if (listOpen){ html += "</"+listType+">"; listOpen = false; } }
  function splitRow(l){ return l.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(function(c){ return c.trim(); }); }
  while (i < lines.length){
    var line = lines[i].trim();
    if (!line){ closeList(); i++; continue; }
    if (line.charAt(0)==="|" && i+1<lines.length && /^[\s|:\-]+$/.test(lines[i+1].trim())){
      closeList();
      var head = splitRow(line); i += 2; var rows = [];
      while (i<lines.length && lines[i].trim().charAt(0)==="|"){ rows.push(splitRow(lines[i])); i++; }
      html += '<div class="md-table"><table><thead><tr>'+head.map(function(h){ return "<th>"+inlineMd(h)+"</th>"; }).join("")+"</tr></thead><tbody>"
        + rows.map(function(r){ return "<tr>"+r.map(function(c){ return "<td>"+inlineMd(c)+"</td>"; }).join("")+"</tr>"; }).join("")+"</tbody></table></div>";
      continue;
    }
    var h = line.match(/^#{1,6}\s+(.+)$/);
    if (h){ closeList(); html += '<div class="md-h">'+inlineMd(h[1])+"</div>"; i++; continue; }
    var ul = line.match(/^[-*•]\s+(.+)$/);
    if (ul){ if (!listOpen || listType!=="ul"){ closeList(); html += "<ul>"; listOpen=true; listType="ul"; } html += "<li>"+inlineMd(ul[1])+"</li>"; i++; continue; }
    var ol = line.match(/^\d+[.)]\s+(.+)$/);
    if (ol){ if (!listOpen || listType!=="ol"){ closeList(); html += "<ol>"; listOpen=true; listType="ol"; } html += "<li>"+inlineMd(ol[1])+"</li>"; i++; continue; }
    closeList(); html += "<p>"+inlineMd(line)+"</p>"; i++;
  }
  closeList(); return html;
}
function renderAiEmpty(){
  $("#aiMsgs").innerHTML =
    '<div class="ai-empty"><div class="ae-ic">'+ic("sparkles",20)+'</div>'
    +'<p class="ae-t">Your restaurant, explained.</p>'
    +'<p class="ae-s">I read your live bills — sales, dishes, peak hours — and answer like a business analyst. Ask anything, or start with:</p>'
    +'<div class="ae-qs">'+QUICK.map(function(q,i){ return '<button data-q="'+esc(q)+'" data-i="'+i+'">'+esc(q)+"</button>"; }).join("")+"</div></div>";
  $$("[data-q]").forEach(function(b){ b.addEventListener("click",function(){ aiSend(b.getAttribute("data-q"), true, Number(b.getAttribute("data-i"))||0); }); });
}
function aiSend(text, fromChip, chipIdx){
  var q = (text||"").trim(); if (!q || aiBusy) return;
  aiBusy = true; $("#aiSend").disabled = true;
  $("#aiMsgs").innerHTML = "";
  var u = document.createElement("div"); u.className="msg msg-user"; u.textContent=q; $("#aiMsgs").appendChild(u);
  var t = document.createElement("div"); t.className="ai-typing";
  t.innerHTML = '<svg class="spin" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg><span class="at-t">READING LIVE BILLS…</span>';
  $("#aiMsgs").appendChild(t);
  $("#aiInput").value = "";
  setTimeout(function(){
    t.remove();
    var d = document.createElement("div");
    d.className = "msg msg-ai";
    d.innerHTML = mdRender(fromChip ? chipReply(chipIdx) : LOCKED_REPLY);
    $("#aiMsgs").appendChild(d);
    $("#aiMsgs").scrollTo({top: $("#aiMsgs").scrollHeight, behavior: "smooth"});
    aiBusy = false;
    $("#aiSend").disabled = !$("#aiInput").value.trim();
  },900);
}

/* ── drag-to-resize (ai-panel.tsx): grab the left-edge pill and stretch —
   up to 75% of the screen (max 760px); width remembered like the real app ── */
var AI_MIN_W = 280, AI_ABS_MAX = 760, aiW = 380, aiDrag = false;
function aiMaxW(){ return Math.min(AI_ABS_MAX, Math.max(340, Math.floor(window.innerWidth*0.75))); }
function setAiW(w){ aiW = w; $("#aiPanel").style.setProperty("--ai-w", w+"px"); }
(function aiResizeInit(){
  try{
    var savedW = Number(localStorage.getItem("fx-ai-width"));
    if (Number.isFinite(savedW) && savedW >= AI_MIN_W) setAiW(Math.min(savedW, aiMaxW()));
  }catch(e){}
  function gx(e){ return "touches" in e ? e.touches[0].clientX : e.clientX; }
  function move(e){
    if (!aiDrag) return;
    setAiW(Math.min(aiMaxW(), Math.max(AI_MIN_W, window.innerWidth - gx(e))));
  }
  function up(){
    if (!aiDrag) return;
    aiDrag = false;
    document.body.style.userSelect = "";
    try{ localStorage.setItem("fx-ai-width", String(aiW)); }catch(e){}
    if (shellReady){
      if (currentView==="dashboard") paintDash();
      else if (currentView==="pos") paintPosGrid();
      else if (currentView==="lodge") paintLodgeCharts();
    }
  }
  function down(){ aiDrag = true; document.body.style.userSelect = "none"; }
  var grip = $("#aiGrip");
  grip.addEventListener("mousedown", down);
  grip.addEventListener("touchstart", down, {passive:true});
  window.addEventListener("mousemove", move);
  window.addEventListener("touchmove", move, {passive:true});
  window.addEventListener("mouseup", up);
  window.addEventListener("touchend", up);
})();

/* send button disabled until there is text — same as the real panel */
(function aiInputGate(){
  var inp = $("#aiInput"), btn = $("#aiSend");
  function sync(){ if (!aiBusy) btn.disabled = !inp.value.trim(); }
  inp.addEventListener("input", sync);
  sync();
})();

/* ═══════════════ BOOT — fresh open always lands on the pre-login page;
   sessionStorage keeps the demo signed in across refreshes in the same tab ══ */
(function boot(){
  applyThemeIcons();
  try{ localStorage.removeItem("fx-auth-demo"); }catch(e){}
  setTimeout(function(){
    var signed = false;
    try{ signed = sessionStorage.getItem("fx-auth-demo")==="1"; }catch(e){}
    if (signed){
      $("#landing").style.display="none";
      $("#splash").style.display="none";
      $("#app").style.display="flex";
      initShell(); showView("dashboard");
    } else {
      $("#splash").style.display="none";
    }
  },500);
})();
window.addEventListener("resize",function(){
  if (!shellReady) return;
  clearTimeout(window.__fxrz);
  window.__fxrz = setTimeout(function(){
    if (currentView==="dashboard") paintDash();
    else if (currentView==="pos") paintPosGrid();
    else if (currentView==="lodge") paintLodgeCharts();
  },200);
});
