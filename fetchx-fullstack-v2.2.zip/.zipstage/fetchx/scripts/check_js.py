import re, subprocess, sys
src = open('/home/z/my-project/download/fetchx-demo.html', encoding='utf-8').read()
blocks = re.findall(r'<script>(.*?)</script>', src, re.S)
print(f"{len(blocks)} script blocks found")
ok = True
for i, b in enumerate(blocks):
    p = f'/home/z/my-project/scripts/_chk{i}.js'
    open(p, 'w', encoding='utf-8').write(b)
    r = subprocess.run(['node', '--check', p], capture_output=True, text=True)
    if r.returncode != 0:
        ok = False
        print(f'--- block {i}: SYNTAX ERROR ---')
        print(r.stderr[:1500])
    else:
        print(f'block {i}: OK ({len(b)} chars)')
sys.exit(0 if ok else 1)
