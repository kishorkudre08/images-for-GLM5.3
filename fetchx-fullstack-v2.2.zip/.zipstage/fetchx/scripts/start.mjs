#!/usr/bin/env node
/**
 * Fetch-X one-command launcher — self-healing, cross-platform (Windows / macOS / Linux).
 *
 * `npm run dev` and `npm run dev:w` both land here. Whatever is missing gets
 * fixed automatically, in order, before the server starts:
 *
 *   1. dependencies      — node_modules incomplete?  -> npm install
 *   2. database client   — prisma client missing?    -> prisma generate
 *   3. status report     — which db file, AI key set or not
 *   4. server            — next dev (stdout also teed into dev.log)
 *
 * Only Node built-ins are used (fs/path/child_process) so this runs BEFORE any
 * dependency exists. Spawned via array arguments (never a shell command
 * string), so folder names with spaces — e.g. "Fetch-X Lodge" — are safe.
 */

import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import process from "node:process";

const C = {
  dim: (s) => `\x1b[2m${s}\x1b[0m`,
  ok: (s) => `\x1b[32m${s}\x1b[0m`,
  warn: (s) => `\x1b[33m${s}\x1b[0m`,
  err: (s) => `\x1b[31m${s}\x1b[0m`,
  purple: (s) => `\x1b[38;5;99m${s}\x1b[0m`,
};
const tag = C.purple("[fetchx]");

const say = (...a) => console.log(tag, ...a);

/** Read a JSON file, or null. */
function readJson(p) {
  try {
    return JSON.parse(fs.readFileSync(p, "utf8"));
  } catch {
    return null;
  }
}

/** Run a command, stream its output, resolve to { code }. */
function run(cmd, args, opts = {}) {
  return new Promise((resolve) => {
    const child = spawn(cmd, args, {
      stdio: "inherit",
      shell: opts.shell ?? false,
      env: opts.env ?? process.env,
    });
    child.on("exit", (code, signal) => resolve({ code: code ?? (signal ? 1 : 0) }));
    child.on("error", (e) => {
      console.error(String(e?.message ?? e));
      resolve({ code: 1 });
    });
  });
}

async function main() {
  const cwd = process.cwd();
  const isWin = process.platform === "win32";

  // ---- banner -------------------------------------------------------------
  const pkg = readJson(path.join(cwd, "package.json"));
  const appName = pkg?.name ?? "Fetch-X";
  const appVer = pkg?.version ?? "";
  console.log("");
  say(C.purple(`Fetch-X ${appVer ? `v${appVer}` : ""} — one-command launcher`));
  say(C.dim(`folder: ${cwd}`));

  // Node sanity (Next.js 16 needs >= 20.9)
  const [maj, min] = process.versions.node.split(".").map(Number);
  if (maj < 20 || (maj === 20 && min < 9)) {
    say(C.warn(`Node v${process.versions.node} is too old for Next.js 16 (needs 20.9+).`));
    say(C.warn("Install the LTS from https://nodejs.org and re-open the terminal."));
  } else {
    say(C.ok(`Node v${process.versions.node}`));
  }

  // ---- step 1: dependencies ----------------------------------------------
  const depsNeeded = ["next", "react", "react-dom", "prisma", "@prisma/client"].filter(
    (d) => !fs.existsSync(path.join(cwd, "node_modules", d, "package.json")),
  );
  // A next package.json without its launcher binary = corrupted/partial
  // install — let npm install repair it instead of failing at launch time.
  if (
    !depsNeeded.includes("next") &&
    !fs.existsSync(path.join(cwd, "node_modules", "next", "dist", "bin", "next"))
  ) {
    depsNeeded.push("next");
  }
  if (depsNeeded.length > 0) {
    console.log("");
    say(C.warn(`Dependencies missing (${depsNeeded.join(", ")}) — running npm install…`));
    say(C.dim("First run downloads everything; this can take a few minutes. One time only."));
    console.log("");
    const { code } = await run("npm", ["install", "--no-audit", "--no-fund"], {
      shell: isWin, // Windows resolves npm.cmd through the shell
    });
    if (code !== 0) {
      console.log("");
      say(C.err("npm install failed. Things to check:"));
      say(C.err("  1) internet connection"));
      say(C.err('  2) delete the node_modules folder, then run this command again'));
      say(C.err("  3) corporate proxy? set HTTPS_PROXY in the terminal"));
      process.exit(code);
    }
    const stillMissing = ["next", "react", "prisma"].filter(
      (d) => !fs.existsSync(path.join(cwd, "node_modules", d, "package.json")),
    );
    if (stillMissing.length > 0) {
      say(C.err(`npm install finished but ${stillMissing.join(", ")} are still missing — run: npm install`));
      process.exit(1);
    }
    say(C.ok("Dependencies installed."));
  } else {
    say(C.dim("dependencies ✓ (already installed)"));
  }

  // ---- step 2: prisma client ---------------------------------------------
  const clientDir = path.join(cwd, "node_modules", ".prisma", "client");
  const clientReady =
    fs.existsSync(path.join(clientDir, "index.js")) &&
    fs.existsSync(path.join(clientDir, "default.js")) &&
    fs.existsSync(path.join(clientDir, "schema.prisma"));
  if (!clientReady) {
    const prismaCli = path.join(cwd, "node_modules", "prisma", "build", "index.js");
    if (!fs.existsSync(prismaCli)) {
      say(C.err("prisma CLI not found — run: npm install"));
      process.exit(1);
    }
    console.log("");
    say(C.warn("Database client not generated yet — generating (one time, ~10s)…"));
    const { code } = await run(process.execPath, [prismaCli, "generate"]);
    if (code !== 0) {
      say(C.err("prisma generate failed — run manually: npx prisma generate"));
      process.exit(code);
    }
    say(C.ok("Database client generated."));
  } else {
    say(C.dim("database client ✓ (already generated)"));
  }

  // ---- status: database + AI ----------------------------------------------
  const dbCandidates = ["db/custom.db", "prisma/dev.db", "custom.db", "dev.db"];
  const dbFound = dbCandidates.find((rel) => fs.existsSync(path.join(cwd, rel)));
  console.log("");
  if (dbFound) {
    say(C.ok(`database → ${dbFound}`));
  } else {
    say(C.warn("no database file found yet — the app will create guidance on first open (or run: npm run db:push)"));
  }

  let groqKey = "";
  try {
    const envText = fs.readFileSync(path.join(cwd, ".env"), "utf8");
    const m = envText.match(/^\s*GROQ_API_KEY\s*=\s*(.+)\s*$/m);
    if (m) groqKey = m[1].trim().replace(/^["']|["']$/g, "");
  } catch {
    /* no .env — fine */
  }
  if (groqKey && groqKey.startsWith("gsk_") && !groqKey.startsWith("gsk_your")) {
    say(C.ok(`AI copilot → Groq key ${groqKey.slice(0, 4)}…${groqKey.slice(-4)} (engine: gpt-oss-120b)`));
  } else if (groqKey) {
    say(C.warn("AI copilot → GROQ_API_KEY looks like a placeholder — paste your real key from https://console.groq.com/keys"));
  } else {
    say(C.warn("AI copilot → no key yet. Everything else works; to switch AI on, put GROQ_API_KEY=gsk_… in .env (free key: https://console.groq.com/keys), then restart."));
  }

  // ---- env hygiene: stale exported DATABASE_URL --------------------------
  // A globally exported DATABASE_URL (set once for another project) silently
  // overrides the app's own .env — Next.js never overwrites existing env.
  // The database always ships INSIDE the project folder, so a file:-URL that
  // points outside it is pollution by definition. Remote (non-file:) URLs,
  // e.g. hosted Postgres, are legitimate and pass untouched.
  const childEnv = { ...process.env, FX_PROJECT_DIR: cwd };
  const exportedUrl = process.env.DATABASE_URL?.trim();
  if (exportedUrl?.startsWith("file:")) {
    let exportedPath = exportedUrl.slice("file:".length).replace(/^\/+(?=[A-Za-z]:)/, "");
    if (!path.isAbsolute(exportedPath)) exportedPath = path.resolve(cwd, exportedPath);
    const inside = path.resolve(exportedPath).startsWith(path.resolve(cwd) + path.sep);
    if (!inside) {
      delete childEnv.DATABASE_URL;
      say(C.warn(`ignoring globally exported DATABASE_URL (points outside this folder): ${exportedUrl}`));
    }
  }

  // ---- step 3: launch next dev ---------------------------------------------
  const port = String(process.env.PORT || "3000");
  const nextBin = path.join(cwd, "node_modules", "next", "dist", "bin", "next");
  if (!fs.existsSync(nextBin)) {
    say(C.err("next binary missing even after install — delete node_modules and run this again"));
    process.exit(1);
  }

  console.log("");
  say(C.purple(`starting server → http://localhost:${port}`));
  say(C.dim("(stop with Ctrl+C — all output is also copied to dev.log)"));
  console.log("");

  const logStream = fs.createWriteStream(path.join(cwd, "dev.log"), { flags: "w" });
  const tee = (chunk) => {
    process.stdout.write(chunk);
    logStream.write(chunk);
  };

  let shuttingDown = false;
  const child = spawn(process.execPath, [nextBin, "dev", "-p", port], {
    cwd,
    stdio: ["inherit", "pipe", "pipe"],
    env: childEnv,
  });
  child.stdout?.on("data", tee);
  child.stderr?.on("data", tee);

  child.on("exit", (code, signal) => {
    logStream.end();
    if (shuttingDown) process.exit(0);
    say(code === 0 ? C.dim("server stopped.") : C.err(`server exited unexpectedly (code ${code ?? signal}). Fix any error above, then run this command again.`));
    process.exit(code ?? 1);
  });

  const forward = (signal) => {
    if (shuttingDown) return;
    shuttingDown = true;
    try {
      child.kill(signal);
    } catch {
      /* already gone */
    }
    setTimeout(() => process.exit(0), 3000).unref();
  };
  process.on("SIGINT", () => forward("SIGINT"));
  process.on("SIGTERM", () => forward("SIGTERM"));
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
