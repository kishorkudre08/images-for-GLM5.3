
/* ═══════════════════════════════════════════════════════════════════════
   FETCH-X single-file demo — mirrors the full-stack product 1:1.
   Pre-login: the landing page.  Post-login: Imperial Spice's live console.
   Platform brand = Fetch-X (fixed) · Hotel identity = tenant variable.
   ═══════════════════════════════════════════════════════════════════════ */
"use strict";
function $(s,r){return (r||document).querySelector(s)}
function $$(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))}
function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})}
function inr(n,d){return "₹"+Number(n).toLocaleString("en-IN",{minimumFractionDigits:d?2:0,maximumFractionDigits:d?2:0})}
function inr2(n){return inr(n,true)}
function num(n){return Number(n).toLocaleString("en-IN")}
function istTime(d){return new Date(d).toLocaleTimeString("en-IN",{timeZone:"Asia/Calcutta",hour:"numeric",minute:"2-digit",hour12:true})}
function istDateTime(d){return new Date(d).toLocaleString("en-IN",{timeZone:"Asia/Calcutta",day:"2-digit",month:"short",hour:"numeric",minute:"2-digit",hour12:true})}
function istDateLong(d){return new Date(d||Date.now()).toLocaleDateString("en-IN",{timeZone:"Asia/Calcutta",weekday:"long",day:"numeric",month:"long"})}
function fmtAxisINR(v){v=Number(v);return v>=100000?(Math.round(v/100000*10)/10)+"L":v>=10000?Math.round(v/1000)+"k":v>=1000?(Math.round(v/1000*10)/10)+"k":String(Math.round(v))}
function hourLabel(h){var s=h>=12?"PM":"AM";var b=h%12===0?12:h%12;return b+" "+s}

/* ── Icons (lucide, inline) ─────────────────────────────────────────── */
var P = {
  chart:'<path d="M3 3v18h18"/><path d="M18 17V9"/><path d="M13 17V5"/><path d="M8 17v-3"/>',
  receipt:'<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M14 8H8"/><path d="M16 12H8"/><path d="M13 16H8"/>',
  clip:'<rect width="8" height="4" x="8" y="2" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M12 11h4"/><path d="M12 16h4"/><path d="M8 11h.01"/><path d="M8 16h.01"/>',
  logout:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/>',
  chevL:'<path d="m11 17-5-5 5-5"/><path d="m18 17-5-5 5-5"/>',
  chevR:'<path d="m6 17 5-5-5-5"/><path d="m13 17 5-5-5-5"/>',
  chevD:'<path d="m6 9 6 6 6-6"/>',
  sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>',
  moon:'<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
  search:'<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  plus:'<path d="M5 12h14"/><path d="M12 5v14"/>',
  minus:'<path d="M5 12h14"/>',
  trash:'<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/>',
  zap:'<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
  loader:'<path d="M21 12a9 9 0 1 1-6.219-8.56"/>',
  bot:'<path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/>',
  send:'<path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/>',
  sparkles:'<path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/>',
  x:'<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
  rotate:'<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/>',
  banknote:'<rect width="20" height="12" x="2" y="6" rx="2"/><circle cx="12" cy="12" r="2"/><path d="M6 12h.01"/><path d="M18 12h.01"/>',
  tup:'<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
  tdn:'<polyline points="22 17 13.5 8.5 8.5 13.5 2 7"/><polyline points="16 17 22 17 22 11"/>',
  bag:'<path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/>',
  users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  wallet:'<path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4Z"/>',
  clock:'<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  flame:'<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>',
  undo:'<path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11"/>',
  arrow:'<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
  check:'<path d="M20 6 9 17l-5-5"/>',
  chef:'<path d="M6 13.87A4 4 0 0 1 7.41 6a5.11 5.11 0 0 1 1.05-1.54 5 5 0 0 1 7.08 0A5.11 5.11 0 0 1 16.59 6 4 4 0 0 1 18 13.87V21H6Z"/><path d="M6 17h12"/>',
  mail:'<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
  shield:'<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
  crown:'<path d="M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.735H5.81a1 1 0 0 1-.957-.735L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z"/><path d="M5 21h14"/>',
  utensils:'<path d="m16 2-2.3 2.3a3 3 0 0 0 0 4.2l1.8 1.8a3 3 0 0 0 4.2 0L22 8"/><path d="M15 15 3.3 3.3a4.2 4.2 0 0 0 0 6l7.3 7.3c.7.7 2 .7 2.8 0L15 15Zm0 0 7 7"/><path d="m2.1 21.8 6.4-6.3"/><path d="m19 5-7 7"/>',
  rupee:'<path d="M6 3h12"/><path d="M6 8h12"/><path d="m6 13 8.5 8"/><path d="M6 13h3"/><path d="M9 13c6.667 0 6.667-10 0-10"/>',
  sprout:'<path d="M7 20h10"/><path d="M10 20c5.5-2.5.8-6.4 3-10"/><path d="M9.5 9.4c1.1.8 1.8 2.2 2.3 3.7-2 .4-3.5.4-4.8-.3-1.2-.6-2.3-1.9-3-4.2 2.8-.5 4.4 0 5.5.8z"/><path d="M14.1 6a7 7 0 0 0-1.1 4c1.9-.1 3.3-.6 4.3-1.4 1-1 1.6-2.3 1.7-4.6-2.7.1-4 1-4.9 2z"/>',
  wrench:'<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
  grid:'<rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/>',
  hotel:'<path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"/><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"/><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"/><path d="M10 6h4"/><path d="M10 10h4"/><path d="M10 14h4"/><path d="M10 18h4"/>',
  save:'<path d="M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7"/><path d="M7 3v4a1 1 0 0 0 1 1h7"/>',
  pencil:'<path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>',
  printer:'<path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 14h12v8H6z"/>'
};
function ic(name,size,sw){return '<svg width="'+(size||16)+'" height="'+(size||16)+'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="'+(sw||2)+'" stroke-linecap="round" stroke-linejoin="round">'+(P[name]||"")+"</svg>"}
function veg(veg){return '<span class="vd'+(veg?"":" nv")+'" title="'+(veg?"Vegetarian":"Non-vegetarian")+'" aria-hidden="true"><i></i></span>'}
function tier(num,eyebrow,title,sub,tag){
  var eyebrowHtml = (tag.liveDot ? '<span class="fx-live-dot" aria-hidden="true"></span>' : '') + esc(eyebrow);
  return '<div class="tier fx-band"><span class="tier-num">'+num+'</span><div class="tier-body"><div class="fx-label" style="display:inline-flex;align-items:center;gap:8px">'+eyebrowHtml+'</div><h1>'+esc(title)+'</h1><p>'+esc(sub)+'</p></div><span class="chip-tag">'+tag.html+"</span></div>";
}

/* ── Brand: fixed platform + variable tenant ────────────────────────── */
var PLATFORM = {name:"Fetch-X", receiptLine:"POWERED BY FETCH-X"};
var HOTEL = {name:"Imperial Spice", tagline:"PURE VEG RESTAURANT", address:"12, Main Road, Mailoor", phone:"+91 98XXX 45XXX", gstin:"29ABCDE1234F1Z5", fssai:"Lic. No. 21222222222222", cashier:"RAVI · COUNTER 01"};
var OWNER = "kishorkudre08@gmail.com";
function hotelInitials(n){var w=n.trim().split(/\s+/).filter(Boolean);if(!w.length)return"FX";return ((w[0][0]||"")+(w.length>1?(w[w.length-1][0]||""):"")).toUpperCase()}
function upperName(){return HOTEL.name.toUpperCase()}

/* ── Demo dataset — Imperial Spice (46-dish pure-veg menu) ──────────── */
var CATS = ["Starters","Main Course","Breads","Rice & Biryani","Desserts","Beverages"];
var DISHES = [
  {n:"Paneer Tikka",p:220,c:"Starters"},{n:"Hara Bhara Kebab",p:190,c:"Starters"},{n:"Crispy Corn",p:150,c:"Starters"},{n:"Veg Manchurian",p:160,c:"Starters"},{n:"Gobi 65",p:130,c:"Starters"},{n:"Paneer Chilli Dry",p:240,c:"Starters"},{n:"Mushroom Pepper Fry",p:190,c:"Starters"},{n:"Cheese Balls",p:180,c:"Starters"},{n:"Veg Spring Rolls",p:150,c:"Starters"},{n:"Corn Cheese Balls",p:170,c:"Starters"},
  {n:"Paneer Butter Masala",p:260,c:"Main Course"},{n:"Kadai Paneer",p:250,c:"Main Course"},{n:"Palak Paneer",p:240,c:"Main Course"},{n:"Malai Kofta",p:240,c:"Main Course"},{n:"Navratan Kurma",p:240,c:"Main Course"},{n:"Methi Malai Mutter",p:230,c:"Main Course"},{n:"Mushroom Do Pyaza",p:230,c:"Main Course"},{n:"Veg Jalfrezi",p:210,c:"Main Course"},{n:"Veg Kolhapuri",p:220,c:"Main Course"},{n:"Chana Masala",p:190,c:"Main Course"},{n:"Dal Tadka",p:170,c:"Main Course"},{n:"Dal Fry",p:150,c:"Main Course"},
  {n:"Tandoori Roti",p:25,c:"Breads"},{n:"Butter Naan",p:55,c:"Breads"},{n:"Garlic Naan",p:70,c:"Breads"},{n:"Lachha Paratha",p:60,c:"Breads"},{n:"Kulcha",p:50,c:"Breads"},
  {n:"Veg Biryani",p:200,c:"Rice & Biryani"},{n:"Paneer Biryani",p:240,c:"Rice & Biryani"},{n:"Veg Dum Biryani",p:230,c:"Rice & Biryani"},{n:"Paneer Pulao",p:180,c:"Rice & Biryani"},{n:"Veg Fried Rice",p:160,c:"Rice & Biryani"},{n:"Schezwan Fried Rice",p:180,c:"Rice & Biryani"},{n:"Jeera Rice",p:120,c:"Rice & Biryani"},{n:"Curd Rice",p:90,c:"Rice & Biryani"},
  {n:"Gulab Jamun (2 pc)",p:80,c:"Desserts"},{n:"Rasmalai (2 pc)",p:110,c:"Desserts"},{n:"Gajar Halwa",p:100,c:"Desserts"},{n:"Brownie with Ice Cream",p:150,c:"Desserts"},{n:"Kesari Bath",p:60,c:"Desserts"},
  {n:"Masala Chai",p:30,c:"Beverages"},{n:"Filter Coffee",p:45,c:"Beverages"},{n:"Sweet Lassi",p:70,c:"Beverages"},{n:"Salt Lassi",p:65,c:"Beverages"},{n:"Fresh Lime Soda",p:60,c:"Beverages"},{n:"Masala Buttermilk",p:55,c:"Beverages"}
].map(function(d,i){d.id="d"+i;d.veg=true;d.active=true;return d});
var EMPS = [
  {id:"e1",n:"Suresh Nair",r:"Head Chef",s:28000,a:true},
  {id:"e2",n:"Lakshmi Iyer",r:"South Indian Station",s:20000,a:true},
  {id:"e3",n:"Ravi Kumar",r:"Cashier · Counter 01",s:18000,a:true},
  {id:"e4",n:"Kumar Swamy",r:"Server",s:14000,a:true},
  {id:"e5",n:"Devi Shetty",r:"Kitchen Helper & Cleaning",s:9000,a:true}
];
var EXP_RAW = [
  {id:"r1",l:"Weekly market purchase",a:42481,d:"2026-09-15"},
  {id:"r2",l:"Vegetables, dairy & groceries",a:40999,d:"2026-09-08"},
  {id:"r3",l:"Weekly market purchase",a:36611,d:"2026-09-01"},
  {id:"r4",l:"Vegetables, dairy & groceries",a:3500,d:"2026-09-18"},
  {id:"r5",l:"Weekly market purchase",a:38240,d:"2026-08-25"}
];
var EXP_MAINT = [
  {id:"m1",l:"Chimney & exhaust cleaning",a:1483,d:"2026-09-05"},
  {id:"m2",l:"Repairs & upkeep",a:2840,d:"2026-08-12"}
];

/* ── Lodge dataset — Imperial Spices Hotel · 100 rooms · 5 floors ─────
   Room statuses: avl available · occ occupied · res reserved (arriving today)
                  dirty checkout-cleaning · mnt maintenance
   Booking states: st in in-house · arr arriving today · up upcoming · out checked-out
   ci = check-in offset in days from TODAY (−2 = two nights ago) · nts = nights
   mb/ld/dn = running folio extras (mini-bar / laundry / restaurant tab)      */
var LODGE_TYPES = {
  std:{name:"Standard",rate:1800,occ:58},
  dlx:{name:"Deluxe",rate:2800,occ:66},
  clb:{name:"Club Executive",rate:4200,occ:71},
  sui:{name:"Suite",rate:6500,occ:64},
  pre:{name:"Presidential",rate:12000,occ:40}
};
var LODGE_ROOMS = [
  [101,"std","res"],
  [102,"std","occ"],
  [103,"std","res"],
  [104,"std","occ"],
  [105,"std","occ"],
  [106,"std","dirty"],
  [107,"std","occ"],
  [108,"std","dirty"],
  [109,"std","occ"],
  [110,"std","occ"],
  [111,"std","occ"],
  [112,"std","occ"],
  [113,"std","occ"],
  [114,"std","avl"],
  [115,"std","occ"],
  [116,"std","occ"],
  [117,"std","res"],
  [118,"std","avl"],
  [119,"std","occ"],
  [120,"std","res"],
  [201,"std","dirty"],
  [202,"std","occ"],
  [203,"std","dirty"],
  [204,"std","avl"],
  [205,"std","avl"],
  [206,"std","avl"],
  [207,"std","occ"],
  [208,"std","avl"],
  [209,"std","avl"],
  [210,"std","avl"],
  [211,"std","occ"],
  [212,"std","occ"],
  [213,"std","occ"],
  [214,"std","avl"],
  [215,"std","res"],
  [216,"std","res"],
  [217,"std","occ"],
  [218,"std","occ"],
  [219,"std","occ"],
  [220,"std","occ"],
  [301,"dlx","occ"],
  [302,"dlx","occ"],
  [303,"dlx","mnt"],
  [304,"dlx","occ"],
  [305,"dlx","occ"],
  [306,"dlx","dirty"],
  [307,"dlx","occ"],
  [308,"dlx","occ"],
  [309,"dlx","avl"],
  [310,"dlx","avl"],
  [311,"dlx","occ"],
  [312,"dlx","occ"],
  [313,"dlx","res"],
  [314,"dlx","occ"],
  [315,"dlx","occ"],
  [316,"dlx","occ"],
  [317,"dlx","occ"],
  [318,"dlx","res"],
  [319,"dlx","occ"],
  [320,"dlx","occ"],
  [401,"dlx","avl"],
  [402,"dlx","occ"],
  [403,"dlx","occ"],
  [404,"dlx","occ"],
  [405,"dlx","occ"],
  [406,"dlx","occ"],
  [407,"dlx","occ"],
  [408,"dlx","avl"],
  [409,"dlx","occ"],
  [410,"dlx","occ"],
  [411,"clb","occ"],
  [412,"clb","occ"],
  [413,"clb","occ"],
  [414,"clb","occ"],
  [415,"clb","occ"],
  [416,"clb","dirty"],
  [417,"clb","occ"],
  [418,"clb","occ"],
  [419,"clb","occ"],
  [420,"clb","occ"],
  [501,"clb","mnt"],
  [502,"clb","dirty"],
  [503,"clb","occ"],
  [504,"clb","dirty"],
  [505,"clb","occ"],
  [506,"sui","occ"],
  [507,"sui","avl"],
  [508,"sui","occ"],
  [509,"sui","res"],
  [510,"sui","occ"],
  [511,"sui","occ"],
  [512,"sui","avl"],
  [513,"sui","occ"],
  [514,"sui","occ"],
  [515,"sui","avl"],
  [516,"pre","occ"],
  [517,"pre","occ"],
  [518,"pre","res"],
  [519,"pre","res"],
  [520,"pre","occ"]
];
var LODGE_BOOKINGS = [
  {id:"BK-2411",g:"Preeti Sinha",ph:"+91 91974 37671",t:"dlx",rm:311,ci:-4,nts:4,gx:1,src:"Phone",st:"in",mb:250,ld:0,dn:0,eta:0},
  {id:"BK-2412",g:"Aditi Rane",ph:"+91 99954 82588",t:"dlx",rm:316,ci:-3,nts:3,gx:3,src:"Booking.com",st:"in",mb:0,ld:200,dn:0,eta:0},
  {id:"BK-2413",g:"Vikram Deshpande",ph:"+91 95135 80885",t:"std",rm:104,ci:-4,nts:4,gx:1,src:"Phone",st:"in",mb:150,ld:450,dn:1200,eta:0},
  {id:"BK-2414",g:"Girish Prabhu",ph:"+91 91653 68139",t:"dlx",rm:405,ci:-2,nts:2,gx:3,src:"Corporate",st:"in",mb:400,ld:0,dn:1200,eta:0},
  {id:"BK-2415",g:"Farhan Ali",ph:"+91 96172 90568",t:"std",rm:107,ci:-1,nts:1,gx:3,src:"Booking.com",st:"in",mb:0,ld:0,dn:1200,eta:0},
  {id:"BK-2416",g:"Kiran Majumdar",ph:"+91 98608 16050",t:"sui",rm:510,ci:-4,nts:4,gx:2,src:"Corporate",st:"in",mb:250,ld:350,dn:2400,eta:0},
  {id:"BK-2417",g:"Sameer Kulkarni",ph:"+91 93594 32952",t:"clb",rm:503,ci:-4,nts:4,gx:2,src:"Booking.com",st:"in",mb:250,ld:200,dn:450,eta:0},
  {id:"BK-2418",g:"Robert Wilson",ph:"+91 96353 62944",t:"std",rm:220,ci:-1,nts:1,gx:2,src:"Goibibo",st:"in",mb:400,ld:200,dn:1200,eta:0},
  {id:"BK-2419",g:"Ann Kurian",ph:"+91 97056 55019",t:"clb",rm:505,ci:-4,nts:4,gx:3,src:"MakeMyTrip",st:"in",mb:0,ld:450,dn:1800,eta:0},
  {id:"BK-2420",g:"Sharvari Kadam",ph:"+91 91200 62408",t:"pre",rm:516,ci:-1,nts:3,gx:4,src:"Corporate",st:"in",mb:250,ld:0,dn:850,eta:0},
  {id:"BK-2421",g:"Sunita Joshi",ph:"+91 96417 30399",t:"clb",rm:411,ci:-2,nts:4,gx:1,src:"MakeMyTrip",st:"in",mb:0,ld:200,dn:850,eta:0},
  {id:"BK-2422",g:"Daniel Fernandes",ph:"+91 92957 62906",t:"pre",rm:520,ci:-4,nts:8,gx:3,src:"MakeMyTrip",st:"in",mb:0,ld:350,dn:1200,eta:0},
  {id:"BK-2423",g:"Kavya Reddy",ph:"+91 98460 58474",t:"std",rm:112,ci:-3,nts:5,gx:3,src:"Goibibo",st:"in",mb:0,ld:0,dn:0,eta:0},
  {id:"BK-2424",g:"George Mathew",ph:"+91 98693 39297",t:"clb",rm:412,ci:-2,nts:6,gx:3,src:"Goibibo",st:"in",mb:600,ld:120,dn:450,eta:0},
  {id:"BK-2425",g:"Tarun Sethi",ph:"+91 91336 09894",t:"clb",rm:414,ci:-2,nts:6,gx:2,src:"Website",st:"in",mb:0,ld:350,dn:0,eta:0},
  {id:"BK-2426",g:"Vivek Anand",ph:"+91 91759 57479",t:"dlx",rm:407,ci:-1,nts:2,gx:2,src:"MakeMyTrip",st:"in",mb:0,ld:120,dn:0,eta:0},
  {id:"BK-2427",g:"Naveen Kumar",ph:"+91 94937 53313",t:"sui",rm:514,ci:-4,nts:6,gx:4,src:"Walk-in",st:"in",mb:150,ld:0,dn:850,eta:0},
  {id:"BK-2428",g:"Chaitanya Dev",ph:"+91 94702 49594",t:"std",rm:207,ci:-4,nts:7,gx:1,src:"Agoda",st:"in",mb:0,ld:120,dn:0,eta:0},
  {id:"BK-2429",g:"Mala Chandrasekhar",ph:"+91 93249 47033",t:"std",rm:202,ci:-3,nts:6,gx:2,src:"Phone",st:"in",mb:0,ld:450,dn:0,eta:0},
  {id:"BK-2430",g:"Shruti Bhat",ph:"+91 94845 66010",t:"clb",rm:418,ci:-1,nts:4,gx:3,src:"Corporate",st:"in",mb:600,ld:200,dn:1800,eta:0},
  {id:"BK-2431",g:"Gaurav Mhambrey",ph:"+91 99931 29703",t:"dlx",rm:317,ci:-4,nts:6,gx:1,src:"Walk-in",st:"in",mb:0,ld:0,dn:850,eta:0},
  {id:"BK-2432",g:"Raghavendra Kulkarni",ph:"+91 94136 27119",t:"clb",rm:417,ci:-3,nts:5,gx:3,src:"Walk-in",st:"in",mb:0,ld:200,dn:1200,eta:0},
  {id:"BK-2433",g:"Poornima Rao",ph:"+91 99065 48731",t:"dlx",rm:319,ci:-2,nts:6,gx:3,src:"Goibibo",st:"in",mb:400,ld:0,dn:1800,eta:0},
  {id:"BK-2434",g:"Anita Menon",ph:"+91 96827 16450",t:"dlx",rm:314,ci:-2,nts:3,gx:2,src:"Booking.com",st:"in",mb:400,ld:450,dn:850,eta:0},
  {id:"BK-2435",g:"Sanjay Patil",ph:"+91 92449 29047",t:"dlx",rm:308,ci:-4,nts:5,gx:2,src:"Goibibo",st:"in",mb:150,ld:350,dn:0,eta:0},
  {id:"BK-2436",g:"Chandran Menon",ph:"+91 92831 56700",t:"std",rm:212,ci:-3,nts:5,gx:1,src:"Phone",st:"in",mb:0,ld:450,dn:0,eta:0},
  {id:"BK-2437",g:"Karthik Subramanian",ph:"+91 95463 36168",t:"std",rm:218,ci:-4,nts:8,gx:2,src:"Website",st:"in",mb:400,ld:200,dn:1200,eta:0},
  {id:"BK-2438",g:"Vishwanath Alluri",ph:"+91 92054 95523",t:"std",rm:219,ci:-3,nts:6,gx:3,src:"Website",st:"in",mb:0,ld:200,dn:450,eta:0},
  {id:"BK-2439",g:"Neha Sabharwal",ph:"+91 94332 85478",t:"std",rm:119,ci:-1,nts:5,gx:1,src:"MakeMyTrip",st:"in",mb:250,ld:200,dn:450,eta:0},
  {id:"BK-2440",g:"Vidya Vyas",ph:"+91 97828 69079",t:"clb",rm:413,ci:-1,nts:5,gx:1,src:"Corporate",st:"in",mb:400,ld:0,dn:850,eta:0},
  {id:"BK-2441",g:"Vasanth Kumar",ph:"+91 95833 68090",t:"std",rm:115,ci:-2,nts:5,gx:2,src:"Website",st:"in",mb:0,ld:450,dn:0,eta:0},
  {id:"BK-2442",g:"Ramesh Kamat",ph:"+91 93351 16485",t:"dlx",rm:406,ci:-4,nts:8,gx:1,src:"Booking.com",st:"in",mb:250,ld:120,dn:2400,eta:0},
  {id:"BK-2443",g:"Pallavi Dhumal",ph:"+91 92836 27775",t:"std",rm:211,ci:-1,nts:5,gx:3,src:"Corporate",st:"in",mb:0,ld:0,dn:1800,eta:0},
  {id:"BK-2444",g:"Sridhar Iyengar",ph:"+91 99427 81533",t:"sui",rm:511,ci:-1,nts:4,gx:3,src:"Website",st:"in",mb:250,ld:450,dn:0,eta:0},
  {id:"BK-2445",g:"Meera Nair",ph:"+91 98615 43106",t:"dlx",rm:409,ci:-3,nts:7,gx:2,src:"Phone",st:"in",mb:0,ld:0,dn:450,eta:0},
  {id:"BK-2446",g:"Prakash Gowda",ph:"+91 93164 73148",t:"dlx",rm:312,ci:-3,nts:5,gx:3,src:"Website",st:"in",mb:600,ld:120,dn:0,eta:0},
  {id:"BK-2447",g:"Sharat Chandra",ph:"+91 97459 91796",t:"dlx",rm:307,ci:-1,nts:3,gx:3,src:"MakeMyTrip",st:"in",mb:400,ld:0,dn:1800,eta:0},
  {id:"BK-2448",g:"Harish Chandra",ph:"+91 99210 60129",t:"std",rm:102,ci:-4,nts:5,gx:3,src:"MakeMyTrip",st:"in",mb:0,ld:0,dn:2400,eta:0},
  {id:"BK-2449",g:"Aparna Das",ph:"+91 95921 34333",t:"std",rm:116,ci:-4,nts:5,gx:3,src:"Phone",st:"in",mb:0,ld:450,dn:850,eta:0},
  {id:"BK-2450",g:"Ashwin Mahadevan",ph:"+91 96238 73355",t:"std",rm:111,ci:-3,nts:5,gx:2,src:"Agoda",st:"in",mb:150,ld:0,dn:0,eta:0},
  {id:"BK-2451",g:"Girija Raghavan",ph:"+91 95718 18235",t:"dlx",rm:410,ci:-2,nts:5,gx:1,src:"Website",st:"in",mb:150,ld:0,dn:2400,eta:0},
  {id:"BK-2452",g:"Padma Venkat",ph:"+91 94264 37142",t:"dlx",rm:305,ci:-2,nts:3,gx:3,src:"Phone",st:"in",mb:0,ld:200,dn:450,eta:0},
  {id:"BK-2453",g:"Omkar Desai",ph:"+91 93600 22529",t:"sui",rm:508,ci:-2,nts:5,gx:2,src:"Website",st:"in",mb:600,ld:0,dn:1800,eta:0},
  {id:"BK-2454",g:"Suresh Babu",ph:"+91 93528 02307",t:"dlx",rm:315,ci:-1,nts:5,gx:3,src:"Booking.com",st:"in",mb:400,ld:120,dn:1200,eta:0},
  {id:"BK-2455",g:"Latha Krishnan",ph:"+91 91488 42723",t:"dlx",rm:404,ci:-1,nts:5,gx:3,src:"Booking.com",st:"in",mb:0,ld:0,dn:450,eta:0},
  {id:"BK-2456",g:"Indira Bhattacharya",ph:"+91 97920 65318",t:"dlx",rm:304,ci:-1,nts:4,gx:1,src:"Agoda",st:"in",mb:250,ld:0,dn:0,eta:0},
  {id:"BK-2457",g:"Ravi Varma",ph:"+91 95785 46165",t:"std",rm:213,ci:-1,nts:4,gx:1,src:"Walk-in",st:"in",mb:150,ld:350,dn:450,eta:0},
  {id:"BK-2458",g:"Vinayak Joshi",ph:"+91 91066 28404",t:"dlx",rm:403,ci:-3,nts:5,gx:2,src:"Booking.com",st:"in",mb:600,ld:450,dn:0,eta:0},
  {id:"BK-2459",g:"Bhairavi Joshi",ph:"+91 92024 00602",t:"std",rm:105,ci:-4,nts:8,gx:2,src:"Walk-in",st:"in",mb:250,ld:120,dn:850,eta:0},
  {id:"BK-2460",g:"Ayesha Khan",ph:"+91 99207 04198",t:"sui",rm:506,ci:-4,nts:5,gx:2,src:"MakeMyTrip",st:"in",mb:0,ld:120,dn:450,eta:0},
  {id:"BK-2461",g:"Swati Tiwari",ph:"+91 96903 22696",t:"dlx",rm:320,ci:-1,nts:2,gx:3,src:"Website",st:"in",mb:150,ld:200,dn:0,eta:0},
  {id:"BK-2462",g:"Emily Carter",ph:"+91 98389 81861",t:"clb",rm:420,ci:-4,nts:7,gx:3,src:"Phone",st:"in",mb:0,ld:350,dn:850,eta:0},
  {id:"BK-2463",g:"Yash Agarwal",ph:"+91 91897 89270",t:"std",rm:113,ci:-2,nts:6,gx:3,src:"Agoda",st:"in",mb:150,ld:200,dn:850,eta:0},
  {id:"BK-2464",g:"Ganesh Aithal",ph:"+91 98899 61277",t:"std",rm:217,ci:-4,nts:7,gx:3,src:"Walk-in",st:"in",mb:250,ld:350,dn:1200,eta:0},
  {id:"BK-2465",g:"Sriram Vaidyanathan",ph:"+91 91922 13712",t:"sui",rm:513,ci:-3,nts:6,gx:3,src:"Corporate",st:"in",mb:0,ld:0,dn:850,eta:0},
  {id:"BK-2466",g:"Michael D'Souza",ph:"+91 95794 51577",t:"pre",rm:517,ci:-4,nts:5,gx:3,src:"Phone",st:"in",mb:250,ld:350,dn:850,eta:0},
  {id:"BK-2467",g:"Divya Hegde",ph:"+91 99537 69227",t:"std",rm:109,ci:-3,nts:7,gx:1,src:"MakeMyTrip",st:"in",mb:0,ld:0,dn:0,eta:0},
  {id:"BK-2468",g:"Amit Malhotra",ph:"+91 94238 21869",t:"std",rm:110,ci:-1,nts:2,gx:1,src:"Corporate",st:"in",mb:400,ld:450,dn:0,eta:0},
  {id:"BK-2469",g:"Hans Meier",ph:"+91 97410 37838",t:"dlx",rm:402,ci:-3,nts:4,gx:1,src:"Walk-in",st:"in",mb:0,ld:350,dn:2400,eta:0},
  {id:"BK-2470",g:"Radhika Shetty",ph:"+91 91484 78549",t:"dlx",rm:302,ci:-1,nts:3,gx:2,src:"Phone",st:"in",mb:150,ld:450,dn:1200,eta:0},
  {id:"BK-2471",g:"Yuki Tanaka",ph:"+91 94132 23557",t:"dlx",rm:301,ci:-4,nts:8,gx:3,src:"Goibibo",st:"in",mb:0,ld:0,dn:0,eta:0},
  {id:"BK-2472",g:"Dinesh Shenoy",ph:"+91 98113 87031",t:"clb",rm:419,ci:-2,nts:5,gx:3,src:"Phone",st:"in",mb:0,ld:350,dn:850,eta:0},
  {id:"BK-2473",g:"Bala Murugan",ph:"+91 91628 64560",t:"clb",rm:415,ci:-3,nts:4,gx:3,src:"Phone",st:"in",mb:0,ld:120,dn:1200,eta:0},
  {id:"BK-2474",g:"Nikhil Barot",ph:"+91 99610 91362",t:"pre",rm:519,ci:0,nts:1,gx:3,src:"Corporate",st:"arr",mb:0,ld:0,dn:0,eta:18},
  {id:"BK-2475",g:"Arjun Hegde",ph:"+91 91336 28295",t:"std",rm:215,ci:0,nts:1,gx:2,src:"Website",st:"arr",mb:0,ld:0,dn:0,eta:20},
  {id:"BK-2476",g:"Jennifer Pinto",ph:"+91 98763 97289",t:"sui",rm:509,ci:0,nts:4,gx:3,src:"Walk-in",st:"arr",mb:0,ld:0,dn:0,eta:16},
  {id:"BK-2477",g:"Pooja Trivedi",ph:"+91 91810 46722",t:"std",rm:120,ci:0,nts:1,gx:2,src:"Booking.com",st:"arr",mb:0,ld:0,dn:0,eta:11},
  {id:"BK-2478",g:"Ritu Bakshi",ph:"+91 92267 07812",t:"dlx",rm:313,ci:0,nts:1,gx:2,src:"Booking.com",st:"arr",mb:0,ld:0,dn:0,eta:20},
  {id:"BK-2479",g:"Gayathri Ram",ph:"+91 98369 85959",t:"std",rm:216,ci:0,nts:1,gx:1,src:"Walk-in",st:"arr",mb:0,ld:0,dn:0,eta:12},
  {id:"BK-2480",g:"Deepa Sharma",ph:"+91 94178 21931",t:"std",rm:101,ci:0,nts:1,gx:2,src:"Booking.com",st:"arr",mb:0,ld:0,dn:0,eta:10},
  {id:"BK-2481",g:"Uma Mahesh",ph:"+91 94528 68001",t:"std",rm:103,ci:0,nts:4,gx:3,src:"Corporate",st:"arr",mb:0,ld:0,dn:0,eta:17},
  {id:"BK-2482",g:"Bhavani Shankar",ph:"+91 92243 36720",t:"std",rm:117,ci:0,nts:3,gx:3,src:"Corporate",st:"arr",mb:0,ld:0,dn:0,eta:17},
  {id:"BK-2483",g:"Rohit Shet",ph:"+91 98768 66692",t:"dlx",rm:318,ci:0,nts:2,gx:3,src:"Walk-in",st:"arr",mb:0,ld:0,dn:0,eta:11},
  {id:"BK-2484",g:"Prasad Rao",ph:"+91 96960 80275",t:"pre",rm:518,ci:0,nts:2,gx:3,src:"Booking.com",st:"arr",mb:0,ld:0,dn:0,eta:14},
  {id:"BK-2485",g:"Subhash Ghosal",ph:"+91 95805 50424",t:"clb",rm:502,ci:-3,nts:3,gx:1,src:"Goibibo",st:"out",mb:150,ld:120,dn:850,eta:0},
  {id:"BK-2486",g:"Tanya Doshi",ph:"+91 91337 08542",t:"std",rm:201,ci:-1,nts:1,gx:3,src:"Corporate",st:"out",mb:0,ld:350,dn:850,eta:0},
  {id:"BK-2487",g:"Tejaswi Halmidi",ph:"+91 99399 57623",t:"std",rm:106,ci:-1,nts:1,gx:2,src:"Goibibo",st:"out",mb:150,ld:0,dn:1200,eta:0},
  {id:"BK-2488",g:"Arvind Rao",ph:"+91 98238 13434",t:"clb",rm:504,ci:-2,nts:2,gx:3,src:"Walk-in",st:"out",mb:150,ld:0,dn:450,eta:0},
  {id:"BK-2489",g:"Anil Sahay",ph:"+91 93005 58655",t:"std",rm:203,ci:-2,nts:2,gx:2,src:"Phone",st:"out",mb:0,ld:350,dn:1200,eta:0},
  {id:"BK-2490",g:"Sneha Kulkarni",ph:"+91 92681 67234",t:"clb",rm:416,ci:-4,nts:4,gx:3,src:"Phone",st:"out",mb:0,ld:0,dn:0,eta:0},
  {id:"BK-2491",g:"Nandini Rao",ph:"+91 91558 37111",t:"dlx",rm:306,ci:-2,nts:2,gx:2,src:"Walk-in",st:"out",mb:150,ld:120,dn:1200,eta:0},
  {id:"BK-2492",g:"Deepthi Suresh",ph:"+91 99874 23336",t:"std",rm:108,ci:-2,nts:2,gx:2,src:"Website",st:"out",mb:0,ld:120,dn:450,eta:0},
  {id:"BK-2493",g:"Zoya Sheikh",ph:"+91 97341 50905",t:"dlx",rm:null,ci:3,nts:1,gx:1,src:"MakeMyTrip",st:"up",mb:0,ld:0,dn:0,eta:0},
  {id:"BK-2494",g:"Prosenjit Dutta",ph:"+91 99339 41032",t:"sui",rm:null,ci:4,nts:1,gx:1,src:"Corporate",st:"up",mb:0,ld:0,dn:0,eta:0},
  {id:"BK-2495",g:"Devi Priya",ph:"+91 96748 32610",t:"pre",rm:null,ci:6,nts:2,gx:1,src:"Walk-in",st:"up",mb:0,ld:0,dn:0,eta:0},
  {id:"BK-2496",g:"Sunanda Pillai",ph:"+91 93182 86048",t:"std",rm:null,ci:6,nts:1,gx:3,src:"MakeMyTrip",st:"up",mb:0,ld:0,dn:0,eta:0},
  {id:"BK-2497",g:"Nagaraj Shastri",ph:"+91 95852 36592",t:"clb",rm:null,ci:6,nts:3,gx:1,src:"Goibibo",st:"up",mb:0,ld:0,dn:0,eta:0},
  {id:"BK-2498",g:"Mohan Urs",ph:"+91 97336 72332",t:"dlx",rm:null,ci:3,nts:3,gx:3,src:"MakeMyTrip",st:"up",mb:0,ld:0,dn:0,eta:0},
  {id:"BK-2499",g:"Sarah Thomas",ph:"+91 97853 60956",t:"std",rm:null,ci:2,nts:2,gx:2,src:"Corporate",st:"up",mb:0,ld:0,dn:0,eta:0},
  {id:"BK-2500",g:"Gopal Krishna",ph:"+91 94538 54375",t:"clb",rm:null,ci:5,nts:1,gx:3,src:"Phone",st:"up",mb:0,ld:0,dn:0,eta:0},
  {id:"BK-2501",g:"Manoj Pillai",ph:"+91 94899 44091",t:"clb",rm:null,ci:4,nts:3,gx:1,src:"Corporate",st:"up",mb:0,ld:0,dn:0,eta:0},
  {id:"BK-2502",g:"Nitin Gokhale",ph:"+91 93367 73271",t:"sui",rm:null,ci:6,nts:3,gx:2,src:"Booking.com",st:"up",mb:0,ld:0,dn:0,eta:0},
  {id:"BK-2503",g:"Kritika Jain",ph:"+91 98118 53580",t:"sui",rm:null,ci:4,nts:3,gx:2,src:"Agoda",st:"up",mb:0,ld:0,dn:0,eta:0},
  {id:"BK-2504",g:"Ilana Pereira",ph:"+91 93682 55491",t:"std",rm:null,ci:3,nts:1,gx:3,src:"Booking.com",st:"up",mb:0,ld:0,dn:0,eta:0},
  {id:"BK-2505",g:"Vijay Anand",ph:"+91 99956 49364",t:"clb",rm:null,ci:6,nts:3,gx:1,src:"Phone",st:"up",mb:0,ld:0,dn:0,eta:0},
  {id:"BK-2506",g:"Lakshmi Narayan",ph:"+91 92645 29639",t:"pre",rm:null,ci:4,nts:1,gx:1,src:"Corporate",st:"up",mb:0,ld:0,dn:0,eta:0}
];
var LODGE_MNT_NOTES = {  303:"AC compressor servicing",   501:"AC compressor servicing"};
var LODGE_TREND = [58,61,64,59,72,77,63]; /* occupancy % · last 7 days, today last */

/* ── Dashboard dataset — five ranges (auto-fed story) ─────────────────
   Lifetime: 10,229 bills · ₹54.7L revenue · 46 dishes · 5 staff.       */
function monthlySalary(){ return EMPS.filter(function(e){return e.a}).reduce(function(s,e){return s+e.s},0); } // ₹89,000 seeded
function monthlyRaw(){var m=new Date().toISOString().slice(0,7);return EXP_RAW.filter(function(x){return (x.d||"").slice(0,7)===m}).reduce(function(s,x){return s+x.a},0)}
function monthlyMaint(){var m=new Date().toISOString().slice(0,7);return EXP_MAINT.filter(function(x){return (x.d||"").slice(0,7)===m}).reduce(function(s,x){return s+x.a},0)}
var PIE_COLORS = ["#5b4fe9","#f59e0b","#0d9488","#e11d48","#10b981","#8a7cf6","#d946ef"];

var RANGES = {
  "today":{short:"TODAY",title:"SALES CURVE · TODAY (IST)",every:2,peak:"PEAK HOUR",period:"TODAY",prev:"yesterday",
    stats:{revenue:21840,bills:34,items:96,discounts:120,revDelta:12.4,billDelta:9.8},peakLabel:"1 PM",
    buckets:{labels:["9 AM","10 AM","11 AM","12 PM","1 PM","2 PM","3 PM","4 PM","5 PM","6 PM","7 PM","8 PM","9 PM","10 PM","11 PM"],
             values:[520,880,1240,1980,3420,2960,1840,760,540,680,1120,1980,2140,1290,490]},
    items:[["Paneer Butter Masala",9],["Veg Biryani",8],["Butter Naan",14],["Veg Dum Biryani",5],["Dal Tadka",6],["Masala Chai",11],["Gulab Jamun (2 pc)",6],["Filter Coffee",7],["Sweet Lassi",4],["Gobi 65",5]],
    mix:[["Main Course",32],["Rice & Biryani",24],["Starters",14],["Breads",12],["Beverages",11],["Desserts",7]]},
  "7d":{short:"7 DAYS",title:"REVENUE · LAST 7 DAYS",every:0,peak:"PEAK DAY",period:"LAST 7 DAYS",prev:"previous 7 days",
    stats:{revenue:142650,bills:236,items:682,discounts:940,revDelta:8.4,billDelta:5.2},peakLabel:"Sunday",
    buckets:{labels:["MON","TUE","WED","THU","FRI","SAT","SUN"],values:[17240,14310,15180,16890,18960,27640,32430]},
    items:[["Paneer Butter Masala",58],["Veg Biryani",49],["Butter Naan",82],["Veg Dum Biryani",34],["Dal Tadka",41],["Masala Chai",64],["Kadai Paneer",27],["Gulab Jamun (2 pc)",36],["Veg Fried Rice",29],["Filter Coffee",44]],
    mix:[["Main Course",33],["Rice & Biryani",23],["Starters",13],["Breads",13],["Beverages",11],["Desserts",7]]},
  "1m":{short:"1 MONTH",title:"REVENUE · LAST 30 DAYS",every:4,peak:"PEAK DAY",period:"LAST 30 DAYS",prev:"previous 30 days",
    stats:{revenue:614300,bills:1024,items:2960,discounts:4210,revDelta:11.2,billDelta:6.7},peakLabel:"Sep 6",
    buckets:{daily:30,shape:[8.2,8.9,9.6,9.1,10.4,14.2,16.8,8.4,9.0,9.8,9.4,10.9,14.9,17.4,8.8,9.2,8.1,10.2,15.1,17.0,8.9,9.6,10.1,9.8,11.2,14.6,16.2,9.3,9.9,10.6]},
    items:[["Paneer Butter Masala",251],["Veg Biryani",208],["Butter Naan",356],["Veg Dum Biryani",148],["Dal Tadka",178],["Masala Chai",271],["Kadai Paneer",118],["Veg Fried Rice",131],["Gulab Jamun (2 pc)",157],["Filter Coffee",188]],
    mix:[["Main Course",32],["Rice & Biryani",23],["Starters",14],["Breads",13],["Beverages",11],["Desserts",7]]},
  "3m":{short:"3 MONTHS",title:"REVENUE · LAST 3 MONTHS",every:1,peak:"PEAK WEEK",period:"LAST 3 MONTHS",prev:"previous 90 days",
    stats:{revenue:1786400,bills:2981,items:8620,discounts:12480,revDelta:9.1,billDelta:7.4},peakLabel:"Week of Aug 31",
    buckets:{weekly:12,shape:[8.6,9.0,9.5,8.7,9.3,9.8,8.9,9.4,9.9,9.1,9.6,10.2]},
    items:[["Paneer Butter Masala",724],["Veg Biryani",601],["Butter Naan",1042],["Veg Dum Biryani",427],["Dal Tadka",512],["Masala Chai",806],["Kadai Paneer",341],["Veg Fried Rice",379],["Gulab Jamun (2 pc)",452],["Filter Coffee",548]],
    mix:[["Main Course",32],["Rice & Biryani",23],["Starters",14],["Breads",13],["Beverages",11],["Desserts",7]]},
  "1y":{short:"1 YEAR",title:"REVENUE · LAST 12 MONTHS",every:1,peak:"PEAK MONTH",period:"LAST 12 MONTHS",prev:"previous year",
    stats:{revenue:5468000,bills:10229,items:29470,discounts:48650,revDelta:22.4,billDelta:18.9},peakLabel:"December",
    buckets:{labels:["OCT","NOV","DEC","JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP"],values:[482000,512000,545000,428000,406000,462000,444000,471000,432000,438000,465000,383000]},
    items:[["Paneer Butter Masala",2340],["Veg Biryani",1985],["Butter Naan",3120],["Veg Dum Biryani",1410],["Dal Tadka",1860],["Masala Chai",2750],["Kadai Paneer",1120],["Veg Fried Rice",1240],["Gulab Jamun (2 pc)",1540],["Filter Coffee",1930]],
    mix:[["Main Course",32],["Rice & Biryani",24],["Starters",14],["Breads",12],["Beverages",11],["Desserts",7]]}
};
var ALL_TIME = {bills:10229, revenue:5468000};
/* hourly rhythm — the average day, permanent across ranges */
var HOURLY = {labels:["9 AM","10 AM","11 AM","12 PM","1 PM","2 PM","3 PM","4 PM","5 PM","6 PM","7 PM","8 PM","9 PM","10 PM","11 PM"],
              values:[620,840,1160,1820,3120,2650,1650,690,510,640,1040,1810,1960,1180,450]};

/* normalise daily/weekly shapes so each range's buckets sum exactly */
function bucketData(key){
  var r = RANGES[key], b = r.buckets, labels, values;
  if (b.labels){ labels = b.labels.slice(); values = b.values.slice(); }
  else if (b.daily){
    labels = []; values = [];
    var now = new Date();
    for (var i=b.daily-1;i>=0;i--){
      var d = new Date(now.getTime()-i*86400000);
      labels.push(d.toLocaleDateString("en-IN",{timeZone:"Asia/Calcutta",day:"numeric",month:"short"}));
    }
    values = b.shape.slice();
  } else { // weekly
    labels = []; values = b.shape.slice();
    var monday = new Date(); monday.setHours(12,0,0,0);
    monday = new Date(monday.getTime() - ((monday.getDay()+6)%7)*86400000);
    for (var w=b.weekly-1;w>=0;w--){
      var m = new Date(monday.getTime()-w*7*86400000);
      labels.push(m.toLocaleDateString("en-IN",{timeZone:"Asia/Calcutta",day:"numeric",month:"short"}));
    }
  }
  var target = r.stats.revenue, sum = values.reduce(function(a,x){return a+x},0);
  var scaled = values.map(function(v){return Math.round(v/sum*target)});
  var diff = target - scaled.reduce(function(a,x){return a+x},0);
  scaled[scaled.length-1] += diff; // exact totals, always
  var maxIdx = 0; scaled.forEach(function(v,i){if(v>scaled[maxIdx])maxIdx=i});
  return {labels:labels, values:scaled, peak:labels[maxIdx]};
}
function itemsData(key){
  return RANGES[key].items.map(function(row){
    var d = DISHES.filter(function(x){return x.n===row[0]})[0] || {n:row[0],p:100};
    return {name:d.n, qty:row[1], revenue:row[1]*d.p};
  });
}
function costsData(key){
  var rev = RANGES[key].stats.revenue, div = {"today":30,"7d":30/7,"1m":1,"3m":1/3,"1y":1/12}[key];
  var sal = Math.round(monthlySalary()/div), raw, mnt;
  if (key==="1m"){raw=monthlyRaw();mnt=monthlyMaint()}
  else if (key==="3m"){raw=Math.round(monthlyRaw()*3);mnt=Math.round(monthlyMaint()*3)}
  else if (key==="1y"){raw=Math.round(monthlyRaw()*12);mnt=Math.round(monthlyMaint()*12)}
  else if (key==="7d"){raw=Math.round(monthlyRaw()/4.3);mnt=Math.round(monthlyMaint()/4.3)}
  else {raw=Math.round(monthlyRaw()/30);mnt=Math.round(monthlyMaint()/30)}
  var profit = rev - sal - raw - mnt;
  return {salaries:sal, raw:raw, maint:mnt, profit:profit, marginPct: rev>0?Math.round(profit/rev*100):null};
}
/* live today stats (bills generated / undone in the demo mutate these) */
var LIVE = {todayBills:0, todayRevenue:0, todayItems:0, lastBillNumber:10229};
function todayStats(){
  var s = RANGES["today"].stats;
  return {bills:s.bills+LIVE.todayBills, revenue:s.revenue+LIVE.todayRevenue, items:s.items+LIVE.todayItems,
          avg: Math.round((s.revenue+LIVE.todayRevenue)/Math.max(1,s.bills+LIVE.todayBills))};
}

/* ── Recent bills — the live feed (tap to reprint · undo removes) ───── */
function mkBill(number, minsAgo, items, discount){
  var subtotal = 0, count = 0;
  items.forEach(function(it){ var d = DISHES.filter(function(x){return x.n===it.n})[0]; subtotal += d.p*it.q; count += it.q; });
  var disc = Math.min(discount||0, subtotal), taxable = subtotal-disc;
  var tax = Math.round(taxable*5)/100, total = Math.round((taxable+tax)*100)/100;
  return {id:"b"+number, number:number, subtotal:subtotal, discount:disc, tax:tax, total:total,
          itemCount:count, createdAt:new Date(Date.now()-minsAgo*60000).toISOString(),
          items:items.map(function(it){var d=DISHES.filter(function(x){return x.n===it.n})[0];return {id:d.id,name:d.n,qty:it.q,price:d.p,category:d.c}})};
}
var BILLS = [
  mkBill(10229, 2,  [{n:"Paneer Butter Masala",q:2},{n:"Butter Naan",q:3},{n:"Jeera Rice",q:1},{n:"Sweet Lassi",q:2}]),
  mkBill(10228, 14, [{n:"Veg Dum Biryani",q:1},{n:"Masala Chai",q:1}]),
  mkBill(10227, 31, [{n:"Gobi 65",q:3},{n:"Tandoori Roti",q:2},{n:"Veg Fried Rice",q:1}], 20),
  mkBill(10226, 49, [{n:"Kadai Paneer",q:2},{n:"Garlic Naan",q:4},{n:"Veg Biryani",q:1}]),
  mkBill(10225, 66, [{n:"Filter Coffee",q:1},{n:"Kesari Bath",q:1}]),
  mkBill(10224, 88, [{n:"Masala Chai",q:4},{n:"Veg Spring Rolls",q:2}]),
  mkBill(10223, 107,[{n:"Palak Paneer",q:1},{n:"Lachha Paratha",q:2},{n:"Curd Rice",q:1}]),
  mkBill(10222, 126,[{n:"Crispy Corn",q:2},{n:"Fresh Lime Soda",q:1}]),
  mkBill(10221, 148,[{n:"Malai Kofta",q:1},{n:"Rasmalai (2 pc)",q:1},{n:"Kulcha",q:2}])
];

/* ── Theme ──────────────────────────────────────────────────────────── */
function applyThemeIcons(){
  var dark = document.documentElement.classList.contains("dark");
  $$("[data-theme]").forEach(function(b){ b.innerHTML = ic(dark?"sun":"moon",16); });
}
function toggleTheme(){
  var dark = document.documentElement.classList.toggle("dark");
  try{localStorage.setItem("fx-theme",dark?"dark":"light")}catch(e){}
  applyThemeIcons();
  renderView(currentView, true); // charts re-paint with CSS-var colors
}
(function initTheme(){
  try{ if (localStorage.getItem("fx-theme")==="dark") document.documentElement.classList.add("dark"); }catch(e){}
})();
document.addEventListener("click",function(e){
  var b = e.target.closest ? e.target.closest("[data-theme]") : null;
  if (b) toggleTheme();
});

/* ── Toast ──────────────────────────────────────────────────────────── */
function toast(title,desc){
  var w = $("#toasts"); if(!w) return;
  var t = document.createElement("div");
  t.className="toast fx-card-soft";
  t.innerHTML='<div class="t-t">'+esc(title)+'</div>'+(desc?'<div class="t-d">'+esc(desc)+"</div>":"");
  w.appendChild(t);
  setTimeout(function(){ t.style.transition="opacity .3s"; t.style.opacity="0"; setTimeout(function(){t.remove()},320); },4200);
}
