// Sets the runtime hotel identity (Setting table) — the VARIABLE tenant name.
// Usage: bun scripts/set-hotel-name.ts "Imperial Spice"
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const name = (process.argv[2] ?? "Imperial Spice").trim();

const row = await db.setting.upsert({
  where: { key: "hotelName" },
  update: { value: name },
  create: { key: "hotelName", value: name },
});

console.log("hotelName =", row.value);
await db.$disconnect();
