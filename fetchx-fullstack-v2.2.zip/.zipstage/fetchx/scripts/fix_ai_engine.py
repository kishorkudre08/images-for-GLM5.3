# -*- coding: utf-8 -*-
"""Swap fetchx-demo.html AI engine: 1:1 panel (resize grip + width persistence),
every question -> single locked reply. No scripted tables, no DEMO PREVIEW."""
import io

P = "/home/z/my-project/download/fetchx-demo.html"
s = io.open(P, encoding="utf-8").read()

# ── 1. replace engine constants + replyFor (from AI comment to markdown renderer) ──
j2 = s.index("hardcoded demo showcase")
i = s.rindex("/*", 0, j2)          # start of that comment line
j = s.index("/* tiny markdown renderer")

engine = u'''/* ═══════════════ FETCH-X AI (ai-panel.tsx 1:1) — same panel, replies locked ═══ */
var aiMsgs = [];
var aiBusy = false;

var QUICK = [
  "Summarize my sales for this period",
  "Which dishes should I promote or reprice?",
  "What are my peak hours and how do I staff them?",
  "Tips to grow revenue this month"
];

/* The one reply the demo AI gives — the live AI runs only on the full product */
var LOCKED_REPLY = "To unlock AI on your own restaurant data, email kishorkudre08@gmail.com \u2014 purchase the subscription and it's live within a day.";

'''
s = s[:i] + engine + s[j:]

# ── 2. aiSend: always answer LOCKED_REPLY, smooth scroll, send-btn gate like React ──
old_timeout = '''  setTimeout(function(){
    t.remove();
    var r = replyFor(q);
    var d = document.createElement("div");
    d.className = "msg msg-ai"+(r.lock?" lock":"");
    d.innerHTML = mdRender(r.text);
    $("#aiMsgs").appendChild(d);
    $("#aiMsgs").scrollTop = 999999;
    aiBusy = false; $("#aiSend").disabled = false;
  },900);'''
new_timeout = '''  setTimeout(function(){
    t.remove();
    var d = document.createElement("div");
    d.className = "msg msg-ai";
    d.innerHTML = mdRender(LOCKED_REPLY);
    $("#aiMsgs").appendChild(d);
    $("#aiMsgs").scrollTo({top: $("#aiMsgs").scrollHeight, behavior: "smooth"});
    aiBusy = false;
    $("#aiSend").disabled = !$("#aiInput").value.trim();
  },900);'''
assert old_timeout in s, "aiSend body not found"
s = s.replace(old_timeout, new_timeout)

# ── 3. resize controller + input gate, inserted before BOOT ──
k = s.index("/* ═══════════════ BOOT")
resize = u'''/* \u2500\u2500 drag-to-resize (ai-panel.tsx): grab the left-edge pill and stretch \u2014
   up to 75% of the screen (max 760px); width remembered like the real app \u2500\u2500 */
var AI_MIN_W = 280, AI_ABS_MAX = 760, aiW = 380, aiDrag = false;
function aiMaxW(){ return Math.min(AI_ABS_MAX, Math.max(340, Math.floor(window.innerWidth*0.75))); }
function setAiW(w){ aiW = w; $("#aiPanel").style.setProperty("--ai-w", w+"px"); }
(function aiResizeInit(){
  try{
    var savedW = Number(localStorage.getItem("fx-ai-width"));
    if (Number.isFinite(savedW) && savedW >= AI_MIN_W) setAiW(Math.min(savedW, aiMaxW()));
  }catch(e){}
  function gx(e){ return "touches" in e ? e.touches[0].clientX : e.clientX; }
  function move(e){
    if (!aiDrag) return;
    setAiW(Math.min(aiMaxW(), Math.max(AI_MIN_W, window.innerWidth - gx(e))));
  }
  function up(){
    if (!aiDrag) return;
    aiDrag = false;
    document.body.style.userSelect = "";
    try{ localStorage.setItem("fx-ai-width", String(aiW)); }catch(e){}
    if (shellReady){
      if (currentView==="dashboard") paintDash();
      else if (currentView==="pos") paintPosGrid();
    }
  }
  function down(){ aiDrag = true; document.body.style.userSelect = "none"; }
  var grip = $("#aiGrip");
  grip.addEventListener("mousedown", down);
  grip.addEventListener("touchstart", down, {passive:true});
  window.addEventListener("mousemove", move);
  window.addEventListener("touchmove", move, {passive:true});
  window.addEventListener("mouseup", up);
  window.addEventListener("touchend", up);
})();

/* send button disabled until there is text \u2014 same as the real panel */
(function aiInputGate(){
  var inp = $("#aiInput"), btn = $("#aiSend");
  function sync(){ if (!aiBusy) btn.disabled = !inp.value.trim(); }
  inp.addEventListener("input", sync);
  sync();
})();

'''
s = s[:k] + resize + s[k:]

io.open(P, "w", encoding="utf-8").write(s)
print("engine swapped OK; LOCKED_REPLY present:", "LOCKED_REPLY" in s)
print("scripted leftovers:", s.count("replyFor"), s.count("DEMO PREVIEW"), s.count("REPLY_"))
