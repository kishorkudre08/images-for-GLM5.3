#!/usr/bin/env python3
"""Task 41 — remove the Latest-Activity feed from dashboard-view.tsx."""
import re, pathlib

p = pathlib.Path("/home/z/my-project/src/components/dashboard-view.tsx")
s = p.read_text()
orig = s

# 1. imports: drop Undo2, ScrollFadeBox, useReceipt
s = s.replace('  TrendingDown,\n  Undo2,\n} from "lucide-react";', '  TrendingDown,\n} from "lucide-react";')
s = s.replace('import { ScrollFadeBox, TierBand } from "@/components/fx";\nimport { useReceipt } from "@/components/receipt-dialog";\n', 'import { TierBand } from "@/components/fx";\n')

# 2. Feed component block: from its banner comment up to (not incl.) "small helpers" banner
s2, n = re.subn(
    r"/\* ── activity feed .*?\*/\n\nfunction Feed\(.*?\n\}\n\n(?=/\* ── small helpers)",
    "",
    s,
    count=1,
    flags=re.S,
)
assert n == 1, "Feed block not removed"
s = s2

# 3. lodgeBillToBill helper
s2, n = re.subn(r"function lodgeBillToBill\(b: \{.*?\n\}\n\ntype Wall = \{", "type Wall = {", s, count=1, flags=re.S)
assert n == 1, "lodgeBillToBill not removed"
s = s2

# 4. undoFeedRow handler (banner comment + async fn, ends before the 15s poll effect)
s2, n = re.subn(
    r"  // UNDO in the latest-activity feed.*?\n  \};\n\n(  React\.useEffect\(\(\) => \{\n    void load\(range\);)",
    r"\1",
    s,
    count=1,
    flags=re.S,
)
assert n == 1, "undoFeedRow not removed"
s = s2

# 5. feedRows + feedFiltered construction (ends right before the scope-chips banner)
s2, n = re.subn(
    r"  const feedRows = \[.*?const feedFiltered = feedRows\.filter\(\(r\) => \(scope === \"rest\" \? r\.kind === \"rest\" : scope === \"lodge\" \? r\.kind === \"lodge\" : true\)\)\;\n\n",
    "",
    s,
    count=1,
    flags=re.S,
)
assert n == 1, "feedRows not removed"
s = s2

# 6. The Latest Activity card itself
s2, n = re.subn(
    r"      \{/\* ═+ LATEST ACTIVITY[^\n]*\*/\}\n      <div className=\"fx-card p-5\">\n        <span className=\"fx-label\">\n          LATEST ACTIVITY.*?\n        </ScrollFadeBox>\n      </div>\n",
    "",
    s,
    count=1,
    flags=re.S,
)
assert n == 1, "Latest activity card not removed"
s = s2

# 7. openReceipt no longer used in this view
s = s.replace("  const { openReceipt } = useReceipt();\n", "")
s = s.replace('import { useReceipt } from "@/components/receipt-dialog";\n', "")

p.write_text(s)
print("dashboard-view.tsx: removed", len(orig) - len(s), "chars")
