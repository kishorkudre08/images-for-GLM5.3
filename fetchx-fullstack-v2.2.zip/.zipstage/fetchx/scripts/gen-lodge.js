/* Generates the Imperial Spices Hotel lodge dataset — deterministic (seeded),
   so the demo HTML and the full-stack app embed the exact same data.
   Outputs:
     scripts/lodge-data.js    — JS literal snippet for fetchx-demo.html
     scripts/lodge-data.json  — same data for src/lib/lodge-data.ts        */
"use strict";
const fs = require("fs");

/* seeded PRNG — same recipe on both sides is unnecessary (we embed literals),
   but determinism here keeps regeneration stable */
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rnd = mulberry32(20260920);
const ri = (min, max) => min + Math.floor(rnd() * (max - min + 1)); // inclusive
const pick = (arr) => arr[Math.floor(rnd() * arr.length)];

function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/* ── room types ─────────────────────────────────────────────────────── */
const TYPES = {
  std: { name: "Standard", rate: 1800, occ: 58 },
  dlx: { name: "Deluxe", rate: 2800, occ: 66 },
  clb: { name: "Club Executive", rate: 4200, occ: 71 },
  sui: { name: "Suite", rate: 6500, occ: 64 },
  pre: { name: "Presidential", rate: 12000, occ: 40 },
};

/* ── 100 rooms across 5 floors ────────────────────────────────────────
   F1 101–120 Standard(20) · F2 201–220 Standard(20) · F3 301–320 Deluxe(20)
   F4 401–410 Deluxe(10) + 411–420 Club(10)
   F5 501–505 Club(5) + 506–515 Suite(10) + 516–520 Presidential(5)      */
const ROOMS = [];
const floorPlan = [
  [1, 101, 120, "std"],
  [2, 201, 220, "std"],
  [3, 301, 320, "dlx"],
  [4, 401, 410, "dlx"],
  [4, 411, 420, "clb"],
  [5, 501, 505, "clb"],
  [5, 506, 515, "sui"],
  [5, 516, 520, "pre"],
];
for (const [fl, from, to, t] of floorPlan)
  for (let n = from; n <= to; n++) ROOMS.push({ rm: n, fl, t, st: "avl" });

/* ── status mix: 63 occ · 11 res · 8 dirty · 2 mnt · 16 avl ─────────── */
const OCC = 63, RES = 11, DIRTY = 8, MNT = 2;
const shuffled = shuffle(ROOMS);
let k = 0;
shuffled.slice(0, OCC).forEach((r) => (r.st = "occ"));
shuffled.slice(OCC, OCC + RES).forEach((r) => (r.st = "res"));
shuffled.slice(OCC + RES, OCC + RES + DIRTY).forEach((r) => (r.st = "dirty"));
shuffled.slice(OCC + RES + DIRTY, OCC + RES + DIRTY + MNT).forEach((r) => (r.st = "mnt"));

/* ── guests ─────────────────────────────────────────────────────────── */
const NAMES = [
  "Rajesh Iyer","Meera Nair","Arvind Rao","Kavya Reddy","Sanjay Patil","Deepa Sharma",
  "Vikram Deshpande","Anita Menon","Suresh Babu","Latha Krishnan","Prakash Gowda","Sneha Kulkarni",
  "Manoj Pillai","Radhika Shetty","Girish Prabhu","Sunita Joshi","Ramesh Kamat","Preeti Sinha",
  "Naveen Kumar","Divya Hegde","Mohan Urs","Shruti Bhat","Anil Sahay","Vasanth Kumar",
  "Lakshmi Narayan","Harish Chandra","Bhavani Shankar","Gopal Krishna","Ravi Varma","Nandini Rao",
  "Sridhar Iyengar","Uma Mahesh","Karthik Subramanian","Padma Venkat","George Mathew","Ann Kurian",
  "Farhan Ali","Ayesha Khan","Zoya Sheikh","Tarun Sethi","Neha Sabharwal","Amit Malhotra",
  "Ritu Bakshi","Vivek Anand","Swati Tiwari","Nikhil Barot","Pooja Trivedi","Sameer Kulkarni",
  "Aditi Rane","Yash Agarwal","Kritika Jain","Rohit Shet","Gaurav Mhambrey","Sagar Naik",
  "Pallavi Dhumal","Vinayak Joshi","Rekha Pai","Dinesh Shenoy","Mala Chandrasekhar","Sriram Vaidyanathan",
  "Girija Raghavan","Bala Murugan","Vijay Anand","Gayathri Ram","Prasad Rao","Chandran Menon",
  "Devi Priya","Arjun Hegde","Kiran Majumdar","Tanya Doshi","Omkar Desai","Sharvari Kadam",
  "Nitin Gokhale","Aparna Das","Subhash Ghosal","Indira Bhattacharya","Prosenjit Dutta","Ilana Pereira",
  "Michael D'Souza","Sarah Thomas","Daniel Fernandes","Jennifer Pinto","Robert Wilson","Emily Carter",
  "Hans Meier","Yuki Tanaka","Raghavendra Kulkarni","Sunanda Pillai","Mahesh Bhatt" /* drop actor-like */,
  "Vishwanath Alluri","Chaitanya Dev","Poornima Rao","Tejaswi Halmidi","Ganesh Aithal","Vidya Vyas",
  "Ashwin Mahadevan","Reema Lagu","Sharat Chandra","Bhairavi Joshi","Nagaraj Shastri","Deepthi Suresh"
];
const names = shuffle(NAMES.filter((n) => n !== "Mahesh Bhatt" && n !== "Reema Lagu")); // keep it neutral
let ni = 0;
const nextName = () => names[ni++ % names.length];
const phone = () => "+91 9" + ri(10, 99) + " " + ri(10000, 99999) + " " + ri(1000, 9999) && ("+91 9" + ri(10, 99) + ri(10000, 99999)).replace(/(\d{5})(\d{5})/, "$1 $2");
function phoneOk() {
  const rest = String(ri(100000000, 999999999)); // 9 digits → total 10 with leading 9
  return "+91 9" + rest.slice(0, 4) + " " + rest.slice(4);
}
const SRC = [
  "Walk-in","Walk-in","Walk-in","Phone","Phone","Phone","Website","Website",
  "MakeMyTrip","MakeMyTrip","MakeMyTrip","Booking.com","Booking.com","Booking.com",
  "Agoda","Corporate","Corporate","Corporate","Goibibo"
];

/* ── bookings ───────────────────────────────────────────────────────── */
const bookings = [];
let bk = 2410;
const addBk = (b) => { b.id = "BK-" + (++bk); bookings.push(b); return b; };

/* in-house — 63, exactly 9 due out today (ci + nts === 0) */
const occRooms = shuffled.slice(0, OCC);
occRooms.forEach((r, i) => {
  const ci = -ri(1, 4);
  const dueToday = i < 9;
  const nts = dueToday ? -ci : -ci + ri(1, 4);
  const suite = r.t === "sui" || r.t === "pre";
  addBk({
    g: nextName(), ph: phoneOk(), t: r.t, rm: r.rm, ci, nts,
    gx: suite ? ri(2, 4) : ri(1, 3), src: pick(SRC), st: "in",
    mb: pick([0, 0, 0, 150, 250, 400, 600]),
    ld: pick([0, 0, 120, 200, 350, 450]),
    dn: pick([0, 0, 450, 850, 1200, 1800, 2400]),
    eta: 0,
  });
});
/* arriving today — 11 (reserved rooms) */
shuffled.slice(OCC, OCC + RES).forEach((r) => {
  addBk({
    g: nextName(), ph: phoneOk(), t: r.t, rm: r.rm, ci: 0, nts: ri(1, 4),
    gx: ri(1, 3), src: pick(SRC), st: "arr",
    mb: 0, ld: 0, dn: 0, eta: ri(10, 20),
  });
});
/* checked out this morning — 8 (dirty rooms) */
shuffled.slice(OCC + RES, OCC + RES + DIRTY).forEach((r) => {
  const ci = -ri(1, 4);
  addBk({
    g: nextName(), ph: phoneOk(), t: r.t, rm: r.rm, ci, nts: -ci,
    gx: ri(1, 3), src: pick(SRC), st: "out",
    mb: pick([0, 0, 150, 400]), ld: pick([0, 120, 350]), dn: pick([0, 450, 850, 1200]),
    eta: 0,
  });
});
/* upcoming — 14, room assigned at check-in */
for (let i = 0; i < 14; i++) {
  addBk({
    g: nextName(), ph: phoneOk(), t: pick(["std", "std", "dlx", "dlx", "clb", "sui", "pre"]),
    rm: null, ci: ri(1, 6), nts: ri(1, 3), gx: ri(1, 3), src: pick(SRC), st: "up",
    mb: 0, ld: 0, dn: 0, eta: 0,
  });
}

/* ── maintenance notes ──────────────────────────────────────────────── */
const MNT_NOTES = [
  "AC compressor servicing",
  "Bathroom plumbing leak",
  "Deep cleaning after paint work",
  "Carpet replacement",
];
const mntRooms = shuffled.slice(OCC + RES + DIRTY, OCC + RES + DIRTY + MNT);

/* ── output ─────────────────────────────────────────────────────────── */
const roomsLit = ROOMS.slice().sort((a, b) => a.rm - b.rm)
  .map((r) => `  [${r.rm},"${r.t}","${r.st}"]`).join(",\n");

const bookingsLit = bookings
  .map((b) => `  {id:"${b.id}",g:"${b.g}",ph:"${b.ph}",t:"${b.t}",rm:${b.rm},ci:${b.ci},nts:${b.nts},gx:${b.gx},src:"${b.src}",st:"${b.st}",mb:${b.mb},ld:${b.ld},dn:${b.dn},eta:${b.eta}}`)
  .join(",\n");

const mntLit = mntRooms.map((r) => `  ${r.rm}:"${pick(MNT_NOTES)}"`).join(", ");

const js = `/* ── Lodge dataset — Imperial Spices Hotel · 100 rooms · 5 floors ─────
   Room statuses: avl available · occ occupied · res reserved (arriving today)
                  dirty checkout-cleaning · mnt maintenance
   Booking states: st in in-house · arr arriving today · up upcoming · out checked-out
   ci = check-in offset in days from TODAY (−2 = two nights ago) · nts = nights
   mb/ld/dn = running folio extras (mini-bar / laundry / restaurant tab)      */
var LODGE_TYPES = {
  std:{name:"Standard",rate:1800,occ:58},
  dlx:{name:"Deluxe",rate:2800,occ:66},
  clb:{name:"Club Executive",rate:4200,occ:71},
  sui:{name:"Suite",rate:6500,occ:64},
  pre:{name:"Presidential",rate:12000,occ:40}
};
var LODGE_ROOMS = [
${roomsLit}
];
var LODGE_BOOKINGS = [
${bookingsLit}
];
var LODGE_MNT_NOTES = {${mntLit}};
var LODGE_TREND = [58,61,64,59,72,77,63]; /* occupancy % · last 7 days, today last */
`;

fs.writeFileSync(__dirname + "/lodge-data.js", js);

/* JSON for the TS side */
const json = {
  types: TYPES,
  rooms: ROOMS.slice().sort((a, b) => a.rm - b.rm).map((r) => [r.rm, r.t, r.st]),
  bookings: bookings,
  mntNotes: Object.fromEntries(mntRooms.map((r) => [String(r.rm), MNT_NOTES[0]])),
  trend: [58, 61, 64, 59, 72, 77, 63],
};
fs.writeFileSync(__dirname + "/lodge-data.json", JSON.stringify(json, null, 1));

/* sanity report */
const cnt = { avl: 0, occ: 0, res: 0, dirty: 0, mnt: 0 };
ROOMS.forEach((r) => cnt[r.st]++);
const occBookings = bookings.filter((b) => b.st === "in");
const revTonight = occBookings.reduce((s, b) => s + TYPES[b.t].rate, 0);
const byType = {};
occBookings.forEach((b) => (byType[b.t] = (byType[b.t] || 0) + 1));
console.log("rooms:", ROOMS.length, cnt);
console.log("bookings:", bookings.length, {
  in: bookings.filter((b) => b.st === "in").length,
  arr: bookings.filter((b) => b.st === "arr").length,
  up: bookings.filter((b) => b.st === "up").length,
  out: bookings.filter((b) => b.st === "out").length,
});
console.log("due out today:", occBookings.filter((b) => b.ci + b.nts === 0).length);
console.log("revenue tonight:", revTonight, "ADR:", Math.round(revTonight / occBookings.length), "RevPAR:", Math.round(revTonight / 100));
console.log("in-house guests:", occBookings.reduce((s, b) => s + b.gx, 0));
console.log("occupied by type:", byType);
console.log("unique names used:", ni, "of", names.length);
