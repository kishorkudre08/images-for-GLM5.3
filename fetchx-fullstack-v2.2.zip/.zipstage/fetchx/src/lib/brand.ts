// ═══════════════════════════════════════════════════════════════════════════
// BRAND ARCHITECTURE — two distinct layers:
//
//  1. PLATFORM BRAND (Fetch-X) — FIXED. Never changes, no matter which hotel
//     runs on the software. Appears in footers, receipts' "powered by", credits.
//
//  2. HOTEL IDENTITY (variable) — the tenant running on Fetch-X. This name is
//     a VARIABLE: it can be swapped per restaurant (default below, and it can
//     be edited live in Management → Hotel Profile, stored in the Setting table).
//     Every screen, bill, PDF and persona reads from it.
// ═══════════════════════════════════════════════════════════════════════════

// ── Platform brand — DO NOT CHANGE ──────────────────────────────────────────
export const PLATFORM = {
  name: "Fetch-X",
  tagline: "Data Intelligence Platform",
  copyright: "© 2026 Fetch-X — Data Intelligence Platform. All rights reserved.",
  receiptLine: "POWERED BY FETCH-X",
};

// ── Hotel identity — tenant variable (default; runtime-editable in Management)
export const HOTEL_DEFAULT = {
  name: "Imperial Spice",
  tagline: "PURE VEG RESTAURANT",
  address: "12, Main Road, Mailoor",
  phone: "+91 98XXX 45XXX",
  gstin: "29ABCDE1234F1Z5",
  fssai: "Lic. No. 21222222222222",
  cashier: "RAVI · COUNTER 01",
};

/** "Imperial Spice" → "IS" · "Jaya's Kitchen" → "JK" · "Spice" → "S" */
export function hotelInitials(name: string): string {
  const words = name.trim().split(/\s+/).filter(Boolean);
  if (words.length === 0) return "FX";
  const first = words[0][0] ?? "";
  const second = words.length > 1 ? words[words.length - 1][0] ?? "" : "";
  return (first + second).toUpperCase();
}

/** "Imperial Spice" → "imperial-spice" (used for PDF filenames) */
export function hotelSlug(name: string): string {
  return (
    name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "") || "restaurant"
  );
}
