import { db } from "@/lib/db";
import { HOTEL_DEFAULT } from "@/lib/brand";

export const HOTEL_NAME_KEY = "hotelName";

/** Server-side read of the variable hotel identity (falls back to the default). */
export async function getHotelName(): Promise<string> {
  const row = await db.setting.findUnique({ where: { key: HOTEL_NAME_KEY } });
  const name = row?.value.trim();
  return name ? name : HOTEL_DEFAULT.name;
}

/** Upsert the hotel name (validated 2–40 chars). Returns the stored value. */
export async function setHotelName(raw: string): Promise<string> {
  const name = raw.trim().replace(/\s+/g, " ").slice(0, 40);
  if (name.length < 2) throw new Error("Hotel name needs at least 2 characters.");
  await db.setting.upsert({
    where: { key: HOTEL_NAME_KEY },
    update: { value: name },
    create: { key: HOTEL_NAME_KEY, value: name },
  });
  return name;
}
