"use client";

import * as React from "react";
import { Minus, Plus, Receipt, Search, Trash2, Loader2, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { TierBand, VegDot, ScrollFadeBox } from "@/components/fx";
import { BillsFeed } from "@/components/bills-feed";
import { useReceipt } from "@/components/receipt-dialog";
import { useHotel } from "@/components/hotel-context";
import { useToast } from "@/hooks/use-toast";
import type { Bill, Dish } from "@/lib/types";
import { inr, inr2, istDateLong, istTime } from "@/lib/format";

const GST_RATE = 0.05;

type CartLine = { dish: Dish; qty: number };

// ── Billing dock — lives at the BOTTOM of the POS screen ────────────────────
function BillingDock({
  lines,
  setQty,
  removeLine,
  discount,
  setDiscount,
  onGenerate,
  generating,
  billCount,
}: {
  lines: CartLine[];
  setQty: (dishId: string, qty: number) => void;
  removeLine: (dishId: string) => void;
  discount: number;
  setDiscount: (n: number) => void;
  onGenerate: () => void;
  generating: boolean;
  billCount: number;
}) {
  const { upperName } = useHotel();
  const subtotal = lines.reduce((s, l) => s + l.dish.price * l.qty, 0);
  const disc = Math.min(discount || 0, subtotal);
  const taxable = subtotal - disc;
  const tax = Math.round(taxable * GST_RATE * 100) / 100;
  const total = taxable + tax;
  const items = lines.reduce((s, l) => s + l.qty, 0);

  return (
    <div className="space-y-3">
      {/* header row */}
      <div className="flex flex-wrap items-center gap-2.5">
        <div className="min-w-0">
          <div className="fx-label">CURRENT BILL · {upperName}</div>
          <div className="truncate text-[12.5px] font-bold text-[var(--fx-ink)]">
            Counter 01 · {istDateLong()}
          </div>
        </div>
        <span className="fx-num rounded-full bg-[var(--fx-purple)] px-3 py-1 text-[11px] font-extrabold text-white">
          {items} ITEM{items === 1 ? "" : "S"}
        </span>
        <span className="ml-auto hidden text-[10px] font-bold tracking-[0.1em] text-[var(--fx-muted)] md:block">
          {billCount > 0
            ? `${billCount} BILL${billCount === 1 ? "" : "S"} TODAY · AUTO-RECORDED`
            : "DISH · QTY · TIME AUTO-RECORDED"}
        </span>
      </div>

      {/* item chips — horizontal scroller */}
      <div className="fx-scroll -mx-1 flex gap-2 overflow-x-auto px-1 py-0.5">
        {lines.length === 0 ? (
          <p className="py-1.5 text-[12.5px] font-semibold text-[var(--fx-muted)]">
            Cart is empty — tap dishes above and they land here. The bill writes itself to the
            database.
          </p>
        ) : (
          lines.map((l) => (
            <div
              key={l.dish.id}
              className="flex shrink-0 items-center gap-2 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] py-1.5 pl-2.5 pr-2"
            >
              <VegDot veg={l.dish.veg} />
              <span className="max-w-[150px] truncate text-[12.5px] font-bold text-[var(--fx-ink)]">
                {l.dish.name}
              </span>
              <span className="flex items-center gap-1">
                <button
                  aria-label={`Decrease ${l.dish.name}`}
                  onClick={() => setQty(l.dish.id, l.qty - 1)}
                  className="grid h-6 w-6 place-items-center rounded-lg border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-ink)] hover:border-[var(--fx-purple)] hover:text-[var(--fx-purple)]"
                >
                  <Minus className="h-3 w-3" />
                </button>
                <span className="fx-num w-5 text-center text-[12.5px] font-extrabold">{l.qty}</span>
                <button
                  aria-label={`Increase ${l.dish.name}`}
                  onClick={() => setQty(l.dish.id, l.qty + 1)}
                  className="grid h-6 w-6 place-items-center rounded-lg bg-[var(--fx-purple)] text-white hover:bg-[var(--fx-purple-deep)]"
                >
                  <Plus className="h-3 w-3" />
                </button>
              </span>
              <span className="fx-num min-w-[52px] text-right text-[12px] font-extrabold text-[var(--fx-purple)]">
                {inr(l.dish.price * l.qty)}
              </span>
              <button
                aria-label={`Remove ${l.dish.name}`}
                onClick={() => removeLine(l.dish.id)}
                className="grid h-6 w-6 place-items-center rounded-lg text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-rose)]"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          ))
        )}
      </div>

      {/* totals row */}
      <div className="flex flex-wrap items-center gap-x-5 gap-y-3 border-t border-dashed border-[var(--fx-line)] pt-3">
        <div className="fx-num flex items-center gap-1.5 text-[12px] font-bold text-[var(--fx-muted)]">
          <span>SUBTOTAL</span>
          <span className="text-[var(--fx-ink)]">{inr2(subtotal)}</span>
        </div>
        <div className="fx-num flex items-center gap-1.5 text-[12px] font-bold text-[var(--fx-muted)]">
          <span>GST 5%</span>
          <span className="text-[var(--fx-ink)]">{inr2(tax)}</span>
        </div>
        <label className="fx-num flex items-center gap-1.5 text-[12px] font-bold text-[var(--fx-muted)]">
          <span>DISCOUNT ₹</span>
          <Input
            type="number"
            min={0}
            value={discount || ""}
            placeholder="0"
            onChange={(e) => setDiscount(Math.max(0, Number(e.target.value) || 0))}
            className="fx-num h-8 w-20 border-[var(--fx-line)] bg-[var(--fx-page)] text-right text-[12.5px] font-bold"
            aria-label="Discount in rupees"
          />
        </label>
        <div className="flex items-baseline gap-2">
          <span className="fx-label">TOTAL</span>
          <span className="fx-num text-xl font-extrabold text-[var(--fx-ink)]">{inr2(total)}</span>
        </div>
        <Button
          disabled={lines.length === 0 || generating}
          onClick={onGenerate}
          className="ml-auto h-12 rounded-2xl bg-[var(--fx-purple)] px-7 text-[13px] font-extrabold tracking-wide text-white shadow-[3px_4px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
        >
          {generating ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" /> SAVING BILL…
            </>
          ) : (
            <>
              <Zap className="mr-2 h-4 w-4" /> GENERATE BILL · {inr2(total)}
            </>
          )}
        </Button>
      </div>
    </div>
  );
}

// ── The POS view ───────────────────────────────────────────────────────────
export function PosView({ dishes, loading }: { dishes: Dish[]; loading: boolean }) {
  const { toast } = useToast();
  const { openReceipt } = useReceipt();
  const { hotelName, upperName } = useHotel();
  const [query, setQuery] = React.useState("");
  const [cat, setCat] = React.useState<string>("All");
  const [cart, setCart] = React.useState<Record<string, number>>({});
  const [discount, setDiscount] = React.useState(0);
  const [generating, setGenerating] = React.useState(false);
  const [billsToday, setBillsToday] = React.useState(0);
  const [recent, setRecent] = React.useState<Bill[]>([]);

  const active = React.useMemo(() => dishes.filter((d) => d.active), [dishes]);
  const cats = React.useMemo(() => ["All", ...new Set(active.map((d) => d.category))], [active]);
  const filtered = React.useMemo(
    () =>
      active.filter(
        (d) =>
          (cat === "All" || d.category === cat) &&
          d.name.toLowerCase().includes(query.trim().toLowerCase()),
      ),
    [active, cat, query],
  );
  const lines: CartLine[] = React.useMemo(
    () =>
      Object.entries(cart)
        .map(([id, qty]) => {
          const dish = active.find((d) => d.id === id);
          return dish ? { dish, qty } : null;
        })
        .filter((x): x is CartLine => x !== null),
    [cart, active],
  );

  // how many bills today (from the same auto-fed analytics the owner sees)
  React.useEffect(() => {
    fetch("/api/dashboard?range=today")
      .then((r) => r.json())
      .then((d) => setBillsToday(d?.stats?.bills ?? 0))
      .catch(() => {});
  }, [generating]);

  // the register's own feed — newest restaurant bills, tap to reprint, UNDO to tear
  const loadRecent = React.useCallback(async () => {
    try {
      const res = await fetch("/api/bills?limit=14", { cache: "no-store" });
      if (!res.ok) return;
      setRecent(await res.json());
    } catch {
      /* the feed is cosmetic — never block the counter */
    }
  }, []);
  React.useEffect(() => {
    void loadRecent();
  }, [loadRecent, generating]);

  const undoBill = async (b: Bill) => {
    try {
      const res = await fetch(`/api/bills/${b.id}`, { method: "DELETE" });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Undo failed");
      toast({
        title: `Bill #${b.number} undone`,
        description: "Removed everywhere — totals, trends & top dishes recompute instantly.",
      });
    } catch (e) {
      toast({
        title: "Undo failed",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    }
    void loadRecent();
    fetch("/api/dashboard?range=today")
      .then((r) => r.json())
      .then((d) => setBillsToday(d?.stats?.bills ?? 0))
      .catch(() => {});
  };

  const add = (id: string) => setCart((c) => ({ ...c, [id]: (c[id] ?? 0) + 1 }));
  const setQty = (id: string, qty: number) =>
    setCart((c) => {
      const next = { ...c };
      if (qty <= 0) delete next[id];
      else next[id] = qty;
      return next;
    });
  const removeLine = (id: string) =>
    setCart((c) => {
      const next = { ...c };
      delete next[id];
      return next;
    });

  const generate = async () => {
    if (lines.length === 0) return;
    setGenerating(true);
    try {
      const res = await fetch("/api/bills", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: lines.map((l) => ({ dishId: l.dish.id, qty: l.qty })),
          discount,
        }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error ?? "Bill generation failed");
      }
      const bill: Bill = await res.json();
      openReceipt(bill);
      setCart({});
      setDiscount(0);
      toast({
        title: `Bill #${bill.number} saved · ${hotelName}`,
        description: `${bill.itemCount} item(s) auto-fed to the database — no entry needed.`,
      });
    } catch (e) {
      toast({
        title: "Could not generate bill",
        description: e instanceof Error ? e.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="space-y-5">
      <TierBand
        num="02"
        eyebrow="TIER 02 · CASHIER BILLING"
        title="POS Terminal"
        sub="Tap dishes → generate the bill. Everything else — prices, totals, timestamp, database — happens by itself."
        tag={`${upperName} · PURE VEG · ${active.length} LIVE DISHES`}
      />

      {/* ── Dishes ── */}
      <div className="fx-card min-w-0 p-5">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative min-w-[220px] flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--fx-muted)]" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search dishes…"
              aria-label="Search dishes"
              className="h-11 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] pl-9 font-semibold"
            />
          </div>
          <span className="fx-label hidden md:block">{filtered.length} SHOWN</span>
        </div>

        <div className="fx-scroll mt-4 flex gap-2 overflow-x-auto pb-1">
          {cats.map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={`whitespace-nowrap rounded-full border px-4 py-2 text-[11.5px] font-extrabold tracking-wide transition ${
                cat === c
                  ? "border-[var(--fx-purple)] bg-[var(--fx-purple)] text-white shadow-[2px_2px_0_0_var(--fx-hard)]"
                  : "border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-ink)] hover:border-[var(--fx-purple)] hover:text-[var(--fx-purple)]"
              }`}
            >
              {c.toUpperCase()}
            </button>
          ))}
        </div>

        <div className="fx-scroll mt-4 max-h-[calc(100vh-500px)] min-h-[220px] overflow-y-auto pb-1 pl-1 pr-1 pt-2 xl:max-h-[calc(100vh-560px)]">
          {loading ? (
            <div className="grid place-items-center py-20 text-[var(--fx-muted)]">
              <Loader2 className="h-6 w-6 animate-spin" />
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 2xl:grid-cols-4">
              {filtered.map((d) => {
                const qty = cart[d.id] ?? 0;
                return (
                  <button
                    key={d.id}
                    onClick={() => add(d.id)}
                    className={`fx-tile group relative px-4 py-3.5 text-left ${qty > 0 ? "in-cart" : ""}`}
                  >
                    {qty > 0 && (
                      <span className="fx-num absolute -right-1.5 -top-1.5 grid h-6 min-w-6 place-items-center rounded-full bg-[var(--fx-purple)] px-1 text-[11px] font-extrabold text-white shadow-[1px_2px_0_0_var(--fx-hard)]">
                        {qty}
                      </span>
                    )}
                    <div className="flex items-start gap-2">
                      <VegDot veg={d.veg} className="mt-0.5" />
                      <span className="line-clamp-2 min-h-[32px] text-[13px] font-bold leading-snug text-[var(--fx-ink)]">
                        {d.name}
                      </span>
                    </div>
                    <div className="mt-2 flex items-center justify-between">
                      <span className="fx-num text-[14px] font-extrabold text-[var(--fx-purple)]">
                        {inr(d.price)}
                      </span>
                      {qty === 0 ? (
                        <span className="grid h-7 w-7 place-items-center rounded-lg bg-[var(--fx-lav)] text-[var(--fx-purple)] transition group-hover:bg-[var(--fx-purple)] group-hover:text-white">
                          <Plus className="h-4 w-4" />
                        </span>
                      ) : (
                        <span className="flex items-center gap-1">
                          <span
                            role="button"
                            aria-label={`Decrease ${d.name}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              setQty(d.id, qty - 1);
                            }}
                            className="grid h-7 w-7 place-items-center rounded-lg border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-ink)]"
                          >
                            <Minus className="h-3.5 w-3.5" />
                          </span>
                          <span
                            role="button"
                            aria-label={`Increase ${d.name}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              setQty(d.id, qty + 1);
                            }}
                            className="grid h-7 w-7 place-items-center rounded-lg bg-[var(--fx-purple)] text-white"
                          >
                            <Plus className="h-3.5 w-3.5" />
                          </span>
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
              {filtered.length === 0 && (
                <p className="col-span-full py-12 text-center text-sm font-semibold text-[var(--fx-muted)]">
                  No dishes match “{query}”.
                </p>
              )}
            </div>
          )}
        </div>
      </div>

      {/* ── Billing dock — pinned to the bottom while scrolling dishes ── */}
      <div className="sticky bottom-[calc(76px+env(safe-area-inset-bottom))] z-30 md:bottom-3">
        <div className="fx-card p-4 shadow-[3px_4px_0_0_var(--fx-hard)] md:p-5">
          <BillingDock
            lines={lines}
            setQty={setQty}
            removeLine={removeLine}
            discount={discount}
            setDiscount={setDiscount}
            onGenerate={generate}
            generating={generating}
            billCount={billsToday}
          />
        </div>
      </div>

      {/* ── Restaurant bills — the register's own feed, reprint + UNDO ── */}
      <div className="fx-card p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="fx-label">RESTAURANT BILLS · TAP TO REPRINT</span>
          <span className="mut-chip">{billsToday} TODAY · TAP UNDO TWICE TO TEAR ONE</span>
        </div>
        <ScrollFadeBox className="mt-3" maxH={352}>
          <BillsFeed
            rows={recent.map((b) => ({
              key: b.id,
              kind: "rest" as const,
              bill: b,
              title: `BILL #${b.number}`,
              sub: `${b.itemCount} ${b.itemCount === 1 ? "ITEM" : "ITEMS"} · ${b.items.map((i) => i.name).slice(0, 2).join(", ")}${b.items.length > 2 ? "…" : ""}`,
              amt: inr2(b.total),
              at: istTime(b.createdAt),
            }))}
            onReprint={(b) => openReceipt(b, "reprint")}
            onUndo={(r) => void undoBill(r.bill)}
          />
        </ScrollFadeBox>
      </div>
    </div>
  );
}
