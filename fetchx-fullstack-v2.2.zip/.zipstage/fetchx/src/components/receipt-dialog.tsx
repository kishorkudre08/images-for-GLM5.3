"use client";

import * as React from "react";
import { createContext, useContext } from "react";
import { createPortal } from "react-dom";
import { Download, Printer, Plus } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import type { Bill } from "@/lib/types";
import { inr2, istDateTime } from "@/lib/format";
import { HOTEL_DEFAULT, PLATFORM, hotelSlug } from "@/lib/brand";
import { useHotel } from "@/components/hotel-context";

// ── Thermal-style receipt sheet (shared by screen, print and PDF) ──────────
// Hotel name comes from the VARIABLE tenant identity (HotelProvider);
// legal/address details stay per-tenant config in brand.ts.
export function ReceiptSheet({ bill }: { bill: Bill }) {
  const { upperName } = useHotel();
  const cgst = bill.tax / 2;
  const sgst = bill.tax - bill.tax / 2;
  return (
    <div className="receipt-sheet mx-auto rounded-xl border border-[var(--fx-line)] shadow-sm">
      {/* header */}
      <div className="text-center">
        <div className="text-[16px] font-extrabold tracking-[0.14em]">{upperName}</div>
        <div className="text-[10px] font-bold tracking-[0.22em] text-[#444]">
          {HOTEL_DEFAULT.tagline}
        </div>
        <div className="mt-0.5 text-[10px] font-semibold text-[#555]">
          {HOTEL_DEFAULT.address} · {HOTEL_DEFAULT.phone}
        </div>
        <div className="text-[9.5px] font-semibold text-[#777]">
          GSTIN: {HOTEL_DEFAULT.gstin} · {HOTEL_DEFAULT.fssai}
        </div>
      </div>
      <div className="rc-sep" />
      {/* bill meta */}
      <div className="flex justify-between font-semibold">
        <span>BILL {bill.numberLabel ?? `#${bill.number}`}</span>
        <span>{istDateTime(bill.createdAt)}</span>
      </div>
      <div className="mt-0.5 flex justify-between text-[10.5px] font-semibold text-[#555]">
        <span>{HOTEL_DEFAULT.cashier}</span>
        <span>{bill.meta3 ?? "DINE-IN / TAKEAWAY"}</span>
      </div>
      {bill.meta2 && (
        <div className="mt-0.5 text-[10.5px] font-semibold text-[#555]">{bill.meta2}</div>
      )}
      <div className="rc-sep" />
      {/* items */}
      <table className="w-full">
        <thead>
          <tr className="text-left text-[9.5px] font-bold tracking-wider text-[#666]">
            <th className="pb-1 pr-1">#</th>
            <th className="pb-1">ITEM</th>
            <th className="pb-1 text-center">QTY</th>
            <th className="pb-1 text-right">RATE</th>
            <th className="pb-1 text-right">AMT</th>
          </tr>
        </thead>
        <tbody>
          {bill.items.map((it, i) => (
            <tr key={it.id} className="align-top">
              <td className="py-0.5 pr-1 text-[#888]">{i + 1}.</td>
              <td className="py-0.5 pr-2">
                {it.name}
                <span className="block text-[9.5px] text-[#999]">{it.category}</span>
              </td>
              <td className="py-0.5 text-center font-semibold">{it.qty}</td>
              <td className="py-0.5 text-right text-[#555]">{inr2(it.price)}</td>
              <td className="py-0.5 text-right font-semibold">{inr2(it.qty * it.price)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="rc-sep" />
      {/* totals with CGST/SGST split */}
      <div className="space-y-0.5 font-semibold">
        <div className="flex justify-between">
          <span>SUBTOTAL ({bill.itemCount} items)</span>
          <span>{inr2(bill.subtotal)}</span>
        </div>
        <div className="flex justify-between">
          <span>DISCOUNT</span>
          <span>− {inr2(bill.discount)}</span>
        </div>
        <div className="flex justify-between text-[#444]">
          <span>CGST @ 2.5%</span>
          <span>{inr2(cgst)}</span>
        </div>
        <div className="flex justify-between text-[#444]">
          <span>SGST @ 2.5%</span>
          <span>{inr2(sgst)}</span>
        </div>
        <div className="rc-sep" />
        <div className="flex justify-between text-[15px] font-extrabold">
          <span>GRAND TOTAL</span>
          <span>{inr2(bill.total)}</span>
        </div>
      </div>
      <div className="rc-sep" />
      {/* footer */}
      <div className="text-center text-[9.5px] font-semibold tracking-wider text-[#555]">
        TAXES AS APPLICABLE · THIS IS A COMPUTER-GENERATED BILL
        <div className="mt-1 text-[11px] font-bold tracking-[0.2em]">THANK YOU · VISIT AGAIN</div>
        <div className="mt-0.5 text-[9px] tracking-[0.18em] text-[#999]">
          {PLATFORM.receiptLine} · ZERO-ENTRY BILLING
        </div>
      </div>
    </div>
  );
}

// ── 80mm PDF export — layout computed first so height is always exact ──────
async function savePdf(bill: Bill, hotelName: string) {
  const { jsPDF } = await import("jspdf");
  const LH = 4.4; // line height, mm
  type Op =
    | { k: "c"; t: string; s?: number; b?: boolean }
    | { k: "row"; l: string; r: string; b?: boolean; s?: number; indent?: number }
    | { k: "rule" }
    | { k: "gap"; h: number };

  const cgst = bill.tax / 2;
  const sgst = bill.tax - cgst;
  const ops: Op[] = [
    { k: "c", t: hotelName.toUpperCase(), s: 12, b: true },
    { k: "c", t: HOTEL_DEFAULT.tagline, s: 6.8, b: true },
    { k: "c", t: `${HOTEL_DEFAULT.address} · ${HOTEL_DEFAULT.phone}`, s: 6.4 },
    { k: "c", t: `GSTIN: ${HOTEL_DEFAULT.gstin}`, s: 6.4 },
    { k: "rule" },
    { k: "row", l: `BILL ${bill.numberLabel ?? `#${bill.number}`}`, r: istDateTime(bill.createdAt), b: true },
    { k: "row", l: HOTEL_DEFAULT.cashier, r: bill.meta3 ?? "DINE-IN / TAKEAWAY", s: 6.6 },
    ...(bill.meta2 ? ([{ k: "row", l: bill.meta2, r: "", s: 6.6 }] as Op[]) : []),
    { k: "rule" },
    { k: "row", l: "#  ITEM", r: "QTY   RATE    AMT", b: true, s: 6.8 },
    { k: "gap", h: 1.2 },
  ];
  bill.items.forEach((it, i) => {
    ops.push({
      k: "row",
      l: `${i + 1}. ${it.name.slice(0, 18)}`,
      r: `${it.qty}  ${inr2(it.price).slice(1).padStart(6)} ${inr2(it.qty * it.price).slice(1).padStart(7)}`,
      b: true,
    });
    ops.push({ k: "row", l: `   ${it.category}`, r: "", s: 5.8 });
  });
  ops.push({ k: "rule" });
  ops.push({ k: "row", l: `SUBTOTAL (${bill.itemCount} items)`, r: inr2(bill.subtotal), b: true });
  ops.push({ k: "row", l: "DISCOUNT", r: "- " + inr2(bill.discount) });
  ops.push({ k: "row", l: "CGST @ 2.5%", r: inr2(cgst) });
  ops.push({ k: "row", l: "SGST @ 2.5%", r: inr2(sgst) });
  ops.push({ k: "rule" });
  ops.push({ k: "row", l: "GRAND TOTAL", r: inr2(bill.total), b: true, s: 10 });
  ops.push({ k: "rule" });
  ops.push({ k: "c", t: "COMPUTER-GENERATED BILL · TAXES AS APPLICABLE", s: 6 });
  ops.push({ k: "c", t: "THANK YOU · VISIT AGAIN", s: 8, b: true });
  ops.push({ k: "c", t: PLATFORM.receiptLine, s: 6 });

  const height = 10 + ops.length * LH + 6;
  const doc = new jsPDF({ unit: "mm", format: [80, height] });
  const mid = 40;
  let y = 8;

  const setFont = (size: number, bold = false) => {
    doc.setFont("courier", bold ? "bold" : "normal");
    doc.setFontSize(size);
  };
  for (const op of ops) {
    if (op.k === "c") {
      setFont(op.s ?? 8, op.b);
      doc.text(op.t, mid, y, { align: "center" });
    } else if (op.k === "row") {
      setFont(op.s ?? 8, op.b);
      doc.text(op.l.slice(0, 30), 4 + (op.indent ?? 0), y);
      if (op.r) doc.text(op.r, 76, y, { align: "right" });
    } else if (op.k === "rule") {
      doc.setLineDashPattern([1, 1], 0);
      doc.setLineWidth(0.2);
      doc.line(4, y - 1.4, 76, y - 1.4);
    } else {
      y += op.h - LH;
    }
    y += LH;
  }
  doc.save(`${hotelSlug(hotelName)}-bill-${bill.numberLabel ?? bill.number}.pdf`);
}

// ── Context: one receipt dialog + one print area shared by every view ──────
// mode "new" = just generated at the POS; "reprint" = opened from history.
type Ctx = { openReceipt: (bill: Bill, mode?: "new" | "reprint") => void };
const ReceiptCtx = createContext<Ctx>({ openReceipt: () => {} });
export const useReceipt = () => useContext(ReceiptCtx);

export function ReceiptProvider({ children }: { children: React.ReactNode }) {
  const { hotelName } = useHotel();
  const [bill, setBill] = React.useState<Bill | null>(null);
  const [open, setOpen] = React.useState(false);
  const [mounted, setMounted] = React.useState(false);
  const [mode, setMode] = React.useState<"new" | "reprint">("new");

  React.useEffect(() => setMounted(true), []);

  const openReceipt = (b: Bill, m: "new" | "reprint" = "new") => {
    setBill(b);
    setMode(m);
    setOpen(true);
  };

  return (
    <ReceiptCtx.Provider value={{ openReceipt }}>
      {children}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[92vh] overflow-y-auto border-[var(--fx-line)] bg-[var(--fx-surf)] p-6 sm:max-w-[420px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-left">
              <span className="fx-live-dot" aria-hidden />
              {mode === "reprint"
                ? (
                  <>
                    Bill {bill?.numberLabel ?? `#${bill?.number ?? "—"}`} · reprint
                  </>
                )
                : (
                  <>
                    Bill {bill?.numberLabel ?? `#${bill?.number ?? "—"}`} generated &amp; auto-saved
                  </>
                )}
            </DialogTitle>
            <DialogDescription className="text-left">
              {mode === "reprint"
                ? "Saved bill from history — reprint it or export a PDF anytime."
                : bill?.numberLabel
                  ? (
                    <>
                      The stay is written to the database — the room is now under maintenance and the
                      front desk is already updated.
                    </>
                  )
                  : (
                    <>
                      {bill?.itemCount} item(s) written to the database with dish, quantity &amp;
                      time — the dashboard is already updated.
                    </>
                  )}
            </DialogDescription>
          </DialogHeader>
          {bill && (
            <>
              <ReceiptSheet bill={bill} />
              <div className="flex flex-wrap gap-2">
                <Button
                  onClick={() => window.print()}
                  className="flex-1 rounded-xl bg-[var(--fx-purple)] text-white shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
                >
                  <Printer className="mr-1 h-4 w-4" /> Print
                </Button>
                <Button
                  onClick={() => void savePdf(bill, hotelName)}
                  variant="outline"
                  className="flex-1 rounded-xl border-[var(--fx-line)] bg-[var(--fx-surf)] shadow-[2px_3px_0_0_var(--fx-hard)]"
                >
                  <Download className="mr-1 h-4 w-4" /> PDF
                </Button>
                <Button
                  onClick={() => {
                    setOpen(false);
                    setBill(null);
                  }}
                  variant="outline"
                  className="flex-1 rounded-xl border-[var(--fx-line)] bg-[var(--fx-surf)] shadow-[2px_3px_0_0_var(--fx-hard)]"
                >
                  <Plus className="mr-1 h-4 w-4" /> New
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
      {/* Dedicated print sheet at <body> level — the ONLY thing that prints */}
      {mounted &&
        createPortal(
          bill ? (
            <div id="receipt-print" aria-hidden>
              <ReceiptSheet bill={bill} />
            </div>
          ) : (
            <div id="receipt-print" aria-hidden style={{ display: "none" }} />
          ),
          document.body,
        )}
    </ReceiptCtx.Provider>
  );
}
