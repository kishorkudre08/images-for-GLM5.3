"use client";

import * as React from "react";
import {
  Loader2,
  Plus,
  Search,
  RotateCcw,
  Users,
  UtensilsCrossed,
  LayoutGrid,
  Hotel,
  BedDouble,
  Save,
  Pencil,
  X,
  ChevronDown,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { TierBand, VegDot } from "@/components/fx";
import { useHotel } from "@/components/hotel-context";
import { useToast } from "@/hooks/use-toast";
import type { Category, Dish, Employee } from "@/lib/types";
import { LG_ROOMS, type Level } from "@/lib/lodge";
import { inr } from "@/lib/format";

export function ManagementView({
  dishes,
  loading,
  refresh,
}: {
  dishes: Dish[];
  loading: boolean;
  refresh: () => Promise<void>;
}) {
  const { toast } = useToast();
  const { hotelName, saveHotelName } = useHotel();

  // ── data ──────────────────────────────────────────────────────────────────
  const [employees, setEmployees] = React.useState<Employee[]>([]);
  const [categories, setCategories] = React.useState<Category[]>([]);
  const [opLoading, setOpLoading] = React.useState(false);
  const [confirming, setConfirming] = React.useState<string | null>(null); // two-step delete

  const loadOps = React.useCallback(async () => {
    try {
      const [e, c] = await Promise.all([
        fetch("/api/employees").then((x) => x.json()),
        fetch("/api/categories").then((x) => x.json()),
      ]);
      setEmployees(Array.isArray(e) ? e : []);
      setCategories(Array.isArray(c) ? c : []);
    } catch {
      // keep old data on failure
    }
  }, []);

  React.useEffect(() => {
    void loadOps();
  }, [loadOps]);

  const activeEmployees = employees.filter((e) => e.active);
  const monthlySalary = activeEmployees.reduce((s, e) => s + e.salary, 0);
  const activeDishes = dishes.filter((d) => d.active);

  // ── collapsible subsections (menu, rooms & hotel start folded to keep it calm) ──
  const [open, setOpen] = React.useState<Record<string, boolean>>({
    emp: true,
    menu: false,
    rooms: false,
    hotel: false,
  });
  const toggle = (k: string) => setOpen((m) => ({ ...m, [k]: !m[k] }));

  // ── ROOMS & RATES — the level categorizer (fetch + draft + live validation) ──
  const [levels, setLevels] = React.useState<Level[] | null>(null);
  const [levelsDraft, setLevelsDraft] = React.useState<Array<{ name: string; from: string; to: string; rate: string }>>([]);
  const [levelsBusy, setLevelsBusy] = React.useState(false);
  const loadLevels = React.useCallback(async () => {
    try {
      const w = await fetch("/api/lodge", { cache: "no-store" }).then((x) => x.json());
      const lv: Level[] = Array.isArray(w.levels) ? w.levels : [];
      setLevels(lv);
      setLevelsDraft(
        lv.map((l) => ({ name: l.name, from: String(l.from), to: String(l.to), rate: String(l.rate) })),
      );
    } catch {
      setLevels(null);
    }
  }, []);
  React.useEffect(() => {
    void loadLevels();
  }, [loadLevels]);

  // ── inline row editing (one row in edit mode at a time) ───────────────────
  const [editing, setEditing] = React.useState<string | null>(null);
  const [draft, setDraft] = React.useState<Record<string, Record<string, string>>>({});
  const setD = (k: string, patch: Record<string, string>) =>
    setDraft((m) => ({ ...m, [k]: { ...m[k], ...patch } }));

  const startEdit = (k: string, vals: Record<string, string>) => {
    setConfirming(null);
    setEditing(k);
    setDraft((m) => ({ ...m, [k]: vals }));
  };
  const cancelEdit = () => setEditing(null);

  // ── mutation helper ───────────────────────────────────────────────────────
  const mutate = async (
    url: string,
    method: string,
    body?: unknown,
    okMsg?: string,
    after?: () => Promise<void>,
  ): Promise<boolean> => {
    setOpLoading(true);
    try {
      const res = await fetch(url, {
        method,
        headers: body ? { "Content-Type": "application/json" } : undefined,
        body: body ? JSON.stringify(body) : undefined,
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error ?? "Request failed");
      }
      if (after) await after();
      if (okMsg) toast({ title: okMsg });
      return true;
    } catch (e) {
      toast({
        title: "Action failed",
        description: e instanceof Error ? e.message : "Unknown error",
        variant: "destructive",
      });
      return false;
    } finally {
      setOpLoading(false);
    }
  };

  // two-step delete: first click arms the button, second click executes
  const confirmBtn = (key: string, onConfirm: () => void, label = "Remove") => {
    const armed = confirming === key;
    return (
      <Button
        size="sm"
        variant="ghost"
        disabled={opLoading}
        onClick={() => {
          if (armed) {
            setConfirming(null);
            onConfirm();
          } else {
            setConfirming(key);
            setTimeout(() => setConfirming((c) => (c === key ? null : c)), 3000); // auto-disarm
          }
        }}
        className={`h-8 shrink-0 rounded-lg px-2.5 text-[10.5px] font-extrabold tracking-wider ${
          armed
            ? "bg-[var(--fx-rose)] text-white hover:bg-[var(--fx-rose)]"
            : "text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-rose)]"
        }`}
      >
        {armed ? "SURE?" : label.toUpperCase()}
      </Button>
    );
  };

  // shared row buttons: EDIT · SAVE · CANCEL · RESTORE
  const editBtn = (key: string, vals: Record<string, string>) => (
    <Button
      size="sm"
      variant="ghost"
      disabled={opLoading}
      onClick={() => startEdit(key, vals)}
      className="h-8 shrink-0 rounded-lg px-2.5 text-[10.5px] font-extrabold tracking-wider text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-purple)]"
    >
      <Pencil className="mr-1 h-3 w-3" /> EDIT
    </Button>
  );
  const saveBtn = (onSave: () => void) => (
    <Button
      size="sm"
      disabled={opLoading}
      onClick={onSave}
      className="h-8 shrink-0 rounded-lg bg-[var(--fx-purple)] px-3 text-[10.5px] font-extrabold tracking-wider text-white shadow-[2px_2px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
    >
      {opLoading ? <Loader2 className="h-3 w-3 animate-spin" /> : <><Save className="mr-1 h-3 w-3" /> SAVE</>}
    </Button>
  );
  const cancelBtn = () => (
    <Button
      size="sm"
      variant="ghost"
      onClick={cancelEdit}
      aria-label="Cancel editing"
      className="h-8 w-8 shrink-0 rounded-lg p-0 text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
    >
      <X className="h-3.5 w-3.5" />
    </Button>
  );
  const restoreBtn = (onClick: () => void) => (
    <Button
      size="sm"
      variant="ghost"
      disabled={opLoading}
      onClick={onClick}
      className="h-8 shrink-0 rounded-lg px-2.5 text-[10.5px] font-extrabold tracking-wider text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-green)]"
    >
      <RotateCcw className="mr-1 h-3 w-3" /> RESTORE
    </Button>
  );

  // collapsible numbered section shell
  const sectionHead = (
    num: string,
    icon: React.ReactNode,
    title: string,
    badge: string,
    isOpen: boolean,
  ) => (
    <span className="flex min-w-0 flex-1 flex-wrap items-center gap-2.5">
      <span className="fx-num grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-[var(--fx-purple)] text-[12px] font-black text-white shadow-[2px_3px_0_0_var(--fx-hard)]">
        {num}
      </span>
      <span className="fx-label flex items-center gap-2">
        {icon} {title}
      </span>
      <span className="fx-num ml-auto max-w-[240px] truncate rounded-full bg-[var(--fx-lav)] px-3 py-1 text-[10px] font-extrabold text-[var(--fx-muted)]">
        {badge}
      </span>
      <ChevronDown
        aria-hidden
        className={`h-4 w-4 shrink-0 text-[var(--fx-muted)] transition-transform ${isOpen ? "" : "-rotate-90"}`}
      />
    </span>
  );

  // ══ 01 · EMPLOYEE LIST ═══════════════════════════════════════════════════
  const [empName, setEmpName] = React.useState("");
  const [empRole, setEmpRole] = React.useState("");
  const [empSalary, setEmpSalary] = React.useState("");
  const [empBook, setEmpBook] = React.useState<"all" | "rest" | "lodge">("all");
  const [empNewBook, setEmpNewBook] = React.useState<"rest" | "lodge">("rest");

  const addEmployee = async () => {
    const salary = Number(empSalary);
    if (!empName.trim() || !Number.isFinite(salary) || salary <= 0) {
      toast({
        title: "Missing details",
        description: "Employee needs a name and a monthly salary above zero.",
        variant: "destructive",
      });
      return;
    }
    const ok = await mutate(
      "/api/employees",
      "POST",
      { name: empName.trim(), role: empRole.trim() || "Staff", salary, book: empNewBook },
      `${empName.trim()} joined the team`,
      loadOps,
    );
    if (ok) {
      setEmpName("");
      setEmpRole("");
      setEmpSalary("");
    }
  };

  const saveEmployee = async (emp: Employee) => {
    const d = draft[`emp:${emp.id}`] ?? {};
    const name = (d.name ?? "").trim();
    const salary = Number(d.salary);
    if (!name || !Number.isFinite(salary) || salary <= 0) {
      toast({
        title: "Missing details",
        description: "Name and a monthly salary above zero are required.",
        variant: "destructive",
      });
      return;
    }
    const ok = await mutate(
      "/api/employees",
      "PATCH",
      { id: emp.id, name, role: (d.role ?? "").trim() || emp.role, salary },
      `${name} updated`,
      loadOps,
    );
    if (ok) setEditing(null);
  };

  const empRow = (emp: Employee) => {
    const ek = `emp:${emp.id}`;
    if (editing === ek) {
      const d = draft[ek] ?? {};
      return (
        <div
          key={emp.id}
          className="flex flex-wrap items-center gap-2 rounded-xl border border-[var(--fx-purple)]/40 bg-[var(--fx-lav)] px-3 py-2"
        >
          <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-[var(--fx-purple)] text-[12px] font-black text-white">
            {emp.name.slice(0, 1).toUpperCase()}
          </span>
          <Input
            value={d.name ?? ""}
            onChange={(e) => setD(ek, { name: e.target.value })}
            placeholder="Name"
            aria-label={`Edit name of ${emp.name}`}
            className="h-9 min-w-[120px] flex-[1.2] rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] font-semibold"
          />
          <Input
            value={d.role ?? ""}
            onChange={(e) => setD(ek, { role: e.target.value })}
            placeholder="Role"
            aria-label={`Edit role of ${emp.name}`}
            className="h-9 min-w-[100px] flex-1 rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] font-semibold"
          />
          <Input
            value={d.salary ?? ""}
            onChange={(e) => setD(ek, { salary: e.target.value })}
            type="number"
            min={0}
            placeholder="₹/month"
            aria-label={`Edit monthly salary of ${emp.name}`}
            className="fx-num h-9 w-[104px] rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] font-bold"
          />
          {saveBtn(() => void saveEmployee(emp))}
          {cancelBtn()}
        </div>
      );
    }
    return (
      <div
        key={emp.id}
        className={`flex items-center gap-2.5 rounded-xl border border-[var(--fx-line)] px-3 py-2 ${
          emp.active ? "bg-[var(--fx-page)]" : "bg-[var(--fx-lav)] opacity-60"
        }`}
      >
        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-[var(--fx-lav)] text-[12px] font-black text-[var(--fx-purple)]">
          {emp.name.slice(0, 1).toUpperCase()}
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[13px] font-bold text-[var(--fx-ink)]">
            {emp.name}
          </span>
          <span className="block truncate text-[10.5px] font-semibold text-[var(--fx-muted)]">
            {emp.role}
          </span>
        </span>
        <span className="fx-num shrink-0 text-right text-[13px] font-extrabold text-[var(--fx-ink)]">
          {inr(emp.salary)}
          <span className="text-[9.5px] font-bold text-[var(--fx-muted)]">/MO</span>
        </span>
        {emp.active ? (
          <>
            {editBtn(ek, { name: emp.name, role: emp.role, salary: String(emp.salary) })}
            {confirmBtn(ek, () =>
              void mutate("/api/employees", "DELETE", undefined, `${emp.name} removed`, loadOps),
            )}
          </>
        ) : (
          restoreBtn(() =>
            void mutate("/api/employees", "PATCH", { id: emp.id, active: true }, `${emp.name} restored`, loadOps),
          )
        )}
      </div>
    );
  };

  // ══ 03 · ROOMS & RATES — the level categorizer (live-validated draft) ═════
  const setLvlAt = (i: number, patch: Partial<{ name: string; from: string; to: string; rate: string }>) =>
    setLevelsDraft((m) => m.map((r, j) => (j === i ? { ...r, ...patch } : r)));

  const levelsCheck = (): { ok: boolean; msg: string | null; bad: Set<number> } => {
    const bad = new Set<number>();
    const rows = levelsDraft.map((r) => ({
      name: r.name.trim().toUpperCase(),
      from: Math.round(Number(r.from)),
      to: Math.round(Number(r.to)),
      rate: Math.round(Number(r.rate)),
      i: 0,
    }));
    if (!rows.length) return { ok: false, msg: "Add at least one level.", bad };
    rows.forEach((r, i) => {
      r.i = i;
      if (!r.name) bad.add(i);
      if (!Number.isFinite(r.rate) || r.rate < 100) bad.add(i);
      if (!Number.isFinite(r.from) || !Number.isFinite(r.to) || r.from < 1 || r.to > LG_ROOMS || r.from > r.to)
        bad.add(i);
    });
    const sorted = [...rows].sort((a, b) => a.from - b.from);
    let msg: string | null = null;
    if (sorted.some((r) => bad.has(r.i))) {
      msg = `Fix the highlighted rows — every level needs a name, a rate of at least ₹100, and a low → high range inside 1 – ${LG_ROOMS}.`;
    } else {
      for (let j = 1; j < sorted.length; j++) {
        const prev = sorted[j - 1];
        const cur = sorted[j];
        if (cur.from <= prev.to) {
          bad.add(prev.i);
          bad.add(cur.i);
          msg = `OVERLAP — "${prev.name}" and "${cur.name}" both claim rooms ${cur.from}–${Math.min(prev.to, cur.to)}. No two levels may share a room.`;
          break;
        }
        if (cur.from > prev.to + 1) {
          bad.add(prev.i);
          bad.add(cur.i);
          msg = `GAP — rooms ${prev.to + 1}–${cur.from - 1} belong to no level. Extend "${prev.name}" or "${cur.name}" to cover them.`;
          break;
        }
      }
      if (!msg) {
        if (sorted[0].from !== 1) {
          bad.add(sorted[0].i);
          msg = `The first level must start at room 1 — it starts at ${sorted[0].from}.`;
        } else if (sorted[sorted.length - 1].to !== LG_ROOMS) {
          bad.add(sorted[sorted.length - 1].i);
          msg = `The last level must end at room ${LG_ROOMS} — it ends at ${sorted[sorted.length - 1].to}.`;
        } else {
          const names = rows.map((r) => r.name);
          if (new Set(names).size !== names.length) {
            rows.forEach((r, i) => {
              if (names.indexOf(r.name) !== i) bad.add(i);
            });
            msg = "Two levels share a name — rename one.";
          }
        }
      }
    }
    return { ok: !msg, msg, bad };
  };
  const lvCheck = levelsCheck();

  const applyLevels = async () => {
    if (!lvCheck.ok || levelsBusy) return;
    const payload = levelsDraft.map((r) => ({
      name: r.name.trim().toUpperCase(),
      from: Math.round(Number(r.from)),
      to: Math.round(Number(r.to)),
      rate: Math.round(Number(r.rate)),
    }));
    setLevelsBusy(true);
    try {
      const res = await fetch("/api/lodge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "levels-apply", levels: payload }),
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Apply failed");
      setLevels(out.levels ?? payload);
      toast({
        title: `Levels applied — ${payload.length} across ${LG_ROOMS} rooms`,
        description: "The wall, check-in picker, tooltips and the dashboard's revenue-by-level all rebuild.",
      });
    } catch (e) {
      toast({
        title: "Could not apply levels",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setLevelsBusy(false);
    }
  };

  const addLevel = () => {
    if (levelsDraft.length >= 8) {
      toast({ title: "Eight levels is plenty", description: "Split further only if the wall really needs it." });
      return;
    }
    let wi = 0;
    let w = 0;
    levelsDraft.forEach((t, i) => {
      const sz = (Number(t.to) || 0) - (Number(t.from) || 0) + 1;
      if (sz > w) {
        w = sz;
        wi = i;
      }
    });
    if (w < 2) {
      toast({ title: "Nothing left to split", description: "Every level is a single room — remove one instead." });
      return;
    }
    const t = levelsDraft[wi];
    const mid = Math.round(Number(t.from)) + Math.ceil(w / 2) - 1;
    setLevelsDraft((m) => {
      const copy = [...m];
      copy.splice(
        wi,
        1,
        { name: `${t.name} A`, from: t.from, to: String(mid), rate: t.rate },
        { name: `${t.name} B`, from: String(mid + 1), to: t.to, rate: t.rate },
      );
      return copy;
    });
    toast({ title: "Level split — apply to save", description: "Rename both halves and set their charges, then APPLY LEVELS." });
  };

  const removeLevel = (i: number) => {
    setLevelsDraft((m) => {
      const copy = [...m];
      const gone = copy.splice(i, 1)[0];
      if (copy.length) {
        if (copy[i - 1]) copy[i - 1].to = gone.to; // merge into the previous neighbour
        else copy[0].from = gone.from; // first level merges forward into the next
      }
      return copy;
    });
  };

  // ══ 02 · MENU & SECTIONS (collapsible) ═══════════════════════════════════
  const [dishName, setDishName] = React.useState("");
  const [dishPrice, setDishPrice] = React.useState("");
  const [dishCat, setDishCat] = React.useState<string>("");
  const [dishVeg, setDishVeg] = React.useState(true);
  const [newSection, setNewSection] = React.useState("");
  const [query, setQuery] = React.useState("");

  const catNames = categories.map((c) => c.name);
  const effectiveCat = dishCat || catNames[0] || "Main Course";

  const addDish = async () => {
    const price = Number(dishPrice);
    if (!dishName.trim() || !Number.isFinite(price) || price <= 0) {
      toast({
        title: "Missing details",
        description: "Dish needs a name and a price above zero.",
        variant: "destructive",
      });
      return;
    }
    const ok = await mutate(
      "/api/menu",
      "POST",
      { name: dishName.trim(), price, category: effectiveCat, veg: dishVeg },
      `${dishName.trim()} added to ${effectiveCat}`,
      async () => {
        await refresh();
        await loadOps();
      },
    );
    if (ok) {
      setDishName("");
      setDishPrice("");
    }
  };

  const addSection = async () => {
    const name = newSection.trim();
    if (!name) {
      toast({
        title: "Section name needed",
        description: "Examples: Rice, Ice Cream, Smoothies, Combos…",
        variant: "destructive",
      });
      return;
    }
    const ok = await mutate("/api/categories", "POST", { name }, `Section “${name}” created`, loadOps);
    if (ok) {
      setNewSection("");
      setDishCat(name);
    }
  };

  // Section removal — possible ONLY when no live dish is under the section
  // (dishes on the menu lock it to protect the menu). Inactive leftovers are
  // purged server-side; past bills keep their frozen snapshots.
  const removeSection = (cat: string) => {
    const live = dishes.filter((d) => d.category === cat && d.active).length;
    if (live > 0) {
      toast({
        title: "Section not empty",
        description: `“${cat}” still has ${live} dish${live === 1 ? "" : "es"} on the menu. Remove or move its dishes first.`,
        variant: "destructive",
      });
      return;
    }
    if (catNames.length <= 1) {
      toast({
        title: "Keep at least one section",
        description: "The menu needs at least one section for new dishes.",
        variant: "destructive",
      });
      return;
    }
    const catId = categories.find((c) => c.name === cat)?.id;
    if (!catId) return;
    const gone = dishes.filter((d) => d.category === cat && !d.active).length;
    void mutate(
      `/api/categories?id=${encodeURIComponent(catId)}`,
      "DELETE",
      undefined,
      gone
        ? `Section “${cat}” removed — ${gone} removed dish${gone === 1 ? "" : "es"} cleared; past bills keep their snapshots`
        : `Section “${cat}” removed — the empty section is off the menu`,
      async () => {
        await refresh();
        await loadOps();
      },
    );
  };

  // guarded REMOVE chip on every section header — locked while dishes are live
  const sectionRemoveBtn = (cat: string) => {
    const live = dishes.filter((d) => d.category === cat && d.active).length;
    const locked = live > 0;
    const armed = confirming === `section:${cat}`;
    if (catNames.length <= 1) return null; // never remove the last section
    return (
      <button
        onClick={() => {
          if (locked) {
            removeSection(cat);
            return;
          }
          if (armed) {
            setConfirming(null);
            removeSection(cat);
          } else {
            setConfirming(`section:${cat}`);
            setTimeout(() => setConfirming((c) => (c === `section:${cat}` ? null : c)), 3000);
          }
        }}
        disabled={opLoading}
        title={
          locked
            ? `“${cat}” still has ${live} dish${live === 1 ? "" : "es"} on the menu — remove or move them first`
            : "Remove this section"
        }
        aria-label={`Remove section ${cat}`}
        className={`h-8 shrink-0 rounded-lg border border-transparent px-2.5 text-[10.5px] font-extrabold tracking-wider transition ${
          armed
            ? "bg-[var(--fx-rose)] text-white"
            : locked
              ? "text-[var(--fx-muted)] opacity-40"
              : "text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-rose)]"
        }`}
      >
        {armed && !locked ? "SURE?" : "REMOVE"}
      </button>
    );
  };

  // rename + price — PATCHes the Dish by id, so dishId (and therefore the
  // whole bill/analytics history) stays attached; old bills keep their
  // frozen name/price snapshots, stats follow the new name.
  const saveDish = async (d: Dish) => {
    const dd = draft[`dish:${d.id}`] ?? {};
    const name = (dd.name ?? "").trim();
    const price = Number(dd.price);
    if (!name || !Number.isFinite(price) || price <= 0) {
      toast({
        title: "Missing details",
        description: "Dish needs a name and a price above zero.",
        variant: "destructive",
      });
      return;
    }
    const ok = await mutate(
      `/api/menu/${d.id}`,
      "PATCH",
      { name, price },
      name === d.name
        ? `${name} → ${inr(price)}`
        : `Renamed to “${name}” — all past bills & stats keep their history`,
      refresh,
    );
    if (ok) setEditing(null);
  };

  const removeDish = (d: Dish) =>
    void mutate(`/api/menu/${d.id}`, "PATCH", { active: false }, `${d.name} removed from POS`, refresh);
  const restoreDish = (d: Dish) =>
    void mutate(`/api/menu/${d.id}`, "PATCH", { active: true }, `${d.name} is live again`, refresh);

  const filteredDishes = dishes.filter((d) =>
    d.name.toLowerCase().includes(query.trim().toLowerCase()),
  );
  const groups = catNames
    .map((cat) => ({ cat, list: filteredDishes.filter((d) => d.category === cat) }))
    .filter((g) => g.list.length > 0 || !query.trim()); // keep empty sections visible
  const orphanGroups = [
    ...new Set(
      filteredDishes
        .filter((d) => !catNames.includes(d.category))
        .map((d) => d.category),
    ),
  ].map((cat) => ({ cat, list: filteredDishes.filter((d) => d.category === cat) }));

  const dishRow = (d: Dish) => {
    const dk = `dish:${d.id}`;
    if (editing === dk) {
      const dd = draft[dk] ?? {};
      return (
        <div
          key={d.id}
          className="flex flex-wrap items-center gap-2 rounded-xl border border-[var(--fx-purple)]/40 bg-[var(--fx-lav)] px-3 py-2"
        >
          <VegDot veg={d.veg} />
          <Input
            value={dd.name ?? ""}
            onChange={(e) => setD(dk, { name: e.target.value })}
            placeholder="Dish name"
            aria-label={`Edit name of ${d.name}`}
            className="h-9 min-w-[150px] flex-1 rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] font-semibold"
          />
          <Input
            value={dd.price ?? ""}
            onChange={(e) => setD(dk, { price: e.target.value })}
            type="number"
            min={0}
            placeholder="₹"
            aria-label={`Edit price of ${d.name}`}
            className="fx-num h-9 w-[104px] rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] font-bold"
          />
          {saveBtn(() => void saveDish(d))}
          {cancelBtn()}
        </div>
      );
    }
    return (
      <div
        key={d.id}
        className={`flex items-center gap-2.5 rounded-xl border border-[var(--fx-line)] px-3 py-2 ${
          d.active ? "bg-[var(--fx-page)]" : "bg-[var(--fx-lav)] opacity-60"
        }`}
      >
        <VegDot veg={d.veg} />
        <span className="min-w-0 flex-1 truncate text-[13px] font-bold text-[var(--fx-ink)]">
          {d.name}
        </span>
        <span className="fx-num shrink-0 text-[13px] font-extrabold text-[var(--fx-ink)]">
          {inr(d.price)}
        </span>
        {d.active ? (
          <>
            {editBtn(dk, { name: d.name, price: String(d.price) })}
            {confirmBtn(dk, () => removeDish(d))}
          </>
        ) : (
          restoreBtn(() => restoreDish(d))
        )}
      </div>
    );
  };

  const menuBody = (
    <>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="relative w-full max-w-[260px]">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--fx-muted)]" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search menu…"
            aria-label="Search menu"
            className="h-10 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] pl-9 font-semibold"
          />
        </div>
      </div>

      {/* add section */}
      <div className="mt-3 flex flex-wrap items-center gap-2 rounded-2xl border border-dashed border-[var(--fx-line)] bg-[var(--fx-lav)] p-3">
        <LayoutGrid className="h-4 w-4 text-[var(--fx-purple)]" />
        <span className="text-[11px] font-extrabold tracking-wider text-[var(--fx-ink)]">
          ADD SECTION
        </span>
        <Input
          value={newSection}
          onChange={(e) => setNewSection(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") void addSection();
          }}
          placeholder="New category — e.g. Rice, Ice Cream, Smoothies…"
          aria-label="New section name"
          className="h-10 min-w-[200px] flex-1 rounded-xl border-[var(--fx-line)] bg-[var(--fx-surf)] font-semibold"
        />
        <Button
          onClick={() => void addSection()}
          disabled={opLoading}
          className="h-10 rounded-xl bg-[var(--fx-purple)] px-5 text-[12px] font-extrabold text-white shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
        >
          <Plus className="mr-1 h-4 w-4" /> CREATE
        </Button>
      </div>

      {/* add dish */}
      <div className="mt-3 grid gap-2 md:grid-cols-[1.4fr_110px_1fr_auto_auto]">
        <Input
          value={dishName}
          onChange={(e) => setDishName(e.target.value)}
          placeholder="Dish name…"
          aria-label="Dish name"
          className="h-10 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-semibold"
        />
        <Input
          value={dishPrice}
          onChange={(e) => setDishPrice(e.target.value)}
          placeholder="₹ Price"
          type="number"
          min={0}
          aria-label="Price in rupees"
          className="fx-num h-10 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-bold"
        />
        <Select value={effectiveCat} onValueChange={setDishCat}>
          <SelectTrigger
            aria-label="Dish category"
            className="h-10 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-semibold"
          >
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            {catNames.map((c) => (
              <SelectItem key={c} value={c}>
                {c}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <label className="flex h-10 items-center justify-center gap-2 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-3 text-[11.5px] font-extrabold text-[var(--fx-ink)]">
          <VegDot veg={dishVeg} />
          VEG
          <Switch checked={dishVeg} onCheckedChange={setDishVeg} aria-label="Toggle vegetarian" />
        </label>
        <Button
          onClick={() => void addDish()}
          disabled={opLoading}
          className="h-10 rounded-xl bg-[var(--fx-purple)] px-5 text-[12px] font-extrabold text-white shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
        >
          {opLoading ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Plus className="mr-1 h-4 w-4" />}
          ADD DISH
        </Button>
      </div>

      {/* grouped list */}
      {loading ? (
        <div className="grid place-items-center py-16 text-[var(--fx-muted)]">
          <Loader2 className="h-6 w-6 animate-spin" />
        </div>
      ) : (
        <div className="mt-5 space-y-5">
          {[...groups, ...orphanGroups].map(({ cat, list }) => (
            <div key={cat}>
              <div className="flex items-center gap-2">
                <span className="text-[12px] font-extrabold tracking-wide text-[var(--fx-ink)]">
                  {cat.toUpperCase()}
                </span>
                <span className="fx-num rounded-full bg-[var(--fx-lav)] px-2 py-0.5 text-[10px] font-extrabold text-[var(--fx-muted)]">
                  {list.filter((d) => d.active).length}
                </span>
                <span className="h-px flex-1 border-t border-dashed border-[var(--fx-line)]" />
                {sectionRemoveBtn(cat)}
              </div>
              <div className="mt-2 space-y-1.5">
                {list.map(dishRow)}
                {list.length === 0 && (
                  <p className="rounded-xl border border-dashed border-[var(--fx-line)] px-3 py-3 text-center text-[12px] font-semibold text-[var(--fx-muted)]">
                    Empty section — add a dish here, or remove it.
                  </p>
                )}
              </div>
            </div>
          ))}
          {groups.length === 0 && orphanGroups.length === 0 && (
            <p className="py-10 text-center text-sm font-semibold text-[var(--fx-muted)]">
              No dishes match “{query}”.
            </p>
          )}
        </div>
      )}
      <p className="mt-4 text-[10.5px] font-semibold text-[var(--fx-muted)]">
        EDIT renames a dish or changes its price — the dish keeps its full sales history, and old
        bills stay exactly as printed. A section can be REMOVED only when it is empty; sections
        with dishes are locked to protect the menu.
      </p>
    </>
  );

  // ══ HOTEL PROFILE (variable tenant identity; Fetch-X brand stays fixed) ══
  const [hotelDraft, setHotelDraft] = React.useState<string | null>(null);
  const hotelValue = hotelDraft ?? hotelName;
  const hotelDirty = hotelValue.trim() !== hotelName && hotelValue.trim().length >= 2;

  const saveHotel = async () => {
    const ok = await saveHotelName(hotelValue);
    if (ok) {
      setHotelDraft(null);
      toast({ title: `Hotel renamed — every screen now says “${hotelValue.trim()}”` });
    } else {
      toast({
        title: "Could not rename",
        description: "Name needs at least 2 characters.",
        variant: "destructive",
      });
    }
  };

  const hotelBody = (
    <>
      <div className="flex flex-wrap items-center gap-2">
        <Input
          value={hotelValue}
          onChange={(e) => setHotelDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && hotelDirty) void saveHotel();
          }}
          placeholder="Hotel name…"
          aria-label="Hotel name"
          className="h-10 min-w-[220px] flex-1 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-semibold"
        />
        <Button
          onClick={() => void saveHotel()}
          disabled={opLoading || !hotelDirty}
          className="ml-auto h-10 rounded-xl bg-[var(--fx-purple)] px-4 text-[12px] font-extrabold text-white shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)] disabled:opacity-50"
        >
          {opLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          SAVE NAME
        </Button>
      </div>
      <p className="mt-2 text-[10.5px] font-semibold text-[var(--fx-muted)]">
        This name is a tenant variable — it flows onto every bill, PDF and dashboard inside your
        app. The Fetch-X platform brand never changes.
      </p>
    </>
  );

  return (
    <div className="space-y-5">
      <TierBand
        num="05"
        eyebrow="TIER 05 · RESTAURANT MANAGEMENT"
        title="Management"
        sub="Team, menu & room rates in three tidy subsections. Everything here flows into the dashboard automatically — the dashboard does every calculation by itself."
        tag={`${activeEmployees.length} EMPLOYEES · ${activeDishes.length} LIVE DISHES`}
      />

      {/* ── 01 · EMPLOYEE LIST ── */}
      <div className="fx-card overflow-hidden">
        <button
          onClick={() => toggle("emp")}
          aria-expanded={open.emp}
          className="flex w-full flex-wrap items-center gap-2.5 px-5 py-4 text-left transition hover:bg-[var(--fx-lav)]/40"
        >
          {sectionHead("01", <Users className="h-3.5 w-3.5" />, "EMPLOYEE LIST", `${activeEmployees.length} STAFF · ${inr(monthlySalary)}/MO`, open.emp)}
        </button>
        {open.emp && (
          <div className="border-t border-[var(--fx-line)] p-5">
            <div className="mb-3 flex flex-wrap items-center gap-1.5">
              {([["all", "ALL BOOKS"], ["rest", "RESTAURANT BOOK"], ["lodge", "LODGE BOOK"]] as const).map(([v, l]) => (
                <button
                  key={v}
                  onClick={() => setEmpBook(v)}
                  aria-pressed={empBook === v}
                  className={`rounded-full px-3.5 py-1.5 text-[9.5px] font-extrabold tracking-[0.09em] transition ${
                    empBook === v
                      ? "bg-[var(--fx-purple)] text-white shadow-[2px_2px_0_0_var(--fx-hard)]"
                      : "border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
                  }`}
                >
                  {l}
                </button>
              ))}
              <span className="fx-label ml-auto hidden md:inline-flex">NEW STAFF JOINS</span>
              <select
                value={empNewBook}
                onChange={(e) => setEmpNewBook(e.target.value === "lodge" ? "lodge" : "rest")}
                aria-label="Book for the new employee"
                className="h-9 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-2.5 text-[11px] font-extrabold text-[var(--fx-ink)]"
              >
                <option value="rest">RESTAURANT BOOK</option>
                <option value="lodge">LODGE BOOK</option>
              </select>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Input
                value={empName}
                onChange={(e) => setEmpName(e.target.value)}
                placeholder="Name…"
                aria-label="Employee name"
                className="h-10 min-w-[150px] flex-[1.2] rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-semibold"
              />
              <Input
                value={empRole}
                onChange={(e) => setEmpRole(e.target.value)}
                placeholder="Role e.g. Cook"
                aria-label="Employee role"
                className="h-10 min-w-[130px] flex-1 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-semibold"
              />
              <Input
                value={empSalary}
                onChange={(e) => setEmpSalary(e.target.value)}
                placeholder="₹/month"
                type="number"
                min={0}
                aria-label="Monthly salary in rupees"
                className="fx-num h-10 w-[110px] rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-bold"
              />
              <Button
                onClick={() => void addEmployee()}
                disabled={opLoading}
                className="ml-auto h-10 rounded-xl bg-[var(--fx-purple)] px-4 text-[12px] font-extrabold text-white shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
              >
                {opLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
                ADD
              </Button>
            </div>
            <div className="fx-scroll mt-3 max-h-[300px] space-y-1.5 overflow-y-auto pr-1">
              {(empBook === "all" ? employees : employees.filter((e) => e.book === empBook)).map(empRow)}
              {(empBook === "all" ? employees : employees.filter((e) => e.book === empBook)).length === 0 && (
                <p className="py-8 text-center text-[13px] font-semibold text-[var(--fx-muted)]">
                  No employees yet — add your team above.
                </p>
              )}
            </div>
            <p className="mt-2 text-[10.5px] font-semibold text-[var(--fx-muted)]">
              EDIT changes name, role or salary. Salaries flow into the dashboard automatically —
              day = ÷30, week = ÷30×7, year = ×12.
            </p>
          </div>
        )}
      </div>

      {/* ── 02 · MENU & SECTIONS (collapsed by default) ── */}
      <div className="fx-card overflow-hidden">
        <button
          onClick={() => toggle("menu")}
          aria-expanded={open.menu}
          className="flex w-full flex-wrap items-center gap-2.5 px-5 py-4 text-left transition hover:bg-[var(--fx-lav)]/40"
        >
          {sectionHead("02", <UtensilsCrossed className="h-3.5 w-3.5" />, "MENU & SECTIONS", `${activeDishes.length} DISHES · ${catNames.length} SECTIONS`, open.menu)}
        </button>
        {open.menu && <div className="border-t border-[var(--fx-line)] p-5">{menuBody}</div>}
      </div>

      {/* ── 03 · ROOMS & RATES — the level categorizer (live-validated) ── */}
      <div className="fx-card overflow-hidden">
        <button
          onClick={() => toggle("rooms")}
          aria-expanded={open.rooms}
          className="flex w-full flex-wrap items-center gap-2.5 px-5 py-4 text-left transition hover:bg-[var(--fx-lav)]/40"
        >
          {sectionHead("03", <BedDouble className="h-3.5 w-3.5" />, "ROOMS & RATES", `${LG_ROOMS} ROOMS · ${levels?.length ?? "–"} LEVELS`, open.rooms)}
        </button>
        {open.rooms && (
          <div className="border-t border-[var(--fx-line)] p-5">
            <p className="text-[10.5px] font-semibold text-[var(--fx-muted)]">
              Room levels — the categorizer for the wall. Name each level, set its room range and
              the 24-hour charge. Ranges must cover every room exactly once: start at room 1, end at
              room {LG_ROOMS}, no gaps or overlaps. ADD LEVEL splits the widest level; REMOVE merges
              a level into its neighbour.
            </p>
            <div className="mt-3 flex flex-col gap-2">
              {levelsDraft.map((t, i) => {
                const bad = lvCheck.bad.has(i);
                return (
                  <div key={i} className="flex flex-wrap items-center gap-2">
                    <span
                      className={`h-2.5 w-2.5 shrink-0 rounded-full ${
                        bad ? "bg-[var(--fx-rose)]" : i % 3 === 0 ? "bg-[var(--fx-green)]" : i % 3 === 1 ? "bg-[#f97316]" : "bg-[var(--fx-purple)]"
                      }`}
                      aria-hidden
                    />
                    <Input
                      value={t.name}
                      onChange={(e) => setLvlAt(i, { name: e.target.value })}
                      placeholder="Level name"
                      aria-label={`Level ${i + 1} name`}
                      className={`h-9 min-w-[120px] flex-[1.4] rounded-xl bg-[var(--fx-page)] font-bold ${bad ? "border-[var(--fx-rose)]" : "border-[var(--fx-line)]"}`}
                    />
                    <Input
                      value={t.from}
                      onChange={(e) => setLvlAt(i, { from: e.target.value })}
                      type="number"
                      min={1}
                      aria-label={`Level ${i + 1} first room`}
                      className={`fx-num h-9 w-[76px] rounded-xl bg-[var(--fx-page)] font-bold ${bad ? "border-[var(--fx-rose)]" : "border-[var(--fx-line)]"}`}
                    />
                    <Input
                      value={t.to}
                      onChange={(e) => setLvlAt(i, { to: e.target.value })}
                      type="number"
                      min={1}
                      aria-label={`Level ${i + 1} last room`}
                      className={`fx-num h-9 w-[76px] rounded-xl bg-[var(--fx-page)] font-bold ${bad ? "border-[var(--fx-rose)]" : "border-[var(--fx-line)]"}`}
                    />
                    <Input
                      value={t.rate}
                      onChange={(e) => setLvlAt(i, { rate: e.target.value })}
                      type="number"
                      min={0}
                      aria-label={`Level ${i + 1} charge per 24 hours`}
                      className={`fx-num h-9 w-[92px] rounded-xl bg-[var(--fx-page)] font-bold ${bad ? "border-[var(--fx-rose)]" : "border-[var(--fx-line)]"}`}
                    />
                    <span className="text-[9.5px] font-extrabold tracking-[0.08em] text-[var(--fx-muted)]">₹ / 24 H</span>
                    {levelsDraft.length > 1 &&
                      (confirming === `lvl:${i}` ? (
                        <Button
                          size="sm"
                          onClick={() => {
                            removeLevel(i);
                            setConfirming(null);
                          }}
                          className="h-9 rounded-xl bg-[var(--fx-rose)] px-3 text-[10px] font-extrabold tracking-wider text-white"
                        >
                          SURE?
                        </Button>
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setConfirming(`lvl:${i}`)}
                          title="Merge this level into its neighbour"
                          className="h-9 rounded-xl border-[var(--fx-line)] bg-[var(--fx-surf)] px-3 text-[10px] font-extrabold tracking-wider text-[var(--fx-muted)]"
                        >
                          REMOVE
                        </Button>
                      ))}
                  </div>
                );
              })}
            </div>
            {lvCheck.msg && (
              <p
                role="alert"
                className="mt-3 rounded-xl border border-[var(--fx-rose)]/40 bg-[color-mix(in_srgb,var(--fx-rose)_8%,transparent)] px-3 py-2 text-[11px] font-bold text-[var(--fx-rose)]"
              >
                {lvCheck.msg}
              </p>
            )}
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <Button
                onClick={addLevel}
                className="h-9 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-surf)] px-4 text-[11px] font-extrabold tracking-wider text-[var(--fx-ink)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-lav)]"
              >
                <Plus className="h-3.5 w-3.5" /> ADD LEVEL
              </Button>
              <Button
                onClick={() => void applyLevels()}
                disabled={!lvCheck.ok || levelsBusy}
                className="h-9 rounded-xl bg-[var(--fx-purple)] px-4 text-[11px] font-extrabold tracking-wider text-white shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)] disabled:opacity-50"
              >
                {levelsBusy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
                APPLY LEVELS
              </Button>
              {!lvCheck.ok && (
                <span className="text-[10px] font-extrabold tracking-[0.08em] text-[var(--fx-rose)]">
                  FIX THE RANGES TO ENABLE APPLY
                </span>
              )}
            </div>
            <p className="mt-3 text-[10.5px] font-semibold text-[var(--fx-muted)]">
              APPLY LEVELS pushes them live — the wall, check-in picker, tooltips and the
              dashboard's revenue-by-level all rebuild. Bills already printed keep the rate that was
              charged.
            </p>
          </div>
        )}
      </div>

      {/* ── Hotel profile — the VARIABLE identity (Fetch-X brand is fixed) ── */}
      <div className="fx-card overflow-hidden">
        <button
          onClick={() => toggle("hotel")}
          aria-expanded={open.hotel}
          className="flex w-full flex-wrap items-center gap-2.5 px-5 py-4 text-left transition hover:bg-[var(--fx-lav)]/40"
        >
          <span className="flex min-w-0 flex-1 flex-wrap items-center gap-2.5">
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-[var(--fx-lav)] text-[var(--fx-purple)]">
              <Hotel className="h-4 w-4" />
            </span>
            <span className="fx-label flex items-center gap-2">HOTEL PROFILE</span>
            <span className="fx-num ml-auto max-w-[240px] truncate rounded-full bg-[var(--fx-lav)] px-3 py-1 text-[10px] font-extrabold text-[var(--fx-muted)]">
              {hotelName.toUpperCase()}
            </span>
            <ChevronDown
              aria-hidden
              className={`h-4 w-4 shrink-0 text-[var(--fx-muted)] transition-transform ${open.hotel ? "" : "-rotate-90"}`}
            />
          </span>
        </button>
        {open.hotel && <div className="border-t border-[var(--fx-line)] p-5">{hotelBody}</div>}
      </div>
    </div>
  );
}
