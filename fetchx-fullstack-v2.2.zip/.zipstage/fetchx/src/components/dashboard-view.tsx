"use client";

/**
 * Live Dashboard — ported 1:1 from the approved demo (Tasks 30–37):
 * ALL BUSINESS shows every pair as TWO independent book blocks under ONE
 * common header (REVENUE, REVENUE TREND, ONE DAY · TWO ENGINES,
 * REVENUE BREAKDOWN, TEAM); RESTAURANT / LODGE scopes keep single blocks.
 */

import * as React from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  Banknote,
  Receipt,
  ShoppingBag,
  Flame,
  KeyRound,
  BedDouble,
  UtensilsCrossed,
  Users,
  Wallet,
  Clock,
  Hotel,
  TrendingDown,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { TierBand } from "@/components/fx";
import type { Bill, DashboardData, RangeKey } from "@/lib/types";
import { deltaChip, inr, inr2, istTime, num } from "@/lib/format";

const PURPLE = "#5b4fe9";
const GOLD = "#d9a441";

const TABS: Array<{ key: RangeKey; short: string }> = [
  { key: "today", short: "TODAY" },
  { key: "7d", short: "7 DAYS" },
  { key: "1m", short: "1 MONTH" },
  { key: "3m", short: "3 MONTHS" },
  { key: "1y", short: "1 YEAR" },
];

const PERIOD: Record<RangeKey, string> = {
  today: "TODAY",
  "7d": "LAST 7 DAYS",
  "1m": "LAST 30 DAYS",
  "3m": "LAST 3 MONTHS",
  "1y": "LAST 12 MONTHS",
};

const PREV: Record<RangeKey, string> = {
  today: "yesterday",
  "7d": "previous 7 days",
  "1m": "previous 30 days",
  "3m": "previous 90 days",
  "1y": "previous year",
};

type Scope = "all" | "rest" | "lodge";
const SCOPE_KEY = "fx-dash-scope";

/* ── micro pieces ─────────────────────────────────────────────────────────── */

function SecHead({
  icon,
  title,
  sub,
  chip,
}: {
  icon?: React.ReactNode;
  title: string;
  sub?: string;
  chip?: string;
}) {
  return (
    <div className="sec-head">
      <span className="sec-t">
        {icon}
        {title}
      </span>
      {sub ? <span className="sec-sub">{sub}</span> : null}
      <span className="hline" />
      {chip ? <span className="mut-chip">{chip}</span> : null}
    </div>
  );
}

function VTag({ kind, label }: { kind: "rest" | "lodge"; label: string }) {
  return (
    <span className={`vtag ${kind}`}>
      <i className="scope-dot" style={{ background: kind === "rest" ? PURPLE : GOLD }} />
      {label}
    </span>
  );
}

function Pk({ children, mut }: { children: React.ReactNode; mut?: boolean }) {
  return <span className={`pk-chip${mut ? " mut" : ""}`}>{children}</span>;
}

function ic(El: React.ComponentType<{ className?: string }>, cls = "h-3.5 w-3.5") {
  return <El className={cls} />;
}

/* ── charts (recharts, Fetch-X dressed) ───────────────────────────────────── */

function compactINR(v: number): string {
  if (v >= 1e7) return `₹${(v / 1e7).toFixed(1)}Cr`;
  if (v >= 1e5) return `₹${(v / 1e5).toFixed(1)}L`;
  if (v >= 1e3) {
    const k = v / 1e3;
    return `₹${k >= 10 ? Math.round(k) : Math.round(k * 10) / 10}k`;
  }
  return `₹${Math.round(v)}`;
}

function FxTip({
  active,
  payload,
  label,
  fmt,
}: {
  active?: boolean;
  payload?: Array<{ value?: number }>;
  label?: string;
  fmt?: (v: number) => string;
}) {
  if (!active || !payload || !payload.length) return null;
  const v = Number(payload[0].value ?? 0);
  return (
    <div className="chart-tip">
      <span className="ct-l">{label}</span>
      <span className="ct-v fx-num">{fmt ? fmt(v) : inr(Math.round(v))}</span>
    </div>
  );
}

function AreaTrend({
  data,
  color,
  fmt,
  tall,
}: {
  data: Array<{ label: string; value: number }>;
  color: string;
  fmt?: (v: number) => string;
  tall?: boolean;
}) {
  const id = React.useId();
  return (
    <div className={tall ? "h-[240px]" : "h-[190px]"}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 6, right: 6, left: -14, bottom: 0 }}>
          <defs>
            <linearGradient id={`g${id}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.34} />
              <stop offset="100%" stopColor={color} stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke="var(--fx-line)" strokeDasharray="3 6" vertical={false} />
          <XAxis
            dataKey="label"
            tick={{ fontSize: 9.5, fontWeight: 700, fill: "var(--fx-muted)" }}
            axisLine={false}
            tickLine={false}
            interval="preserveStartEnd"
            minTickGap={22}
          />
          <YAxis
            tick={{ fontSize: 9.5, fontWeight: 700, fill: "var(--fx-muted)" }}
            axisLine={false}
            tickLine={false}
            tickFormatter={(v: number) => compactINR(v)}
            width={54}
          />
          <Tooltip
            content={<FxTip fmt={fmt} />}
            cursor={{ stroke: color, strokeDasharray: "4 4" }}
          />
          <Area
            type="monotone"
            dataKey="value"
            stroke={color}
            strokeWidth={2.5}
            fill={`url(#g${id})`}
            dot={false}
            activeDot={{ r: 4, fill: color }}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

function LineTrend({
  data,
  color,
  fmt,
  max,
  tall,
}: {
  data: Array<{ label: string; value: number }>;
  color: string;
  fmt: (v: number) => string;
  max?: number;
  tall?: boolean;
}) {
  return (
    <div className={tall ? "h-[240px]" : "h-[190px]"}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 6, right: 6, left: -14, bottom: 0 }}>
          <CartesianGrid stroke="var(--fx-line)" strokeDasharray="3 6" vertical={false} />
          <XAxis
            dataKey="label"
            tick={{ fontSize: 9.5, fontWeight: 700, fill: "var(--fx-muted)" }}
            axisLine={false}
            tickLine={false}
            interval="preserveStartEnd"
            minTickGap={22}
          />
          <YAxis
            tick={{ fontSize: 9.5, fontWeight: 700, fill: "var(--fx-muted)" }}
            axisLine={false}
            tickLine={false}
            domain={max ? [0, max] : undefined}
            tickFormatter={(v: number) => fmt(v)}
            width={54}
          />
          <Tooltip content={<FxTip fmt={fmt} />} cursor={{ stroke: color, strokeDasharray: "4 4" }} />
          <Line
            type="monotone"
            dataKey="value"
            stroke={color}
            strokeWidth={2.5}
            dot={{ r: 2.2, fill: color, strokeWidth: 0 }}
            activeDot={{ r: 4.5 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

function Donut({
  data,
  colors,
  centerTop,
  centerLabel,
}: {
  data: Array<{ name: string; value: number }>;
  colors: string[];
  centerTop: string;
  centerLabel: string;
}) {
  // the donut hole is 124px wide — scale the figure down as it grows so a
  // ₹4,07,08,000 month never spills over the ring
  const fit =
    centerTop.length <= 8 ? 20 : centerTop.length <= 10 ? 17 : centerTop.length <= 12 ? 15 : 13;
  return (
    <div className="donut-flex">
      <div className="donut-w">
        <div className="h-[170px] w-[240px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                dataKey="value"
                innerRadius={62}
                outerRadius={84}
                paddingAngle={2}
                stroke="none"
              >
                {data.map((_, i) => (
                  <Cell key={i} fill={colors[i % colors.length]} />
                ))}
              </Pie>
              <Tooltip content={<FxTip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="donut-c">
          <div>
            <div
              className="dc-v fx-num whitespace-nowrap"
              style={{ fontSize: `${fit}px`, letterSpacing: "-0.02em" }}
            >
              {centerTop}
            </div>
            <div className="fx-label">{centerLabel}</div>
          </div>
        </div>
      </div>
      <div className="donut-legend">
        {data.map((d, i) => (
          <div className="dl-row" key={d.name}>
            <i className="scope-dot" style={{ background: colors[i % colors.length] }} />
            {d.name}
            <span className="dl-v fx-num">{inr(Math.round(d.value))}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ── stat card with optional net-profit line (the revenue duo) ────────────── */

function Stat({
  label,
  value,
  icon,
  delta,
  footnote,
  gold,
  net,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  delta?: { text: string; up: boolean } | null;
  footnote?: string;
  gold?: boolean;
  net?: string;
}) {
  return (
    <div className="fx-card fx-pop px-5 py-4">
      <div className="flex items-center justify-between gap-3">
        <span className="fx-label">{label}</span>
        <span
          className={`grid h-8 w-8 place-items-center rounded-xl ${
            gold ? "bg-[color-mix(in_srgb,var(--fx-gold)_16%,transparent)] text-[var(--fx-gold)]" : "bg-[var(--fx-lav)] text-[var(--fx-purple)]"
          }`}
        >
          {icon}
        </span>
      </div>
      <div className="d-val fx-num mt-2 text-2xl font-extrabold tracking-tight text-[var(--fx-ink)] md:text-[26px]">
        {value}
      </div>
      <div className="mt-1 h-4 text-[11px] font-semibold">
        {delta ? (
          <span className={delta.up ? "text-[var(--fx-green)]" : "text-[var(--fx-rose)]"}>{delta.text}</span>
        ) : (
          <span className="text-[var(--fx-muted)]">{footnote ?? ""}</span>
        )}
      </div>
      {net ? <div className="mt-1.5"><span className="net-mini">NET PROFIT · {net}</span></div> : null}
    </div>
  );
}

/* ── cost book card (REVENUE BREAKDOWN pair) ─────────────────────────────── */

type CostRow = { label: string; note: string; amount: number; color: string };

function BookCard({
  title,
  tag,
  kind,
  rev,
  rows,
  net,
  margin,
  note,
}: {
  title: string;
  tag: string;
  kind: "rest" | "lodge";
  rev: number;
  rows: CostRow[];
  net: number;
  margin: number | null;
  note: string;
}) {
  const mx = Math.max(1, ...rows.map((r) => r.amount));
  return (
    <div className="fx-card p-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="fx-label inline-flex items-center gap-2">
          {ic(Wallet)}
          {title}
        </span>
        <span className="flex flex-wrap items-center gap-1.5">
          <VTag kind={kind} label={tag} />
          {margin !== null ? <span className="mut-chip">{margin}% MARGIN</span> : null}
        </span>
      </div>
      <div className="bd-rows mt-4">
        <div className="bd-row">
          <div className="bd-top">
            <span className="bd-l">TOTAL REVENUE</span>
            <span className="bd-v rev fx-num">{inr(rev)}</span>
          </div>
          <div className="bd-bar">
            <i style={{ width: "100%", background: kind === "rest" ? "var(--fx-purple)" : "var(--fx-gold)" }} />
          </div>
        </div>
        {rows.map((r) => (
          <div className="bd-row" key={r.label}>
            <div className="bd-top">
              <span className="bd-l">
                {r.label}
                <span className="bd-note">{r.note}</span>
              </span>
              <span className="bd-v fx-num">− {inr(r.amount)}</span>
            </div>
            <div className="bd-bar">
              <i style={{ width: `${Math.max(4, Math.min(100, (r.amount / mx) * 100))}%`, background: r.color }} />
            </div>
          </div>
        ))}
      </div>
      <div className="bd-total">
        <span className="fx-label">NET PROFIT</span>
        <span className="bt-v fx-num" style={{ color: net >= 0 ? "var(--fx-green)" : "var(--fx-rose)" }}>
          {inr(net)}
        </span>
      </div>
      <p className="mt-2 text-[11.5px] font-medium leading-relaxed text-[var(--fx-muted)]">{note}</p>
    </div>
  );
}

/* ── roster card (TEAM pair) ─────────────────────────────────────────────── */

type Emp = { id: string; name: string; role: string; salary: number; book: "rest" | "lodge" };

function TeamCard({
  book,
  staff,
  periodCost,
}: {
  book: "rest" | "lodge";
  staff: Emp[];
  periodCost: number;
}) {
  const monthly = staff.reduce((s, e) => s + e.salary, 0);
  return (
    <div className="fx-card flex flex-col p-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="fx-label inline-flex items-center gap-2">{ic(Users)}{book === "rest" ? "RESTAURANT" : "LODGE"}</span>
        <span className="flex flex-wrap items-center gap-1.5">
          <VTag kind={book} label={book === "rest" ? "FOOD & BEV" : "ROOMS & STAYS"} />
          <span className="mut-chip">{staff.length} STAFF · {inr(monthly)}/MO</span>
        </span>
      </div>
      <div className="scrollfade mt-3">
        <div className="team-list max-h-[300px] overflow-y-auto pr-1 fx-scroll">
          {staff.length ? (
            staff.map((e) => (
              <div className="emp-row" key={e.id}>
                <span className="eav">{e.name.slice(0, 1).toUpperCase()}</span>
                <span className="e-main">
                  <span className="e-n">{e.name}</span>
                  <span className="e-r">{e.role}</span>
                </span>
                <span className="e-s fx-num">
                  {inr(e.salary)}
                  <span className="per">/MO</span>
                </span>
              </div>
            ))
          ) : (
            <p className="mt-2 text-[11.5px] text-[var(--fx-muted)]">No employees in this book yet — add them in Management.</p>
          )}
        </div>
      </div>
      <div className="bd-total" style={{ marginTop: "auto" }}>
        <span className="fx-label">TEAM COST</span>
        <span className="bt-v fx-num">{inr(periodCost)}</span>
      </div>
    </div>
  );
}

/* ── small helpers ───────────────────────────────────────────────────────── */

function fmtHrsLabel(hours: number): string {
  const mins = Math.max(0, Math.round(hours * 60));
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  let txt = h >= 24 ? `${Math.floor(h / 24)} d ${h % 24} h` : `${h} h`;
  if (m) txt += ` ${m} m`;
  return txt;
}

type Wall = {
  rooms: Array<{ number: number; status: string; guestName: string | null; checkInAt: string | null }>;
  bills: Bill[];
  levels: Array<{ from: number; to: number; rate: number; name: string }>;
  counts: { occ: number; mnt: number; avl: number };
  tonight: number;
};

/* ── the view ────────────────────────────────────────────────────────────── */

export function DashboardView({
  onRangeChange,
}: {
  onGoToPos?: () => void;
  onRangeChange: (r: RangeKey) => void;
}) {
  const [range, setRange] = React.useState<RangeKey>("today");
  const [scope, setScopeState] = React.useState<Scope>("all");
  const [data, setData] = React.useState<DashboardData | null>(null);
  const [wall, setWall] = React.useState<Wall | null>(null);
  const [failed, setFailed] = React.useState(false);

  React.useEffect(() => {
    try {
      const s = localStorage.getItem(SCOPE_KEY);
      if (s === "rest" || s === "lodge") setScopeState(s);
    } catch { /* private mode */ }
  }, []);

  const setScope = (s: Scope) => {
    setScopeState(s);
    try { localStorage.setItem(SCOPE_KEY, s); } catch { /* private mode */ }
  };

  const load = React.useCallback(async (r: RangeKey) => {
    try {
      const res = await fetch(`/api/dashboard?range=${r}`, { cache: "no-store" });
      if (!res.ok) throw new Error("bad status");
      setData(await res.json());
      setFailed(false);
    } catch {
      setFailed(true);
    }
  }, []);

  React.useEffect(() => {
    void load(range);
    onRangeChange(range);
    const t = setInterval(() => void load(range), 15000);
    return () => clearInterval(t);
  }, [range, load, onRangeChange]);

  React.useEffect(() => {
    fetch("/api/lodge", { cache: "no-store" })
      .then((r) => r.json())
      .then(setWall)
      .catch(() => { /* wall is optional on the dashboard */ });
  }, [data?.lodge.inHouse, data?.lodge.mnt]);

  const setRangeSafe = (k: RangeKey) => setRange(k);

  if (failed && !data) {
    return (
      <div className="flex flex-col gap-5">
        <TierBand num="01" eyebrow="TIER 01 · OWNER INTELLIGENCE" title="Live Dashboard" sub="Could not reach the kitchen — check the connection and retry." />
        <div className="fx-card grid place-items-center px-6 py-20 text-center">
          <div>
            <div className="fx-label">SIGNAL LOST</div>
            <Button className="mt-4 rounded-xl" onClick={() => void load(range)}>RETRY NOW</Button>
          </div>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="flex flex-col gap-5">
        <TierBand num="01" eyebrow="TIER 01 · OWNER INTELLIGENCE" title="Live Dashboard" sub="Every bill and every stay feeds this wall by itself." />
        <div className="fx-card grid place-items-center px-6 py-20 text-center">
          <div className="flex flex-col items-center gap-3">
            <span className="fx-label flex items-center gap-2"><Clock className="h-3.5 w-3.5 animate-pulse" /> LOADING FETCH-X…</span>
          </div>
        </div>
      </div>
    );
  }

  const R = data;
  const L = data.lodge;
  const staffRest = data.team.employees.filter((e) => e.book === "rest");
  const staffLodge = data.team.employees.filter((e) => e.book === "lodge");
  const revTot = data.stats.revenue + L.revenue;
  const rp = revTot > 0 ? Math.round((data.stats.revenue / revTot) * 100) : 50;
  const period = PERIOD[range];
  const inrFmt = (v: number) => inr(Math.round(v));
  const pctFmt = (v: number) => `${Math.round(v)}%`;

  const trendRest = data.buckets.map((b) => ({ label: b.label, value: b.revenue }));
  const trendLodge = L.buckets.map((b) => ({ label: b.label, value: b.revenue }));
  const hourlyRest = data.hourly.series.map((s) => ({ label: s.label, value: s.avg }));
  const dayCurve = L.dayCurve.map((c) => ({ label: c.label, value: c.pct }));

  /* scope chips row */
  const scopeRow = (
    <div className="fx-card flex flex-wrap items-center gap-2.5 p-3" role="tablist" aria-label="Business view">
      <span className="fx-label inline-flex items-center gap-1.5">{ic(Hotel, "h-3.5 w-3.5")}BUSINESS VIEW</span>
      {([
        { id: "all", label: "ALL BUSINESS", dot: `linear-gradient(90deg,${PURPLE} 50%,${GOLD} 50%)` },
        { id: "rest", label: "RESTAURANT", dot: PURPLE },
        { id: "lodge", label: "LODGE", dot: GOLD },
      ] as const).map((c) => (
        <button
          key={c.id}
          role="tab"
          aria-selected={scope === c.id}
          onClick={() => setScope(c.id)}
          className={`scope-chip${scope === c.id ? " on" : ""}`}
        >
          <i className="scope-dot" style={{ background: c.dot }} />
          {c.label}
        </button>
      ))}
      <span className="scope-spacer" />
      {scope === "all" ? (
        <>
          <span className="split-leg"><i className="scope-dot" style={{ background: PURPLE }} />RESTAURANT {rp}%</span>
          <span className="split-bar" aria-hidden>
            <i style={{ width: `${rp}%`, background: PURPLE }} />
            <i style={{ width: `${100 - rp}%`, background: GOLD }} />
          </span>
          <span className="split-leg"><i className="scope-dot" style={{ background: GOLD }} />LODGE {100 - rp}%</span>
          <span className="mut-chip">{inr(revTot)} COMBINED</span>
        </>
      ) : (
        <span className="mut-chip">{scope === "rest" ? "FOOD & BEV ONLY" : "ROOMS & STAYS ONLY"} · {period}</span>
      )}
    </div>
  );

  /* range tabs */
  const tabs = (
    <div className="fx-card inline-flex flex-wrap gap-1.5 p-1.5" role="tablist" aria-label="Dashboard time range">
      {TABS.map((t) => (
        <button
          key={t.key}
          role="tab"
          aria-selected={range === t.key}
          onClick={() => setRangeSafe(t.key)}
          className={`rounded-xl px-4 py-2.5 text-[11px] font-extrabold tracking-[0.08em] transition ${
            range === t.key
              ? "bg-[var(--fx-purple)] text-white shadow-[2px_2px_0_0_var(--fx-hard)]"
              : "text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
          }`}
        >
          {t.short}
        </button>
      ))}
    </div>
  );

  /* ── shared card builders ── */
  const restRows: CostRow[] = [
    { label: "EMPLOYEE SALARIES", note: `${staffRest.length} STAFF · PRORATED`, amount: data.books.rest.salaries, color: "var(--fx-amber)" },
    { label: "RAW MATERIALS", note: "HOTEL BOOK ENTRIES", amount: data.books.rest.rawMaterials, color: "var(--fx-teal)" },
    { label: "MAINTENANCE", note: "HOTEL BOOK ENTRIES", amount: data.books.rest.maintenance, color: "var(--fx-rose)" },
  ];
  const lodgeRows: CostRow[] = [
    { label: "EMPLOYEE SALARIES", note: `${staffLodge.length} STAFF · FRONT DESK & HOUSEKEEPING`, amount: data.books.lodge.salaries, color: "var(--fx-amber)" },
    { label: "RAW MATERIALS", note: "LODGE BOOK ENTRIES", amount: data.books.lodge.rawMaterials, color: "var(--fx-teal)" },
    { label: "MAINTENANCE", note: "LODGE BOOK ENTRIES", amount: data.books.lodge.maintenance, color: "var(--fx-rose)" },
  ];
  const marginOf = (rev: number, book: "rest" | "lodge") => {
    const b = data.books[book];
    return rev > 0 ? Math.round((b.profit / rev) * 100) : null;
  };

  return (
    <div className="flex flex-col gap-5">
      <TierBand
        num="01"
        eyebrow="TIER 01 · OWNER INTELLIGENCE"
        title="Live Dashboard"
        sub="Every bill and every stay feeds this wall by itself — restaurant and lodge on one screen, zero data entry, forever."
        live
      >
        <span className="rounded-full border border-[var(--fx-line)] bg-[var(--fx-lav)] px-4 py-2 text-[10px] font-extrabold tracking-[0.12em] text-[var(--fx-ink)]">
          <span className="fx-live-dot mr-1.5" aria-hidden />LIVE · UPDATED {istTime(new Date())}
        </span>
      </TierBand>
      {tabs}
      {scopeRow}

      {/* ══════════ ALL BUSINESS — two independent book blocks per section ══════════ */}
      {scope === "all" && (
        <>
          <section>
            <SecHead icon={ic(Banknote)} title={`REVENUE · ${period}`} sub="FOOD & BEV + ROOMS & STAYS" />
            <div className="rev-duo">
              <Stat
                label="HOTEL"
                value={inr(data.stats.revenue)}
                icon={ic(UtensilsCrossed)}
                delta={deltaChip(data.stats.revenueDeltaPct, PREV[range])}
                footnote={`FOOD & BEV · ${num(data.stats.bills)} BILLS`}
                net={inr(data.books.rest.profit)}
              />
              <Stat
                label="LODGE"
                value={inr(L.revenue)}
                icon={ic(Hotel)}
                gold
                delta={deltaChip(L.deltaPct, PREV[range])}
                footnote={`ROOMS & STAYS · ${num(L.stays)} STAYS`}
                net={inr(data.books.lodge.profit)}
              />
            </div>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
              <Stat label={`RESTAURANT BILLS · ${period}`} value={num(data.stats.bills)} icon={ic(Receipt)} delta={deltaChip(data.stats.billDeltaPct, PREV[range])} footnote={`AVG TICKET · ${inr(data.stats.avgTicket)}`} />
              <Stat label={`LODGE STAYS · ${period}`} value={num(L.stays)} icon={ic(KeyRound)} gold delta={deltaChip(L.deltaPct, PREV[range])} footnote={`AVG STAY · ${inr(L.avgStay)}`} />
              <Stat label="IN-HOUSE NOW" value={num(L.inHouse)} icon={ic(BedDouble)} gold footnote={`${L.pctFull}% FULL · ${inr(L.tonight)} / NIGHT${L.mnt ? ` · ${L.mnt} MNT` : ""}`} />
            </div>
          </section>

          <section>
            <SecHead icon={ic(Banknote)} title={`REVENUE TREND · ${period}`} sub="BOTH BOOKS · SIDE BY SIDE" />
            <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
              <div className="fx-card p-5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="fx-label">RESTAURANT</span>
                  <span className="flex flex-wrap items-center gap-1.5">
                    <VTag kind="rest" label="FOOD & BEV" />
                    {data.peakLabel ? <Pk>{ic(Flame, "h-3 w-3")}PEAK · {data.peakLabel.toUpperCase()}</Pk> : null}
                  </span>
                </div>
                <p className="mt-1 text-[11.5px] font-medium text-[var(--fx-muted)]">
                  {range === "today" ? "Today's food bills as they land — live from the POS, bill by bill." : `The restaurant's food flow across the ${period.toLowerCase()} — averaged from the POS register.`}
                </p>
                <div className="mt-2"><AreaTrend data={trendRest} color={PURPLE} tall /></div>
              </div>
              <div className="fx-card p-5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="fx-label">LODGE</span>
                  <span className="flex flex-wrap items-center gap-1.5">
                    <VTag kind="lodge" label="ROOMS & STAYS" />
                    {L.peakLabel ? <Pk>{ic(Flame, "h-3 w-3")}{range === "today" ? "PEAK HOUR" : "PEAK"} · {L.peakLabel.toUpperCase()}</Pk> : null}
                  </span>
                </div>
                <p className="mt-1 text-[11.5px] font-medium text-[var(--fx-muted)]">
                  {range === "today" ? "Stay revenue settling hour by hour — checkout-heavy late morning, a smaller evening wave." : `The lodge's stay revenue across the ${period.toLowerCase()} — billed to the hour, floor ₹1,000, 5% GST.`}
                </p>
                <div className="mt-2"><AreaTrend data={trendLodge} color={GOLD} tall /></div>
              </div>
            </div>
          </section>

          <section>
            <SecHead icon={ic(Clock)} title="ONE DAY · TWO ENGINES" sub="SAME HOURS · SEPARATE BOOKS" />
            <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
              <div className="fx-card p-5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="fx-label inline-flex items-center gap-2">{ic(Clock)}HOURLY RHYTHM · ₹ PER HOUR</span>
                  <span className="flex flex-wrap items-center gap-1.5">
                    <VTag kind="rest" label="RESTAURANT" />
                    {data.hourly.peak ? <Pk>{ic(Flame, "h-3 w-3")}PEAK · {data.hourly.peak}</Pk> : null}
                    {data.hourly.quiet ? <Pk mut>{ic(TrendingDown, "h-3 w-3")}QUIET · {data.hourly.quiet}</Pk> : null}
                  </span>
                </div>
                <p className="mt-1 text-[11.5px] font-medium text-[var(--fx-muted)]">The restaurant's day has a sharp lunch hump — the kitchen carries the afternoon, dinner runs a smaller second wave.</p>
                <div className="mt-2"><LineTrend data={hourlyRest} color={PURPLE} fmt={inrFmt} /></div>
              </div>
              <div className="fx-card p-5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="fx-label inline-flex items-center gap-2">{ic(Clock)}AVERAGE DAY · ROOMS IN HOUSE</span>
                  <span className="flex flex-wrap items-center gap-1.5">
                    <VTag kind="lodge" label="LODGE" />
                    {L.dayPeak ? <Pk>{ic(Flame, "h-3 w-3")}PEAK · {L.dayPeak.toUpperCase()}</Pk> : null}
                  </span>
                </div>
                <p className="mt-1 text-[11.5px] font-medium text-[var(--fx-muted)]">The lodge runs a gentler fill curve of its own — checkouts empty the morning, arrivals refill the evening. Same hours, separate book.</p>
                <div className="mt-2"><LineTrend data={dayCurve} color={GOLD} fmt={pctFmt} max={100} /></div>
              </div>
            </div>
          </section>

          <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
            <div className="fx-card p-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="fx-label">ITEMS SOLD · {period}</span>
                <span className="flex items-center gap-1.5"><VTag kind="rest" label="RESTAURANT" /><span className="mut-chip">{data.itemsSold.length} DISHES</span></span>
              </div>
              <div className="scrollfade mt-3">
                <div className="fx-scroll max-h-[260px] min-h-[200px] overflow-y-auto pr-1">
                  {data.itemsSold.slice(0, 12).map((d, i) => (
                    <div className="rank" key={d.name}>
                      <span className="rk-n fx-num">{String(i + 1).padStart(2, "0")}</span>
                      <div className="rk-main">
                        <div className="rk-top"><span className="rk-name">{d.name}</span><span className="rk-rev fx-num">{inr(d.revenue)}</span></div>
                        <div className="rk-bar-w"><span className="rk-bar"><i style={{ width: `${Math.max(5, Math.round((d.qty / (data.itemsSold[0]?.qty || 1)) * 100))}%` }} /></span><span className="rk-qty">{num(d.qty)} sold</span></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="fx-card p-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="fx-label inline-flex items-center gap-2">{ic(Clock)}STAY MIX · {period}</span>
                <span className="flex items-center gap-1.5"><VTag kind="lodge" label="LODGE" /><span className="mut-chip">{num(L.stays)} STAYS</span></span>
              </div>
              <div className="mt-4">
                {L.stayMix.map((m) => (
                  <div className="rank" key={m.label}>
                    <div className="rk-main">
                      <div className="rk-top"><span className="rk-name">{m.label}</span><span className="rk-rev fx-num">{m.share}%</span></div>
                      <div className="rk-bar-w"><span className="rk-bar"><i style={{ width: `${Math.max(6, m.share)}%`, background: GOLD }} /></span><span className="rk-qty">of stays</span></div>
                    </div>
                  </div>
                ))}
              </div>
              <p className="mt-3 text-[11.5px] font-medium text-[var(--fx-muted)]">Your rooms bill around the clock — short stays dominate, long stays anchor the month.</p>
            </div>
          </div>

          <div className="fx-card p-5">
            <span className="fx-label">REVENUE SPLIT · {period}</span>
            <div className="mt-3">
              <Donut
                data={[{ name: "RESTAURANT", value: data.stats.revenue }, { name: "LODGE", value: L.revenue }]}
                colors={[PURPLE, GOLD]}
                centerTop={inr(revTot)}
                centerLabel="COMBINED"
              />
            </div>
          </div>

          <section>
            <SecHead icon={ic(Wallet)} title={`REVENUE BREAKDOWN · ${period}`} sub="COSTS & NET · PER BOOK" />
            <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
              <BookCard title="RESTAURANT BOOK" tag="FOOD & BEV" kind="rest" rev={data.stats.revenue} rows={restRows} net={data.books.rest.profit} margin={marginOf(data.stats.revenue, "rest")} note="The kitchen's own ledger — food revenue minus this book's salaries, ingredients and upkeep." />
              <BookCard title="LODGE BOOK" tag="ROOMS & STAYS" kind="lodge" rev={L.revenue} rows={lodgeRows} net={data.books.lodge.profit} margin={marginOf(L.revenue, "lodge")} note="The rooms' own ledger — stay revenue minus front-desk salaries, supplies and repairs." />
            </div>
          </section>

          <section>
            <SecHead icon={ic(Users)} title={`TEAM · ${data.team.employees.length} EMPLOYEES`} sub="TWO BOOKS · SEPARATE ROSTERS" chip={`${inr(data.team.monthlyTotal)} / MO COMBINED`} />
            <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
              <TeamCard book="rest" staff={staffRest} periodCost={data.books.rest.salaries} />
              <TeamCard book="lodge" staff={staffLodge} periodCost={data.books.lodge.salaries} />
            </div>
          </section>
        </>
      )}

      {/* ══════════ RESTAURANT scope — single blocks ══════════ */}
      {scope === "rest" && (
        <>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
            <Stat label={`REVENUE · ${period}`} value={inr(data.stats.revenue)} icon={ic(Banknote)} delta={deltaChip(data.stats.revenueDeltaPct, PREV[range])} footnote="vs previous period" net={inr(data.books.rest.profit)} />
            <Stat label={`BILLS · ${period}`} value={num(data.stats.bills)} icon={ic(Receipt)} delta={deltaChip(data.stats.billDeltaPct, PREV[range])} footnote="counting every generated bill" />
            <Stat label="AVG TICKET" value={inr(data.stats.avgTicket)} icon={ic(UtensilsCrossed)} footnote="revenue ÷ bills" />
            <Stat label={`ITEMS SOLD · ${period}`} value={num(data.stats.items)} icon={ic(ShoppingBag)} footnote={data.stats.discounts > 0 ? `DISCOUNTS GIVEN · ${inr(data.stats.discounts)}` : `LIFETIME · ${inr(data.allTime.revenue)} / ${num(data.allTime.bills)} BILLS`} />
          </div>
          <div className="fx-card p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="fx-label">{range === "today" ? "SALES CURVE · TODAY (IST)" : `REVENUE · ${period}`}</span>
              <span className="flex items-center gap-1.5"><VTag kind="rest" label="RESTAURANT" />{data.peakLabel ? <Pk>{ic(Flame, "h-3 w-3")}{range === "today" ? "PEAK HOUR" : "PEAK"} · {data.peakLabel.toUpperCase()}</Pk> : null}</span>
            </div>
            <div className="mt-2"><AreaTrend data={trendRest} color={PURPLE} tall /></div>
          </div>
          <div className="fx-card p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="fx-label inline-flex items-center gap-2">{ic(Clock)}HOURLY RHYTHM · AVG REVENUE PER HOUR</span>
              <span className="flex flex-wrap items-center gap-1.5">
                {data.hourly.peak ? <Pk>{ic(Flame, "h-3 w-3")}PEAK · {data.hourly.peak}</Pk> : null}
                {data.hourly.quiet ? <Pk mut>{ic(TrendingDown, "h-3 w-3")}QUIET · {data.hourly.quiet}</Pk> : null}
              </span>
            </div>
            <div className="mt-2"><LineTrend data={hourlyRest} color={PURPLE} fmt={inrFmt} /></div>
          </div>
          <div className="fx-card p-5">
            <span className="fx-label">CATEGORY MIX · {period}</span>
            <div className="mt-3">
              <Donut
                data={data.categoryMix.slice(0, 5).map((c) => ({ name: c.category.toUpperCase(), value: c.revenue }))}
                colors={[PURPLE, "#f59e0b", "#0d9488", "#e11d48", "#8a7cf6"]}
                centerTop={inr(data.stats.revenue)}
                centerLabel="FOOD & BEV"
              />
            </div>
          </div>
          <BookCard title={`REVENUE BREAKDOWN · ${period}`} tag="RESTAURANT" kind="rest" rev={data.stats.revenue} rows={restRows} net={data.books.rest.profit} margin={marginOf(data.stats.revenue, "rest")} note="The lodge keeps its own cost book — open ALL BUSINESS for the rooms' ledger side by side with this one." />
          <div className="fx-card p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="fx-label inline-flex items-center gap-2">{ic(Users)}RESTAURANT TEAM · {staffRest.length} EMPLOYEES</span>
              <span className="mut-chip">{inr(staffRest.reduce((s, e) => s + e.salary, 0))} / MONTH</span>
            </div>
            <div className="mt-3"><TeamCard book="rest" staff={staffRest} periodCost={data.books.rest.salaries} /></div>
          </div>
        </>
      )}

      {/* ══════════ LODGE scope — single blocks ══════════ */}
      {scope === "lodge" && (
        <>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
            <Stat label={`LODGE REVENUE · ${period}`} value={inr(L.revenue)} icon={ic(Hotel)} gold delta={deltaChip(L.deltaPct, PREV[range])} footnote="ROOMS & STAYS · HOURLY BILLING" net={inr(data.books.lodge.profit)} />
            <Stat label={`STAYS · ${period}`} value={num(L.stays)} icon={ic(KeyRound)} gold delta={deltaChip(L.deltaPct, PREV[range])} footnote="CHECKOUTS THAT BILLED" />
            <Stat label="AVG STAY VALUE" value={inr(L.avgStay)} icon={ic(Banknote)} gold footnote="REVENUE ÷ STAYS" />
            <Stat label="OCCUPANCY NOW" value={`${L.pctFull}%`} icon={ic(BedDouble)} gold footnote={`${L.inHouse} OF 100 ROOMS IN HOUSE${L.mnt ? ` · ${L.mnt} UNDER MAINTENANCE` : ""}`} />
          </div>
          <div className="fx-card p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="fx-label">{range === "today" ? "OCCUPANCY THROUGH THE DAY · TODAY" : `LODGE REVENUE · ${period}`}</span>
              <span className="flex items-center gap-1.5"><VTag kind="lodge" label="LODGE" />{range === "today" ? L.dayPeak ? <Pk>{ic(Flame, "h-3 w-3")}PEAK · {L.dayPeak.toUpperCase()}</Pk> : null : L.peakLabel ? <Pk>{ic(Flame, "h-3 w-3")}PEAK · {L.peakLabel.toUpperCase()}</Pk> : null}</span>
            </div>
            <p className="mt-1 text-[11.5px] font-medium text-[var(--fx-muted)]">
              {range === "today" ? "Rooms in house, hour by hour — checkout hour empties the wall, the evening wave refills it." : `Stay revenue across the ${period.toLowerCase()} — billed to the hour, floor ₹1,000, 5% GST.`}
            </p>
            <div className="mt-2">
              {range === "today"
                ? <LineTrend data={dayCurve} color={GOLD} fmt={pctFmt} max={100} />
                : <AreaTrend data={trendLodge} color={GOLD} tall />}
            </div>
          </div>
          <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
            <div className="fx-card p-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="fx-label inline-flex items-center gap-2">{ic(Clock)}STAY MIX · {period}</span>
                <span className="flex items-center gap-1.5"><span className="mut-chip">{num(L.stays)} STAYS</span></span>
              </div>
              <div className="mt-4">
                {L.stayMix.map((m) => (
                  <div className="rank" key={m.label}>
                    <div className="rk-main">
                      <div className="rk-top"><span className="rk-name">{m.label}</span><span className="rk-rev fx-num">{m.share}%</span></div>
                      <div className="rk-bar-w"><span className="rk-bar"><i style={{ width: `${Math.max(6, m.share)}%`, background: GOLD }} /></span><span className="rk-qty">of stays</span></div>
                    </div>
                  </div>
                ))}
              </div>
              <p className="mt-3 text-[11.5px] font-medium text-[var(--fx-muted)]">Most guests stay under a day — hourly billing keeps short stays honest, the ₹1,000 floor keeps them fair.</p>
            </div>
            <div className="fx-card p-5">
              <span className="fx-label">GUESTS IN HOUSE · LIVE</span>
              <div className="scrollfade mt-3">
                <div className="team-list fx-scroll max-h-[300px] overflow-y-auto pr-1">
                  {(wall?.rooms ?? []).filter((r) => r.status === "occ" && r.guestName).slice(0, 40).map((r) => (
                    <div className="emp-row" key={r.number}>
                      <span className="eav">{r.guestName?.slice(0, 1).toUpperCase()}</span>
                      <span className="e-main">
                        <span className="e-n">{r.guestName}</span>
                        <span className="e-r">ROOM {r.number} · {levelNameOf(wall, r.number)} · IN FOR {fmtHrsLabel(hoursSince(r.checkInAt))}</span>
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
          <div className="fx-card p-5">
            <span className="fx-label">REVENUE BY LEVEL · {period}</span>
            <div className="mt-3">
              <Donut
                data={L.tierMix.map((t) => ({ name: t.tier, value: t.revenue }))}
                colors={[GOLD, PURPLE, "#0d9488"]}
                centerTop={inr(L.revenue)}
                centerLabel="ROOMS & STAYS"
              />
            </div>
          </div>
          <BookCard title={`REVENUE BREAKDOWN · LODGE`} tag="LODGE" kind="lodge" rev={L.revenue} rows={lodgeRows} net={data.books.lodge.profit} margin={marginOf(L.revenue, "lodge")} note="Stays bill as RATE × HOURS ÷ 24 — never below the ₹1,000 minimum — then 5% GST. Costs come from the lodge book in Management." />
          <div className="fx-card p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="fx-label inline-flex items-center gap-2">{ic(Users)}LODGE TEAM · {staffLodge.length} EMPLOYEES</span>
              <span className="mut-chip">{inr(staffLodge.reduce((s, e) => s + e.salary, 0))} / MONTH</span>
            </div>
            <div className="mt-3"><TeamCard book="lodge" staff={staffLodge} periodCost={data.books.lodge.salaries} /></div>
          </div>
        </>
      )}

    </div>
  );
}

function levelNameOf(wall: Wall | null, room: number): string {
  const lv = wall?.levels?.find((l) => room >= l.from && room <= l.to);
  return lv ? lv.name : "BASIC";
}

function hoursSince(iso: string | null): number {
  if (!iso) return 0;
  return (Date.now() - new Date(iso).getTime()) / 3600000;
}
