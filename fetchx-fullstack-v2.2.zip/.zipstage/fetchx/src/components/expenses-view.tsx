"use client";

import * as React from "react";
import {
  BedDouble,
  Carrot,
  Loader2,
  Pencil,
  Plus,
  Save,
  UtensilsCrossed,
  Wrench,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FxDatePicker, ScrollFadeBox, TierBand } from "@/components/fx";
import { useToast } from "@/hooks/use-toast";
import type { Expense } from "@/lib/types";
import { inr } from "@/lib/format";

const todayStr = () => new Date().toISOString().slice(0, 10);
const istDayLabel = (iso: string) =>
  new Date(iso).toLocaleDateString("en-IN", { timeZone: "Asia/Kolkata", day: "numeric", month: "short" });

type ExpenseKind = "raw_material" | "maintenance";
type Book = "rest" | "lodge";

// ── book tag chip — RESTAURANT purple / LODGE gold ──────────────────────────
function BookTag({ b }: { b: Book }) {
  return b === "lodge" ? (
    <span className="shrink-0 rounded-full bg-[color-mix(in_srgb,var(--fx-gold)_14%,transparent)] px-2.5 py-1 text-[8.5px] font-extrabold tracking-[0.09em] text-[var(--fx-gold)]">
      LODGE
    </span>
  ) : (
    <span className="shrink-0 rounded-full bg-[var(--fx-lav)] px-2.5 py-1 text-[8.5px] font-extrabold tracking-[0.09em] text-[var(--fx-purple)]">
      RESTAURANT
    </span>
  );
}

// ── per-book "this month" stat card ─────────────────────────────────────────
function BookMonthCard({ b, amount, count }: { b: Book; amount: number; count: number }) {
  return (
    <div className="fx-card px-5 py-4">
      <div className="flex items-center justify-between gap-3">
        <span className="fx-label">THIS MONTH · {b === "lodge" ? "LODGE" : "RESTAURANT"}</span>
        {b === "lodge" ? (
          <span className="grid h-8 w-8 place-items-center rounded-xl bg-[color-mix(in_srgb,var(--fx-gold)_14%,transparent)] text-[var(--fx-gold)]">
            <BedDouble className="h-4 w-4" />
          </span>
        ) : (
          <span className="grid h-8 w-8 place-items-center rounded-xl bg-[var(--fx-lav)] text-[var(--fx-purple)]">
            <UtensilsCrossed className="h-4 w-4" />
          </span>
        )}
      </div>
      <div className="fx-num mt-2 text-2xl font-extrabold tracking-tight text-[var(--fx-ink)] md:text-[26px]">
        {inr(amount)}
      </div>
      <div className="mt-1 h-4 text-[11px] font-semibold text-[var(--fx-muted)]">
        {count} {count === 1 ? "ENTRY" : "ENTRIES"} · ABSORBED BY THIS BOOK'S PROFIT
      </div>
    </div>
  );
}

export function ExpensesView() {
  const { toast } = useToast();

  // ── data ──────────────────────────────────────────────────────────────────
  const [rawCosts, setRawCosts] = React.useState<Expense[]>([]);
  const [maintCosts, setMaintCosts] = React.useState<Expense[]>([]);
  const [opLoading, setOpLoading] = React.useState(false);
  const [confirming, setConfirming] = React.useState<string | null>(null); // two-step delete

  const loadOps = React.useCallback(async () => {
    try {
      const [r, m] = await Promise.all([
        fetch("/api/expenses?kind=raw_material&limit=200").then((x) => x.json()),
        fetch("/api/expenses?kind=maintenance&limit=200").then((x) => x.json()),
      ]);
      setRawCosts(Array.isArray(r) ? r : []);
      setMaintCosts(Array.isArray(m) ? m : []);
    } catch {
      // keep old data on failure
    }
  }, []);

  React.useEffect(() => {
    void loadOps();
  }, [loadOps]);

  const monthKey = todayStr().slice(0, 7);
  const monthSum = (list: Expense[]) =>
    list.filter((x) => x.spentOn.slice(0, 7) === monthKey).reduce((s, x) => s + x.amount, 0);

  // ── THE ENTRY TOGGLE — which business the forms are entering for ──────────
  const [entryBook, setEntryBook] = React.useState<Book>("rest");

  // ── feed filter — the mixed list can show all books or just one ───────────
  const [feedBook, setFeedBook] = React.useState<"all" | Book>("all");

  // ── mutation helper ───────────────────────────────────────────────────────
  const mutate = async (
    url: string,
    method: string,
    body?: unknown,
    okMsg?: string,
    after?: () => Promise<void>,
  ): Promise<boolean> => {
    setOpLoading(true);
    try {
      const res = await fetch(url, {
        method,
        headers: body ? { "Content-Type": "application/json" } : undefined,
        body: body ? JSON.stringify(body) : undefined,
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error ?? "Request failed");
      }
      if (after) await after();
      if (okMsg) toast({ title: okMsg });
      return true;
    } catch (e) {
      toast({
        title: "Action failed",
        description: e instanceof Error ? e.message : "Unknown error",
        variant: "destructive",
      });
      return false;
    } finally {
      setOpLoading(false);
    }
  };

  // two-step delete: first click arms the button, second click executes
  const confirmBtn = (key: string, onConfirm: () => void, label = "Remove") => {
    const armed = confirming === key;
    return (
      <Button
        size="sm"
        variant="ghost"
        disabled={opLoading}
        onClick={() => {
          if (armed) {
            setConfirming(null);
            onConfirm();
          } else {
            setConfirming(key);
            setTimeout(() => setConfirming((c) => (c === key ? null : c)), 3000); // auto-disarm
          }
        }}
        className={`h-8 shrink-0 rounded-lg px-2.5 text-[10.5px] font-extrabold tracking-wider ${
          armed
            ? "bg-[var(--fx-rose)] text-white hover:bg-[var(--fx-rose)]"
            : "text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-rose)]"
        }`}
      >
        {armed ? "SURE?" : label.toUpperCase()}
      </Button>
    );
  };

  // ── inline row editing (one row in edit mode at a time) ───────────────────
  const [editing, setEditing] = React.useState<string | null>(null);
  const [draft, setDraft] = React.useState<Record<string, Record<string, string>>>({});
  const setD = (k: string, patch: Record<string, string>) =>
    setDraft((m) => ({ ...m, [k]: { ...m[k], ...patch } }));

  const startEdit = (k: string, vals: Record<string, string>) => {
    setConfirming(null);
    setEditing(k);
    setDraft((m) => ({ ...m, [k]: vals }));
  };
  const cancelEdit = () => setEditing(null);

  const editBtn = (key: string, vals: Record<string, string>) => (
    <Button
      size="sm"
      variant="ghost"
      disabled={opLoading}
      onClick={() => startEdit(key, vals)}
      className="h-8 shrink-0 rounded-lg px-2.5 text-[10.5px] font-extrabold tracking-wider text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-purple)]"
    >
      <Pencil className="mr-1 h-3 w-3" /> EDIT
    </Button>
  );
  const saveBtn = (onSave: () => void) => (
    <Button
      size="sm"
      disabled={opLoading}
      onClick={onSave}
      className="h-8 shrink-0 rounded-lg bg-[var(--fx-purple)] px-3 text-[10.5px] font-extrabold tracking-wider text-white shadow-[2px_2px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
    >
      {opLoading ? <Loader2 className="h-3 w-3 animate-spin" /> : <><Save className="mr-1 h-3 w-3" /> SAVE</>}
    </Button>
  );
  const cancelBtn = () => (
    <Button
      size="sm"
      variant="ghost"
      onClick={cancelEdit}
      aria-label="Cancel editing"
      className="h-8 w-8 shrink-0 rounded-lg p-0 text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
    >
      <X className="h-3.5 w-3.5" />
    </Button>
  );

  // ── add / save ────────────────────────────────────────────────────────────
  const [expDraft, setExpDraft] = React.useState<
    Record<"raw" | "maint", { label: string; amount: string; date: string }>
  >({
    raw: { label: "", amount: "", date: todayStr() },
    maint: { label: "", amount: "", date: todayStr() },
  });
  const setExpDraftAt = (dk: "raw" | "maint", patch: Partial<{ label: string; amount: string; date: string }>) =>
    setExpDraft((m) => ({ ...m, [dk]: { ...m[dk], ...patch } }));

  const addExpense = async (kind: ExpenseKind, label: string, amount: string, date: string) => {
    const amt = Number(amount);
    if (!Number.isFinite(amt) || amt <= 0) {
      toast({
        title: "Amount needed",
        description: "Enter the cost amount above zero.",
        variant: "destructive",
      });
      return;
    }
    const kindName = kind === "raw_material" ? "Raw material" : "Maintenance";
    const ok = await mutate(
      "/api/expenses",
      "POST",
      { kind, label: label.trim(), amount: amt, spentOn: date, book: entryBook },
      `${kindName} cost of ${inr(amt)} recorded`,
      loadOps,
    );
    if (ok)
      toast({
        title: `${kindName} cost of ${inr(amt)} recorded`,
        description: `Logged in the ${entryBook === "lodge" ? "LODGE" : "RESTAURANT"} book — that book's net profit absorbs it.`,
      });
    if (ok) setExpDraftAt(kind === "raw_material" ? "raw" : "maint", { label: "", amount: "" });
  };

  const saveExpense = async (x: Expense, xk: string) => {
    const d = draft[xk] ?? {};
    const amount = Number(d.amount);
    if (!Number.isFinite(amount) || amount <= 0) {
      toast({
        title: "Amount needed",
        description: "Amount must be above zero.",
        variant: "destructive",
      });
      return;
    }
    const ok = await mutate(
      "/api/expenses",
      "PATCH",
      {
        id: x.id,
        label: (d.label ?? "").trim(),
        amount,
        spentOn: d.date,
        ...(d.book === "rest" || d.book === "lodge" ? { book: d.book } : {}),
      },
      "Entry updated",
      loadOps,
    );
    if (ok) setEditing(null);
  };

  // one mixed ledger — both kinds, both books, newest first
  const allExpenses: Array<Expense & { kind: ExpenseKind }> = React.useMemo(
    () =>
      [
        ...rawCosts.map((x) => ({ ...x, kind: "raw_material" as ExpenseKind })),
        ...maintCosts.map((x) => ({ ...x, kind: "maintenance" as ExpenseKind })),
      ].sort((a, b) => b.spentOn.localeCompare(a.spentOn)),
    [rawCosts, maintCosts],
  );
  const expShown = feedBook === "all" ? allExpenses : allExpenses.filter((x) => x.book === feedBook);
  const monthAll = monthSum(rawCosts) + monthSum(maintCosts);
  const inMonth = (x: Expense & { kind: ExpenseKind }) => x.spentOn.slice(0, 7) === monthKey;
  const restRows = allExpenses.filter((x) => x.book === "rest");
  const lodgeRows = allExpenses.filter((x) => x.book === "lodge");
  const restMonth = restRows.filter(inMonth);
  const lodgeMonth = lodgeRows.filter(inMonth);

  return (
    <div className="space-y-5">
      <TierBand
        num="03"
        eyebrow="TIER 03 · COST LEDGER"
        title="Expenses"
        sub="Raw materials & maintenance for both businesses — enter them per book, every row stays tagged, and each book's own revenue absorbs its costs on the dashboard."
        tag={`THIS MONTH · ${inr(monthAll)}`}
      />

      {/* ── per-book month cards ── */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <BookMonthCard b="rest" amount={monthSum(restRows)} count={restMonth.length} />
        <BookMonthCard b="lodge" amount={monthSum(lodgeRows)} count={lodgeMonth.length} />
      </div>

      {/* ── ENTRY — the business toggle + the two add forms ── */}
      <div className="fx-card p-5">
        <div className="flex flex-wrap items-center gap-3">
          <span className="fx-label inline-flex items-center gap-2">ENTER EXPENSES FOR</span>
          <div className="flex flex-wrap items-center gap-1.5" role="tablist" aria-label="Business to enter expenses for">
            <button
              onClick={() => setEntryBook("rest")}
              aria-pressed={entryBook === "rest"}
              className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-[10.5px] font-extrabold tracking-[0.09em] transition ${
                entryBook === "rest"
                  ? "bg-[var(--fx-purple)] text-white shadow-[2px_2px_0_0_var(--fx-hard)]"
                  : "border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
              }`}
            >
              <UtensilsCrossed className="h-3.5 w-3.5" /> RESTAURANT
            </button>
            <button
              onClick={() => setEntryBook("lodge")}
              aria-pressed={entryBook === "lodge"}
              className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-[10.5px] font-extrabold tracking-[0.09em] transition ${
                entryBook === "lodge"
                  ? "bg-[var(--fx-gold)] text-[var(--fx-surf)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                  : "border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
              }`}
            >
              <BedDouble className="h-3.5 w-3.5" /> LODGE
            </button>
          </div>
          <span className="ml-auto text-[10px] font-bold tracking-[0.08em] text-[var(--fx-muted)]">
            BOTH FORMS BELOW LOG INTO THE{" "}
            <b className={entryBook === "lodge" ? "text-[var(--fx-gold)]" : "text-[var(--fx-purple)]"}>
              {entryBook === "lodge" ? "LODGE" : "RESTAURANT"}
            </b>{" "}
            BOOK
          </span>
        </div>

        {/* add forms — raw material + maintenance side by side */}
        <div className="mt-4 grid grid-cols-1 gap-3 xl:grid-cols-2">
          {([
            ["raw_material", "RAW MATERIAL", "What? e.g. vegetables, rice, oil…", "raw"],
            ["maintenance", "MAINTENANCE", "What? e.g. gas cylinder, repairs, pest control…", "maint"],
          ] as const).map(([kind, name, ph, dk]) => {
            const d = expDraft[dk];
            return (
              <div key={kind} className="rounded-2xl border border-dashed border-[var(--fx-line)] bg-[var(--fx-lav)]/50 p-3">
                <div className="mb-2 flex flex-wrap items-center gap-2">
                  <span
                    className={`grid h-6 w-6 place-items-center rounded-lg ${
                      kind === "raw_material"
                        ? "bg-[#0d9488]/12 text-[#0d9488]"
                        : "bg-[color-mix(in_srgb,var(--fx-amber)_14%,transparent)] text-[var(--fx-amber)]"
                    }`}
                  >
                    {kind === "raw_material" ? <Carrot className="h-3.5 w-3.5" /> : <Wrench className="h-3.5 w-3.5" />}
                  </span>
                  <span className="text-[10px] font-extrabold tracking-[0.12em] text-[var(--fx-ink)]">ADD {name}</span>
                  <span
                    className={`ml-auto rounded-full px-2.5 py-1 text-[8.5px] font-extrabold tracking-[0.09em] ${
                      entryBook === "lodge"
                        ? "bg-[color-mix(in_srgb,var(--fx-gold)_14%,transparent)] text-[var(--fx-gold)]"
                        : "bg-[var(--fx-lav)] text-[var(--fx-purple)]"
                    }`}
                  >
                    {entryBook === "lodge" ? "LODGE BOOK" : "RESTAURANT BOOK"}
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <Input
                    value={d.label}
                    onChange={(e) => setExpDraftAt(dk, { label: e.target.value })}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") void addExpense(kind, d.label, d.amount, d.date);
                    }}
                    placeholder={ph}
                    aria-label={`${name} description`}
                    className="h-9 min-w-[150px] flex-1 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-semibold"
                  />
                  <Input
                    value={d.amount}
                    onChange={(e) => setExpDraftAt(dk, { amount: e.target.value })}
                    placeholder="₹"
                    type="number"
                    min={0}
                    aria-label={`${name} amount in rupees`}
                    className="fx-num h-9 w-[96px] rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-bold"
                  />
                  <FxDatePicker value={d.date} onChange={(v) => setExpDraftAt(dk, { date: v })} ariaLabel={`${name} date`} />
                  <Button
                    onClick={() => void addExpense(kind, d.label, d.amount, d.date)}
                    disabled={opLoading}
                    className="ml-auto h-9 rounded-xl bg-[var(--fx-purple)] px-3.5 text-[11.5px] font-extrabold text-white shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
                  >
                    {opLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
                    ADD
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ── THE LEDGER — one mixed list, tagged, filterable ── */}
      <div className="fx-card p-5">
        <div className="flex flex-wrap items-center gap-2">
          <span className="fx-label inline-flex items-center gap-2">EXPENSE LEDGER · NEWEST FIRST</span>
          <div className="flex flex-wrap items-center gap-1.5">
            {([["all", "ALL BOOKS"], ["rest", "RESTAURANT"], ["lodge", "LODGE"]] as const).map(([v, l]) => (
              <button
                key={v}
                onClick={() => setFeedBook(v)}
                aria-pressed={feedBook === v}
                className={`rounded-full px-3.5 py-1.5 text-[9.5px] font-extrabold tracking-[0.09em] transition ${
                  feedBook === v
                    ? "bg-[var(--fx-purple)] text-white shadow-[2px_2px_0_0_var(--fx-hard)]"
                    : "border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
                }`}
              >
                {l}
              </button>
            ))}
          </div>
          <span className="mut-chip ml-auto">{expShown.length} ENTRIES</span>
        </div>

        <ScrollFadeBox className="mt-3" maxH={420}>
          <div className="flex flex-col gap-1.5">
            {expShown.map((x) => {
              const xk = `exp:${x.id}`;
              const kindName = x.kind === "raw_material" ? "RAW MATERIAL" : "MAINTENANCE";
              if (editing === xk) {
                const dd = draft[xk] ?? {};
                return (
                  <div
                    key={x.id}
                    className="flex flex-wrap items-center gap-2 rounded-xl border border-[var(--fx-purple)]/40 bg-[var(--fx-lav)] px-3 py-2"
                  >
                    <Input
                      value={dd.label ?? ""}
                      onChange={(e) => setD(xk, { label: e.target.value })}
                      placeholder="What?"
                      aria-label={`Edit description of ${x.label || kindName}`}
                      className="h-9 min-w-[140px] flex-1 rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] font-semibold"
                    />
                    <Input
                      value={dd.amount ?? ""}
                      onChange={(e) => setD(xk, { amount: e.target.value })}
                      type="number"
                      min={0}
                      placeholder="₹"
                      aria-label={`Edit amount of ${x.label || kindName}`}
                      className="fx-num h-9 w-[96px] rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] font-bold"
                    />
                    <FxDatePicker
                      value={dd.date ?? x.spentOn.slice(0, 10)}
                      onChange={(v) => setD(xk, { date: v })}
                      ariaLabel={`Edit date of ${x.label || kindName}`}
                    />
                    <select
                      value={dd.book ?? x.book}
                      onChange={(e) => setD(xk, { book: e.target.value === "lodge" ? "lodge" : "rest" })}
                      aria-label={`Edit book of ${x.label || kindName}`}
                      className="h-9 rounded-lg border border-[var(--fx-line)] bg-[var(--fx-surf)] px-2 text-[10.5px] font-extrabold text-[var(--fx-ink)]"
                    >
                      <option value="rest">RESTAURANT BOOK</option>
                      <option value="lodge">LODGE BOOK</option>
                    </select>
                    {saveBtn(() => void saveExpense(x, xk))}
                    {cancelBtn()}
                  </div>
                );
              }
              return (
                <div
                  key={x.id}
                  className="flex flex-wrap items-center gap-x-2.5 gap-y-1.5 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-3 py-2"
                >
                  <span
                    className={`h-2.5 w-2.5 shrink-0 rounded-full ${
                      x.kind === "raw_material" ? "bg-[#0d9488]" : "bg-[var(--fx-amber)]"
                    }`}
                    aria-hidden
                  />
                  <span className="min-w-[160px] flex-1">
                    <span className="block truncate text-[13px] font-bold text-[var(--fx-ink)]">
                      {x.label || (x.kind === "raw_material" ? "Raw material" : "Maintenance")}
                    </span>
                    <span className="text-[10.5px] font-semibold text-[var(--fx-muted)]">
                      {kindName} · {istDayLabel(x.spentOn)}
                    </span>
                  </span>
                  <BookTag b={x.book} />
                  <span className="fx-num shrink-0 text-[13px] font-extrabold text-[var(--fx-ink)]">
                    {inr(x.amount)}
                  </span>
                  <span className="ml-auto flex shrink-0 items-center gap-1 sm:ml-0">
                    {editBtn(xk, {
                      label: x.label || "",
                      amount: String(x.amount),
                      date: x.spentOn.slice(0, 10),
                      book: x.book,
                    })}
                    {confirmBtn(xk, () =>
                      void mutate(`/api/expenses?id=${x.id}`, "DELETE", undefined, "Entry deleted", loadOps),
                    )}
                  </span>
                </div>
              );
            })}
            {expShown.length === 0 && (
              <p className="py-8 text-center text-[13px] font-semibold text-[var(--fx-muted)]">
                {feedBook === "all"
                  ? "No expenses yet — pick a business above and add the first entry."
                  : feedBook === "rest"
                    ? "No restaurant-book expenses yet — switch the toggle to RESTAURANT and add one."
                    : "No lodge-book expenses yet — switch the toggle to LODGE and add one."}
              </p>
            )}
          </div>
        </ScrollFadeBox>
        <p className="mt-2 text-[10.5px] font-semibold text-[var(--fx-muted)]">
          One mixed ledger — raw materials in teal, maintenance in amber, every row tagged with its
          book. The dashboard subtracts each book's costs from that book's own revenue.
        </p>
      </div>
    </div>
  );
}
