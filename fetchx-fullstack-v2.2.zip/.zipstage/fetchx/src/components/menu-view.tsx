"use client";

import * as React from "react";
import { Loader2, Plus, Search, PowerOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { TierBand, VegDot } from "@/components/fx";
import { useToast } from "@/hooks/use-toast";
import type { Dish } from "@/lib/types";
import { CATEGORIES } from "@/lib/types";
import { inr } from "@/lib/format";

export function MenuView({
  dishes,
  loading,
  refresh,
}: {
  dishes: Dish[];
  loading: boolean;
  refresh: () => Promise<void>;
}) {
  const { toast } = useToast();
  const [query, setQuery] = React.useState("");
  const [adding, setAdding] = React.useState(false);
  const [priceEdits, setPriceEdits] = React.useState<Record<string, string>>({});

  // add form
  const [name, setName] = React.useState("");
  const [price, setPrice] = React.useState("");
  const [category, setCategory] = React.useState<string>(CATEGORIES[0]);
  const [veg, setVeg] = React.useState(true);

  const filtered = dishes.filter((d) =>
    d.name.toLowerCase().includes(query.trim().toLowerCase()),
  );
  const groups = React.useMemo(() => {
    const m = new Map<string, Dish[]>();
    for (const d of filtered) {
      const arr = m.get(d.category) ?? [];
      arr.push(d);
      m.set(d.category, arr);
    }
    return [...m.entries()];
  }, [filtered]);

  const addDish = async () => {
    const p = Number(price);
    if (!name.trim() || !Number.isFinite(p) || p <= 0) {
      toast({
        title: "Missing details",
        description: "Dish needs a name and a price above zero.",
        variant: "destructive",
      });
      return;
    }
    setAdding(true);
    try {
      const res = await fetch("/api/menu", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), price: p, category, veg }),
      });
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error ?? "Failed");
      setName("");
      setPrice("");
      await refresh();
      toast({ title: "Dish added", description: `${name.trim()} is live on the POS grid.` });
    } catch (e) {
      toast({
        title: "Could not add dish",
        description: e instanceof Error ? e.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setAdding(false);
    }
  };

  const patch = async (id: string, data: Record<string, unknown>, okMsg: string) => {
    try {
      const res = await fetch(`/api/menu/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error ?? "Failed");
      await refresh();
      toast({ title: okMsg });
    } catch (e) {
      toast({
        title: "Update failed",
        description: e instanceof Error ? e.message : "Unknown error",
        variant: "destructive",
      });
    }
  };

  const commitPrice = (d: Dish) => {
    const raw = priceEdits[d.id];
    if (raw === undefined) return;
    const p = Number(raw);
    if (!Number.isFinite(p) || p <= 0 || p === d.price) {
      setPriceEdits((m) => {
        const { [d.id]: _drop, ...rest } = m;
        return rest;
      });
      return;
    }
    void patch(d.id, { price: p }, `${d.name} → ${inr(p)}`);
    setPriceEdits((m) => {
      const { [d.id]: _drop, ...rest } = m;
      return rest;
    });
  };

  return (
    <div className="space-y-5">
      <TierBand
        num="03"
        eyebrow="TIER 03 · MENU MANAGER"
        title="Menu & Prices"
        sub="The only screen in the system where a human is allowed to type. Everything else fills itself."
        tag={`${dishes.filter((d) => d.active).length} ACTIVE · PURE VEG`}
      />

      {/* Add form */}
      <div className="fx-card p-5">
        <span className="fx-label">ADD A DISH</span>
        <div className="mt-3 grid gap-3 md:grid-cols-[1.5fr_100px_1fr_auto_auto]">
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Dish name…"
            aria-label="Dish name"
            className="h-11 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-semibold"
          />
          <Input
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            placeholder="₹ Price"
            type="number"
            min={0}
            aria-label="Price in rupees"
            className="fx-num h-11 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-bold"
          />
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger className="h-11 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-semibold">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              {CATEGORIES.map((c) => (
                <SelectItem key={c} value={c}>
                  {c}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <label className="flex h-11 items-center justify-center gap-2 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-4 text-[12px] font-extrabold text-[var(--fx-ink)]">
            <VegDot veg={veg} />
            {veg ? "VEG" : "NON-VEG"}
            <Switch checked={veg} onCheckedChange={setVeg} aria-label="Toggle vegetarian" />
          </label>
          <Button
            onClick={() => void addDish()}
            disabled={adding}
            className="h-11 rounded-xl bg-[var(--fx-purple)] px-5 text-[12.5px] font-extrabold text-white shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
          >
            {adding ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Plus className="mr-1 h-4 w-4" />}
            ADD
          </Button>
        </div>
      </div>

      {/* List */}
      <div className="fx-card p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <span className="fx-label">FULL MENU · EDIT PRICES INLINE</span>
          <div className="relative w-full max-w-[260px]">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--fx-muted)]" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search menu…"
              aria-label="Search menu"
              className="h-10 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] pl-9 font-semibold"
            />
          </div>
        </div>

        {loading ? (
          <div className="grid place-items-center py-16 text-[var(--fx-muted)]">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        ) : (
          <div className="mt-4 space-y-5">
            {groups.map(([cat, list]) => (
              <div key={cat}>
                <div className="flex items-center gap-2">
                  <span className="text-[12px] font-extrabold tracking-wide text-[var(--fx-ink)]">
                    {cat.toUpperCase()}
                  </span>
                  <span className="fx-num rounded-full bg-[var(--fx-lav)] px-2 py-0.5 text-[10px] font-extrabold text-[var(--fx-muted)]">
                    {list.length}
                  </span>
                  <span className="h-px flex-1 border-t border-dashed border-[var(--fx-line)]" />
                </div>
                <div className="mt-2 space-y-1.5">
                  {list.map((d) => (
                    <div
                      key={d.id}
                      className={`flex items-center gap-3 rounded-xl border border-[var(--fx-line)] px-3 py-2 ${
                        d.active ? "bg-[var(--fx-page)]" : "bg-[var(--fx-lav)] opacity-60"
                      }`}
                    >
                      <VegDot veg={d.veg} />
                      <span className="min-w-0 flex-1 truncate text-[13px] font-bold text-[var(--fx-ink)]">
                        {d.name}
                      </span>
                      <span className="fx-num hidden text-[11px] font-bold text-[var(--fx-muted)] sm:block">
                        PRICE {inr(d.price)}
                      </span>
                      <Input
                        value={priceEdits[d.id] ?? String(d.price)}
                        onChange={(e) => setPriceEdits((m) => ({ ...m, [d.id]: e.target.value }))}
                        onBlur={() => commitPrice(d)}
                        type="number"
                        min={0}
                        aria-label={`Price of ${d.name}`}
                        className="fx-num h-9 w-24 border-[var(--fx-line)] bg-[var(--fx-surf)] text-right text-[12.5px] font-extrabold"
                      />
                      <Switch
                        checked={d.active}
                        onCheckedChange={(v) =>
                          void patch(d.id, { active: v }, v ? `${d.name} live again` : `${d.name} hidden from POS`)
                        }
                        aria-label={`Toggle ${d.name} availability`}
                      />
                      {!d.active && (
                        <Button
                          size="icon"
                          variant="ghost"
                          title="Dish is off — reactivate with the switch"
                          className="h-8 w-8 text-[var(--fx-muted)]"
                        >
                          <PowerOff className="h-3.5 w-3.5" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
            {groups.length === 0 && (
              <p className="py-10 text-center text-sm font-semibold text-[var(--fx-muted)]">
                No dishes match “{query}”.
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
