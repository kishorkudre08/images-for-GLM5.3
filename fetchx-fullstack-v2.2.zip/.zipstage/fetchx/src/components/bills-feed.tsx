"use client";

/**
 * BillsFeed — the live-dashboard activity feed, extracted so it can live
 * wherever bills land: POS (restaurant), Lodge front desk (stays) and any
 * future surface. Every row reprints on tap and carries a two-step UNDO
 * (first tap arms SURE?, second tap tears the bill).
 */

import * as React from "react";
import { Undo2, Receipt, Hotel } from "lucide-react";
import type { Bill } from "@/lib/types";

export function feedIcon(El: React.ComponentType<{ className?: string }>, cls = "h-3.5 w-3.5") {
  return <El className={cls} />;
}

export type FeedRow = {
  key: string;
  kind: "rest" | "lodge";
  title: string;
  sub: string;
  amt: string;
  at: string;
  bill?: Bill;
};

export function BillsFeed({
  rows,
  onReprint,
  onUndo,
}: {
  rows: FeedRow[];
  onReprint: (b: Bill) => void;
  onUndo: (r: { kind: "rest" | "lodge"; bill: Bill }) => void;
}) {
  const [arm, setArm] = React.useState<string | null>(null);
  React.useEffect(() => {
    if (!arm) return;
    const t = setTimeout(() => setArm(null), 3000);
    return () => clearTimeout(t);
  }, [arm]);

  if (!rows.length) {
    return (
      <p className="text-[12px] font-medium text-[var(--fx-muted)]">
        Nothing yet — the moment a bill lands it appears here by itself.
      </p>
    );
  }
  return (
    <div className="flex flex-col gap-2">
      {rows.map((r) => (
        <div key={r.key} className={`feed-row ${r.kind}`}>
          <button
            onClick={() => r.bill && onReprint(r.bill)}
            className="f-main-btn text-left"
            title={r.bill ? "Tap to reprint" : undefined}
            disabled={!r.bill}
          >
            <span className="f-av">{feedIcon(r.kind === "rest" ? Receipt : Hotel)}</span>
            <span className="f-main">
              <span className="f-t">{r.title}</span>
              <span className="f-s">{r.sub}</span>
            </span>
          </button>
          <span className="f-side">
            <span className="block text-right">
              <span className="f-amt fx-num block">{r.amt}</span>
              <span className="block text-[9.5px] font-bold tracking-wider text-[var(--fx-muted)]">{r.at}</span>
            </span>
            {r.bill && (
              <button
                className={`f-undo ${arm === r.key ? "arm" : ""}`}
                aria-label={`Undo ${r.kind === "rest" ? "bill" : "stay"} ${r.title}`}
                onClick={() => {
                  if (arm === r.key) {
                    setArm(null);
                    onUndo({ kind: r.kind, bill: r.bill! });
                  } else {
                    setArm(r.key);
                  }
                }}
              >
                {feedIcon(Undo2, "h-3 w-3")}
                {arm === r.key ? "SURE?" : "UNDO"}
              </button>
            )}
          </span>
        </div>
      ))}
    </div>
  );
}

// Lodge stay bill → the receipt shape the reprint dialog expects.
export function lodgeBillToBill(b: {
  number: number; room: number; guestName: string; total: number; createdAt: string; hours: number;
}): Bill {
  const stay = Math.round((b.total / 1.05) * 100) / 100;
  const tax = Math.round((b.total - stay) * 100) / 100;
  return {
    id: `L${b.number}`,
    number: b.number,
    subtotal: stay,
    discount: 0,
    tax,
    total: b.total,
    itemCount: 1,
    createdAt: b.createdAt,
    numberLabel: `L-${b.number}`,
    meta2: b.guestName,
    meta3: `LODGE · ROOM ${b.room}`,
    items: [{ id: `L${b.number}`, dishId: null, name: `ROOM ${b.room} STAY`, category: `TIER · ${Math.round(b.hours)} H`, qty: 1, price: stay }],
  };
}
