import { NextResponse } from "next/server";
import { getHotelName, setHotelName } from "@/lib/settings";

export const dynamic = "force-dynamic";

// GET /api/settings — public read of tenant variables (landing needs the hotel
// name before login; nothing sensitive lives here).
export async function GET() {
  try {
    const hotelName = await getHotelName();
    return NextResponse.json({ hotelName });
  } catch {
    return NextResponse.json({ hotelName: null }, { status: 200 });
  }
}

// PATCH /api/settings — update the hotel name (Management → Hotel Profile).
export async function PATCH(req: Request) {
  try {
    const body = (await req.json()) as { hotelName?: string };
    if (typeof body.hotelName !== "string") {
      return NextResponse.json({ error: "hotelName is required." }, { status: 400 });
    }
    const hotelName = await setHotelName(body.hotelName);
    return NextResponse.json({ ok: true, hotelName });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Could not save." },
      { status: 400 },
    );
  }
}
