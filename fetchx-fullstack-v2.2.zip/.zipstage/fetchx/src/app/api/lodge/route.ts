import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { invalidateDashboardCache } from "@/lib/analytics";
import { LG_ROOMS, lgStay, parseLevels, tierOfRoom, DEFAULT_LEVELS, type Level } from "@/lib/lodge";

export const dynamic = "force-dynamic";

async function loadLevels(): Promise<Level[]> {
  const s = await db.setting.findUnique({ where: { key: "lodgeLevels" } });
  return parseLevels(s?.value) ?? DEFAULT_LEVELS;
}

// GET /api/lodge — the whole wall (100 rooms) + levels + live stats + recent bills
export async function GET() {
  const [rooms, bills, levels] = await Promise.all([
    db.room.findMany({ orderBy: { number: "asc" } }),
    db.lodgeBill.findMany({ orderBy: { number: "desc" }, take: 8 }),
    loadLevels(),
  ]);
  const occ = rooms.filter((r) => r.status === "occ");
  const mnt = rooms.filter((r) => r.status === "mnt");
  // tonight = what the guests currently in house are being billed per hour, projected to 24 h
  const tonight = occ.reduce((sum, r) => sum + tierOfRoom(r.number, levels).rate, 0);
  // stay mix — share of checkouts by duration bucket (last 90 days)
  const since = new Date(Date.now() - 90 * 86400000);
  const stays = await db.lodgeBill.findMany({
    where: { createdAt: { gte: since } },
    select: { hours: true },
  });
  const buckets = [
    { label: "UNDER 6 H", test: (h: number) => h < 6 },
    { label: "6 – 12 H", test: (h: number) => h >= 6 && h < 12 },
    { label: "12 – 24 H", test: (h: number) => h >= 12 && h < 24 },
    { label: "24 H +", test: (h: number) => h >= 24 },
  ];
  const total = stays.length || 1;
  const stayMix = buckets.map((b) => ({
    label: b.label,
    share: Math.round((stays.filter((s) => b.test(s.hours)).length / total) * 100),
  }));
  return NextResponse.json({
    rooms,
    bills,
    levels,
    counts: { occ: occ.length, mnt: mnt.length, avl: LG_ROOMS - occ.length - mnt.length },
    tonight,
    stayMix,
  });
}

type Body = {
  action?: "checkin" | "checkout" | "maintenance-done" | "levels-apply" | "bill-undo" | "reset";
  room?: number;
  name?: string;
  phone?: string;
  checkInAt?: string;
  checkOutAt?: string;
  discount?: number;
  levels?: Level[];
  number?: number;
};

// POST /api/lodge — action-based front-desk operations.
// Every path re-reads the room inside a transaction, so two cashiers can
// never check the same green room in twice.
export async function POST(req: NextRequest) {
  let body: Body;
  try {
    body = (await req.json()) as Body;
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const action = body.action;

  try {
    /* ── CHECK IN — green → gold ─────────────────────────────────────────── */
    if (action === "checkin") {
      const room = Number(body.room);
      const name = String(body.name ?? "").trim();
      const phone = String(body.phone ?? "").trim();
      if (!Number.isInteger(room) || room < 1 || room > LG_ROOMS)
        return NextResponse.json({ error: `Pick a room between 1 and ${LG_ROOMS}` }, { status: 400 });
      if (name.length < 2)
        return NextResponse.json({ error: "Enter the guest's name to check in" }, { status: 400 });
      if (phone.replace(/\D/g, "").length < 10)
        return NextResponse.json({ error: "Enter a valid 10-digit mobile number" }, { status: 400 });
      const checkInAt = body.checkInAt ? new Date(body.checkInAt) : new Date();
      if (isNaN(checkInAt.getTime()))
        return NextResponse.json({ error: "Invalid entry time" }, { status: 400 });

      const taken = await db.$transaction(async (tx) => {
        const r = await tx.room.findUnique({ where: { number: room } });
        if (!r) return "Room not found";
        if (r.status !== "avl") return `Room ${room} is no longer free — pick another green room`;
        await tx.room.update({
          where: { number: room },
          data: { status: "occ", guestName: name, guestPhone: phone, checkInAt },
        });
        return null;
      });
      if (taken) return NextResponse.json({ error: taken }, { status: 409 });
      return NextResponse.json({ ok: true });
    }

    /* ── CHECK OUT — gold → amber, bill generated ────────────────────────── */
    if (action === "checkout") {
      const room = Number(body.room);
      if (!Number.isInteger(room) || room < 1 || room > LG_ROOMS)
        return NextResponse.json({ error: "Invalid room" }, { status: 400 });
      const checkOutAt = body.checkOutAt ? new Date(body.checkOutAt) : new Date();
      if (isNaN(checkOutAt.getTime()))
        return NextResponse.json({ error: "Invalid exit time" }, { status: 400 });
      const levels = await loadLevels();

      const bill = await db.$transaction(async (tx) => {
        const r = await tx.room.findUnique({ where: { number: room } });
        if (!r) throw new Error("Room not found");
        if (r.status !== "occ" || !r.checkInAt || !r.guestName)
          throw new Error(`Room ${room} has no guest to check out`);
        if (checkOutAt.getTime() <= r.checkInAt.getTime())
          throw new Error("Exit time is before entry — it must be after the guest's entry time");

        const tier = tierOfRoom(room, levels);
        const hours = (checkOutAt.getTime() - r.checkInAt.getTime()) / 3600000;
        const s = lgStay(tier.rate, hours);
        const disc = Math.min(Math.max(0, Math.round(Number(body.discount) || 0)), s.stay);
        const taxable = s.stay - disc;
        const tax = Math.round(taxable * 5) / 100; // paise-exact, as printed
        const total = Math.round((taxable + tax) * 100) / 100;

        // Successive numbering (L-5001…): reuse the first free number when a
        // bill-undo tore a hole, so stay-bill numbers never skip.
        const maxAgg = await tx.lodgeBill.aggregate({ _max: { number: true } });
        const cnt = await tx.lodgeBill.count();
        const maxNum = maxAgg._max.number ?? 5000;
        let number: number;
        if (cnt === maxNum - 5000) {
          number = maxNum + 1; // dense series — keep counting up
        } else {
          const nums = await tx.lodgeBill.findMany({ select: { number: true }, orderBy: { number: "asc" } });
          number = 5001;
          for (const n of nums) {
            if (n.number === number) number += 1;
            else break;
          }
        }

        await tx.room.update({
          where: { number: room },
          data: { status: "mnt", guestName: null, guestPhone: null, checkInAt: null },
        });
        return tx.lodgeBill.create({
          data: {
            number,
            room,
            guestName: r.guestName,
            guestPhone: r.guestPhone ?? "",
            tier: tier.name,
            rate: tier.rate,
            checkInAt: r.checkInAt,
            checkOutAt,
            hours: Math.round(hours * 100) / 100,
            stay: s.stay,
            minApplied: s.min,
            discount: disc,
            tax,
            total,
          },
        });
      });
      return NextResponse.json({ ok: true, bill });
    }

    /* ── MAINTENANCE DONE — amber → green (the housekeeping loop) ────────── */
    if (action === "maintenance-done") {
      const room = Number(body.room);
      if (!Number.isInteger(room) || room < 1 || room > LG_ROOMS)
        return NextResponse.json({ error: "Invalid room" }, { status: 400 });
      const room0 = await db.room.findUnique({ where: { number: room } });
      if (!room0) return NextResponse.json({ error: "Room not found" }, { status: 404 });
      if (room0.status === "mnt")
        await db.room.update({
          where: { number: room },
          data: { status: "avl", guestName: null, guestPhone: null, checkInAt: null },
        });
      return NextResponse.json({ ok: true, status: "avl" });
    }

    /* ── LEVELS APPLY — save the graded-rate config (Management editor) ──── */
    if (action === "levels-apply") {
      const parsed = parseLevels(JSON.stringify(body.levels ?? null));
      if (!parsed)
        return NextResponse.json(
          { error: "Levels must cover rooms 1 – 100 with no gaps or overlaps, rates ≥ ₹100" },
          { status: 400 },
        );
      await db.setting.upsert({
        where: { key: "lodgeLevels" },
        create: { key: "lodgeLevels", value: JSON.stringify(parsed) },
        update: { value: JSON.stringify(parsed) },
      });
      return NextResponse.json({ ok: true, levels: parsed });
    }

    /* ── STAY BILL UNDO — tear a wrong checkout bill ─────────────────────── */
    // Deletes the LodgeBill and, when the room still sits in the exact state
    // that checkout left it in (amber, waiting for housekeeping), puts the
    // guest straight back in — status gold, same name, same entry time.
    if (action === "bill-undo") {
      const num = Number(body.number);
      if (!Number.isInteger(num))
        return NextResponse.json({ error: "Invalid stay bill number" }, { status: 400 });
      const err = await db.$transaction(async (tx) => {
        const b = await tx.lodgeBill.findUnique({ where: { number: num } });
        if (!b) return `Stay bill L-${num} not found`;
        const r = await tx.room.findUnique({ where: { number: b.room } });
        if (r && r.status === "mnt") {
          await tx.room.update({
            where: { number: b.room },
            data: {
              status: "occ",
              guestName: b.guestName,
              guestPhone: b.guestPhone,
              checkInAt: b.checkInAt,
            },
          });
        }
        // avl (housekeeping already done) or occ (room re-used): only remove the bill
        await tx.lodgeBill.delete({ where: { number: num } });
        return null;
      });
      if (err) return NextResponse.json({ error: err }, { status: 404 });
      invalidateDashboardCache();
      return NextResponse.json({ ok: true });
    }

    /* ── RESET WALL — demo lever: everything back to green ───────────────── */
    if (action === "reset") {
      await db.room.updateMany({ data: { status: "avl", guestName: null, guestPhone: null, checkInAt: null } });
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Lodge operation failed";
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}
