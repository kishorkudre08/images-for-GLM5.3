import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { invalidateDashboardCache } from "@/lib/analytics";

export const dynamic = "force-dynamic";

const KINDS = ["raw_material", "maintenance"] as const;
type Kind = (typeof KINDS)[number];

// GET /api/expenses?limit=60&kind=raw_material|maintenance&book=rest|lodge — recent cost entries
export async function GET(req: NextRequest) {
  const limit = Math.min(Number(req.nextUrl.searchParams.get("limit") ?? 60) || 60, 200);
  const kind = req.nextUrl.searchParams.get("kind");
  const book = req.nextUrl.searchParams.get("book");
  const expenses = await db.expense.findMany({
    where: {
      ...(kind && KINDS.includes(kind as Kind) ? { kind } : {}),
      ...(book === "rest" || book === "lodge" ? { book } : {}),
    },
    orderBy: [{ spentOn: "desc" }, { createdAt: "desc" }],
    take: limit,
  });
  return NextResponse.json(expenses);
}

// PATCH /api/expenses — { id, label?, amount?, spentOn?, kind? } — fix a wrong entry
export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const id = String(body.id ?? "");
    if (!id) return NextResponse.json({ error: "id is required" }, { status: 400 });

    const data: Record<string, unknown> = {};
    if (body.label !== undefined) data.label = String(body.label).trim().slice(0, 120);
    if (body.amount !== undefined) {
      const amount = Math.round(Number(body.amount) * 100) / 100;
      if (!Number.isFinite(amount) || amount <= 0)
        return NextResponse.json({ error: "Amount must be above zero" }, { status: 400 });
      data.amount = amount;
    }
    if (body.spentOn !== undefined) {
      const d = new Date(String(body.spentOn));
      if (!Number.isFinite(d.getTime()))
        return NextResponse.json({ error: "Invalid date" }, { status: 400 });
      if (d.getTime() > Date.now() + 86_400_000)
        return NextResponse.json({ error: "Costs cannot be dated in the future" }, { status: 400 });
      data.spentOn = d;
    }
    if (body.kind !== undefined) {
      const kind = String(body.kind) as Kind;
      if (!KINDS.includes(kind))
        return NextResponse.json({ error: "Invalid kind" }, { status: 400 });
      data.kind = kind;
    }
    if (body.book === "rest" || body.book === "lodge") data.book = body.book;
    if (Object.keys(data).length === 0)
      return NextResponse.json({ error: "Nothing to update" }, { status: 400 });

    const expense = await db.expense.update({ where: { id }, data });
    invalidateDashboardCache();
    return NextResponse.json(expense);
  } catch {
    return NextResponse.json({ error: "Could not update expense" }, { status: 500 });
  }
}

// POST /api/expenses — { kind, label?, amount, spentOn? }
// The owner's manual data-entry moment for raw materials & maintenance.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const kind = String(body.kind ?? "") as Kind;
    if (!KINDS.includes(kind))
      return NextResponse.json(
        { error: "kind must be raw_material or maintenance" },
        { status: 400 },
      );

    const amount = Math.round(Number(body.amount) * 100) / 100;
    if (!Number.isFinite(amount) || amount <= 0)
      return NextResponse.json({ error: "Amount must be above zero" }, { status: 400 });

    const label = String(body.label ?? "").trim().slice(0, 120);
    const spentOnRaw = body.spentOn ? new Date(String(body.spentOn)) : new Date();
    const spentOn = Number.isFinite(spentOnRaw.getTime()) ? spentOnRaw : new Date();
    if (spentOn.getTime() > Date.now() + 86_400_000)
      return NextResponse.json({ error: "Costs cannot be dated in the future" }, { status: 400 });

    const book = body.book === "lodge" ? "lodge" : "rest"; // which cost book carries this entry
    const expense = await db.expense.create({ data: { kind, book, label, amount, spentOn } });
    invalidateDashboardCache();
    return NextResponse.json(expense, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Could not save expense" }, { status: 500 });
  }
}

// DELETE /api/expenses?id=… — hard delete a wrong entry
export async function DELETE(req: NextRequest) {
  const id = req.nextUrl.searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id is required" }, { status: 400 });
  try {
    await db.expense.delete({ where: { id } });
    invalidateDashboardCache();
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Could not delete expense" }, { status: 500 });
  }
}
