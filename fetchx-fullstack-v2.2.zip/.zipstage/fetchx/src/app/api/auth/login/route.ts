import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

/**
 * Demo sign-in — single owner account (mirrors the Fetch-X landing pattern:
 * hardcoded role credentials, no account creation, everything stays local).
 */
const DEMO_USER = {
  email: "spice1234@gmail.com",
  password: "spice1234",
  name: "Imperial",
  role: "owner",
};

export async function POST(req: Request) {
  let body: { email?: string; password?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Bad request." }, { status: 400 });
  }

  const email = (body.email ?? "").trim().toLowerCase();
  const password = body.password ?? "";

  if (!email || !password) {
    return NextResponse.json(
      { ok: false, error: "Email and password are required." },
      { status: 400 },
    );
  }

  if (email !== DEMO_USER.email || password !== DEMO_USER.password) {
    return NextResponse.json({ ok: false, error: "Wrong email or password." }, { status: 401 });
  }

  return NextResponse.json({
    ok: true,
    user: { name: DEMO_USER.name, role: DEMO_USER.role, email: DEMO_USER.email },
  });
}
