"use client";

import * as React from "react";
import {
  BarChart3,
  BedDouble,
  ClipboardList,
  LogOut,
  PanelLeftClose,
  PanelLeftOpen,
  Receipt,
  Wallet,
} from "lucide-react";
import { ThemeToggle } from "@/components/fx";
import { HotelProvider, useHotel } from "@/components/hotel-context";
import { ReceiptProvider } from "@/components/receipt-dialog";
import { AiPanel } from "@/components/ai-panel";
import { PosView } from "@/components/pos-view";
import { DashboardView } from "@/components/dashboard-view";
import { LodgeView } from "@/components/lodge-view";
import { ManagementView } from "@/components/management-view";
import { ExpensesView } from "@/components/expenses-view";
import { LandingView, type AuthUser } from "@/components/landing-view";
import type { Dish, RangeKey } from "@/lib/types";

type View = "dashboard" | "pos" | "expenses" | "lodge" | "management";

const AUTH_KEY = "fx-auth";
const LEGACY_AUTH_KEY = "jk-auth"; // pre-Imperial-Spices sessions
const SIDE_KEY = "fx-side-open"; // sidebar collapsed = "0"

const NAV: Array<{ id: View; label: string; short: string; tip: string; icon: React.ReactNode }> = [
  { id: "dashboard", label: "Live Dashboard", short: "DASHBOARD", tip: "Owner intelligence", icon: <BarChart3 className="h-[18px] w-[18px]" /> },
  { id: "pos", label: "POS Billing", short: "POS", tip: "Cashier terminal", icon: <Receipt className="h-[18px] w-[18px]" /> },
  { id: "expenses", label: "Expenses", short: "EXPENSES", tip: "Raw materials & maintenance — both books", icon: <Wallet className="h-[18px] w-[18px]" /> },
  { id: "lodge", label: "Lodge Front Desk", short: "LODGE", tip: "100 rooms · stays & maintenance", icon: <BedDouble className="h-[18px] w-[18px]" /> },
  { id: "management", label: "Management", short: "MANAGE", tip: "Team, menu & room rates", icon: <ClipboardList className="h-[18px] w-[18px]" /> },
];

export default function Page() {
  return (
    <HotelProvider>
      <AppShell />
    </HotelProvider>
  );
}

function AppShell() {
  const { upperName, initials } = useHotel();
  const [user, setUser] = React.useState<AuthUser | null | "checking">("checking");
  const [view, setView] = React.useState<View>("dashboard");
  const [aiRange, setAiRange] = React.useState<RangeKey>("today");
  const [dishes, setDishes] = React.useState<Dish[]>([]);
  const [menuLoading, setMenuLoading] = React.useState(true);
  const [navOpen, setNavOpen] = React.useState(true);

  /* Sidebar collapse — remembered between sessions */
  React.useEffect(() => {
    if (localStorage.getItem(SIDE_KEY) === "0") setNavOpen(false);
  }, []);
  const toggleNav = () =>
    setNavOpen((o) => {
      localStorage.setItem(SIDE_KEY, o ? "0" : "1");
      return !o;
    });

  /* ── Auth gate: restore the demo session before rendering anything ── */
  React.useEffect(() => {
    try {
      localStorage.removeItem(LEGACY_AUTH_KEY); // retire old tenant's sessions
      const raw = localStorage.getItem(AUTH_KEY);
      setUser(raw ? (JSON.parse(raw) as AuthUser) : null);
    } catch {
      setUser(null);
    }
  }, []);

  const loadMenu = React.useCallback(async () => {
    try {
      const res = await fetch("/api/menu");
      setDishes(await res.json());
    } catch {
      // keep previous dishes on failure
    } finally {
      setMenuLoading(false);
    }
  }, []);

  React.useEffect(() => {
    void loadMenu();
  }, [loadMenu]);

  const signOut = () => {
    try {
      localStorage.removeItem(AUTH_KEY);
    } catch {
      /* private mode */
    }
    setView("dashboard");
    setUser(null);
  };

  /* Splash while the session is being restored (avoids a flash of the login) */
  if (user === "checking") {
    return (
      <div className="grid h-screen place-items-center bg-[var(--fx-page)]">
        <div className="flex flex-col items-center gap-3">
          <span className="grid h-12 w-12 animate-pulse place-items-center rounded-2xl bg-[var(--fx-purple)] font-mono text-[14px] font-black text-white shadow-[3px_4px_0_0_var(--fx-hard)]">
            FX
          </span>
          <span className="fx-label">LOADING FETCH-X…</span>
        </div>
      </div>
    );
  }

  /* ── Pre-login landing page ── */
  if (!user) {
    return (
      <LandingView
        onSignedIn={(u) =>
          setUser({ name: u.name, role: u.role, email: u.email })
        }
      />
    );
  }

  const navButton = (n: (typeof NAV)[number]) => {
    const isActive = view === n.id;
    return (
      <button
        key={n.id}
        onClick={() => setView(n.id)}
        title={navOpen ? n.tip : `${n.label} — ${n.tip}`}
        aria-current={isActive ? "page" : undefined}
        className={`group flex w-full items-center gap-3 rounded-xl text-left transition ${
          navOpen ? "px-3.5 py-3" : "justify-center py-3"
        } ${
          isActive
            ? "bg-[var(--fx-purple-soft)] text-[var(--fx-purple)] shadow-[inset_0_0_0_1px_rgba(91,79,233,.25)]"
            : "text-[var(--fx-ink)] hover:bg-[var(--fx-lav)]"
        }`}
      >
        <span className={isActive ? "text-[var(--fx-purple)]" : "text-[var(--fx-muted)] group-hover:text-[var(--fx-ink)]"}>
          {n.icon}
        </span>
        {navOpen && <span className="text-[13px] font-bold">{n.label}</span>}
      </button>
    );
  };

  return (
    <ReceiptProvider>
      <div id="app-root" className="flex h-screen overflow-hidden bg-[var(--fx-page)]">
        {/* ── Sidebar (desktop, collapsible to an icon rail) ── */}
        <aside
          className={`hidden shrink-0 flex-col border-r border-[var(--fx-line)] bg-[var(--fx-surf)] p-4 transition-[width] duration-200 md:flex ${
            navOpen ? "w-[240px]" : "w-[68px] items-center"
          }`}
        >
          <div className={`flex items-center gap-2.5 pb-6 pt-2 ${navOpen ? "px-1.5" : "flex-col"}`}>
            <span
              className={`grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-[var(--fx-purple)] font-mono text-[13px] font-black text-white shadow-[2px_3px_0_0_var(--fx-hard)] ${
                navOpen ? "" : "mb-1"
              }`}
            >
              {initials}
            </span>
            {navOpen && (
              <div className="min-w-0 flex-1">
                <div className="truncate text-[14px] font-black tracking-tight text-[var(--fx-ink)]">
                  {upperName}
                </div>
                <div className="fx-label">POWERED BY FETCH-X</div>
              </div>
            )}
            <button
              onClick={toggleNav}
              title={navOpen ? "Collapse side panel" : "Expand side panel"}
              aria-label={navOpen ? "Collapse side panel" : "Expand side panel"}
              aria-expanded={navOpen}
              className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg text-[var(--fx-muted)] transition hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)] ${
                navOpen ? "" : "h-9 w-9"
              }`}
            >
              {navOpen ? <PanelLeftClose className="h-4 w-4" /> : <PanelLeftOpen className="h-4 w-4" />}
            </button>
          </div>

          {navOpen && <div className="fx-label px-2 pb-2">CASHIER &amp; OWNER</div>}
          <nav
            className={`space-y-1.5 ${navOpen ? "" : "flex w-full flex-col items-center"}`}
            aria-label="Main"
          >
            {NAV.map((n) => navButton(n))}
          </nav>

          <div className={`mt-auto space-y-2 ${navOpen ? "" : "flex w-full flex-col items-center"}`}>
            {navOpen ? (
              <div className="rounded-2xl border border-dashed border-[var(--fx-line)] bg-[var(--fx-lav)] px-3.5 py-3">
                <div className="fx-label">LOGGED IN</div>
                <div className="mt-0.5 text-[12.5px] font-extrabold text-[var(--fx-ink)]">
                  {user.name.toUpperCase()} · {user.role.toUpperCase()}
                </div>
                <div className="mt-1.5 flex items-center gap-1.5 text-[10px] font-bold tracking-wider text-[var(--fx-green)]">
                  <span className="fx-live-dot" aria-hidden /> SHIFT ACTIVE · PURE VEG
                </div>
              </div>
            ) : (
              <span className="fx-live-dot my-1" aria-hidden title={`${user.name.toUpperCase()} · ${user.role.toUpperCase()}`} />
            )}
            <div className={`flex items-center ${navOpen ? "justify-between" : "w-full flex-col gap-2"}`}>
              <button
                onClick={signOut}
                title="Sign out of the owner console"
                aria-label="Sign out"
                className={`flex items-center gap-2 rounded-xl py-2 text-[11px] font-extrabold tracking-wider text-[var(--fx-muted)] transition hover:text-[var(--fx-rose)] ${
                  navOpen ? "px-2" : "justify-center"
                }`}
              >
                <LogOut className="h-3.5 w-3.5" /> {navOpen && "SIGN OUT"}
              </button>
              <ThemeToggle />
            </div>
          </div>
        </aside>

        {/* ── Main + AI panel row (dashboard contracts when the panel opens) ── */}
        <div className="flex min-w-0 flex-1">
          <main className="min-w-0 flex-1 overflow-y-auto">
            <div className="mx-auto max-w-[1440px] px-4 pb-28 pt-5 md:px-7 md:pb-10">
              {view === "pos" && <PosView dishes={dishes} loading={menuLoading} />}
              {view === "expenses" && <ExpensesView />}
              {view === "lodge" && <LodgeView />}
              {view === "dashboard" && (
                <DashboardView onGoToPos={() => setView("pos")} onRangeChange={setAiRange} />
              )}
              {view === "management" && (
                <ManagementView dishes={dishes} loading={menuLoading} refresh={loadMenu} />
              )}
            </div>
          </main>

          {/* ── AI copilot (adjustable right panel — inline on desktop) ── */}
          <AiPanel range={aiRange} hideFab={view === "pos"} />
        </div>

        {/* ── Mobile bottom nav ── */}
        <nav
          className="fixed inset-x-0 bottom-0 z-30 flex items-stretch justify-around border-t border-[var(--fx-line)] bg-[var(--fx-surf)] px-2 pb-[env(safe-area-inset-bottom)] pt-1.5 md:hidden"
          aria-label="Main mobile"
        >
          {NAV.map((n) => {
            const isActive = view === n.id;
            return (
              <button
                key={n.id}
                onClick={() => setView(n.id)}
                aria-current={isActive ? "page" : undefined}
                className={`flex min-h-[52px] min-w-0 flex-1 flex-col items-center justify-center gap-0.5 rounded-xl px-1.5 text-[10px] font-extrabold tracking-wide ${
                  isActive ? "text-[var(--fx-purple)]" : "text-[var(--fx-muted)]"
                }`}
              >
                {n.icon}
                {n.short}
              </button>
            );
          })}
          <span className="flex min-h-[52px] min-w-[44px] shrink-0 items-center justify-center">
            <span className="scale-90">
              <ThemeToggle />
            </span>
          </span>
        </nav>
      </div>
    </ReceiptProvider>
  );
}
